#ifndef __MAINWINDOW_H_
#define __MAINWINDOW_H_

#include "resource.h"       // main symbols
#include <atlhost.h>
#import <AXCsound/AXCsound.tlb>
#include "AXMathLink.h"

class CMainWindow : 
public CAxDialogImpl<CMainWindow>
{
public:
	static AXCSOUNDLib::IAXCsound *csound;
	CMainWindow()
	{
	}
	
	~CMainWindow()
	{
		if(csound)
		{
			csound->Release();
		}
	}
	
	enum { IDD = IDD_MAINWINDOW };
	
	BEGIN_MSG_MAP(CMainWindow)
		MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
		MESSAGE_HANDLER(WM_CLOSE, OnClose)
		MESSAGE_HANDLER(WM_DESTROY, OnDestroy)
		COMMAND_ID_HANDLER(IDOK, OnOK)
		COMMAND_ID_HANDLER(IDCANCEL, OnCancel)
	END_MSG_MAP()
	// Handler prototypes:
	//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
	//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);
	
	LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		IUnknown *pIUnknown = 0;
		HRESULT hresult = GetDlgControl(IDC_AXCSOUND, __uuidof(AXCSOUNDLib::IAXCsound), (void **)&csound);
		if(FAILED(hresult))
		{
			MessageBox("Failed to create AXCsound object.\nTry running \"regsvr32 AXCsound.dll\".", "AXCsound", MB_ICONEXCLAMATION);
		}
		return 1;  // Let the system set the focus
	}
	
	LRESULT OnClose(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		bHandled = true;
		if(csound)
		{
			csound->Stop();
		}
		::PostQuitMessage(0);
		return 0;
	}

	LRESULT OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		bHandled = true;
		if(csound)
		{
			csound->Stop();
		}
		::PostQuitMessage(0);
		return 0;
	}

	LRESULT OnOK(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		bHandled = true;
		if(csound)
		{
			csound->Stop();
		}
		::PostQuitMessage(0);
		return 0;
	}

	LRESULT OnCancel(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		bHandled = true;
		if(csound)
		{
			csound->Stop();
		}
		::PostQuitMessage(0);
		return 0;
	}
};

#endif //__MAINWINDOW_H_
