#ifndef __COPYRIGHT_H_
#define __COPYRIGHT_H_

#include "resource.h"

EXTERN_C const CLSID CLSID_Copyright;

class ATL_NO_VTABLE CCopyright :
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CCopyright, &CLSID_Copyright>,
	public IPropertyPageImpl<CCopyright>,
	public CDialogImpl<CCopyright>
{
public:
	CCopyright() 
	{
		m_dwTitleID = IDS_TITLECopyright;
		m_dwHelpFileID = IDS_HELP_CSOUND;
		m_dwDocStringID = IDS_DOCSTRINGCopyright;
	}
	enum {IDD = IDD_COPYRIGHT};
DECLARE_REGISTRY_RESOURCEID(IDR_COPYRIGHT)
BEGIN_COM_MAP(CCopyright) 
	COM_INTERFACE_ENTRY_IMPL(IPropertyPage)
END_COM_MAP()
BEGIN_MSG_MAP(CCopyright)
	MESSAGE_HANDLER(WM_PAINT, OnPaint)
	CHAIN_MSG_MAP(IPropertyPageImpl<CCopyright>)
END_MSG_MAP()
	STDMETHOD(Apply)(void)
	{
		ATLTRACE(_T("CCopyright::Apply\n"));
		for (UINT i = 0; i < m_nObjects; i++)
		{
			// Do something interesting here
			// ICircCtl* pCirc;
			// m_ppUnk[i]->QueryInterface(IID_ICircCtl, (void**)&pCirc);
			// pCirc->put_Caption(CComBSTR("something special"));
			// pCirc->Release();
		}
		m_bDirty = FALSE;
		return S_OK;
	}
	STDMETHOD(Help)(LPCOLESTR pszHelpDir);
	LRESULT OnPaint(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
};

#endif //__COPYRIGHT_H_
