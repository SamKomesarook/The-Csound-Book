#include "stdafx.h"
#include "MainWindow.h"
#include "AXMathLink.h"

AXCSOUNDLib::IAXCsound *CMainWindow::csound = 0;

extern "C" 
{
	extern MLDisownStringType *pMLDisownString = 0;
	extern MLPutIntegerType *pMLPutInteger = 0;
	extern MLPutFunctionType *pMLPutFunction = 0;
	extern MLNewPacketType *pMLNewPacket = 0;
	extern MLGetStringType *pMLGetString = 0;
	extern MLDisownRealListType *pMLDisownRealList = 0;
	extern MLGetRealListType *pMLGetRealList = 0;
	extern MLGetIntegerType *pMLGetInteger = 0;
	extern MLFlushType *pMLFlush = 0;
	extern MLPutSymbolType *pMLPutSymbol = 0;
	extern MLConnectType *pMLConnect = 0;
	extern MLErrorType *pMLError = 0;
	extern MLPutStringType *pMLPutString = 0;
	extern MLEndPacketType *pMLEndPacket = 0;
	extern MLClearErrorType *pMLClearError = 0;
	extern MLCheckFunctionType *pMLCheckFunction = 0;
	extern MLNextPacketType *pMLNextPacket = 0;
	extern MLDeinitializeType *pMLDeinitialize = 0;
	extern MLCloseType *pMLClose = 0;
	extern MLSetMessageHandlerType *pMLSetMessageHandler = 0;
	extern MLSetYieldFunctionType *pMLSetYieldFunction = 0;
	extern MLNameType *pMLName = 0;
	extern MLAlertType *pMLAlert = 0;
	extern MLErrorStringType *pMLErrorString = 0;
	extern MLOpenArgvType *pMLOpenArgv = 0;
	extern MLOpenStringType *pMLOpenString = 0;
	extern MLCreateMessageHandlerType *pMLCreateMessageHandler = 0;
	extern MLCreateYieldFunctionType *pMLCreateYieldFunction = 0;
	extern MLInitializeType *pMLInitialize = 0;
	extern MLTransferExpressionType *pMLTransferExpression = 0;

	void loadMathLink()
	{
		HINSTANCE hInstance = LoadLibrary("ml32i1.dll");
		if(!hInstance)
		{
			::MessageBox(0, "Could not load MathLink library (ml32i1.dll).\nCheck your Mathematica 3.0 installation.", "AXCsound", MB_ICONEXCLAMATION);
			exit(1);
		}
		pMLDisownString = (MLDisownStringType *)GetProcAddress(hInstance, "MLDisownString");
		pMLPutInteger = (MLPutIntegerType *)GetProcAddress(hInstance, "MLPutInteger");
		pMLPutFunction = (MLPutFunctionType *)GetProcAddress(hInstance, "MLPutFunction");
		pMLNewPacket = (MLNewPacketType *)GetProcAddress(hInstance, "MLNewPacket");
		pMLGetString = (MLGetStringType *)GetProcAddress(hInstance, "MLGetString");
		pMLDisownRealList = (MLDisownRealListType *)GetProcAddress(hInstance, "MLDisownRealList");
		pMLGetRealList = (MLGetRealListType *)GetProcAddress(hInstance, "MLGetRealList");
		pMLGetInteger = (MLGetIntegerType *)GetProcAddress(hInstance, "MLGetInteger");
		pMLFlush = (MLFlushType *)GetProcAddress(hInstance, "MLFlush");
		pMLPutSymbol = (MLPutSymbolType *)GetProcAddress(hInstance, "MLPutSymbol");
		pMLConnect = (MLConnectType *)GetProcAddress(hInstance, "MLConnect");
		pMLError = (MLErrorType *)GetProcAddress(hInstance, "MLError");
		pMLPutString = (MLPutStringType *)GetProcAddress(hInstance, "MLPutString");
		pMLEndPacket = (MLEndPacketType *)GetProcAddress(hInstance, "MLEndPacket");
		pMLClearError = (MLClearErrorType *)GetProcAddress(hInstance, "MLClearError");
		pMLCheckFunction = (MLCheckFunctionType *)GetProcAddress(hInstance, "MLCheckFunction");
		pMLNextPacket = (MLNextPacketType *)GetProcAddress(hInstance, "MLNextPacket");
		pMLDeinitialize = (MLDeinitializeType *)GetProcAddress(hInstance, "MLDeinitialize");
		pMLClose = (MLCloseType *)GetProcAddress(hInstance, "MLClose");
		pMLSetMessageHandler = (MLSetMessageHandlerType *)GetProcAddress(hInstance, "MLSetMessageHandler");
		pMLSetYieldFunction = (MLSetYieldFunctionType *)GetProcAddress(hInstance, "MLSetYieldFunction");
		pMLName = (MLNameType *)GetProcAddress(hInstance, "MLName");
		pMLAlert = (MLAlertType *)GetProcAddress(hInstance, "MLAlert");
		pMLErrorString = (MLErrorStringType *)GetProcAddress(hInstance, "MLErrorString");
		pMLOpenArgv = (MLOpenArgvType *)GetProcAddress(hInstance, "MLOpenArgv");
		pMLOpenString = (MLOpenStringType *)GetProcAddress(hInstance, "MLOpenString");
		pMLCreateMessageHandler = (MLCreateMessageHandlerType *)GetProcAddress(hInstance, "MLCreateMessageHandler");
		pMLCreateYieldFunction = (MLCreateYieldFunctionType *)GetProcAddress(hInstance, "MLCreateYieldFunction");
		pMLInitialize = (MLInitializeType *)GetProcAddress(hInstance, "MLInitialize");
		pMLTransferExpression = (MLTransferExpressionType *)GetProcAddress(hInstance, "MLTransferExpression");
	}
}

extern "C" int openOrchestra P((const char *filename))
{
	CMainWindow::csound->Open(filename);
	return true;
}

extern "C" int addNotes P((int fieldCount, int noteCount, double *fields, long totalCount))
{
	if(fieldCount < 1 || noteCount < 1)
	{
		return false;
	}
	int noteIndex;
	switch(fieldCount)
	{
	case 3:
		for(noteIndex = 0; noteIndex < noteCount; noteIndex++, fields += fieldCount)
		{
			CMainWindow::csound->AddNote3(fields[0], fields[1], fields[2]);
		}
		break;
	case 4:
		for(noteIndex = 0; noteIndex < noteCount; noteIndex++, fields += fieldCount)
		{
			CMainWindow::csound->AddNote4(fields[0], fields[1], fields[2], fields[3]);
		}
		break;
	case 5:
		for(noteIndex = 0; noteIndex < noteCount; noteIndex++, fields += fieldCount)
		{
			CMainWindow::csound->AddNote5(fields[0], fields[1], fields[2], fields[3], fields[4]);
		}
		break;
	case 6:
		for(noteIndex = 0; noteIndex < noteCount; noteIndex++, fields += fieldCount)
		{
			CMainWindow::csound->AddNote6(fields[0], fields[1], fields[2], fields[3], fields[4], fields[5]);
		}
		break;
	case 7:
		for(noteIndex = 0; noteIndex < noteCount; noteIndex++, fields += fieldCount)
		{
			CMainWindow::csound->AddNote7(fields[0], fields[1], fields[2], fields[3], fields[4], fields[5], fields[6]);
		}
		break;
	case 8:
		for(noteIndex = 0; noteIndex < noteCount; noteIndex++, fields += fieldCount)
		{
			CMainWindow::csound->AddNote8(fields[0], fields[1], fields[2], fields[3], fields[4], fields[5], fields[6], fields[7]);
		}
		break;
	case 9:
		for(noteIndex = 0; noteIndex < noteCount; noteIndex++, fields += fieldCount)
		{
			CMainWindow::csound->AddNote9(fields[0], fields[1], fields[2], fields[3], fields[4], fields[5], fields[6], fields[7], fields[8]);
		}
		break;
	case 10:
		for(noteIndex = 0; noteIndex < noteCount; noteIndex++, fields += fieldCount)
		{
			CMainWindow::csound->AddNote10(fields[0], fields[1], fields[2], fields[3], fields[4], fields[5], fields[6], fields[7], fields[8], fields[9]);
		}
		break;
	}
	return true;
}

extern "C" int clearNotes P(())
{
	CMainWindow::csound->RemoveScoreExceptFunctions();
	return true;
}

