#include "cs.h"                 /*                               MAIN.C */
#include "soundio.h"
#include <ctype.h>              /* For isdigit */

#ifdef SYMANTEC
#define main mw_main
#endif

#ifdef __ZPC__
unsigned int _stack = 0xFFF0U;
#endif

static  int     ScotScore = 0, stdinassgn = 0;
/*static*/  char        *scorename = NULL;
static  char    *xfilename = NULL;
static  char    *sortedscore = "score.srt";
static  char    *xtractedscore = "score.xtr";
static  char    *playscore = "score.srt";     /* unless we extract */
static  FILE    *scorin, *scorout, *xfile;
        FILE    *dribble;
static  void    dieu(char *), usage(void);
extern  OPARMS  O;
char    *orchname = NULL;  /* used by rdorch */
#ifdef LINUX
int midi_out;
extern void openMIDIout(void);
#endif

#define FIND(MSG)   if (*s == '\0')  \
                        if (!(--argc) || ((s = *++argv) != NULL) && *s == '-') \
                            dieu(MSG);

int flprintf =0, flprintfbis=0;  	/* gab-A1 */

#ifdef GAB_RT	/* gab-A1 */
#include <time.h> 
extern int rt_output_flag; 
extern int o_flag;
void gab_putchar(char); 
void setindev_num(int);
void set_rows(int);
void set_columns( int);
void setoutdev_num(int);
void setno_check(void);
void setflag_graphic(void);
void exit_soon(void);
void set_realtime_sleep(void);
void set_DirectSound_flag(void); /* gab-A2 */
void set_rtplay_Dsound(void);  /* gab-A2 */
void set_secondary_flag();	/* gab-A2 */
void SetDsoundDevNum(int);	   /* gab-A2 */
void set_sleep_flag(void); /*gab-A6*/
int argc_err; 				/*gab-A6*/
char **argv_err;			/*gab-A6*/
int platform(char, char**,int argc, char **argv);
char *clbuf;
int remap_argv(char *fname);
void dieu_gab(char *s, char *title);
char *argv_gab[40]; /* allows 40 arguments (!) */
#endif 	/* gab-A1 */



#ifdef CWIN
void dialog_arguments(void);
#include <stdarg.h>
extern int cwin_atexit(void (*)(void));

int cwin_main(int argc, char **argv)
#else
#ifdef CSOUND_REENTRANT_API
int lib_main(int argc, char **argv)
#else
int main(int argc, char **argv)
#endif	//	CSOUND_REENTRANT_API
#endif
{
        char c, *s;
        char  outformch, *filnamp, *envoutyp = NULL;
        int   n;
extern  int   getsizformat(int), musmon(void);
extern  char  *getstrformat(int);

#ifdef	WIN32  /* gab-A1 */
	/*	Michael Gogins 1997-02-24 added: */
	extern OENTRY *opcodlst;
	extern void csOpcodeLoadAll();
	/*	End Gogins. */
#ifdef GAB_RT /*gab-A1*/
	unsigned int timer_init(void); 
	#ifndef CWIN
	void console_rows();
	void console_title();
	#endif /*CWIN*/
	void setport_num(int num);
	void setbuf_num(int	num);
	void midi_out_enable(int midi_out);
	int num;
	clock_t t1, t0;	  
	double elapsed;
	int ug_flag=-1;
	t0 = clock();
	console_title();
	console_rows();
	/* Michael Gogins 1997-02-24 added:  */
	csOpcodeLoadAll();
	/*	End Gogins. */
	argc_err = argc; argv_err = argv;
#endif	/* GAB_RT (gab-A1) */
#endif /*WIN32*/

        err_printf( "Csound Version %d.%d (%s)\n", VERSION, SUBVER, __DATE__);
#ifdef __ZPC__
#ifdef WITHx87
        extern int _8087;
        if (_8087 == 0)
            die("This Csound needs an 80x87");
#endif
#endif
#ifndef SYMANTEC
        {
            char *getenv(const char*);
            if ((envoutyp = getenv("SFOUTYP")) != NULL) {
                if (strcmp(envoutyp,"AIFF") == 0)
                    O.filetyp = TYP_AIFF;
                else if (strcmp(envoutyp,"WAV") == 0)
                    O.filetyp = TYP_WAV;
                else {
                    sprintf(errmsg,"%s not a recognized SFOUTYP env setting",
                            envoutyp);
                    dieu(errmsg);
                }
            }
        }
#endif
        POLL_EVENTS();

#ifdef CWIN
        cwin_atexit(all_free);
#endif
        O.filnamspace = filnamp = mmalloc((long)1024);
        dribble = NULL;
        if (--argc == 0) {
#ifdef CWIN
            dialog_arguments();
#else
            dieu("insufficient arguments");
#endif
        }
#ifdef CWIN
        else
#endif
        do {
            POLL_EVENTS();
            s = *++argv;
prossimo:  /* gab-A1 */
            if (*s++ == '-') {                        /* read all flags:  */
                while ((c = *s++) != '\0') {
                    switch(c) {
                    case 'U': FIND("no utility name")
                              if (strcmp(s,"hetro") == 0) {
                                  printf("util HETRO:\n");
                                  hetro(argc,argv);
                              }
                              if (strcmp(s,"lpanal") == 0) {
                                  printf("util LPANAL:\n");
                                  lpanal(argc,argv);
                              }
                              if (strcmp(s,"pvanal") == 0) {
                                  printf("util PVANAL:\n");
                                  pvanal(argc,argv);
                              }
                              if (strcmp(s,"sndinfo") == 0) {
                                  printf("util SNDINFO:\n");
                                  sndinfo(argc,argv);
                              }
                              if (strcmp(s,"cvanal") == 0) {
                                  printf("util CVANAL:\n");
                                  cvanal(argc,argv);
                                  exit(0);
                              }
                              dies("-U %s not a valid UTIL name",s);
                    case 'C': O.usingcscore = 1;     /* use cscore processing  */
                              break;
                    case 'I': O.initonly = 1;           /* I-only implies */
                    case 'n': O.sfwrite = 0;            /* nosound        */
                              break;
                    case 'i': 
#ifndef GAB_RT  /* gab-A1 */
                              FIND("no infilename")
#else           /* GAB_RT */
                        if (*s != '\0'&& *s >='0' && *s <= '9') {  /* (gab-A1)  Wave IN device Number */
                            sscanf(s,"%d%n",&num, &n); 
                            setindev_num(num);
                            s +=n;
                            O.infilename = "adc\0";							
                        } 
                        else if (*s == '\0') O.infilename = "adc\0";  /* gab-A1 */
                        else {
#endif          /* GAB_RT */                     
                              O.infilename = filnamp;   /* soundin name */
                              while ((*filnamp++ = *s++));  s--;
                              POLL_EVENTS();
                              if (strcmp(O.infilename,"stdout") == 0)
                                  dieu("-i cannot be stdout");
                              if (strcmp(O.infilename,"stdin") == 0)
#ifdef SYMANTEC
                                  dieu("stdin audio not supported");
#else
                              {
                                  if (stdinassgn)
                                      dieu("-i: stdin previously assigned");
                                  stdinassgn = 1;
                              }
#endif
#ifdef GAB_RT   /* gab-A1 */
                        } 
#endif         /* GAB_RT */
                        O.sfread = 1;
                        break;
                    case 'o': FIND("no outfilename")
#ifdef GAB_RT   /* gab-A1 */
                               o_flag=1;
#endif/*GAB_RT*/
                              O.outfilename = filnamp;          /* soundout name */
                              while ((*filnamp++ = *s++)); s--;
                              if (strcmp(O.outfilename,"stdin") == 0)
                                  dieu("-o cannot be stdin");
                              if (strcmp(O.outfilename,"stdout") == 0) 
#if defined SYMANTEC || defined BCC || defined __WATCOMC__ || defined __unix || defined WIN32
                                  dieu("stdout audio not supported");
#else
                                  if ((O.stdoutfd = dup(1)) < 0) /* redefine stdout */
                                      die("too many open files");
                                  dup2(2,1);                /* & send 1's to stderr */
#endif
                              break;
                    case 'b': FIND("no iobufsamps")
                              sscanf(s,"%d%n",&O.outbufsamps, &n);
                    /* defaults in musmon.c */
                              O.inbufsamps = O.outbufsamps;
                              s += n;
                              break;
                    case 'B': FIND("no hardware bufsamps")
                              sscanf(s,"%ld%n",&O.oMaxLag, &n);
                    /* defaults in rtaudio.c */
                              s += n;
                              break;
                    case 'A': if (O.filetyp == TYP_WAV) {
                                  if (envoutyp == NULL) goto outtyp;
                                  warning("-A overriding local default WAV out");
                              }
                              O.filetyp = TYP_AIFF;     /* AIFF output request*/
                              break;
                    case 'W': if (O.filetyp == TYP_AIFF) {
                                if (envoutyp == NULL) goto outtyp;
                                warning("-W overriding local default AIFF out");
                              }
                              POLL_EVENTS();
                              O.filetyp = TYP_WAV;      /* WAV output request */
                              break;
                    case 'h': O.sfheader = 0;           /* skip sfheader  */
                              break;
                    case 'c': if (O.outformat) goto outform;
                              outformch = c;
                              O.outformat = AE_CHAR;    /* signed 8-bit char soundfile */
                              break;
                    case 'a': if (O.outformat) goto outform;
                              outformch = c;
                              O.outformat = AE_ALAW;    /* a-law soundfile */
                              break;
                    case 'u': if (O.outformat) goto outform;
                              outformch = c;
                              O.outformat = AE_ULAW;    /* mu-law soundfile */
                              break;
                    case '8': if (O.outformat) goto outform;
                              outformch = c;
                              O.outformat = AE_UNCH;    /* unsigned 8-bit soundfile */
                              break;
                    case 's': if (O.outformat) goto outform;
                              outformch = c;
                              O.outformat = AE_SHORT;   /* short_int soundfile*/
                              break;
                    case 'l': if (O.outformat) goto outform;
                              outformch = c;
                              O.outformat = AE_LONG;    /* long_int soundfile */
                              break;
                    case 'f': if (O.outformat) goto outform;
                              outformch = c;
                              O.outformat = AE_FLOAT;   /* float soundfile */
                              break;
                    case 'r': FIND("no sample rate")
                              sscanf(s,"%ld",&O.sr_override);
                              while (*++s);
                              break;
                    case 'k': FIND("no control rate")
                              sscanf(s,"%ld",&O.kr_override);
                              while (*++s);
                              break;
                    case 'v': O.odebug = odebug = 1;    /* verbose otran  */
                              break;
                    case 'm': FIND("no message level")
                              sscanf(s,"%d%n",&O.msglevel, &n);
                              s += n;
                              break;
                    case 'd': O.displays = 0;           /* no func displays */
                              break;
                    case 'g': O.graphsoff = 1;          /* don't use graphics */
                              break;
                    case 'G': O.postscript = 1;         /* Postscript graphics*/
                              break;
                    case 'S': ScotScore++;
                              break;
                    case 'x': FIND("no xfilename")
                              xfilename = s;            /* extractfile name */
                              while (*++s);
                              break;
                    case 't': FIND("no tempo value")
                              sscanf(s,"%d%n",&O.cmdTempo, &n);/* use this tempo .. */
                              s += n;
                              if (O.cmdTempo <= 0) dieu("illegal tempo");
                              O.Beatmode = 1;       /* on uninterpreted Beats */
                              break;
                    case 'L': FIND("no Linein score device_name")
                              O.Linename = filnamp;     /* Linein device name */
                              while ((*filnamp++ = *s++));  s--;
                              if (!strcmp(O.Linename,"stdin")) {
                                  if (stdinassgn)
                                      dieu("-L: stdin previously assigned");
                                  stdinassgn = 1;
                              }
                              O.Linein = 1;
                              break;
                    case 'M': FIND("no midi device_name")
                              O.Midiname = filnamp;     /* Midi device name */
                              while ((*filnamp++ = *s++));  s--;
                              if (!strcmp(O.Midiname,"stdin")) {
                                  if (stdinassgn)
                                      dieu("-M: stdin previously assigned");
                                  stdinassgn = 1;
                                }
                              O.Midiin = 1;
                              break;
                    case 'F': FIND("no midifile name")
                              O.FMidiname = filnamp;    /* Midifile name */
                              while ((*filnamp++ = *s++));  s--;
                              if (!strcmp(O.FMidiname,"stdin")) {
                                  if (stdinassgn)
                                      dieu("-F: stdin previously assigned");
                                  stdinassgn = 1;
                                }
                              O.FMidiin = 1;          /***************/
                              break;
                    case 'P': FIND("no pedal threshold")
                              sscanf(s,"%d%n",&O.SusPThresh, &n);
                              s += n;
                              break;
#ifdef LINUX
                    case 'Q': FIND("no MIDI output device")
                              midi_out = -1;
                              if (isdigit(*s)) {
                                sscanf(s,"%d%n",&midi_out,&n);
                                s += n;
                                openMIDIout();
                              }
                              break;
#endif
                    case 'R': O.rewrt_hdr = 1;
                              break;
                    case 'H': if (isdigit(*s)) {
				sscanf(s, "%d%n", &O.heartbeat, &n);
				s += n;
			      }
		              else O.heartbeat = 1;
		              break;
                    case 'N': O.ringbell = 1;        /* notify on completion */
                              break;
                    case 'T': O.termifend = 1;       /* terminate on midifile end */
                              break;
                    case 'D': O.gen01defer = 1;  /* defer GEN01 sample loads 
                                                    until performance time */
                              break;
#ifdef LINUX
#ifdef RTAUDIO
                    /* Add option to set soundcard output volume for real-
                       time audio output under Linux. -- J. Mohr 95 Oct 17 */
                    case 'V': FIND("no volume level")
                              sscanf(s,"%d%n",&O.Volume, &n);
                              s += n;
                              break;
#endif
#endif
                    case 'z': {
                                int full = 0;
                                if (*s != '\0') {
                                  if (isdigit(*s)) full = *s++ - '0';
                                }
                                list_opcodes(full);
                              }
                              return (0);
                    case '-': FIND("no log file");
                              dribble = fopen(s, "w");
                              while (*s++); s--;
                              break;
#ifdef	GAB_RT		 /* gab-A1 */
					case '+': {	 /* platform dependent flags */
						char flag = *s++;
						int gflag;
						gflag = platform(flag, &s, argc, argv);
						if (gflag) goto  prossimo;
						}
						break;
#endif /* GAB_RT */
                    default:  sprintf(errmsg,"unknown flag -%c", c);
                              dieu(errmsg);
                    }
                    POLL_EVENTS();
                }
            }
            else {
                if (orchname == NULL)
                    orchname = --s;
                else if (scorename == NULL)
                    scorename = --s;
                else dieu("too many arguments");
            }
            POLL_EVENTS();
        } while (--argc);

#ifdef GAB_RT /* gab-A1 */
#ifndef CWIN
        console_rows(); 
#endif /* CWIN */
	if 	(ug_flag >=0) {
		list_opcodes(ug_flag);
		printf("\n-----------------------------\n\n");
		dieu("\n-----------------------------\n");
	}
#endif		/* GAB_RT */
        POLL_EVENTS();
        if (O.Linein || O.Midiin || O.FMidiin)
            O.RTevents = 1;
        if (O.RTevents || O.sfread)
            O.ksensing = 1;
        if (!O.outformat)                       /* if no audioformat yet  */
            O.outformat = AE_SHORT;             /*  default to short_ints */
        O.outsampsiz = getsizformat(O.outformat);
        O.informat = O.outformat; /* informat defaults; resettable by readinheader */
        O.insampsiz = O.outsampsiz;
        if (O.filetyp == TYP_AIFF || O.filetyp == TYP_WAV) {
            if (!O.sfheader)
                dieu("can't write AIFF/WAV soundfile with no header");
            /* WAVE format supports only unsigned bytes for 1- to 8-bit
               samples and signed short integers for 9 to 16-bit samples.
                                   -- Jonathan Mohr  1995 Oct 17  */
            /* Also seems that type 3 is floats */
            if (O.filetyp == TYP_WAV &&
                O.outformat != AE_UNCH && O.outformat != AE_SHORT &&
                O.outformat != AE_FLOAT ) {
              sprintf(errmsg,"WAV does not support %s encoding %s",
                      getstrformat(O.outformat), "-- try '-8' or '-s' options");
              dieu(errmsg);
            }
            else if (O.filetyp == TYP_AIFF &&
                     O.outformat != AE_CHAR && O.outformat != AE_SHORT) {
              sprintf(errmsg,"AIFF does not support %s encoding %s",
                      getstrformat(O.outformat), "-- try '-c' or '-s' options");
              dieu(errmsg);
            }
        }
        POLL_EVENTS();
        if (O.rewrt_hdr && !O.sfheader)
            dieu("can't rewrite header if no header requested");
        if (O.sr_override || O.kr_override) {
            long ksmpsover;
            if (!O.sr_override || !O.kr_override)
                dieu("srate and krate overrides must occur jointly");
            ksmpsover = O.sr_override / O.kr_override;
            if (ksmpsover * O.kr_override != O.sr_override)
                dieu("command-line srate / krate not integral");
        }
        if (orchname == NULL)
            dieu("no orchestra name");
        else err_printf("orchname:  %s\n", orchname);
        if (scorename != NULL)
            err_printf("scorename: %s\n", scorename);
        if (xfilename != NULL)
            err_printf("xfilename: %s\n", xfilename);
#if defined(SYS5) || defined(WIN32)
        {
          static  char  buf[80];
          VMSG(setvbuf(stdout,buf,_IOLBF,80);)
        }
#else
#if !defined(SYMANTEC) && !defined(LATTICE)
        VMSG(setlinebuf(stdout);)
#endif
#endif
        if (scorename == NULL) {
          if (O.RTevents) {
            err_printf("realtime performance using dummy numeric scorefile\n");
            POLL_EVENTS();
            goto perf;
          }
          else scorename = "score.srt";
        }
        if (ScotScore) {                          /* if score in Scot format  */
            if (!(scorin = fopen(scorename, "r")))
                dies("cannot open scorefile %s", scorename);
            if (!(scorout = fopen("score", "w")))
                die("cannot open scotout score for writing");
            err_printf("translating Scot score ...\n");
            scot(scorin, scorout, scorename);      /*    do Scot translation  */
            fclose(scorin);
            fclose(scorout);
            scorename = "score";                   /*    and use this "score" */
        }
        POLL_EVENTS();
        if ((n = strlen(scorename)) > 4            /* if score ?.srt or ?.xtr */
          && (!strcmp(scorename+n-4,".srt")
              || !strcmp(scorename+n-4,".xtr"))) {
            err_printf("using previous %s\n",scorename);
            playscore = sortedscore = scorename;            /*   use that one */
        }
        else {
            if (!(scorin = fopen(scorename, "r")))          /* else sort it   */
                dies("cannot open scorefile %s", scorename);
            if (!(scorout = fopen(sortedscore, "w")))
                dies("cannot open %s for writing", sortedscore);
            err_printf("sorting score ...\n");
            scsort(scorin, scorout);
            fclose(scorin);
            fclose(scorout);
        }
        POLL_EVENTS();
        if (xfilename != NULL) {                        /* optionally extract */
            if (!strcmp(scorename,"score.xtr"))
                dies("cannot extract %s, name conflict",scorename);
            if (!(xfile = fopen(xfilename, "r")))
                dies("cannot open extract file %s", xfilename);
            if (!(scorin = fopen(sortedscore, "r")))
                dies("cannot reopen %s", sortedscore);
            if (!(scorout = fopen(xtractedscore, "w")))
                dies("cannot open %s for writing", xtractedscore);
            err_printf("  ... extracting ...\n");
            scxtract(scorin, scorout, xfile);
            fclose(scorin);
            fclose(scorout);
            playscore = xtractedscore;
        }           
        err_printf("\t... done\n");
        POLL_EVENTS();

        s = playscore;
        O.playscore = filnamp;
        while ((*filnamp++ = *s++));    /* copy sorted score name */

perf:   O.filnamsize = filnamp - O.filnamspace;
        POLL_EVENTS();
        otran();                /* read orcfile, setup desblks & spaces     */
        POLL_EVENTS();
#ifdef GAB_RT
        if (flprintfbis) { /* gab-A1 */
    		printf("--->Warning!!! all console text messages are disabled!!!\n");
	    	flprintf=1;
	    }
	    n = musmon();
    	t1 = clock();
    	elapsed = (double) (t1-t0)/ (double) CLOCKS_PER_SEC;
    	printf("Total processing time: %.3lf seconds", elapsed);
    	getgab();
       	return n; 
#else /* GAB_RT */

	/* fine aggiunta Gabriele */   /* gab-A1 */
        return musmon();        /* load current orch and play current score */
#endif /* GAB_RT */

outtyp: dieu("output soundfile cannot be both AIFF and WAV");

outform: sprintf(errmsg,"sound output format cannot be both -%c and -%c",
                outformch, c);
        dieu(errmsg);
}

static void dieu(char *s)
{
#ifdef GAB_RT	  /* gab-A1 */
	char sgab[256] ;
	int j;
	set_rows(67);
#ifndef CWIN
    console_rows();
#endif /* CWIN */
  	usage();
	sprintf(sgab,"Csound Command ERROR: %s",s); 	/* gab-A1 */
	err_printf("\n");
	for (j=0; j< argc_err; j++) {

		err_printf("%s ",argv_err[j]);
	}
	err_printf("\n\nCsound Command ERROR:\t%s\n",s);
	dieu_gab(sgab,"Csound error!");  /* gab-A1 */
#ifndef CWIN
#ifndef CSOUND_REENTRANT_API
	exit(1);
#else
	_endthreadex(1);
#endif	//	CSOUND_REENTRANT_API
#endif /* CWIN */
#else /* GAB_RT */  
    err_printf("Csound Command ERROR:\t%s\n",s);
    usage();
    POLL_EVENTS();
#endif /* GAB_RT */
}

static void usage(void)
{
#ifdef M_I286
err_printf( "See usage.txt\n");
#else
err_printf("Usage:\tcsound [-flags] orchfile scorefile\n");
err_printf( "Legal flags are:\n");
err_printf("-U unam\trun utility program unam\n");
err_printf("-C\tuse Cscore processing of scorefile\n");
err_printf("-I\tI-time only orch run\n");
err_printf("-n\tno sound onto disk\n");
err_printf("-i fnam\tsound input filename\n");
err_printf("-o fnam\tsound output filename\n");
err_printf("-b N\tsample frames (or -kprds) per software sound I/O buffer\n");
err_printf("-B N\tsamples per hardware sound I/O buffer\n");
err_printf("-A\tcreate an AIFF format output soundfile\n");
err_printf("-W\tcreate a WAV format output soundfile\n");
err_printf("-h\tno header on output soundfile\n");
err_printf("-c\t8-bit signed_char sound samples\n");
err_printf("-a\talaw sound samples\n");
err_printf("-8\t8-bit unsigned_char sound samples\n"); /* J. Mohr 1995 Oct 17 */
err_printf("-u\tulaw sound samples\n");
err_printf("-s\tshort_int sound samples\n");
err_printf("-l\tlong_int sound samples\n");
err_printf("-f\tfloat sound samples\n");
err_printf("-r N\torchestra srate override\n");
err_printf("-k N\torchestra krate override\n");
err_printf("-v\tverbose orch translation\n");
err_printf("-m N\ttty message level. Sum of: 1=note amps, 2=out-of-range msg, 4=warnings\n");
err_printf("-d\tsuppress all displays\n");
err_printf("-g\tsuppress graphics, use ascii displays\n");
err_printf("-G\tsuppress graphics, use Postscript displays\n");
err_printf("-S\tscore is in Scot format\n");
err_printf("-x fnam\textract from score.srt using extract file 'fnam'\n");
err_printf("-t N\tuse uninterpreted beats of the score, initially at tempo N\n");
err_printf("-L dnam\tread Line-oriented realtime score events from device 'dnam'\n");
err_printf("-M dnam\tread MIDI realtime events from device 'dnam'\n");
err_printf("-F fnam\tread MIDIfile event stream from file 'fnam'\n");
err_printf("-P N\tMIDI sustain pedal threshold (0 - 128)\n");
err_printf("-R\tcontinually rewrite header while writing soundfile (WAV/AIFF)\n");
err_printf("-H#\tprint a heartbeat style 1, 2 or 3 at each soundfile write\n");
err_printf("-N\tnotify (ring the bell) when score or miditrack is done\n");
err_printf("-T\tterminate the performance when miditrack is done\n");
err_printf("-D\tdefer GEN01 soundfile loads until performance time\n");
#ifdef LINUX                    /* Jonathan Mohr  1995 Oct 17 */
#ifdef RTAUDIO
err_printf("-V N\tset real-time audio output volume to N (1 to 100)\n");
#endif
#endif
err_printf("-z\tList opcodes in this version\n");
err_printf("-- fnam\tlog output to file\n");
#ifdef GAB_RT	   /* gab-A1 */
	err_printf("-+j num\tconsole number of text rows (default 25)\n");
	err_printf("-+J num\tconsole number of text columns (default 80)\n");
	err_printf("-+K num\tenable MIDI IN. 'num' (optional) = MIDI IN port device id number \n");
	err_printf("-+q num\tWAVE OUT device id number (use only if more WAVE devices are installed)\n");
	err_printf("-+p num\tnumber of WAVE OUT buffers (default 4; max. 40)\n");
	err_printf("-+O    \tsuppress all console text output for better realtime performance\n");
	err_printf("-+e    \tallow any sample rate (warn: not all sndcards support non-standard sr)\n");
	err_printf("-+y    \tdon't wait for keypress on exit\n");
	err_printf("-+E    \tallow graphic display for WCSHELL by Riccardo Bianchini\n");
	err_printf("-+Q num\tenable MIDI OUT. 'num' (optional) = MIDI OUT port device id number\n");
	err_printf("-+Y    \tsuppress realtime WAVE OUT for better MIDI OUT timing performance\n");
	err_printf("-+*    \tyield control to system for better multitasking\n");
	err_printf("-+/    \tenable script file command line\n");
    err_printf("-+X num\tenable DirectSound audio out (num is optional)\n");
#endif			/* GAB_RT */
err_printf("flag defaults: csound -s -otest -b%d -B%d -m7 -P128\n",
    IOBUFSAMPS, IODACSAMPS);
#endif
#ifndef GAB_RT	   /* gab-A1 */
#ifndef CSOUND_REENTRANT_API
	exit(1);
#else
	_endthreadex(1);
#endif
#endif
}

#ifdef CWIN
int args_OK = 0;
extern void  cwin_poll_window_manager(void);
extern void cwin_args(char **, char **, char **);

void dialog_arguments(void)
{
    cwin_args(&orchname, &scorename, &xfilename);
}
#endif

#ifndef CWIN
#include <stdarg.h>
#ifdef CSOUND_REENTRANT_API

void (*csLogCallback)(const char *message);

void dribble_printf(char *fmt, ...)
{
	char logMessage[0x500];
    va_list a;
    va_start(a, fmt);
	vsprintf(logMessage, fmt, a);
    va_end(a);
	(csLogCallback)(logMessage);
}

void err_printf(char *fmt, ...)
{
	char logMessage[0x500];
    va_list a;
    va_start(a, fmt);
	vsprintf(logMessage, fmt, a);
    va_end(a);
	(csLogCallback)(logMessage);
}

#else

void dribble_printf(char *fmt, ...)
{
    va_list a;
    va_start(a, fmt);
    vprintf(fmt, a);
    va_end(a);
    if (dribble != NULL) {
      va_start(a, fmt);
      vfprintf(dribble, fmt, a);
      va_end(a);
    }
}

void err_printf(char *fmt, ...)
{
    va_list a;
    va_start(a, fmt);
    vfprintf(stderr, fmt, a);
    va_end(a);
    if (dribble != NULL) {
      va_start(a, fmt); /* gab */
      vfprintf(dribble, fmt, a);
      va_end(a);
    }
}
#endif
#endif

#ifdef GAB_RT
void gab_putchar(char c)	/* gab-A1 */
{
	 if (!flprintf) putchar(c);
}

int remap_argv(char *fname) /* gab-A1 */
{
	FILE * fil;
	char * pt;
	int j=0;
	clbuf = (char *) malloc(2048);
	pt = clbuf;
	if ( !(fil=fopen(fname, "rt"))) die("bad command-line script file\n");
	printf("USING file '%s' as command line\n", fname);
	while (fscanf(fil, "%s", pt) != EOF){
		argv_gab[j++] = pt;
		pt+= strlen(pt)+1;
	}	
	fclose(fil);
	/*if (access(fname, 6))  chmod( fname, S_IREAD | S_IWRITE );  removes read-only flag*/
	return j;	
}

int platform (char flag, char **s, int argc, char **argv)
{
	#define FIND2(MSG)   if (**s == '\0')  \
			if (!(--argc) || ((*s = *++argv) != NULL) && **s == '-') \
			    dieu(MSG);

	int num,n,gflag=0;
	switch (flag)	{
					case 'j':  FIND2("no rows number")  /* GAB */
						sscanf(*s,"%d%n",&num, &n);
						set_rows(num);
						(*s) += n;
						break;
					case 'J':  FIND2("no columns number")  /* GAB */
						sscanf(*s,"%d%n",&num, &n);
						set_columns(num);
						(*s) += n;
						break;
					case 'K': if (**s != '\0' && **s >='0' && **s <= '9') { /* optional midi port number */
							sscanf(*s,"%d%n",&num, &n);  /* GAB midi port number */
							setport_num(num);
							(*s) +=n;
						}
						O.Midiname = "sbmidi";
						O.Midiin = 1; 
						break;
					case 'p': 	FIND2("no audio buffers number")  /* Audio buffers number */
						sscanf(*s,"%d%n",&num, &n); 
						setbuf_num(num);
						(*s) +=n;
						break;
					case 'q': 	if (**s != '\0'&& **s >='0' && **s <= '9') { /* Wave OUT device Number */
						sscanf(*s,"%d%n",&num, &n);
						setoutdev_num(num);
						(*s) +=n;
						}
						rt_output_flag=1;
						break;
					case 'X': 	if (**s != '\0'&& **s >='0' && **s <= '9') { /* gab-A2 DirectSound device Number */
						sscanf(*s,"%d%n",&num, &n);
						SetDsoundDevNum(num);
						(*s) +=n;
						}
						set_DirectSound_flag();
						rt_output_flag=1;
						break;
					case 'S': 	if (**s != '\0'&& **s >='0' && **s <= '9') { /* gab-A2 DirectSound device Number */
						sscanf(*s,"%d%n",&num, &n);
						SetDsoundDevNum(num);
						(*s) +=n;
						}
						set_DirectSound_flag();
						set_secondary_flag();
						rt_output_flag=1;
						break;
					case 'O': 	flprintfbis=1;	/* no text print */
						break;
					case 'e': 	setno_check();	 /* allows arbitrary output sample rate */
						break;
			/*		case 'E': 	setflag_graphic();	// allows graphic display for WCSHELL by Riccardo Bianchini	
						break; */
					case 'y': 	exit_soon(); /* doesn't wait for keypress on exit */
						break;
					case 'Q':{ 	int midi_out=-1;
						if (**s != '\0' && **s >='0' && **s <= '9') {  /* midi out */
							sscanf(*s,"%d%n",&midi_out, &n); 
							(*s) +=n;
						}
						midi_out_enable(midi_out);	}
						break;
					case 'Y': 	O.outformat = AE_NO_AUDIO; /* disables any realtime Wave OUT */
						printf("--->no audio output: only MIDI OUT ENABLED\n");						
						break;
					case '*':  set_sleep_flag();	 /* enables WIN95 YELDING */
						printf("---> WIN95 YIELDING ENABLED!!\n");
						break;
					case '/': FIND2("no command FILE");  /* scan command line into a file */
						argc = remap_argv(*s);
						argv =  argv_gab;
						(*s) = argv[0];
						gflag=1;
						/*goto prossimo; */
						break;
					default:
						die("'-+' flag must be followed by a valid platform specific flag letter!");
	}
	return gflag;
}

#endif /* GAB_RT */