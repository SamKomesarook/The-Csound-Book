#ifndef __COMMANDPAGE_H_
#define __COMMANDPAGE_H_
#include "resource.h"
#include <commctrl.h>

EXTERN_C const CLSID CLSID_CommandPage;

class ATL_NO_VTABLE CCommandPage :
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CCommandPage, &CLSID_CommandPage>,
	public IPropertyPageImpl<CCommandPage>,
	public CDialogImpl<CCommandPage>
{
public:
	enum {IDD = IDD_COMMANDPAGE};
	DECLARE_REGISTRY_RESOURCEID(IDR_COMMANDPAGE)
BEGIN_COM_MAP(CCommandPage) 
	COM_INTERFACE_ENTRY_IMPL(IPropertyPage)
END_COM_MAP()
BEGIN_MSG_MAP(CCommandPage)
	COMMAND_HANDLER(IDNEW, BN_CLICKED, OnNew)
	COMMAND_HANDLER(IDOPEN, BN_CLICKED, OnOpen)
	COMMAND_HANDLER(IDSAVE, BN_CLICKED, OnSave)
	COMMAND_HANDLER(IDSAVEAS, BN_CLICKED, OnSaveAs)
	COMMAND_HANDLER(IDIMPORT, BN_CLICKED, OnImport)
	NOTIFY_HANDLER(IDC_MAIN_SPIN_PLAY, UDN_DELTAPOS, OnPlayOrStop)
	COMMAND_HANDLER(IDPAUSE, BN_CLICKED, OnPause)
	COMMAND_HANDLER(IDRESUME, BN_CLICKED, OnResume)
	COMMAND_HANDLER(IDOPENSOUND, BN_CLICKED, OnOpenSound)
	COMMAND_HANDLER(IDC_EDIT_COMMAND, EN_UPDATE, OnChange)
	COMMAND_HANDLER(IDC_EDIT_COMMAND, EN_CHANGE, OnChange)
	CHAIN_MSG_MAP(IPropertyPageImpl<CCommandPage>)
END_MSG_MAP()
public:
	CCommandPage();
	STDMETHOD(Activate)(HWND hWndParent, LPCRECT pRect, BOOL bModal);
	STDMETHOD(Apply)(void);
	STDMETHOD(Help)(LPCOLESTR pszHelpDir);
	LRESULT OnNew(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
	LRESULT OnOpen(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
	LRESULT OnSave(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
	LRESULT OnSaveAs(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
	LRESULT OnImport(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
	LRESULT OnPlayOrStop(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);
	LRESULT OnPause(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
	LRESULT OnResume(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
	LRESULT OnOpenSound(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
	LRESULT OnChange(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
protected:
	void updateView();
	void updateModel();
};

#endif //__COMMANDPAGE_H_
