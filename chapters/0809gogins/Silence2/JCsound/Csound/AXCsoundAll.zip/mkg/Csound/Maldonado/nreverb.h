#define Combs   6
#define Alpas   5
typedef struct  {
        OPDS    h;
        float   *out, *in, *time, *hdif, *istor;
        float   *cbuf_cur[Combs], *abuf_cur[Alpas];
        float   c_time[Combs], c_gain[Combs], a_time[Alpas], a_gain[Alpas];
        float   z[Combs], g[Combs];
        AUXCH   temp;
        AUXCH   caux[Combs], aaux[Alpas];
        float   prev_time, prev_hdif;
} NREV;
