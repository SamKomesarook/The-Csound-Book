// CommandPage.cpp : Implementation of CCommandPage
#include "stdafx.h"
#include "CommandPage.h"
#include "AXCsound.h"
#include <string>

/////////////////////////////////////////////////////////////////////////////
// CCommandPage

CCommandPage::CCommandPage()
{
	m_dwTitleID = IDS_TITLECommandPage;
	m_dwHelpFileID = IDS_HELPSTRING;
	m_dwDocStringID = IDS_DOCSTRINGCommandPage;
}

LRESULT CCommandPage::OnChange(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
	bHandled = true;
	SetDirty(true);
	return 0;
}

void CCommandPage::updateModel()
{
	USES_CONVERSION;
	_ASSERTE(m_nObjects == 1);
	CComQIPtr<IAXCsound, &IID_IAXCsound> csound(m_ppUnk[0]);
	BSTR buffer = 0;
	if(GetDlgItemText(IDC_EDIT_COMMAND, buffer))
	{
		csound->put_Command(buffer);
	}
	SetDirty(false);
}

void CCommandPage::updateView()
{
	USES_CONVERSION;
	_ASSERTE(m_nObjects == 1);
	CComQIPtr<IAXCsound, &IID_IAXCsound> csound(m_ppUnk[0]);
	BSTR outBuffer = 0;
	long numberBuffer = 0;
	if(SUCCEEDED(csound->get_Command(&outBuffer)))
	{
		SetDlgItemText(IDC_EDIT_COMMAND, OLE2T(outBuffer));
	}
	if(SUCCEEDED(csound->get_Filename(&outBuffer)))
	{
		SetDlgItemText(IDC_EDIT_FILENAME, OLE2T(outBuffer));
	}
}

STDMETHODIMP CCommandPage::Activate(HWND hWndParent, LPCRECT pRect, BOOL bModal)
{
	IPropertyPageImpl<CCommandPage>::Activate(hWndParent, pRect, bModal);
	HWND control = 0;
	updateView();
	return S_OK;
}

STDMETHODIMP CCommandPage::Apply(void)
{
	ATLTRACE(_T("CCommandPage::Apply\n"));
	updateModel();
	return S_OK;
}

LRESULT CCommandPage::OnNew(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
	_ASSERTE(m_nObjects == 1);
	CComQIPtr<IAXCsound, &IID_IAXCsound> csound(m_ppUnk[0]);
	csound->RemoveAll();
	updateView();
	SetDirty(false);
	bHandled = true;
	return 0;
}

LRESULT CCommandPage::OnOpen(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
	USES_CONVERSION;
	char szFile[260];		// buffer for filename
	memset(szFile, 0, sizeof(szFile));
	OPENFILENAME ofn;       // common dialog box structure
	memset(&ofn, 0, sizeof(ofn));
	ofn.lStructSize = sizeof(ofn);
	ofn.hwndOwner = m_hWnd;
	ofn.lpstrFile = szFile;
	ofn.nMaxFile = sizeof(szFile);
	ofn.lpstrFilter = "Csound\0*.csd\0All\0*.*\0\0";
	ofn.nFilterIndex = 0;
	ofn.lpstrFileTitle = 0;
	ofn.nMaxFileTitle = 0;
	ofn.lpstrInitialDir = 0;
	ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;
	ofn.lpstrDefExt = "csd";
	if(GetOpenFileName(&ofn))
	{
		BSTR filename = ::SysAllocString(T2OLE(szFile));
		_ASSERTE(m_nObjects == 1);
		CComQIPtr<IAXCsound, &IID_IAXCsound> csound(m_ppUnk[0]);
		csound->put_Filename(filename);
		csound->Open(filename);
		SetDlgItemText(IDC_EDIT_FILENAME, szFile);
		updateView();
	}	
	else
	{
		long returnValue = CommDlgExtendedError();
	}
	bHandled = true;
	return 0;
}

LRESULT CCommandPage::OnSave(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
	updateModel();
	_ASSERTE(m_nObjects == 1);
	CComQIPtr<IAXCsound, &IID_IAXCsound> csound(m_ppUnk[0]);
	BSTR filename = 0;
	csound->get_Filename(&filename);
	csound->Save(filename);
	bHandled = true;
	return 0;
}

LRESULT CCommandPage::OnSaveAs(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
	USES_CONVERSION;
	char szFile[260];		// buffer for filename
	memset(szFile, 0, sizeof(szFile));
	OPENFILENAME ofn;       // common dialog box structure
	memset(&ofn, 0, sizeof(ofn));
	ofn.lStructSize = sizeof(ofn);
	ofn.hwndOwner = m_hWnd;
	ofn.lpstrFile = szFile;
	ofn.nMaxFile = sizeof(szFile);
	ofn.lpstrFilter = "Csound\0*.csd\0All\0*.*\0\0";
	ofn.nFilterIndex = 0;
	ofn.lpstrFileTitle = 0;
	ofn.nMaxFileTitle = 0;
	ofn.lpstrInitialDir = 0;
	ofn.Flags = OFN_PATHMUSTEXIST | OFN_OVERWRITEPROMPT;
	ofn.lpstrDefExt = "*.csd";
	if(GetSaveFileName(&ofn))
	{
		updateModel();
		BSTR filename = ::SysAllocString(T2OLE(szFile));
		_ASSERTE(m_nObjects == 1);
		CComQIPtr<IAXCsound, &IID_IAXCsound> csound(m_ppUnk[0]);
		csound->put_Filename(filename);
		csound->Save(filename);
		SetDlgItemText(IDC_EDIT_FILENAME, szFile);
		updateView();
	}	
	else
	{
		long returnValue = CommDlgExtendedError();
	}
	bHandled = true;
	return 0;
}

LRESULT CCommandPage::OnImport(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
	USES_CONVERSION;
	char szFile[260];		// buffer for filename
	memset(szFile, 0, sizeof(szFile));
	OPENFILENAME ofn;       // common dialog box structure
	memset(&ofn, 0, sizeof(ofn));
	ofn.lStructSize = sizeof(ofn);
	ofn.hwndOwner = m_hWnd;
	ofn.lpstrFile = szFile;
	ofn.nMaxFile = sizeof(szFile);
	ofn.lpstrFilter = "Csound\0*.csd\0Orchestra\0*.orc\0Score\0*.sco\0Midi\0*.mid\0Launch95\0*.l95\0All\0*.*\0\0";
	ofn.nFilterIndex = 0;
	ofn.lpstrFileTitle = 0;
	ofn.nMaxFileTitle = 0;
	ofn.lpstrInitialDir = 0;
	ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;
	ofn.lpstrDefExt = "*.csd";
	if(GetOpenFileName(&ofn))
	{
		_ASSERTE(m_nObjects == 1);
		CComQIPtr<IAXCsound, &IID_IAXCsound> csound(m_ppUnk[0]);
		csound->Import(T2OLE(szFile));
		SetDirty(false);
		updateView();
	}	
	else
	{
		long returnValue = CommDlgExtendedError();
	}
	bHandled = true;
	return 0;
}

LRESULT CCommandPage::OnPlayOrStop(int idCtrl, LPNMHDR pnmh, BOOL& bHandled)
{
	USES_CONVERSION;
	_ASSERTE(m_nObjects == 1);
	CComQIPtr<IAXCsound, &IID_IAXCsound> csound(m_ppUnk[0]);
	if(((NM_UPDOWN *)pnmh)->iDelta < 0)
	{
		BSTR filename = 0;
		csound->get_Filename(&filename);
		csound->Save(filename);
		std::string command = "Csound ";
		command += OLE2T(filename);
		csound->put_Command(T2OLE(command.c_str()));
		csound->Play();
	}
	else if(((NM_UPDOWN *)pnmh)->iDelta > 0)
	{
		csound->Stop();
	}
	bHandled = true;
	return 0;
}

LRESULT CCommandPage::OnPause(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
	_ASSERTE(m_nObjects == 1);
	CComQIPtr<IAXCsound, &IID_IAXCsound> csound(m_ppUnk[0]);
	csound->Pause();
	bHandled = true;
	return 0;
}

LRESULT CCommandPage::OnResume(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
	_ASSERTE(m_nObjects == 1);
	CComQIPtr<IAXCsound, &IID_IAXCsound> csound(m_ppUnk[0]);
	csound->Resume();
	bHandled = true;
	return 0;
}

LRESULT CCommandPage::OnOpenSound(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
	_ASSERTE(m_nObjects == 1);
	CComQIPtr<IAXCsound, &IID_IAXCsound> csound(m_ppUnk[0]);
	csound->OpenSound();
	bHandled = true;
	return 0;
}

STDMETHODIMP CCommandPage::Help(LPCOLESTR pszHelpDir)
{
	TCHAR path[_MAX_PATH];
	TCHAR drive[_MAX_PATH];
	TCHAR dir[_MAX_PATH];
	TCHAR fname[_MAX_PATH];
	TCHAR ext[_MAX_PATH];
	long returnValue = ::GetModuleFileName(_Module.m_hInst, path, _MAX_PATH);
	if(!returnValue)
	{
		return E_INVALIDARG;
	}
	_splitpath(path, drive, dir, fname, ext);
	std::string helpFilename;
	helpFilename += drive;
	helpFilename += dir;
	helpFilename += "AXCsound.htm";
	returnValue = (long) ShellExecute(0,
		"open",
		helpFilename.c_str(),
		0,
		0,
		SW_SHOWNORMAL);
	return S_OK;
}
