/* Spectral Extraction and Amplitude Gating functions */
/* By Richard Karpen  June, 1998  */
/* Based on ideas from Tom Erbe's SoundHack  */

/* Predeclare Functions */

void SpectralExtract(float  *, float *, long, long, int, float);
float PvocMaxAmp( float *, long, long);
void PvAmpGate(float *, long, FUNC *, float);
