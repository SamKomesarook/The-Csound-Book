#ifndef AXMATHLINK_H
#define AXMATHLINK_H

#ifdef __cplusplus
extern "C" 
{
#endif
	void loadMathLink();
	
	typedef void (__stdcall MLDisownStringType)(MLINK mlp, kcharp_ct s);
	typedef int (__stdcall MLPutIntegerType)(MLINK mlp, int_nt i);
	typedef int (__stdcall MLPutFunctionType)(MLINK mlp, kcharp_ct s, long_st argc);
	typedef int (__stdcall MLNewPacketType)(MLINK mlp);
	typedef int (__stdcall MLGetStringType)(MLINK mlp, kcharpp_ct sp);
	typedef void (__stdcall MLDisownRealListType)(MLINK mlp, doublep_nt data, long_st count);
	typedef int (__stdcall MLGetRealListType)(MLINK mlp, doublepp_nt datap, longp_st countp);
	typedef int (__stdcall MLGetIntegerType)(MLINK mlp, intp_nt ip);
	typedef int (__stdcall MLFlushType)(MLINK mlp);
	typedef int (__stdcall MLPutSymbolType)(MLINK mlp, kcharp_ct s);
	typedef int (__stdcall MLConnectType)(MLINK mlp);
	typedef int (__stdcall MLErrorType)(MLINK mlp);
	typedef int (__stdcall MLPutStringType)(MLINK mlp, kcharp_ct s);
	typedef int (__stdcall MLEndPacketType)(MLINK mlp);
	typedef int (__stdcall MLClearErrorType)(MLINK mlp);
	typedef int (__stdcall MLCheckFunctionType)(MLINK mlp, kcharp_ct s, longp_st countp);
	typedef int (__stdcall MLNextPacketType)(MLINK mlp);
	typedef void (__stdcall MLDeinitializeType)(MLEnvironment env);
	typedef void (__stdcall MLCloseType)(MLINK mlp);
	typedef int (__stdcall MLSetMessageHandlerType)(MLINK mlp, MLMessageHandlerObject h);
	typedef int (__stdcall MLSetYieldFunctionType)(MLINK mlp, MLYieldFunctionObject yf);
	typedef kcharp_ct (__stdcall MLNameType)(MLINK mlp);
	typedef mldlg_result (__stdcall MLAlertType)(MLEnvironment env, kcharp_ct message);
	typedef MLEnvironment (__stdcall MLInitializeType)(MLParametersPointer p); /* pass in NULL */
	typedef int (__stdcall MLTransferExpressionType)(MLINK dmlp, MLINK smlp);
	typedef kcharp_ct (__stdcall MLErrorStringType)(MLEnvironment env, long err);
	typedef MLINK (__stdcall MLOpenArgvType)(MLEnvironment ep, charpp_ct argv, charpp_ct argv_end, longp_ct errp);
	typedef MLINK (__stdcall MLOpenStringType)(MLEnvironment ep, kcharp_ct command_line, longp_ct errp);
	typedef MLMessageHandlerObject (__stdcall MLCreateMessageHandlerType)(MLEnvironment ep, MLMessageHandlerType mh, MLPointer reserved); /* reserved must be 0 */
	typedef MLYieldFunctionObject (__stdcall MLCreateYieldFunctionType)(MLEnvironment ep, MLYieldFunctionType yf, MLPointer reserved); /* reserved must be 0 */

	extern MLDisownStringType *pMLDisownString;
	extern MLPutIntegerType *pMLPutInteger;
	extern MLPutFunctionType *pMLPutFunction;
	extern MLNewPacketType *pMLNewPacket;
	extern MLGetStringType *pMLGetString;
	extern MLDisownRealListType *pMLDisownRealList;
	extern MLGetRealListType *pMLGetRealList;
	extern MLGetIntegerType *pMLGetInteger;
	extern MLFlushType *pMLFlush;
	extern MLPutSymbolType *pMLPutSymbol;
	extern MLConnectType *pMLConnect;
	extern MLErrorType *pMLError;
	extern MLPutStringType *pMLPutString;
	extern MLEndPacketType *pMLEndPacket;
	extern MLClearErrorType *pMLClearError;
	extern MLCheckFunctionType *pMLCheckFunction;
	extern MLNextPacketType *pMLNextPacket;
	extern MLDeinitializeType *pMLDeinitialize;
	extern MLCloseType *pMLClose;
	extern MLSetMessageHandlerType *pMLSetMessageHandler;
	extern MLSetYieldFunctionType *pMLSetYieldFunction;
	extern MLNameType *pMLName;
	extern MLAlertType *pMLAlert;
	extern MLErrorStringType *pMLErrorString;
	extern MLOpenArgvType *pMLOpenArgv;
	extern MLOpenStringType *pMLOpenString;
	extern MLCreateMessageHandlerType *pMLCreateMessageHandler;
	extern MLCreateYieldFunctionType *pMLCreateYieldFunction;
	extern MLInitializeType *pMLInitialize;
	extern MLTransferExpressionType *pMLTransferExpression;
#ifdef __cplusplus
};
#endif


#endif