#include "stdafx.h"
#include "ScorePage.h"
#include "AXCsound.h"
#include <string>

CScorePage::CScorePage() 
{
	m_dwTitleID = IDS_TITLEScorePage;
	m_dwHelpFileID = IDS_HELP_CSOUND;
	m_dwDocStringID = IDS_DOCSTRINGScorePage;
}

LRESULT CScorePage::OnPaint(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	updateView();
	bHandled = false;
	return 0;
}

LRESULT CScorePage::OnClearScore(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
	bHandled = true;
	_ASSERTE(m_nObjects == 1);
	CComQIPtr<IAXCsound, &IID_IAXCsound> csound(m_ppUnk[0]);
	csound->put_ScoreLineCount(0);
	updateView();
	SetDirty(false);
	return 0;
}

LRESULT CScorePage::OnClearNotesOnly(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
	bHandled = true;
	_ASSERTE(m_nObjects == 1);
	CComQIPtr<IAXCsound, &IID_IAXCsound> csound(m_ppUnk[0]);
	csound->RemoveScoreExceptFunctions();
	updateView();
	SetDirty(false);
	return 0;
}

STDMETHODIMP CScorePage::Apply(void)
{
	ATLTRACE(_T("CScorePage::Apply\n"));
	updateModel();
	SetDirty(false);
	return S_OK;
}

STDMETHODIMP CScorePage::Activate(HWND hWndParent, LPCRECT pRect, BOOL bModal)
{
	IPropertyPageImpl<CScorePage>::Activate(hWndParent, pRect, bModal);
	updateView();
	return S_OK;
}

void CScorePage::updateView()
{
	USES_CONVERSION;
	_ASSERTE(m_nObjects == 1);
	CComQIPtr<IAXCsound, &IID_IAXCsound> csound(m_ppUnk[0]);
	BSTR score = 0;
	csound->get_Score(&score);
	SetDlgItemText(IDC_SCORE_EDIT, OLE2T(score));
	SetDirty(true);
}

void CScorePage::updateModel()
{
	USES_CONVERSION;
	_ASSERTE(m_nObjects == 1);
	CComQIPtr<IAXCsound, &IID_IAXCsound> csound(m_ppUnk[0]);
	csound->put_ScoreLineCount(0);		
	long lineCount = SendDlgItemMessage(IDC_SCORE_EDIT, EM_GETLINECOUNT, 0, 0);
	if(lineCount > 0)
	{
		long lineLength = 0;
		long index = 0;
		for(long i = 0; i < lineCount; i++)
		{
			staticBuffer[0] = '\0';
			lineLength = SendDlgItemMessage(IDC_SCORE_EDIT, EM_GETLINE, (WPARAM) i, (LPARAM) staticBuffer);
			if(lineLength)
			{
				index = strcspn(staticBuffer, "\n\r");
				if(index)
				{
					staticBuffer[index] = '\n';
					staticBuffer[index + 1] = '\0';
				}
				csound->AddScoreLine(SysAllocString(T2OLE(staticBuffer)));
			}
		}
	}
	SetDirty(false);
}

LRESULT CScorePage::OnChange(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
	bHandled = true;
	SetDirty(true);
	return 0;
}

STDMETHODIMP CScorePage::Help(LPCOLESTR pszHelpDir)
{
	TCHAR path[_MAX_PATH];
	TCHAR drive[_MAX_PATH];
	TCHAR dir[_MAX_PATH];
	TCHAR fname[_MAX_PATH];
	TCHAR ext[_MAX_PATH];
	long returnValue = ::GetModuleFileName(_Module.m_hInst, path, _MAX_PATH);
	if(!returnValue)
	{
		return E_INVALIDARG;
	}
	_splitpath(path, drive, dir, fname, ext);
	std::string helpFilename;
	helpFilename += drive;
	helpFilename += dir;
	helpFilename += "AXCsound.htm";
	returnValue = (long) ShellExecute(0,
		"open",
		helpFilename.c_str(),
		0,
		0,
		SW_SHOWNORMAL);
	return S_OK;
}
