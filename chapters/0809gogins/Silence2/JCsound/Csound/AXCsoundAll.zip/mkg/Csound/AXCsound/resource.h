//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by AXCsound.rc
//
#define IDPAUSE                         6
#define IDNEW                           10
#define IDOPEN                          11
#define IDSAVE                          12
#define IDSAVEAS                        13
#define IDIMPORT                        14
#define IDOPENSOUND                     16
#define IDS_PROJNAME                    100
#define IDR_AXCSOUND                    101
#define IDS_TITLECommandPage            103
#define IDS_DOCSTRINGCommandPage        107
#define IDD_COMMANDPAGE                 108
#define IDR_COMMANDPAGE                 110
#define IDD_INSTRUMENTSPAGE             114
#define IDD_SCOREPAGE                   115
#define IDD_CONTROLDIALOG               117
#define IDD_COPYRIGHT                   118
#define IDR_ARRANGEMENTPAGE             124
#define IDS_TITLEInstrumentsPage        126
#define IDS_DOCSTRINGInstrumentsPage    128
#define IDR_INSTRUMENTSPAGE             129
#define IDS_TITLEScorePage              131
#define IDS_DOCSTRINGScorePage          133
#define IDR_SCOREPAGE                   134
#define IDR_TESTPAGE                    139
#define IDS_TITLECopyright              141
#define IDS_DOCSTRINGCopyright          143
#define IDR_COPYRIGHT                   144
#define IDS_HELP_CSOUND                 144
#define IDS_HELPSTRING                  145
#define IDC_EDIT_FILENAME               207
#define IDPROPERTIES                    208
#define IDI_NOTE                        208
#define IDRESUME                        209
#define IDB_ANGEL                       209
#define IDC_EDIT_ORCHESTRA              213
#define IDC_EDIT_COMMAND                227
#define IDC_LOG_LIST                    232
#define IDC_MAIN_SPIN_PLAY              237
#define IDC_EDIT_COPYRIGHT              240
#define IDC_SCORE_EDIT                  262
#define IDC_CLEAR_NOTES_ONLY            264
#define IDC_CLEAR_SCORE                 265

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        214
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         242
#define _APS_NEXT_SYMED_VALUE           146
#endif
#endif
