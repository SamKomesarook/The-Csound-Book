#include <malloc.h>
#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <windows.h>
#ifdef CSOUND_REENTRANT_API
#include <initguid.h>
#endif	//	CSOUND_REENTRANT_API
#include <dsound.h>
#include <math.h>

static int DsoundDevNum = -1;
void SetDsoundDevNum(int num) {DsoundDevNum = num;}
void PlayDsoundNowait(char *, int);
void PlayDsoundSleep(char *, int);
void PlayDsoundAndFileNowait(char *, int);
void PlayDsoundAndFileSleep(char *, int);
extern float	esr;
float one2sr;
static DWORD dwBufferSize;

extern void  (*write_to_file) (char *, int);

extern void (*rtplay)(char *, int);
extern void (*rtplay_and_file) (char *, int);

void set_rtplay_Dsound() {	
	rtplay = PlayDsoundNowait;
	rtplay_and_file = PlayDsoundAndFileNowait;
}
void set_critical_priority_flag();
void set_dsound_sleep()
{ 
	rtplay = PlayDsoundSleep;
	rtplay_and_file = PlayDsoundAndFileSleep;
	set_critical_priority_flag();
}

BOOL secondary_flag=0;
void set_secondary_flag() { secondary_flag=1;}


LPDIRECTSOUNDBUFFER DsBuf;

#ifdef CSOUND_REENTRANT_API
//	For some reason, dynamically loading DirectSound doesn't work
//	if the following is optimized... perhaps the compiler forgets the aliases.
#pragma optimize( "", off )

extern void dribble_printf(char *fmt, ...);
#define printf dribble_printf

HWND directSoundWindow = 0;
LPDIRECTSOUND directSound = 0;

void DirectSoundClose()
{
	HRESULT hResult = 0;
	extern int directSound_flag;
	if(!directSound)
	{
		return;
	}
	hResult = DsBuf->lpVtbl->Stop(DsBuf);
	hResult = DsBuf->lpVtbl->Release(DsBuf);
	DsBuf = 0;
	hResult = directSound->lpVtbl->Release(directSound);
	directSound = 0;
	DestroyWindow(directSoundWindow);
	directSoundWindow = 0;
	UnregisterClass("dummy", 0);
	dribble_printf("Closed DirectSound object.");
	directSound_flag = 0;
}
#endif	//	CSOUND_REENTRANT_API

long butta[16]={
/*0*/DS_OK, // The request completed successfully. 
/*1*/DSERR_ALLOCATED,  // The request failed because resources, such as a priority level, were already in use by another caller. 
/*2*/DSERR_ALREADYINITIALIZED, //The object is already initialized. 
/*3*/DSERR_BADFORMAT, //The specified wave format is not supported. 
/*4*/DSERR_BUFFERLOST, //The buffer memory has been lost and must be restored. 
/*5*/DSERR_CONTROLUNAVAIL, //The control (volume, pan, and so forth) requested by the caller is not available. 
/*6*/DSERR_GENERIC, //An undetermined error occurred inside the DirectSound subsystem. 
/*7*/DSERR_INVALIDCALL, //This function is not valid for the current state of this object. 
/*8*/DSERR_INVALIDPARAM, //An invalid parameter was passed to the returning function. 
/*9*/DSERR_NOAGGREGATION, //The object does not support aggregation. 
/*10*/DSERR_NODRIVER, //No sound driver is available for use. 
/*11*/DSERR_OTHERAPPHASPRIO, //This value is obsolete and is not used. 
/*12*/DSERR_OUTOFMEMORY, //The DirectSound subsystem could not allocate sufficient memory to complete the caller's request. 
/*13*/DSERR_PRIOLEVELNEEDED, //The caller does not have the priority level required for the function to succeed. 
/*14*/DSERR_UNINITIALIZED,  //The IDirectSound::Initialize method has not been called or has not been called successfully before other methods were called. 
/*15*/DSERR_UNSUPPORTED, //The function called is not supported at this time. 
} ;


typedef struct {
	  GUID  guid;    // Storage for GUIDs.
	  char  lpstrDescription[256];	// Storage for device description strings.
} DSOUNDDEVICE, *LPDSOUNDDEVICE;

typedef struct {
	DSOUNDDEVICE	DSdevice[10];
	int NumOfDevices;
} APPINSTANCEDATA, *LPAPPINSTANCEDATA;


BOOL _stdcall AppEnumCallbackFunction(
		LPGUID lpGuid, 
		LPTSTR lpstrDescription,
		LPTSTR lpstrModule,
		LPVOID lpContext)
{
	LPAPPINSTANCEDATA lpInstance = (LPAPPINSTANCEDATA) lpContext;
	int i = lpInstance->NumOfDevices;
	strcpy( lpInstance->DSdevice[i].lpstrDescription, lpstrDescription); // Strcpy description string into lpInstance structure.
	if (lpGuid == NULL) {(lpInstance->NumOfDevices)++; return TRUE;}
	memcpy (&(lpInstance->DSdevice[i].guid), lpGuid, sizeof (GUID )); // Copy GUID into lpInstance structure.
	(lpInstance->NumOfDevices)++;
    return TRUE; // Continue enumerating.
}

LPGUID AppLetUserSelectDevice( LPAPPINSTANCEDATA AppInstanceData) {
    int j,DevSelNum;
	if 	(DsoundDevNum == -1) {
#ifdef CSOUND_REENTRANT_API
		{
			char buffer[0x1000];
			char lineBuffer[0x100];
			memset(buffer, 0, sizeof(buffer));
			sprintf(buffer, "Found %d DirectSound devices:\n\n", AppInstanceData->NumOfDevices);
			for(j = 0; j <	AppInstanceData->NumOfDevices; j++)
			{
				sprintf(lineBuffer, "Device %d: %s\n", j, AppInstanceData->DSdevice[j].lpstrDescription);
				strcat(buffer, lineBuffer);
			}
			strcat(buffer, "\nSpecify device number in -+X option and try again.");
			MessageBox(0, buffer, "AXCsound", MB_ICONEXCLAMATION);
#ifndef JCSOUND
			_endthreadex(1);	
#endif
		}
#endif	//	CSOUND_REENTRANT_API
		printf("\n%i DirectSound devices found:\n",AppInstanceData->NumOfDevices);
		for (j = 0; j <	AppInstanceData->NumOfDevices; j++){
			printf("DirectSound device #%d -> %s\n", j, AppInstanceData->DSdevice[j].lpstrDescription);
		}
	repeat:		
		printf("\nPlease, type DirectSound device number and press <RETURN>: ");
		scanf("%d",&DevSelNum);	 printf("\n");
		if (DevSelNum < 0 || DevSelNum >= AppInstanceData->NumOfDevices) {
			printf ("ERROR!! Bad DirectSound device number. Valid numbers are 0 to %d\n",AppInstanceData->NumOfDevices-1);
			goto repeat;
		}	
  
	}
	else DevSelNum = DsoundDevNum; 

	return	 &(AppInstanceData->DSdevice[DevSelNum].guid);
}



BOOL AppCreateWritePrimaryBuffer( LPDIRECTSOUND lpDirectSound, 
								 LPDIRECTSOUNDBUFFER *lplpDsb,
								 LPDWORD lpdwBufferSize, 
								 HWND hwnd, int nchnls, float esr)
{
    PCMWAVEFORMAT pcmwf;
	DSBUFFERDESC dsbdesc;
    DSBCAPS dsbcaps;
    HRESULT hr;
    memset(&pcmwf, 0, sizeof(PCMWAVEFORMAT));
    pcmwf.wf.wFormatTag = WAVE_FORMAT_PCM;
    pcmwf.wf.nChannels = nchnls;
    pcmwf.wf.nSamplesPerSec = (int) esr;
    pcmwf.wBitsPerSample = 16;
	pcmwf.wf.nBlockAlign =  nchnls*(pcmwf.wBitsPerSample>>3);
    pcmwf.wf.nAvgBytesPerSec = pcmwf.wf.nSamplesPerSec * pcmwf.wf.nBlockAlign;
    memset(&dsbdesc, 0, sizeof(DSBUFFERDESC)); 
    dsbdesc.dwSize = sizeof(DSBUFFERDESC);
    dsbdesc.dwFlags = DSBCAPS_PRIMARYBUFFER;
    dsbdesc.dwBufferBytes = 0; 
    dsbdesc.lpwfxFormat = NULL; 
    hr = lpDirectSound->lpVtbl->SetCooperativeLevel(lpDirectSound, hwnd, DSSCL_WRITEPRIMARY);
    if(DS_OK == hr) {
        hr = lpDirectSound->lpVtbl->CreateSoundBuffer(lpDirectSound, &dsbdesc, lplpDsb, NULL);
        if(DS_OK == hr) {
            hr = (*lplpDsb)->lpVtbl->SetFormat(*lplpDsb, &pcmwf);
            if(DS_OK == hr) {
                    dsbcaps.dwSize = sizeof(DSBCAPS);
                (*lplpDsb)->lpVtbl->GetCaps(*lplpDsb, &dsbcaps);
                *lpdwBufferSize = dsbcaps.dwBufferBytes;
                return TRUE;
            }
        }
    }
    *lplpDsb = NULL;
    *lpdwBufferSize = 0;
    return FALSE;
}

LRESULT WINAPI MainWndProc(	HWND hwnd, UINT msg, WPARAM wParam,	LPARAM lParam)
{
	return DefWindowProc( hwnd, msg, wParam, lParam) ;
}


int init_window(HWND* hwnd) {
	WNDCLASS wc ;
	char lpszText[] = "dummy" ;
	char lpszClassName[] = "dummy" ;
	wc.style		= 0;
	wc.lpfnWndProc	= MainWndProc ;
	wc.cbClsExtra	= 0 ;
	wc.cbWndExtra	= 0 ;
	wc.hInstance	= 0 ;
	wc.hIcon		= LoadIcon( NULL, IDI_APPLICATION) ;
	wc.hCursor		= LoadCursor( NULL, IDC_ARROW) ;
	wc.hbrBackground= GetStockObject( WHITE_BRUSH) ;
	wc.lpszMenuName	= NULL ;
	wc.lpszClassName= lpszClassName ;
	if( !RegisterClass( &wc)) {
		MessageBeep( 0) ;
		return FALSE ;
	}
	*hwnd = CreateWindow(lpszClassName,lpszText,WS_OVERLAPPEDWINDOW,10,300,
						CW_USEDEFAULT,0,NULL,NULL,0,NULL);
#ifdef CSOUND_REENTRANT_API
	directSoundWindow = *hwnd;
#endif	//	CSOUND_REENTRANT_API
	/* ShowWindow( *hwnd, SW_SHOWNORMAL) ; */
	if (*hwnd== NULL) return FALSE;
	else	return TRUE;
}

BOOL AppCreateSecondaryBuffer(LPDIRECTSOUND lpDirectSound,
							  LPDIRECTSOUNDBUFFER *lplpDsb, 
							  LPDWORD lpdwBufferSize, HWND hwnd, int nchnls, float esr)
{
    PCMWAVEFORMAT pcmwf;
    DSBUFFERDESC dsbdesc;
    DSBCAPS dsbcaps;
	HRESULT hr;
    memset(&pcmwf, 0, sizeof(PCMWAVEFORMAT));
    pcmwf.wf.wFormatTag = WAVE_FORMAT_PCM;
    pcmwf.wf.nChannels = nchnls;
    pcmwf.wf.nSamplesPerSec = (int) esr;
    pcmwf.wBitsPerSample = 16;
	pcmwf.wf.nBlockAlign = nchnls*(pcmwf.wBitsPerSample>>3);
    pcmwf.wf.nAvgBytesPerSec = pcmwf.wf.nSamplesPerSec * pcmwf.wf.nBlockAlign;
    
    memset(&dsbdesc, 0, sizeof(DSBUFFERDESC));
    dsbdesc.dwSize = sizeof(DSBUFFERDESC);
    dsbdesc.dwFlags = DSBCAPS_STICKYFOCUS|DSBCAPS_LOCSOFTWARE; 
    dsbdesc.dwBufferBytes = 3 * pcmwf.wf.nAvgBytesPerSec; 
    dsbdesc.lpwfxFormat = (LPWAVEFORMATEX)&pcmwf;
    hr = lpDirectSound->lpVtbl->SetCooperativeLevel(lpDirectSound, hwnd, DSSCL_PRIORITY);
    if(DS_OK == hr) {
		hr = lpDirectSound->lpVtbl->CreateSoundBuffer(lpDirectSound, &dsbdesc, lplpDsb, NULL);
	    if(DS_OK == hr) {
			dsbcaps.dwSize = sizeof(DSBCAPS);
			(*lplpDsb)->lpVtbl->GetCaps(*lplpDsb, &dsbcaps);
			*lpdwBufferSize = dsbcaps.dwBufferBytes;
			return TRUE;
		}
    } 
    *lplpDsb = NULL;
    return FALSE;
}

HRESULT  (WINAPI *DsGetCurrentPosition)(LPDIRECTSOUNDBUFFER, LPDWORD, LPDWORD);
HRESULT  (WINAPI *DsLock)(LPDIRECTSOUNDBUFFER, DWORD, DWORD, LPVOID, LPDWORD, LPVOID, LPDWORD, DWORD);
HRESULT  (WINAPI *DsUnlock)(LPDIRECTSOUNDBUFFER, LPVOID, DWORD, LPVOID, DWORD);

#ifdef CSOUND_REENTRANT_API
typedef BOOL (DirectSoundEnumerateFunction)(LPDSENUMCALLBACK lpDSEnumCallback, LPVOID lpContext);
typedef HRESULT (DirectSoundCreateFunction)(GUID FAR *lpGuid, LPDIRECTSOUND *ppDS, IUnknown FAR *pUnkOuter);
#endif	//	CSOUND_REENTRANT_API

BOOL CreateDsoundObject(char *warning, int nchnls, float esr)									
{
	LPDIRECTSOUND lpDirectSound;
	DSCAPS dscaps;
	HRESULT hr;
	APPINSTANCEDATA AppInstanceData;
    LPGUID lpGuid;
	LPDIRECTSOUNDBUFFER lpDsb;
	DWORD flags;
	HWND hwnd;
#ifdef CSOUND_REENTRANT_API
	//	Fail without crashing if DirectSound is not present,
	//	by explicitly loading library and functions 
	//	rather than using the import library.
	DirectSoundEnumerateFunction *DirectSoundEnumerator = 0;
	DirectSoundCreateFunction *DirectSoundCreator = 0;
	HMODULE directSoundLibrary = LoadLibrary("DSound");
	if(!directSoundLibrary)
	{
		sprintf(warning, "Cannot find DirectSound library.");
		return FALSE;
	}
	DirectSoundEnumerator = (DirectSoundEnumerateFunction *) GetProcAddress(directSoundLibrary, "DirectSoundEnumerateA");
	if(!DirectSoundEnumerator)
	{
		sprintf(warning, "Cannot find DirectSoundEnumerate function.");
		return FALSE;
	}
	DirectSoundCreator = (DirectSoundCreateFunction *) GetProcAddress(directSoundLibrary, "DirectSoundCreate");
	if(!DirectSoundCreator)
	{
		sprintf(warning, "Cannot find DirectSoundCreate function.");
		return FALSE;
	}
	memset(&AppInstanceData, 0, sizeof(AppInstanceData));
	AppInstanceData.NumOfDevices=0;
	hr = DirectSoundEnumerator(AppEnumCallbackFunction, &AppInstanceData);
#else
	AppInstanceData.NumOfDevices=0;
    hr = DirectSoundEnumerate(AppEnumCallbackFunction, &AppInstanceData);
#endif	//	CSOUND_REENTRANT_API	AppInstanceData.NumOfDevices=0;
	if (hr != DS_OK) {
		sprintf(warning,"cannot enumerate DirectSound devices");	
		return FALSE;
	}
	if (AppInstanceData.NumOfDevices == 0)	    {
        sprintf(warning,"NO DirectSound DEVICE INSTALLED!!!!\n");
        return FALSE;
    } 
	lpGuid = AppLetUserSelectDevice(&AppInstanceData);
#ifdef CSOUND_REENTRANT_API
	hr = DirectSoundCreator(lpGuid, &lpDirectSound,	NULL);
	if(FAILED(hr)) 
	{
		sprintf(warning,"Error %d: Unable to create DirectSound object.\n", hr);
		return FALSE;
	}
#else
	hr = DirectSoundCreate(lpGuid, &lpDirectSound,	NULL);
	if(hr != DS_OK) {
		sprintf(warning,"unable to create a DirectSound object\n");
		return FALSE;
	}
#endif	//	CSOUND_REENTRANT_API

#ifdef CSOUND_REENTRANT_API
	directSound = lpDirectSound;
#endif	//	CSOUND_REENTRANT_API

	dscaps.dwSize = sizeof(DSCAPS);
	hr = lpDirectSound->lpVtbl->GetCaps(lpDirectSound,&dscaps);
   	if(hr != DS_OK) {
		sprintf(warning,"unable to get the capabilities of the DirectSound object just created\n");
		return FALSE;
	}
	flags = dscaps.dwFlags;
	printf("DSCAPS_PRIMARYMONO: %d\n",(flags & DSCAPS_PRIMARYMONO) && 1);
	printf("DSCAPS_PRIMARYSTEREO: %d\n",(flags & DSCAPS_PRIMARYSTEREO) && 1 );
	printf("DSCAPS_PRIMARY8BIT: %d\n",(flags & DSCAPS_PRIMARY8BIT) && 1 );
	printf("DSCAPS_PRIMARY16BIT: %d\n",(flags & DSCAPS_PRIMARY16BIT) && 1 );
	printf("DSCAPS_CONTINUOUSRATE: %d\n",(flags & DSCAPS_CONTINUOUSRATE) && 1 );
	printf("DSCAPS_EMULDRIVER: %d\n",(flags & DSCAPS_EMULDRIVER) && 1 );
	printf("DSCAPS_CERTIFIED: %d\n",(flags & DSCAPS_CERTIFIED) && 1 );
	printf("DSCAPS_SECONDARYMONO: %d\n",(flags & DSCAPS_SECONDARYMONO) && 1 );
	printf("DSCAPS_SECONDARYSTEREO: %d\n",(flags & DSCAPS_SECONDARYSTEREO) && 1 );
	printf("DSCAPS_SECONDARY8BIT: %d\n",(flags & DSCAPS_SECONDARY8BIT) && 1 );
	
	if(!init_window(&hwnd)) {
		sprintf(warning,"unable to create a window handle for DirectSound\n");
		return FALSE;
	}
	
	//hwnd = GetForegroundWindow();
	if (!secondary_flag) {
		if(!AppCreateWritePrimaryBuffer( lpDirectSound, &lpDsb, &dwBufferSize, hwnd,nchnls,esr)) {
			sprintf(warning,"unable to create a primary buffer for DirectSound\n");
			return FALSE;
		}
	} else {
		if(!AppCreateSecondaryBuffer( lpDirectSound, &lpDsb, &dwBufferSize, hwnd, nchnls, esr)) {
			sprintf(warning,"unable to create a secondary buffer for DirectSound\n");
			return FALSE;
		}
	}
		
	hr = lpDsb->lpVtbl->Play(lpDsb, 0, 0,  DSBPLAY_LOOPING);
	if(hr != DS_OK) {
		sprintf(warning,"the DirectSound object just created is unable to play\n");
		return FALSE;
	}
	DsBuf = lpDsb;
	DsGetCurrentPosition = lpDsb->lpVtbl->GetCurrentPosition;
	DsLock = DsBuf->lpVtbl->Lock;
	DsUnlock = DsBuf->lpVtbl->Unlock;
	one2sr =  1000/(sizeof(short) * esr);
/*
	{
	   
		DWORD dwStatus;
		DWORD dwFrequency;
		LONG lVolume;
		WAVEFORMATEX wfxFormat;

		hr=DsBuf->lpVtbl->GetStatus(DsBuf,&dwStatus);
		hr=DsBuf->lpVtbl->GetFrequency(DsBuf,&dwFrequency);
		hr=DsBuf->lpVtbl->GetVolume(DsBuf,&lVolume);
		hr=DsBuf->lpVtbl->GetFormat(DsBuf,&wfxFormat, sizeof (WAVEFORMATEX), 0);
	}
*/
	return TRUE;
}

#ifdef CSOUND_REENTRANT_API
#pragma optimize( "", on )
#endif	//	CSOUND_REENTRANT_API

/* ------------------------------*/

void PlayDsoundNowait(char *outbuf, int nbytes)
{
		DWORD dwCurrentPlayCursor;
		DWORD dwCurrentWriteCursor;
		static DWORD LastWritePosition=0;
		static DWORD LastPlayPosition;
		static DWORD nrec=1;
		//static int sleepcount=0;
		LPVOID lpvPtr1;
	    DWORD dwBytes1; 
		LPVOID lpvPtr2;
		DWORD dwBytes2;
		do {	
			DsGetCurrentPosition(DsBuf, &dwCurrentPlayCursor, &dwCurrentWriteCursor);
			if (dwCurrentPlayCursor < LastPlayPosition) nrec++;
			LastPlayPosition = dwCurrentPlayCursor;	
		} while (dwBufferSize * nrec + dwCurrentPlayCursor < LastWritePosition);
		LastWritePosition += nbytes;
		DsLock(DsBuf, LastWritePosition % dwBufferSize, nbytes, &lpvPtr1, &dwBytes1, &lpvPtr2, &dwBytes2, 0);
        CopyMemory(lpvPtr1, outbuf, dwBytes1);
        if(NULL != lpvPtr2) CopyMemory(lpvPtr2, outbuf+dwBytes1, dwBytes2);
        DsUnlock(DsBuf, lpvPtr1, dwBytes1, lpvPtr2, dwBytes2);
		
}


void PlayDsoundSleep(char *outbuf, int nbytes)
{
		DWORD dwCurrentPlayCursor;
		DWORD dwCurrentWriteCursor;
		static DWORD LastWritePosition=0;
		static DWORD LastPlayPosition;
		static DWORD nrec=1;
		//static int sleepcount=0;
		LPVOID lpvPtr1;
	    DWORD dwBytes1; 
		LPVOID lpvPtr2;
		DWORD dwBytes2;
		Sleep(1);
		do {	
			DsGetCurrentPosition(DsBuf, &dwCurrentPlayCursor, &dwCurrentWriteCursor);
			if (dwCurrentPlayCursor < LastPlayPosition) nrec++;
			LastPlayPosition = dwCurrentPlayCursor;	
		} while (dwBufferSize * nrec + dwCurrentPlayCursor < LastWritePosition);
		LastWritePosition += nbytes;
		DsLock(DsBuf, LastWritePosition % dwBufferSize, nbytes, &lpvPtr1, &dwBytes1, &lpvPtr2, &dwBytes2, 0);
        CopyMemory(lpvPtr1, outbuf, dwBytes1);
        if(NULL != lpvPtr2) CopyMemory(lpvPtr2, outbuf+dwBytes1, dwBytes2);
        DsUnlock(DsBuf, lpvPtr1, dwBytes1, lpvPtr2, dwBytes2);
		
}



/*
void PlayDsoundNowait(char *outbuf, int nbytes)
{
  LPVOID lpbuf1 = NULL;
  LPVOID lpbuf2 = NULL;
  DWORD dwsize1 = 0;
  DWORD dwsize2 = 0;
  DWORD playPos, safePos, endWrite;
  static UINT m_cbBufOffset=0;
  
  DsGetCurrentPosition(DsBuf, &playPos,&safePos );
  if( playPos < m_cbBufOffset ) playPos += dwBufferSize; // unwrap offset

  endWrite = m_cbBufOffset + nbytes;
  while ( playPos < endWrite ) {
  

    // Calculate number of milliseconds until we will have room, as
    // time = distance * (milliseconds/second) / ((bytes/sample) * (samples/second)),
    // rounded up.
    // Sleep for that long
    Sleep( (DWORD) (1.0 + (endWrite - playPos) * one2sr) );

    // Wake up, find out where we are now
    DsGetCurrentPosition(DsBuf, &playPos,&safePos );
    if( playPos < m_cbBufOffset ) playPos += dwBufferSize; // unwrap offset
  }


  DsLock (DsBuf,m_cbBufOffset, nbytes, &lpbuf1, &dwsize1, &lpbuf2, &dwsize2, 0);
  CopyMemory(lpbuf1, outbuf, dwsize1);
  if(NULL != lpbuf2) CopyMemory(lpbuf2, outbuf+dwsize1, dwsize2);
  m_cbBufOffset = (m_cbBufOffset + dwsize1 + dwsize2) % dwBufferSize;
  DsUnlock (DsBuf,lpbuf1, dwsize1, lpbuf2, dwsize2);
}

*/

 /*
 void PlayDsoundNowaitOld(char *outbuf, int nbytes)
{
		//HRESULT hr;
		DWORD dwCurrentPlayCursor;
		DWORD dwCurrentWriteCursor;
		static DWORD LastWritePosition=0;
		//static DWORD LastPlayPosition;
		LPVOID lpvPtr1;
	    DWORD dwBytes1; 
		LPVOID lpvPtr2;
		DWORD dwBytes2;
	
		do {	
			DsGetCurrentPosition(DsBuf, &dwCurrentPlayCursor, &dwCurrentWriteCursor);
			
			//if (dwCurrentPlayCursor < LastPlayPosition) LastPlayPosition = dwCurrentPlayCursor + dwBufferSize;
			//else  LastPlayPosition =  dwCurrentPlayCursor;
			//if ( (LastPlayPosition + (nbytes)) < LastWritePosition) goto loop;
			
		}while (dwCurrentPlayCursor < LastWritePosition);
			LastWritePosition += nbytes;
			LastWritePosition %= dwBufferSize;
		//LastPlayPosition %=dwBufferSize;
		//%	dwBufferSize 
		//AppWriteDataToBuffer(LastWritePosition, outbuf, nbytes); 
		
		DsLock(DsBuf, LastWritePosition, nbytes, &lpvPtr1, &dwBytes1, &lpvPtr2, &dwBytes2, 0);
        CopyMemory(lpvPtr1, outbuf, dwBytes1);
        if(NULL != lpvPtr2) CopyMemory(lpvPtr2, outbuf+dwBytes1, dwBytes2);
        DsUnlock(DsBuf, lpvPtr1, dwBytes1, lpvPtr2, dwBytes2);
		
}
*/
void PlayDsoundAndFileNowait(char *outbuf, int nbytes)
{
		DWORD dwCurrentPlayCursor;
		DWORD dwCurrentWriteCursor;
		static DWORD LastWritePosition=0;
		static DWORD LastPlayPosition;
		static DWORD nrec=1;
		LPVOID lpvPtr1;
	    DWORD dwBytes1; 
		LPVOID lpvPtr2;
		DWORD dwBytes2;
		do {	
			DsGetCurrentPosition(DsBuf, &dwCurrentPlayCursor, &dwCurrentWriteCursor);
			if (dwCurrentPlayCursor < LastPlayPosition) nrec++;
			LastPlayPosition = dwCurrentPlayCursor;	
		} while (dwBufferSize * nrec + dwCurrentPlayCursor < LastWritePosition);
		LastWritePosition += nbytes;
		DsLock(DsBuf, LastWritePosition % dwBufferSize, nbytes, &lpvPtr1, &dwBytes1, &lpvPtr2, &dwBytes2, 0);
        CopyMemory(lpvPtr1, outbuf, dwBytes1);
        if(NULL != lpvPtr2) CopyMemory(lpvPtr2, outbuf+dwBytes1, dwBytes2);
        DsUnlock(DsBuf, lpvPtr1, dwBytes1, lpvPtr2, dwBytes2);
		write_to_file(outbuf, nbytes);
}

void PlayDsoundAndFileSleep(char *outbuf, int nbytes)
{
		DWORD dwCurrentPlayCursor;
		DWORD dwCurrentWriteCursor;
		static DWORD LastWritePosition=0;
		static DWORD LastPlayPosition;
		static DWORD nrec=1;
		LPVOID lpvPtr1;
	    DWORD dwBytes1; 
		LPVOID lpvPtr2;
		DWORD dwBytes2;
		Sleep(1);
		do {	
			DsGetCurrentPosition(DsBuf, &dwCurrentPlayCursor, &dwCurrentWriteCursor);
			if (dwCurrentPlayCursor < LastPlayPosition) nrec++;
			LastPlayPosition = dwCurrentPlayCursor;	
		} while (dwBufferSize * nrec + dwCurrentPlayCursor < LastWritePosition);
		LastWritePosition += nbytes;
		DsLock(DsBuf, LastWritePosition % dwBufferSize, nbytes, &lpvPtr1, &dwBytes1, &lpvPtr2, &dwBytes2, 0);
        CopyMemory(lpvPtr1, outbuf, dwBytes1);
        if(NULL != lpvPtr2) CopyMemory(lpvPtr2, outbuf+dwBytes1, dwBytes2);
        DsUnlock(DsBuf, lpvPtr1, dwBytes1, lpvPtr2, dwBytes2);
		write_to_file(outbuf, nbytes);
}
