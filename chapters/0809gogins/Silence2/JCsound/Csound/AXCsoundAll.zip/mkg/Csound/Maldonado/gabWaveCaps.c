#include <stdio.h>
#include <windows.h>
#include <mmsystem.h>
#include "cs.h"
#undef printf

#ifdef CSOUND_REENTRANT_API
extern void dribble_printf(char *fmt, ...);
#define printf dribble_printf
#endif	//	CSOUND_REENTRANT_API

int  ChooseAudioOutDev(void) {
	
	WAVEOUTCAPS  woc;	/* address of structure for capabilities*/
  	int DeviceNUM;
    int j,OutDev;
    DeviceNUM = waveOutGetNumDevs();
    if(DeviceNUM==0) {
        printf("\n NO WAVE OUT DEVICE INSTALLED!!!!\n");
        return -1;
    } 
    else if ( DeviceNUM==1 ) { /* if only one device is present */
		return 0; /* choose device number 0 without prompting */
	}
    printf("\n%i WAVE OUT Devices found\n",DeviceNUM);
	for (j=0;j< (int) DeviceNUM; j++) {
        waveOutGetDevCaps(j, &woc, sizeof(woc) );	
        printf("WAVE OUT device #%u ->%s\n",j,woc.szPname); 
    }
  repeat:
	printf("Please, type WAVE OUT device number and press <RETURN>:");
    scanf("%d",&OutDev); printf("\n");
    
    if (OutDev < 0 || OutDev >= DeviceNUM) {
		printf ("ERROR!! Bad WAVE OUT port number. Valid numbers are 0 to %d\n",DeviceNUM-1);
		goto repeat;
	}	
    return OutDev;
}


int  ChooseAudioInDev(void) {
	
	WAVEINCAPS  wic;	/* address of structure for capabilities*/
  	int DeviceNUM;
    int j,InDev;
    DeviceNUM = waveInGetNumDevs();
    if(DeviceNUM==0) {
        printf("\n NO WAVE IN DEVICE INSTALLED!!!!\n");
        return -1;
    } 
    else if ( DeviceNUM==1 ) { /*if only one device is present*/
		return 0; /* choose device number 0 without prompting*/
	}
    printf("\n%i WAVE IN Devices found\n",DeviceNUM);
	for (j=0;j< DeviceNUM; j++) {
        waveInGetDevCaps(j, &wic, sizeof(wic) );	
        printf("WAVE IN device #%u ->%s\n",j,wic.szPname); 
    }
  repeat:
	printf("Please, type WAVE IN device number and press <RETURN>:");
    scanf("%d",&InDev); printf("\n");
    
    if (InDev < 0 || InDev >= DeviceNUM) {
		printf ("ERROR!! Bad WAVE IN port number. Valid numbers are 0 to %d\n",DeviceNUM-1);
		goto repeat;
	}	
    return InDev;
}
