#include "stdafx.h"
#include "InstrumentsPage.h"
#include <string>

CInstrumentsPage::CInstrumentsPage() 
{
	m_dwTitleID = IDS_TITLEInstrumentsPage;
	m_dwHelpFileID = IDS_HELP_CSOUND;
	m_dwDocStringID = IDS_DOCSTRINGInstrumentsPage;
}

LRESULT CInstrumentsPage::OnPaint(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	updateView();
	bHandled = false;
	return 0;
}

STDMETHODIMP CInstrumentsPage::Apply(void)
{
	ATLTRACE(_T("CInstrumentsPage::Apply\n"));
	updateModel();
	return S_OK;
}

STDMETHODIMP CInstrumentsPage::Activate(HWND hWndParent, LPCRECT pRect, BOOL bModal)
{
	IPropertyPageImpl<CInstrumentsPage>::Activate(hWndParent, pRect, bModal);
	updateView();
	return S_OK;
}

void CInstrumentsPage::updateView()
{
	USES_CONVERSION;
	_ASSERTE(m_nObjects == 1);
	CComQIPtr<IAXCsound, &IID_IAXCsound> csound(m_ppUnk[0]);
	BSTR buffer = 0;
	HRESULT hResult = csound->get_Orchestra(&buffer);
	if(SUCCEEDED(hResult))
	{
		SetDlgItemText(IDC_EDIT_ORCHESTRA, OLE2T(buffer));
	}
	SetDirty(false);
}

void CInstrumentsPage::updateModel()
{
	_ASSERTE(m_nObjects == 1);
	CComQIPtr<IAXCsound, &IID_IAXCsound> csound(m_ppUnk[0]);
	BSTR buffer = 0;
	if(GetDlgItemText(IDC_EDIT_ORCHESTRA, buffer))
	{
		csound->put_Orchestra(buffer);
	}
	SetDirty(false);
}

LRESULT CInstrumentsPage::OnChange(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
	bHandled = true;
	SetDirty(true);
	return 0;
}

STDMETHODIMP CInstrumentsPage::Help(LPCOLESTR pszHelpDir)
{
	TCHAR path[_MAX_PATH];
	TCHAR drive[_MAX_PATH];
	TCHAR dir[_MAX_PATH];
	TCHAR fname[_MAX_PATH];
	TCHAR ext[_MAX_PATH];
	long returnValue = ::GetModuleFileName(_Module.m_hInst, path, _MAX_PATH);
	if(!returnValue)
	{
		return E_INVALIDARG;
	}
	_splitpath(path, drive, dir, fname, ext);
	std::string helpFilename;
	helpFilename += drive;
	helpFilename += dir;
	helpFilename += "AXCsound.htm";
	returnValue = (long) ShellExecute(0,
		"open",
		helpFilename.c_str(),
		0,
		0,
		SW_SHOWNORMAL);
	return S_OK;
}
