#include "cs.h"

typedef struct DCBlocker {
    OPDS	h;
    float	*ar, *in, *gg;

    float	outputs;
    float	inputs;
    float	gain;
} DCBlocker;

