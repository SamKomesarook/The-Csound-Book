#include "sort.h"                                          /*   SCSORT.C  */
#include "cs.h"

extern void  sort(void), twarp(void), swrite(void), sfree(void);
extern int sread(void);

void scsort(FILE *scin, FILE *scout)
    /* called from smain.c or some other main */
    /* reads,sorts,timewarps each score sect in turn */
{
	int n;

	SCOREIN = scin;
	SCOREOUT = scout;

	sectcnt = 0;
	do      if ((n = sread()) > 0) {
                        sort();
			POLL_EVENTS();    /* on Mac/Win, allow system events */
			twarp();
			swrite();
			POLL_EVENTS();    /* on Mac/Win, allow system events */
		}
	while (n > 1);
	sfree();        /* return all memory used */
}         

