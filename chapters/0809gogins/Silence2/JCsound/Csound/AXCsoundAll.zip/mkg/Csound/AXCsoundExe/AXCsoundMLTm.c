/*
 * This file automatically produced by C:\PROGRA~1\WOLFRA~1\MATHEM~1\3.0\ADDONS\MATHLINK\DEVELO~1\WINDOWS\COMPIL~1\MLDEV32\BIN\MPREP.EXE from:
 *	ECSound.tm
 * mprep Revision 5 (c) Copyright Wolfram Research, Inc. 1990-1996
 */


#include "mathlink.h"
#include "AXMathLink.h"

int MLAbort = 0;
int MLDone  = 0;
long MLSpecialCharacter = '\0';
HANDLE MLInstance = (HANDLE)0;
HWND MLIconWindow = (HWND)0;

MLINK stdlink = 0;
MLEnvironment stdenv = 0;
MLYieldFunctionObject stdyielder = 0;
MLMessageHandlerObject stdhandler = 0;

#include <windows.h>
#include <stdlib.h>
#include <string.h>
#if WIN32_MATHLINK && !defined(_fstrncpy)
#       define _fstrncpy strncpy
#endif

#ifndef CALLBACK
#define CALLBACK FAR PASCAL
typedef LONG LRESULT;
typedef unsigned int UINT;
typedef WORD WPARAM;
typedef DWORD LPARAM;
#endif


LRESULT CALLBACK MLEXPORT
IconProcedure( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch( msg){
	case WM_CLOSE:
		MLDone = 1;
		MLAbort = 1;
		break;
	case WM_QUERYOPEN:
		return 0;
	}
	return DefWindowProc( hWnd, msg, wParam, lParam);
}


HWND MLInitializeIcon( HANDLE hInstance, int nCmdShow)
{
	char path_name[260], *icon_name;
	WNDCLASS  wc;

	MLInstance = hInstance;
	if( ! nCmdShow) return (HWND)0;

	(void)GetModuleFileName( hInstance, path_name, sizeof(path_name));
	icon_name = strrchr( path_name, '\\') + 1;
	*strchr( icon_name, '.') = '\0';

	wc.style = 0;
	wc.lpfnWndProc = IconProcedure;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = LoadIcon( NULL, IDI_APPLICATION);
	wc.hCursor = LoadCursor( hInstance, IDC_ARROW);
	wc.hbrBackground = GetStockObject( WHITE_BRUSH);
	wc.lpszMenuName =  (LPSTR) 0;
	wc.lpszClassName = "mprepIcon";
	(void)RegisterClass( &wc);

	MLIconWindow = CreateWindow( "mprepIcon", icon_name,
			WS_OVERLAPPEDWINDOW | WS_MINIMIZE, CW_USEDEFAULT,
			CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
			(HWND)0, (HMENU)0, hInstance, (void FAR*)0);

	if( MLIconWindow){
		ShowWindow( MLIconWindow, SW_MINIMIZE);
		UpdateWindow( MLIconWindow);
	}
	return MLIconWindow;
}


#if __BORLANDC__
#pragma argsused
#endif

MLYDEFN( devyield_result, MLDefaultYielder, ( MLINK mlp, MLYieldParameters yp))
{
	MSG msg;

#if !__BORLANDC__
	mlp = mlp; /* suppress unused warning */
	yp = (MLYieldParameters)0; /* suppress unused warning */
#endif

	if( PeekMessage( &msg, (HWND)0, 0, 0, PM_REMOVE))
	{
		TranslateMessage( &msg);
		DispatchMessage( &msg);
	}
	return MLDone;
}


/* To launch this program from within Mathematica use:
 *   In[1]:= link = Install["sumalist"]
 *
 * Or, launch this program from a shell and establish a
 * peer-to-peer connection.  When given the prompt Create Link:
 * type a port name. ( On Unix platforms, a port name is a
 * number less than 65536.  On Mac or Windows platforms,
 * it's an arbitrary word.)
 * Then, from within Mathematica use:
 *   In[1]:= link = Install["portname", LinkMode->Connect]
 */

#include "mathlink.h"

int openOrchestra P((const char *filename));

int addNotes P((int fieldCount, int noteCount, double *fields, long totalCount));

int clearNotes P(());



int openOrchestra P(( kcharp_ct _tp1));

#if MLPROTOTYPES
static int _tr0( MLINK mlp)
#else
static int _tr0(mlp) MLINK mlp;
#endif
{
	int	res = 0;
	int _tp0;
	kcharp_ct _tp1;
	if ( ! pMLGetString( mlp, &_tp1) ) goto L0;
	if ( ! pMLNewPacket(mlp) ) goto L1;

	_tp0 = openOrchestra(_tp1);

	res = MLAbort ?
		pMLPutFunction( mlp, "Abort", 0) : pMLPutInteger( mlp, _tp0);
L1:	pMLDisownString(mlp, _tp1);

L0:	return res;
} /* _tr0 */


int addNotes P(( int _tp1, int _tp2, doublep_nt _tp3, long _tpl3));

#if MLPROTOTYPES
static int _tr1( MLINK mlp)
#else
static int _tr1(mlp) MLINK mlp;
#endif
{
	int	res = 0;
	int _tp0;
	int _tp1;
	int _tp2;
	doublep_nt _tp3;
	long _tpl3;
	if ( ! pMLGetInteger( mlp, &_tp1) ) goto L0;
	if ( ! pMLGetInteger( mlp, &_tp2) ) goto L1;
	if ( ! pMLGetRealList( mlp, &_tp3, &_tpl3) ) goto L2;
	if ( ! pMLNewPacket(mlp) ) goto L3;

	_tp0 = addNotes(_tp1, _tp2, _tp3, _tpl3);

	res = MLAbort ?
		pMLPutFunction( mlp, "Abort", 0) : pMLPutInteger( mlp, _tp0);
L3:	pMLDisownRealList( mlp, _tp3, _tpl3);
L2: L1: 
L0:	return res;
} /* _tr1 */


int clearNotes P(( void));

#if MLPROTOTYPES
static int _tr2( MLINK mlp)
#else
static int _tr2(mlp) MLINK mlp;
#endif
{
	int	res = 0;
	int _tp0;
	if ( ! pMLNewPacket(mlp) ) goto L0;

	_tp0 = clearNotes();

	res = MLAbort ?
		pMLPutFunction( mlp, "Abort", 0) : pMLPutInteger( mlp, _tp0);

L0:	return res;
} /* _tr2 */


static struct func {
	int   f_nargs;
	int   manual;
	int   (*f_func)P((MLINK));
	char  *f_name;
	} _tramps[3] = {
		{ 1, 0, _tr0, "openOrchestra" },
		{ 3, 0, _tr1, "addNotes" },
		{ 0, 0, _tr2, "clearNotes" }
		};


static int  _definepattern P(( MLINK, char*, char*, int));

int  _MLDoCallPacket P(( MLINK, struct func[], int));


#if MLPROTOTYPES
int MLInstall( MLINK mlp)
#else
int MLInstall(mlp) MLINK mlp;
#endif
{
	int _res;
	_res = pMLConnect(mlp);
	if (_res) _res =  _definepattern(mlp, "OpenOrchestra[Filename_String]", "{Filename}", 0);
	if (_res) _res =  _definepattern(mlp, "AddNotes[ScoreList_List]", "{N[Length[ScoreList[[1]]]], N[Length[ScoreList]], N[Flatten[ScoreList]]}", 1);
	if (_res) _res =  _definepattern(mlp, "ClearNotes[]", "{}", 2);
	if (_res) _res = pMLPutSymbol( mlp, "End");
	if (_res) _res = pMLFlush( mlp);
	return _res;
} /* MLInstall */


#if MLPROTOTYPES
int MLDoCallPacket( MLINK mlp)
#else
int MLDoCallPacket( mlp) MLINK mlp;
#endif
{
	return _MLDoCallPacket( mlp, _tramps, 3);
} /* MLDoCallPacket */


static int  _definepattern( MLINK mlp, char *patt, char *args, int func_n)
{
	pMLPutFunction( mlp, "DefineExternal", (long)3);
	  pMLPutString( mlp, patt);
	  pMLPutString( mlp, args);
	  pMLPutInteger( mlp, func_n);
	return !pMLError(mlp);
} /* _definepattern */


int _MLDoCallPacket( MLINK mlp, struct func functable[], int nfuncs)
{
	long len;
	int n, res = 0;
	struct func* funcp;

	if( ! pMLGetInteger( mlp, &n) ||  n < 0 ||  n >= nfuncs) goto L0;
	funcp = &functable[n];

	if( funcp->f_nargs >= 0
	&& ( ! pMLCheckFunction(mlp, "List", &len)
	     || ( !funcp->manual && (len != funcp->f_nargs))
	     || (  funcp->manual && (len <  funcp->f_nargs))
	   )
	) goto L0;

	stdlink = mlp;
	res = (*funcp->f_func)( mlp);

L0:	if( res == 0)
		res = pMLClearError( mlp) && pMLPutSymbol( mlp, "$Failed");
	return res && pMLEndPacket( mlp) && pMLNewPacket( mlp);
} /* _MLDoCallPacket */


int MLAnswer( MLINK mlp)
{
	int pkt = 0;

	while( !MLDone && !pMLError(mlp)
	&& (pkt = pMLNextPacket(mlp), pkt) && pkt == CALLPKT){
		MLAbort = 0;
		if( !MLDoCallPacket(mlp)) pkt = 0;
	}
	MLAbort = 0;
	return pkt;
}



/*
	Module[ { me = $ParentLink},
		$ParentLink = contents of RESUMEPKT;
		Message[ MessageName[$ParentLink, "notfe"], me];
		me]
*/

static int refuse_to_be_a_frontend( MLINK mlp)
{
	int pkt;

	pMLPutFunction( mlp, "EvaluatePacket", 1);
	  pMLPutFunction( mlp, "Module", 2);
	    pMLPutFunction( mlp, "List", 1);
		  pMLPutFunction( mlp, "Set", 2);
		    pMLPutSymbol( mlp, "me");
	        pMLPutSymbol( mlp, "$ParentLink");
	  pMLPutFunction( mlp, "CompoundExpression", 3);
	    pMLPutFunction( mlp, "Set", 2);
	      pMLPutSymbol( mlp, "$ParentLink");
	      pMLTransferExpression( mlp, mlp);
	    pMLPutFunction( mlp, "Message", 2);
	      pMLPutFunction( mlp, "MessageName", 2);
	        pMLPutSymbol( mlp, "$ParentLink");
	        pMLPutString( mlp, "notfe");
	      pMLPutSymbol( mlp, "me");
	    pMLPutSymbol( mlp, "me");
	pMLEndPacket( mlp);

	while( (pkt = pMLNextPacket( mlp), pkt) && pkt != SUSPENDPKT)
		pMLNewPacket( mlp);
	pMLNewPacket( mlp);
	return pMLError( mlp) == MLEOK;
}


int MLEvaluate( MLINK mlp, charp_ct s)
{
	if( MLAbort) return 0;
	return pMLPutFunction( mlp, "EvaluatePacket", 1L)
		&& pMLPutFunction( mlp, "ToExpression", 1L)
		&& pMLPutString( mlp, s)
		&& pMLEndPacket( mlp);
}


int MLEvaluateString( MLINK mlp, charp_ct s)
{
	int pkt;
	if( MLAbort) return 0;
	if( MLEvaluate( mlp, s)){
		while( (pkt = MLAnswer( mlp), pkt) && pkt != RETURNPKT)
			pMLNewPacket( mlp);
		pMLNewPacket( mlp);
	}
	return pMLError( mlp) == MLEOK;
} /* MLEvaluateString */


#if __BORLANDC__
#pragma argsused
#endif

MLMDEFN( void, MLDefaultHandler, ( MLINK mlp, unsigned long message, unsigned long n))
{
#if !__BORLANDC__
	mlp = (MLINK)0; /* suppress unused warning */
	n = 0;          /* suppress unused warning */
#endif

	switch (message){
	case MLTerminateMessage:
		MLDone = 1;
	case MLInterruptMessage:
	case MLAbortMessage:
		MLAbort = 1;
	default:
		return;
	}
}



static int _MLMain( charpp_ct argv, charpp_ct argv_end, charp_ct commandline)
{
	MLINK mlp;
	long err;

	if( !stdenv)
		stdenv = pMLInitialize( (MLParametersPointer)0);
	if( stdenv == (MLEnvironment)0) goto R0;

	if( !stdyielder)
		stdyielder = pMLCreateYieldFunction( stdenv,
			NewMLYielderProc( MLDefaultYielder), 0);
	if( !stdhandler)
		stdhandler = pMLCreateMessageHandler( stdenv,
			NewMLHandlerProc( MLDefaultHandler), 0);


	mlp = commandline
		? pMLOpenString( stdenv, commandline, &err)
		: pMLOpenArgv( stdenv, argv, argv_end, &err);
	if( mlp == (MLINK)0){
		pMLAlert( stdenv, pMLErrorString( stdenv, err));
		goto R1;
	}

	if( MLIconWindow){
		char textbuf[64];
		int len;
		len = GetWindowText(MLIconWindow, textbuf, sizeof(textbuf)-2);
		strcat( textbuf + len, "(");
		_fstrncpy( textbuf + len + 1, pMLName(mlp), sizeof(textbuf) - len - 3);
		textbuf[sizeof(textbuf) - 2] = '\0';
		strcat( textbuf, ")");
		SetWindowText( MLIconWindow, textbuf);
	}

	if( MLInstance){
		if( stdyielder) pMLSetYieldFunction( mlp, stdyielder);
		if( stdhandler) pMLSetMessageHandler( mlp, stdhandler);
	}

	if( MLInstall( mlp))
		while( MLAnswer( mlp) == RESUMEPKT){
			if( ! refuse_to_be_a_frontend( mlp)) break;
		}

	pMLClose( mlp);
R1:	pMLDeinitialize( stdenv);
	stdenv = (MLEnvironment)0;
R0:	return !MLDone;
} /* _MLMain */


int MLMainString( charp_ct commandline)
{
	return _MLMain( (charpp_ct)0, (charpp_ct)0, commandline);
}

int MLMainArgv( char** argv, char** argv_end) /* note not FAR pointers */
{   
	static char FAR * far_argv[128];
	int count = 0;
	
	while(argv < argv_end)
		far_argv[count++] = *argv++;
		 
	return _MLMain( far_argv, far_argv + count, (charp_ct)0);

}

int MLMain( int argc, charpp_ct argv)
{
 	return _MLMain( argv, argv + argc, (charp_ct)0);
}
 
