#ifndef __SCOREPAGE_H_
#define __SCOREPAGE_H_
#include "resource.h"

EXTERN_C const CLSID CLSID_ScorePage;

class ATL_NO_VTABLE CScorePage :
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CScorePage, &CLSID_ScorePage>,
	public IPropertyPageImpl<CScorePage>,
	public CDialogImpl<CScorePage>
{
public:
	enum {IDD = IDD_SCOREPAGE};
DECLARE_REGISTRY_RESOURCEID(IDR_SCOREPAGE)
BEGIN_COM_MAP(CScorePage) 
	COM_INTERFACE_ENTRY_IMPL(IPropertyPage)
END_COM_MAP()
BEGIN_MSG_MAP(CScorePage)
	MESSAGE_HANDLER(WM_PAINT, OnPaint)
	COMMAND_HANDLER(IDC_CLEAR_SCORE, BN_CLICKED, OnClearScore)
	COMMAND_HANDLER(IDC_SCORE_EDIT, EN_CHANGE, OnChange)
	COMMAND_HANDLER(IDC_CLEAR_NOTES_ONLY, BN_CLICKED, OnClearNotesOnly)
	CHAIN_MSG_MAP(IPropertyPageImpl<CScorePage>)
END_MSG_MAP()
public:
	CScorePage();
	LRESULT OnPaint(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnClearScore(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
	LRESULT OnClearNotesOnly(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
	LRESULT OnChange(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
	STDMETHOD(Apply)(void);
	STDMETHOD(Activate)(HWND hWndParent, LPCRECT pRect, BOOL bModal);
	STDMETHOD(Help)(LPCOLESTR pszHelpDir);
	void updateView();
	void updateModel();
};

#endif //__SCOREPAGE_H_
