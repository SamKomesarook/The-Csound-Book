#ifndef __AXCSOUND_H_
#define __AXCSOUND_H_
#include "resource.h"
#include "CommandPage.h"
#include "InstrumentsPage.h"
#include "ScorePage.h"
#include "AXCsound.h"
#include <commctrl.h>
#include <richedit.h>
#include <Csound.h>
#include <CsoundFile.h>
#include <string>

extern "C" void CSLogCallback(const char *message);

class WaitCursor
{
	HCURSOR oldCursor;
public:
	WaitCursor()
	{
		oldCursor = SetCursor(LoadCursor(0, IDC_WAIT));
	}
	~WaitCursor()
	{
		SetCursor(oldCursor);
	}
};

//	An implementation of CComControl using CDialogImpl instead of CWindowImpl.

template <class T>
class ATL_NO_VTABLE CComDialogControl : public CComControlBase, public CDialogImpl<T>
{
public:
	CComDialogControl() : CComControlBase(m_hWnd) 
	{
	}
	HRESULT FireOnRequestEdit(DISPID dispID)
	{
		T* pT = static_cast<T*>(this);
		return T::__ATL_PROP_NOTIFY_EVENT_CLASS::FireOnRequestEdit(pT->GetUnknown(), dispID);
	}
	HRESULT FireOnChanged(DISPID dispID)
	{
		T* pT = static_cast<T*>(this);
		return T::__ATL_PROP_NOTIFY_EVENT_CLASS::FireOnChanged(pT->GetUnknown(), dispID);
	}
	virtual HRESULT ControlQueryInterface(const IID& iid, void** ppv)
	{
		T* pT = static_cast<T*>(this);
		return pT->_InternalQueryInterface(iid, ppv);
	}
	virtual HWND CreateControlWindow(HWND hWndParent, RECT& rcPos)
	{
		T* pT = static_cast<T*>(this);
		//	Instead of: 
		//	return pT->Create(hWndParent, rcPos);
		return pT->Create(hWndParent);
	}
};

class ATL_NO_VTABLE CAXCsound : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CAXCsound, &CLSID_AXCsound>,
	public CComDialogControl<CAXCsound>, //CComControl<CAXCsound>,
	public IDispatchImpl<IAXCsound, &IID_IAXCsound, &LIBID_AXCSOUNDLib>,
	public IProvideClassInfo2Impl<&CLSID_AXCsound, NULL, &LIBID_AXCSOUNDLib>,
	public IPersistStreamInitImpl<CAXCsound>,
	public IPersistStorageImpl<CAXCsound>,
	public IQuickActivateImpl<CAXCsound>,
	public IOleControlImpl<CAXCsound>,
	public IOleObjectImpl<CAXCsound>,
	public IOleInPlaceActiveObjectImpl<CAXCsound>,
	public IViewObjectExImpl<CAXCsound>,
	public IOleInPlaceObjectWindowlessImpl<CAXCsound>,
	public IDataObjectImpl<CAXCsound>,
	public IConnectionPointContainerImpl<CAXCsound>,
	public ISpecifyPropertyPagesImpl<CAXCsound>
{
public:
	enum 
	{
		IDD = IDD_CONTROLDIALOG
	};
DECLARE_REGISTRY_RESOURCEID(IDR_AXCSOUND)
BEGIN_COM_MAP(CAXCsound)
	COM_INTERFACE_ENTRY(IAXCsound)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY_IMPL(IViewObjectEx)
	COM_INTERFACE_ENTRY_IMPL_IID(IID_IViewObject2, IViewObjectEx)
	COM_INTERFACE_ENTRY_IMPL_IID(IID_IViewObject, IViewObjectEx)
	COM_INTERFACE_ENTRY_IMPL(IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY_IMPL_IID(IID_IOleInPlaceObject, IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY_IMPL_IID(IID_IOleWindow, IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY_IMPL(IOleInPlaceActiveObject)
	COM_INTERFACE_ENTRY_IMPL(IOleControl)
	COM_INTERFACE_ENTRY_IMPL(IOleObject)
	COM_INTERFACE_ENTRY_IMPL(IQuickActivate)
	COM_INTERFACE_ENTRY_IMPL(IPersistStorage)
	COM_INTERFACE_ENTRY_IMPL(IPersistStreamInit)
	COM_INTERFACE_ENTRY_IMPL(ISpecifyPropertyPages)
	COM_INTERFACE_ENTRY_IMPL(IDataObject)
	COM_INTERFACE_ENTRY(IProvideClassInfo)
	COM_INTERFACE_ENTRY(IProvideClassInfo2)
	COM_INTERFACE_ENTRY_IMPL(IConnectionPointContainer)
END_COM_MAP()
BEGIN_PROPERTY_MAP(CAXCsound)
	PROP_PAGE(CLSID_CommandPage)
	PROP_PAGE(CLSID_InstrumentsPage)
	PROP_PAGE(CLSID_ScorePage)
	PROP_PAGE(CLSID_Copyright)
END_PROPERTY_MAP()
BEGIN_CONNECTION_POINT_MAP(CAXCsound)
END_CONNECTION_POINT_MAP()
BEGIN_MSG_MAP(CAXCsound)
	MESSAGE_HANDLER(WM_PAINT, OnPaint)
	MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
	MESSAGE_HANDLER(WM_SETFOCUS, OnSetFocus)
	MESSAGE_HANDLER(WM_KILLFOCUS, OnKillFocus)
	MESSAGE_HANDLER(WM_CREATE, OnCreate)
	MESSAGE_HANDLER(WM_MOUSEACTIVATE, OnMouseActivate)
	COMMAND_HANDLER(IDOPEN, BN_CLICKED, OnOpen)
	COMMAND_HANDLER(IDSAVE, BN_CLICKED, OnSave)
	COMMAND_HANDLER(IDIMPORT, BN_CLICKED, OnImport)
	COMMAND_HANDLER(IDPROPERTIES, BN_CLICKED, OnProperties)
	NOTIFY_HANDLER(IDC_MAIN_SPIN_PLAY, UDN_DELTAPOS, OnPlayOrStop)
	COMMAND_HANDLER(IDOPENSOUND, BN_CLICKED, OnOpenSound)
ALT_MSG_MAP(1)
END_MSG_MAP()
public:
	CAXCsound();
	LRESULT OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL &bHandled);
	LRESULT OnMouseActivate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL &bHandled);
	LRESULT OnOpen(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL &bHandled);
	LRESULT OnSave(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL &bHandled);
	LRESULT OnImport(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL &bHandled);
	LRESULT OnProperties(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL &bHandled);
	LRESULT OnPlayOrStop(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);
	LRESULT OnOpenSound(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL &bHandled);
	STDMETHOD(SetObjectRects)(LPCRECT prcPos,LPCRECT prcClip);
	STDMETHOD(GetViewStatus)(DWORD* pdwStatus);
	STDMETHOD(TranslateAccelerator)(MSG *pMsg);
protected:
	Csound csound;
	CsoundFile csoundFile;
	unsigned int renderingThread;
	std::string helpFilename;
	//	IAXCsound
public:
	STDMETHOD(get_OutputSoundfileName)(BSTR *pValue);
	STDMETHOD(Play)(void);
	STDMETHOD(Pause)(void);
	STDMETHOD(Resume)(void);
	STDMETHOD(Stop)(void);
	STDMETHOD(Open)(BSTR Filename);
	STDMETHOD(Import)(BSTR Filename);
	STDMETHOD(Save)(BSTR Filename);
	STDMETHOD(Export)(BSTR Filename);
	STDMETHOD(OpenSound)(void);
	STDMETHOD(get_Filename)(BSTR *pValue);
	STDMETHOD(put_Filename)(BSTR Value);
	STDMETHOD(get_Command)(BSTR *pValue);
	STDMETHOD(put_Command)(BSTR Value);
	STDMETHOD(get_OrcFilename)(BSTR *pValue);
	STDMETHOD(get_ScoFilename)(BSTR *pValue);
	STDMETHOD(get_MidiFilename)(BSTR *pValue);
	STDMETHOD(get_Score)(BSTR *pValue);
	STDMETHOD(put_Score)(BSTR Value);
	STDMETHOD(get_ScoreLine)(long Index, BSTR *pValue);
	STDMETHOD(put_ScoreLine)(long Index, BSTR Value);
	STDMETHOD(AddScoreLine)(BSTR Value);
	STDMETHOD(AddNote10)(double p1, double p2, double p3, double p4, double p5, double p6, double p7, double p8, double p9, double p10);
	STDMETHOD(AddNote9)(double p1, double p2, double p3, double p4, double p5, double p6, double p7, double p8, double p9);
	STDMETHOD(AddNote8)(double p1, double p2, double p3, double p4, double p5, double p6, double p7, double p8);
	STDMETHOD(AddNote7)(double p1, double p2, double p3, double p4, double p5, double p6, double p7);
	STDMETHOD(AddNote6)(double p1, double p2, double p3, double p4, double p5, double p6);
	STDMETHOD(AddNote5)(double p1, double p2, double p3, double p4, double p5);
	STDMETHOD(AddNote4)(double p1, double p2, double p3, double p4);
	STDMETHOD(AddNote3)(double p1, double p2, double p3);
	STDMETHOD(get_ScoreLineCount)(long *pValue);
	STDMETHOD(put_ScoreLineCount)(long NewValue);
	STDMETHOD(get_Orchestra)(BSTR *pValue);
	STDMETHOD(put_Orchestra)(BSTR Value);
	STDMETHOD(RemoveAll)(void);
	STDMETHOD(RemoveCommand)(void);
	STDMETHOD(RemoveOrchestra)(void);
	STDMETHOD(RemoveScore)(void);
	STDMETHOD(RemoveScoreExceptFunctions)(void);
	STDMETHOD(InitNew)();
	STDMETHOD(IsDirty)();
	STDMETHOD(GetSizeMax)(ULARGE_INTEGER FAR* pcbSize);
	STDMETHOD(Load)(LPSTREAM pStream);
	STDMETHOD(Save)(LPSTREAM pStream, BOOL fClearDirty);
	STDMETHOD(InitFromData)(IDataObject *pDataObject, BOOL fCreation, DWORD dwReserved); 
	STDMETHOD(Help)(LPCOLESTR pszHelpDir);

};

#endif //__AXCSOUND_H_
