					
/* some routines for Windows by Gabriel Maldonado */
#include <stdio.h>
#include <windows.h>
#include <wincon.h>
#ifdef GAB_RT
#include "cs.h"
#include "version.h"

int rows=0 , columns=0;
int exit_soon_flag=0;
void exit_soon() { exit_soon_flag=1;}

void set_rows(int n) {
	rows = n;
}

void set_columns( int n) {
 	columns = n;
}
void console_rows()
{
#ifndef CSOUND_REENTRANT_API
	HANDLE cons_handle;
	COORD coord, firstcell;
	DWORD scritti;
	int xret;

	if (!columns && rows) columns=81;
	if (!rows && columns) rows = 26;
	coord.X=columns;
	coord.Y=rows;
 	firstcell.X=0;
	firstcell.Y=0;
 	cons_handle=GetStdHandle(STD_OUTPUT_HANDLE	);
	//if (columns || rows)
	xret = SetConsoleScreenBufferSize(cons_handle, coord);
	xret = SetConsoleTextAttribute( cons_handle,
    						  BACKGROUND_BLUE
    						| BACKGROUND_GREEN
    						| BACKGROUND_RED
    						| BACKGROUND_INTENSITY 
	);

   	if (!columns) { coord.X = 100; coord.Y = 100; }
   	
   	FillConsoleOutputAttribute(
    	cons_handle,	// handle of screen buffer 
    	  BACKGROUND_BLUE
    	| BACKGROUND_GREEN
    	| BACKGROUND_RED
    	| BACKGROUND_INTENSITY,	// color attribute to write 
    	coord.X * coord.Y,	// number of character cells to write to 
    	firstcell,	// x- and y-coordinates of first cell 
    	&scritti	// address of number of cells written to 
    );
    if (columns || rows)  xret =  ShowWindow( cons_handle,  SW_SHOWMAXIMIZED	   );	
#endif	//	CSOUND_REENTRANT_API
}

void console_title()
{
#ifdef CSOUND_REENTRANT_API
	char stringa[256];
	HANDLE cons_handle;
 	cons_handle=GetStdHandle(STD_OUTPUT_HANDLE	);
	sprintf(stringa, "DirectCsound 2.1 (updated to standard ver.%d.%d)", VERSION, SUBVER);
  	SetConsoleTitle(stringa);	
#endif	//	CSOUND_REENTRANT_API
}

void getgab() {
#ifndef CSOUND_REENTRANT_API
	if (exit_soon_flag) return;
	printf("\npress <RETURN> to terminate program...");
	getchar();
#endif
}
#endif
 /*
void set_current_process_priority_critical()
{
 	 BOOL nRet;
 	 HANDLE currProcess, currThread;
 	 currProcess=GetCurrentProcess();
	 nRet=SetPriorityClass(  currProcess, REALTIME_PRIORITY_CLASS);
	 currThread = GetCurrentThread();
	 nRet=SetThreadPriority( currThread,  THREAD_PRIORITY_HIGHEST );
}


void set_current_process_priority_normal()
{
 	 BOOL nRet;
 	 HANDLE currProcess, currThread;
 	 currProcess=GetCurrentProcess();
	 nRet=SetPriorityClass(  currProcess, NORMAL_PRIORITY_CLASS	);
	 currThread = GetCurrentThread();
	 nRet=SetThreadPriority( currThread,  THREAD_PRIORITY_NORMAL );
}
*/

void dieu_gab(char *s, char *title)
{
 		MessageBox( NULL,	// handle of owner window
				s,	// address of text in message box
                title,	// address of title of message box  
                MB_SYSTEMMODAL | MB_ICONSTOP 	// style of message box
		);
}
