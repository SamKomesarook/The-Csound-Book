#ifndef __INSTRUMENTSPAGE_H_
#define __INSTRUMENTSPAGE_H_
#include "resource.h"
#include "AXCsound.h"

EXTERN_C const CLSID CLSID_InstrumentsPage;

class ATL_NO_VTABLE CInstrumentsPage :
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CInstrumentsPage, &CLSID_InstrumentsPage>,
	public IPropertyPageImpl<CInstrumentsPage>,
	public CDialogImpl<CInstrumentsPage>
{
public:
	enum {IDD = IDD_INSTRUMENTSPAGE};
DECLARE_REGISTRY_RESOURCEID(IDR_INSTRUMENTSPAGE)
BEGIN_COM_MAP(CInstrumentsPage) 
	COM_INTERFACE_ENTRY_IMPL(IPropertyPage)
END_COM_MAP()
BEGIN_MSG_MAP(CInstrumentsPage)
	MESSAGE_HANDLER(WM_PAINT, OnPaint)
	COMMAND_HANDLER(IDC_EDIT_ORCHESTRA, EN_UPDATE, OnChange)
	COMMAND_HANDLER(IDC_EDIT_ORCHESTRA, EN_CHANGE, OnChange)
	CHAIN_MSG_MAP(IPropertyPageImpl<CInstrumentsPage>)
END_MSG_MAP()
public:
	CInstrumentsPage();
	LRESULT OnPaint(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnChange(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
	STDMETHOD(Apply)(void);
	STDMETHOD(Activate)(HWND hWndParent, LPCRECT pRect, BOOL bModal);
	STDMETHOD(Help)(LPCOLESTR pszHelpDir);
protected:
	void updateView();
	void updateModel();
};

#endif //__INSTRUMENTSPAGE_H_
