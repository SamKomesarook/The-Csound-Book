/* Resonant Lowpass filters by G.Maldonado */

#include <math.h>
#include "cs.h"
#include "LowPassRes.h"

void lowpr_set(LOWPR *p)
{
	p->ynm1 = p->ynm2 = 0.;
}


void lowpr(LOWPR *p)
{
	float b, k;
	float *ar, *asig, yn,*ynm1, *ynm2 ;
	float kfco = *p->kfco, kres = *p->kres;
	register float coef1, coef2;
	int	nsmps = ksmps;
		
/*	b = 10.0 / *p->kres / sqrt(kfco) - 1.0 ;*/
	b = (float)(10.0 / (*p->kres * sqrt(kfco)) - 1.0 );
	k = 1000.0f / kfco;
	coef1=(b+2*k);
	coef2=1/(1 + b + k);

	ar = p->ar;
	asig = p->asig;
	ynm1 = &(p->ynm1);
	ynm2 = &(p->ynm2);

	do {
		*ar++ = yn = (coef1 * *ynm1 - k * *ynm2 + *asig++) * coef2;
		*ynm2 = *ynm1;
		*ynm1 =  yn;
	} while (--nsmps);
}


void lowpr_setx(LOWPRX *p)
{
	int j;
	if((p->loop = (int) (*p->ord + .5)) < 1) p->loop = 4; /*default value*/
	else if (p->loop > 10)
		initerror("illegal order num. (min 1, max 10)");

	for (j=0; j< p->loop; j++)  p->ynm1[j] = p->ynm2[j] = 0.;

}

void lowprx(LOWPRX *p)
{
	float b, k;
	float *ar, *asig, yn,*ynm1, *ynm2 ;
	register float coef1, coef2;
	float kfco = *p->kfco;
	register int	nsmps, j;

	/* b = 10.0 / *p->kres / sqrt(kfco) - 1.0 ;*/
	b = (float)(10.0f / (*p->kres * sqrt(kfco)) - 1.0f );
	k = 1000.0f / kfco;
	coef1=(b+2*k);
	coef2=1/(1 + b + k);
	
	ynm1 = p->ynm1;
	ynm2 = p->ynm2;
	asig = p->asig;
	
	for (j=0; j< p->loop; j++) {
		nsmps = ksmps;
		ar = p->ar;
		do {
			*ar++ = yn = (coef1 * *ynm1 - k * *ynm2 + *asig++) * coef2;
			*ynm2 = *ynm1;
			*ynm1 =  yn;
		} while (--nsmps);
		ynm1++;
		ynm2++;
		asig= p->ar;
	}
}


void lowpr_w_sep_set(LOWPR_SEP *p)
{
	int j;
	if((p->loop = (int) (*p->ord + .5)) < 1) p->loop = 4; /*default value*/
	else if (p->loop > 10)
		initerror("illegal order num. (min 1, max 10)");

	for (j=0; j< p->loop; j++)  p->ynm1[j] = p->ynm2[j] = 0.;

}



void lowpr_w_sep(LOWPR_SEP *p)
{
	float b, k;
	float *ar, *asig, yn,*ynm1, *ynm2 ;
	register float coef1, coef2;
	float kfcobase = *p->kfco;
	float sep = (*p->sep / p->loop);
	register int	nsmps, j;
	/*register double	linfco;*/
	float kres = *p->kres;
	float kfco;
	ynm1 = p->ynm1;
	ynm2 = p->ynm2;
	asig = p->asig;

	
	for (j=0; j< p->loop; j++) {
		/*
		linfco=log((double) kfco)*ONEtoLOG2	;
		linfco = linfco + (sep / p->loop)*j;
		kfco = (float) pow(2.,linfco);
		*/
		kfco = kfcobase * (1 + (sep * j));
		
		
		b = (float)(10.0 / ( kres * sqrt(kfco)) - 1.0 );
		k = 1000.0f / kfco;
		coef1=(b+2*k);
		coef2=1/(1 + b + k);
	
	
		nsmps = ksmps;
		ar = p->ar;
		do {
			*ar++ = yn = (coef1 * *ynm1 - k * *ynm2 + *asig++) * coef2;
			*ynm2 = *ynm1;
			*ynm1 =  yn;
		} while (--nsmps);
		ynm1++;
		ynm2++;
		asig= p->ar;

	}
}

