typedef struct	{
	OPDS	h;
	float	*out, *amp, *freq, *ift, *iphs;
	FUNC	*ftp;
	long	tablen;
	double	phs;
} POSC;

typedef struct	{
	OPDS	h;
	float	*out, *amp, *freq, *kloop, *kend, *ift, *iphs;
	FUNC	*ftp;
	long	tablen;
	float	fsr;
	double	phs, looplength;

} LPOSC;
