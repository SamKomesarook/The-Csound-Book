#include <stdio.h>
#include <string.h>
#include "cs.h"  
#include "fout.h"  

void wavWriteHdr2(FILE * fd, int sampsize, int nchls, double sr);
void wavReWriteHdr2(FILE * fd, long datasize);
extern long kcounter;
//void (*outfilep) (OUTFILE *p);

float *aout[64];

void outfile_float (OUTFILE *p) 
{
	int nsmps= ksmps, j, nargs = p->nargs;
	for (j = 0; j< nargs; j++) {
		aout[j]= p->argums[j];
	}
	
	do {
		for (j = 0;j< nargs;j++) fwrite( aout[j]++, sizeof(float),1,p->fp);
	} while (--nsmps);
}

void outfile_int (OUTFILE *p) 
{
	int nsmps= ksmps, j,nargs = p->nargs;
	short temp;
	for (j = 0; j< nargs; j++) {
		aout[j]= p->argums[j];
	}
	do {
		for (j = 0;j< nargs;j++) {
			temp = (short)	 *(aout[j]++);
			fwrite( &temp, sizeof(short),1,p->fp);
		}
	} while (--nsmps);
}

void outfile_int_head (OUTFILE *p) 
{
	int nsmps= ksmps, j,nargs = p->nargs;
	short temp;
	for (j = 0; j< nargs; j++) {
		aout[j]= p->argums[j];
	}
	do {
		for (j = 0;j< nargs;j++) {
			temp = (short)	 *(aout[j]++);
			fwrite( &temp, sizeof(short),1,p->fp);
		}
	} while (--nsmps);
	if (!(kcounter % 50))
		wavReWriteHdr2(p->fp, kcounter * ksmps * sizeof(short)*nargs); 
}




void outfile_set(OUTFILE *p) 
{
	float **args = p->argums;
	char fname[256];
	
	p->nargs = p->INOCOUNT-2 ; 
	/*if (*p->fname == sstrcod)   */       /* if char string name given */
    /*    strcpy(fname,unquote(p->STRARG)); */   /*     unquote it,  else use */
    if (*p->fname == sstrcod) {/*gab B1*/ /* if char string name given */
		extern EVTBLK *currevent; /*gab B1*/
		extern char *unquote(char *name);
		if (p->STRARG == NULL) strcpy(fname,unquote(currevent->strarg)); /*gab B1*/
		else strcpy(fname, unquote(p->STRARG));
	} 
	else dies ("fout: problems opening outfile %s",fname);
	if( (_access( fname, 0 )) != -1 )
		 if (access(fname, 0x6))
			  chmod(fname, S_IREAD | S_IWRITE); /* Make read-write */
	if (( p->fp = fopen(fname,"wb")) == NULL)
	    dies("fout: cannot open outfile %s",fname);

	switch((int) (*p->iflag+.5)) {
		case 0:
			p->outfilep = outfile_int;
			break;
		case 1:
			p->outfilep = outfile_float;
			break;
		case 2:
			p->outfilep = outfile_int_head;
			wavWriteHdr2(               /* Write WAV header at start of file.  */
				p->fp,                  /* Called after open, before data writes*/
				2,						/* sample size in bytes */
				p->nargs,
				esr);          
			break;
		case 3:
			//p->outfilep = outfile_float_head;
			break;
		default:
			p->outfilep = outfile_int;
	}

}

void outfile (OUTFILE *p) 
{
	p->outfilep(p);
}



void incr_set (INCR *p)
{
	
}


void incr (INCR *p)
{
	float *avar = p->avar, *aincr = p->aincr;
	int nsmps= ksmps;
	do 	*(avar++) += *(aincr++);
	while (--nsmps);
}


void clear_set (CLEARS *p)
{
	
}


void clear (CLEARS *p)
{
	int nsmps= ksmps,j;
	float *avar;
	for (j=0;j< p->INOCOUNT;j++) {
		avar = p->argums[j];
		nsmps= ksmps;
		do 	*(avar++) = 0.;
		while (--nsmps);
	}
}

#include        "soundio.h"
#include        "wave.h"
#include        "sfheader.h"
#include        <math.h>
static struct wav_head formhdr;
static long   framesize;
/* RWD.2.98 to avoid recalculating  variable  headersizes */
static long	this_hdrsize	= 0;
static short	this_format	= 0;
static long	datasize_offset	= 0;
static long	factchunk_offset= 0;
static long	nchans		= 0;


static short lenshort(short sval) /* coerce a natural short into a littlendian short */
{
    char  benchar[2];
    char *p = benchar;

    *p++ = 0xFF & sval;
    *p   = 0xFF & (sval >> 8);
    return(*(short *)benchar);
}

static long lenlong(long lval)     /* coerce a natural long into a littlendian long */
{
    char  benchar[4];
    char *p = benchar;

    *p++ = (char)(0xFF & lval);
    *p++ = (char)(0xFF & (lval >> 8));
    *p++ = (char)(0xFF & (lval >> 16));
    *p   = (char)(0xFF & (lval >> 24));
    return(*(long *)benchar);
}

static short natlshort(short sval) /* coerce a littlendian short into a natural short */
{
    unsigned char benchar[2];
    short natshort;

    *(short *)benchar = sval;
    natshort = benchar[1];
    natshort <<= 8;
    natshort |= benchar[0];
    return(natshort);
}

static long natllong(long lval)     /* coerce a littlendian long into a natural long */
{
    unsigned char benchar[4];
    unsigned char *p = benchar + 3;
    long natlong;

    *(long *)benchar = lval;
    natlong = *p--;
    natlong <<= 8;
    natlong |= *p--;
    natlong <<= 8;
    natlong |= *p--;
    natlong <<= 8;
    natlong |= *p;
    return(natlong);
}

/* RWD.2.98 many changes to set correct variable-header length etc */
void wavWriteHdr2(               /* Write WAV header at start of file.  */
    FILE *fd,                     /* Called after open, before data writes*/
    int sampsize,               /* sample size in bytes */
    int nchls,
    double sr)                  /* sampling rate */
{
       
	long databytes;
#ifdef DEBUG
        printf("wavWriteHdr: fd %d sampsize %d nchls %d sr %lf\n",
                fd,sampsize,nchls,sr);
#endif
        framesize = sampsize * nchls;
        databytes = 0;          /* reset later by wavReWriteHdr */

        formhdr.magic = *((long *)RIFF_ID);
        formhdr.len0 = lenlong(databytes + 36/*WAVHDRSIZ*/); 
        formhdr.magic1 = *((long *)WAVE_ID);
        formhdr.magic2 = *((long *)FMT_ID);
        /*formhdr.len = lenlong((long)16);        /* length of format chunk */
/* RWD.2.98 */
        this_format = (short)(sampsize==4 ? 3 : 1);
        formhdr.format = lenshort(this_format); /* PCM */		
        formhdr.len = this_format == 3 ? lenlong(18L) : lenlong(16L);
        nchans	= nchnls;       /* RWD for wavReWriteHdr() for fact chunk */
        formhdr.nchns = lenshort((short)nchls);
        formhdr.rate = lenlong((long)sr);
        formhdr.aver = lenlong((long)(sr * framesize));
        formhdr.nBlockAlign = lenshort((short)framesize); /* bytes per frame */
        formhdr.size = lenshort((short)(8 * sampsize));	/* bits per sample */
	/* RWD.2.98 have to do these later */
#if 0
        formhdr.magic3 = *((long *)DATA_ID);
        formhdr.datasize = lenlong(databytes);
#endif
        if (!fwrite((char *)&formhdr, sizeof(formhdr),1,fd))
            die("error writing WAV header");
        /* RWD add cbSize if format = 3 */
        if (this_format==3){
          short cbSize = 0;
          long factid = *((long *)FACT_ID);
          long chunksize = lenlong( sizeof(long));
          long factdata = 0;    /* filled in later... */
          if ((!fwrite((char *) &cbSize,sizeof(short),1,fd))
              || (!fwrite((char *)&factid,sizeof(long),1,fd))
              || (!fwrite((char *)&chunksize,sizeof(long),1,fd))
              || (!(factchunk_offset = fseek(fd,0,SEEK_CUR)) )
              || (!fwrite((char *)&factdata,sizeof(long),1,fd)))
            die("error writing WAV header");
          /* add statutory fact chunk for non-PCM formats */
        }
	/* RWD.2.98 then write data chunk info */
        {
          long magic3 = *((long *)DATA_ID);
          long datasize = lenlong(databytes);
          if ((!fwrite((char *)&magic3,  sizeof(long),1,fd)
              || ((fseek(fd,0,SEEK_CUR)))
              || (!fwrite((char *)&datasize,sizeof(long),1,fd))))
            die("error writing WAV header");
        }
        datasize_offset=ftell(fd)-sizeof(long);
		this_hdrsize = datasize_offset+sizeof(long);
}


void wavReWriteHdr2(FILE *fd,        /* Write proper sizes into WAV header  */
                   long datasize) /*        called before closing file   */
{                                 /*        & optionally under -R        */
     
	long  endpos = ftell(fd);
    /* RWD.2.98: all changed to deal with variable headersize */
    long length = lenlong(endpos-8);
    long size = lenlong(datasize);
    long size_in_samps = lenlong((datasize / sizeof(float)) / nchans);/* for fact chunk */
    if (endpos != datasize + this_hdrsize)
      die("inconsistent WAV size"); /* RWD.2.98: should be able to fudge something! */
    if (fseek(fd, 4L, 0)<0
        || !fwrite((char *)&length, sizeof(long),1,fd) 
        || (fseek(fd,datasize_offset,0))
        || !fwrite((char *)&size,sizeof(long),1,fd) )
      die("error rewriting WAV header");
    /* update fact chunk if non-PCM format */
    if (this_format==(short)3)
      if ((fseek(fd,factchunk_offset,0))
          || (!fwrite((char *)&size_in_samps,sizeof(long),1,fd)))
        die("error rewriting WAV header");		
    fseek(fd, endpos, 0);
}
