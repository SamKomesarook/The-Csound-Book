
#define         ORCH	        601
#define         SCORE           602
#define         BUTTON_SF       603
#define         SOUND           604
#define         BUTTON_Sn       605
#define         BUTTON_A        606
#define         BUTTON_B        607
#define         BUTTON_C        608
#define         BUTTON_D        609
#define         BUTTON_U8       610
#define         BUTTON_8        611
#define         BUTTON_16       612
#define         BUTTON_32       613
#define         BUTTON_FL       614
#define         BUTTON_NG       615     
#define         BUTTON_AG       616
#define         BUTTON_FG       617
#define         BUTTON_PS       618
#define         BUTTON_PLY      619
#define         BUTTON_CNT      620
#define         BUTTON_LOG      621
#define         BUTTON_HLP      622
#define         OTHERS          623
#define         UTIL            624
#define         BUTTON_OF       625

#define         X_CSCORE        630
#define         X_INITTIME      631
#define         X_NOSOUND       632
#define         X_VERBOS        633
#define         X_REWRITE       634
#define         X_SCOT          635
#define         X_HEART         636
#define         X_NOTIFY        637
#define         X_T1            638
#define         X_SRATE         639
#define         X_T2            640
#define         X_KRATE         641
#define         X_T3            642
#define         X_MSGLEV        643
#define         X_T4            644
#define         X_BEATS         645
#define         X_T5            646
#define         X_MIDIFILE      647
#define         X_MIDI          648
#define         X_T6            649
#define         X_PEDAL         650
#define         X_T7            651
#define         X_XTRFILE       652
#define         X_EXTRACT       653
#define         X_T8            654
#define         X_BUFFER        655
#define         X_INPUT         656
#define         X_T9            657
#define         X_IN            658

#define         U_HETRO         670
#define         U_LPANAL        671
#define         U_PVANAL        672
#define         U_CVANAL        673
#define         U_SNDINFO       674

#define         C_T1            680
#define         C_INPUT         681
#define         C_IN            682
#define         C_T2            683
#define         C_OUT           684
#define         C_OUTPUT        685
#define         C_SAMPLE        686
#define         C_T3            687
#define         C_BEGIN         688
#define         C_T4            689
#define         C_DUR           690
#define         C_T5            691
#define         C_FF            692
#define         C_C5            693
#define         C_C1            694
#define         C_C2            695
#define         C_C3            696
#define         C_C4            697

#define         C_FUND  	718
#define         C_HARM   	719
#define         C_MAX    	720
#define         C_MIN    	721
#define         C_NUM    	722
#define         C_FILTER 	723

#define         C_POLES  	767
#define         C_SLICE  	769
#define         C_PCHLOW 	770
#define         C_PCHHIGH       771
#define         C_VERBOSE       772
#define         C_DEBUG 	773
#define         C_GRAPHICS      774
#define         C_OLDFORM       775

#define         C_DISP  	780
#define         C_FRAME 	781
#define         C_OVLP  	782
#define         C_FRAMEI        783
#define         C_LATCH 	784
  
//RWD: VC++ needs some numbers for these
#ifndef CWIN
#  define CWIN		847
#endif
#ifndef DREAM
#  define DREAM		848
#endif
