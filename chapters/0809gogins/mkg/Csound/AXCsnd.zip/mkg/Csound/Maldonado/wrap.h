/********************************************/
/* wrap and mirror UGs by Gabriel Maldonado */
/********************************************/

typedef struct {
  OPDS  h;
  float *xdest, *xsig, *xlow, *xhigh;
} WRAP;


typedef struct {
  OPDS  h;
  float *kout, *ksig, *kthreshold, *kmode;
  float old_sig;
} TRIG;

 
typedef struct {
  OPDS  h;
  float *r, *val1, *val2, *point, *imin, *imax;
  float point_factor;
} INTERPOL;

