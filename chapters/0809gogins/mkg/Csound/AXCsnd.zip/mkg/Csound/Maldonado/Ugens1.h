/*									UGENS1.H	*/

typedef struct {
	OPDS	h;
	float	*xr, *ia, *idur, *ib;
	float	val, incr;
} LINE;

typedef struct {
	OPDS   	h;
	float 	*xr, *ia, *idur, *ib;
	float	val, mlt;
} EXPON;

typedef struct {
	long   cnt;
        float  val, mlt;
} XSEG;

typedef struct {
	long   cnt;
	float  nxtpt;
} SEG;

typedef struct {
	OPDS	h;
	float	*rslt, *argums[VARGMAX];
        SEG	*cursegp;
	long	nsegs;
	long    segsrem, curcnt;
	float   curval, curinc, curainc;
	AUXCH   auxch;
} LINSEG;

typedef struct {
	OPDS	h;
	float	*rslt, *argums[VARGMAX];
	SEG	*cursegp;
	long    segsrem, curcnt;
	float   curval, curmlt, curamlt;
	long	nsegs;
	AUXCH   auxch;
} EXPSEG;

typedef struct {
	OPDS	h;
	float	*rslt, *argums[VARGMAX];
	XSEG	*cursegp;
	long    segsrem, curcnt;
	float   curval, curmlt, curamlt;
	long	nsegs;
	AUXCH   auxch;
} EXXPSEG;

typedef struct {
	OPDS 	h;
	float	*rslt, *sig, *iris, *idur, *idec;
	float 	lin1, inc1, val, lin2, inc2;
	long 	cnt1, cnt2;
} LINEN;

typedef struct {
	OPDS 	h;
	float	*rslt, *sig, *iris, *idec, *iatdec;
	float 	lin1, inc1, val, val2, mlt2;
	long 	cnt1;
} LINENR;

typedef struct {
	OPDS	h;
	float   *rslt, *xamp, *irise, *idur, *idec, *ifn, *iatss;
        float   *iatdec, *ixmod;
	long 	phs, ki, cnt1;
	float	val, mlt1, mlt2, asym;
	FUNC	*ftp;
} ENVLPX;

typedef struct {
	OPDS    h;
	float   *rslt, *xamp, *irise, *idec, *ifn, *iatss, *iatdec;
        float   *ixmod, *irind;
	long    phs, ki, rlsing, rlscnt, rindep;
	float   val, mlt1, mlt2, asym, atdec;
	FUNC    *ftp;
} ENVLPR;

typedef struct {
	OPDS	h;
	float	*rslt, *argums[VARGMAX];
	XSEG	*cursegp;
	long	nsegs;
	AUXCH   auxch;
} EXPSEG2;			   /*gab-A1*/

