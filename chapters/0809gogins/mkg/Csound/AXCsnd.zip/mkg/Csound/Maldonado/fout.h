typedef struct {
	OPDS	h;
	float	*fname,*iflag, *argums[VARGMAX];
	FILE *fp;
	void (*outfilep) (void *);
	int	flag;
	int nargs;
	
} OUTFILE;


typedef struct {
	OPDS	h;
	float	*avar,*aincr;
} INCR;


typedef struct {
	OPDS	h;
	float	*argums[VARGMAX];
} CLEARS;
