
typedef struct {
    	OPDS   h;
	float  *which, *when, *dur;
	float  *argums[VARGMAX-3];
	int    midi;
	INSDS  *kicked;
} SCHED;


typedef struct {
    	OPDS   h;
	float  *trigger;
	float  *which, *when, *dur;
	float  *argums[VARGMAX-3];
	int    todo;
	float  abs_when;
	int    midi;
	INSDS  *kicked;
} WSCHED;

typedef struct {
    	OPDS    h;
	float   *res;
	float   *kamp, *xcps, *type;
	AUXCH   auxd;
	float   *sine;
	int     lasttype;
	long    phs;
} LFO;

