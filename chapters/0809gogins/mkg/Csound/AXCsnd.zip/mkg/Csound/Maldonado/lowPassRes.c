/* Resonant Lowpass filters by G.Maldonado */

#include <math.h>
#include "cs.h"
#include "LowPassRes.h"

void lowpr_set(LOWPR *p)
{
    if (*p->istor==0.0f)
      p->ynm1 = p->ynm2 = 0.0f;
}


void lowpr(LOWPR *p)
{
	float b, k;
	float *ar, *asig, yn,*ynm1, *ynm2 ;
	float kfco = *p->kfco, kres = *p->kres;
	register float coef1, coef2;
	int	nsmps = ksmps;
		
/*	b = 10.0 / *p->kres / sqrt(kfco) - 1.0 ;*/
	b = (float)(10.0 / (*p->kres * sqrt(kfco)) - 1.0 );
	k = 1000.0f / kfco;
	coef1=(b+2*k);
	coef2=1/(1 + b + k);

	ar = p->ar;
	asig = p->asig;
	ynm1 = &(p->ynm1);
	ynm2 = &(p->ynm2);

	do {
		*ar++ = yn = (coef1 * *ynm1 - k * *ynm2 + *asig++) * coef2;
		*ynm2 = *ynm1;
		*ynm1 =  yn;
	} while (--nsmps);
}


void lowpr_setx(LOWPRX *p)
{
	int j;
	if((p->loop = (int) (*p->ord + .5)) < 1) p->loop = 4; /*default value*/
	else if (p->loop > 10)
		initerror("illegal order num. (min 1, max 10)");
	if (*p->istor!= 0)
		for (j=0; j< p->loop; j++)  p->ynm1[j] = p->ynm2[j] = 0.;

}

void lowprx(LOWPRX *p)
{
	float b, k;
	float *ar, *asig, yn,*ynm1, *ynm2 ;
	register float coef1, coef2;
	float kfco = *p->kfco;
	register int	nsmps, j;

	/* b = 10.0 / *p->kres / sqrt(kfco) - 1.0 ;*/
	b = (float)(10.0f / (*p->kres * sqrt(kfco)) - 1.0f );
	k = 1000.0f / kfco;
	coef1=(b+2*k);
	coef2=1/(1 + b + k);
	
	ynm1 = p->ynm1;
	ynm2 = p->ynm2;
	asig = p->asig;
	
	for (j=0; j< p->loop; j++) {
		nsmps = ksmps;
		ar = p->ar;
		do {
			*ar++ = yn = (coef1 * *ynm1 - k * *ynm2 + *asig++) * coef2;
			*ynm2 = *ynm1;
			*ynm1 =  yn;
		} while (--nsmps);
		ynm1++;
		ynm2++;
		asig= p->ar;
	}
}


void lowpr_w_sep_set(LOWPR_SEP *p)
{
	int j;
	if((p->loop = (int) (*p->ord + .5)) < 1) p->loop = 4; /*default value*/
	else if (p->loop > 10)
		initerror("illegal order num. (min 1, max 10)");

	for (j=0; j< p->loop; j++)  p->ynm1[j] = p->ynm2[j] = 0.;

}



void lowpr_w_sep(LOWPR_SEP *p)
{
	float b, k;
	float *ar, *asig, yn,*ynm1, *ynm2 ;
	register float coef1, coef2;
	float kfcobase = *p->kfco;
	float sep = (*p->sep / (int) p->loop); /* gab A9 */
	register int	nsmps, j;
	/*register double	linfco;*/
	float kres = *p->kres;
	float kfco;
	ynm1 = p->ynm1;
	ynm2 = p->ynm2;
	asig = p->asig;

	
	for (j=0; j< p->loop; j++) {
		/*
		linfco=log((double) kfco)*ONEtoLOG2	;
		linfco = linfco + (sep / p->loop)*j;
		kfco = (float) pow(2.,linfco);
		*/
		kfco = (float) (kfcobase * pow(2,sep*j)); /* (gab-A9)   * (1 + (sep * j)); */
		
		
		b = (float)(10.0 / ( kres * sqrt(kfco)) - 1.0 );
		k = 1000.0f / kfco;
		coef1=(b+2*k);
		coef2=1/(1 + b + k);
	
	
		nsmps = ksmps;
		ar = p->ar;
		do {
			*ar++ = yn = (coef1 * *ynm1 - k * *ynm2 + *asig++) * coef2;
			*ynm2 = *ynm1;
			*ynm1 =  yn;
		} while (--nsmps);
		ynm1++;
		ynm2++;
		asig= p->ar;

	}
}



/*------------------------------------*/

void rsnsety(RESONY *p) /*gab-A1 */
{
    int scale;
	int j;
	p->scale = scale = (int) *p->iscl;
	if((p->loop = (int) (*p->ord + .5)) < 1) p->loop = 4; /*default value*/
	else if (p->loop > 50)
				initerror("illegal order num. (min 1, max 50)");
	if (scale && scale != 1 && scale != 2) {
	        sprintf(errmsg,"illegal reson iscl value, %f",*p->iscl);
		initerror(errmsg);
	}
	
	
	if (!(*p->istor)) {
		for (j=0; j< p->loop; j++) p->yt1[j] = p->yt2[j] = 0;
	}

}

void resony(RESONY *p) /*gab-A1 */
{
    int	nsmps, j;
	float	*ar, *asig;
	float	c3p1, c3t4, omc3, c2sqr;
	float *yt1, *yt2, c1,c2,c3,cosf; 
	double cf;
	float sep = (*p->sep / (int) p->loop);
	ar = p->ar;
	nsmps = ksmps;
	do *ar++ = 0.;
	while (--nsmps);

	yt1= p->yt1; 
	yt2= p->yt2;
	
	for (j=0; j< p->loop; j++) {
		cosf = (float) cos((double)((cf = *p->kcf * pow(2,sep*j))  * tpidsr));
		c3 = (float) exp(*p->kbw * (cf / *p->kcf) * mtpdsr);
		c3p1 = (float)(c3 + 1.);
		c3t4 = (float)(c3 * 4.);
		c2 = c3t4 * cosf / c3p1;
		c2sqr = c2 * c2;
		omc3 = 1 - c3;
		if (p->scale == 1)
			c1 = (float)(omc3 * sqrt((double)1. - c2sqr / c3t4));
		else if (p->scale == 2)
			c1 = (float)sqrt((double)((c3p1*c3p1-c2sqr) * omc3/c3p1));
		else c1 = 1.;
		asig = p->asig;	
		ar = p->ar;
		nsmps = ksmps;		
		do {
			float temp = c1 * *asig++ + c2 * *yt1 - c3 * *yt2;
			*ar++ += temp;
			*yt2 = *yt1;
			*yt1 = temp;
		} while (--nsmps);
		yt1++;
		yt2++;
	}
}