# define VERSION (3)
# define SUBVER  (52)
# define VERSIONSTRING  " v3.52"

