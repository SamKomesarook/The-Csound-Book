#ifdef CSOUND_REENTRANT_API
#else

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static char buffer[200];
static char orcname[L_tmpnam+4];
static char sconame[L_tmpnam+4];
static char midname[L_tmpnam+4];
#ifndef TRUE
#define TRUE (1)
#define FALSE (0)
#endif

#ifdef macintosh
#define fgets getstring
char macBuffer[200];
int macBufNdx = 200;
char *getstring(char *str, int num, FILE *stream)
{	
    int bufferNdx = 0;
    size_t ourReturn;
    while (true) {
      if (macBufNdx >= 200) { /*then we must read in new buffer */
	macBufNdx = 0;
	ourReturn = fread(macBuffer, 1, num, stream);
	if (ourReturn == 0)
	  return NULL;
      }
      else {
	char c = macBuffer[macBufNdx];
	if (c == '\0' || c == '\n' || c == '\r') {
	  buffer[bufferNdx] = '\r';
	  if (bufferNdx < 199)
	    buffer[bufferNdx+1] = '\0';
	  macBufNdx++;
	  return buffer;
	}
	else {
	  buffer[bufferNdx] = c;
	  bufferNdx++;
	  macBufNdx++;
	}
      }
    }
}
#endif

/*static*/ void deleteOrch(void) /* gab A8*/
{
    remove(orcname);
}

/*static*/ void deleteScore(void) /* gab A8*/
{
    remove(sconame);
}

static void deleteMIDI(void)
{
    remove(midname);
}

static     char files[1000];
extern int argdecode(int, char**, char**, char*);

int readOptions(FILE *unf)
{
    char *p;
    int argc = 0;
    char *argv[100];
    char *filnamp = files;
	
    while (fgets(buffer, 200, unf)!= NULL) {
		if (strstr(buffer,"</CsOptions>") == buffer) {
			return TRUE;
		}
		argc = 1;
		p = buffer;
		while (*p == ' ' || *p == '\t') p++;    /* Ignore leading spaces and tab (gab A8)*/
		if (*p == ';' || *p == 13 ||*p == 10 ) continue; /*gab A8*/
		argv[1] = p;
		while (*p != '\0') { 
			if (*p==' ') {
				*p++ = '\0';
				/*            printf("argc=%d argv[%d]=%s\n", argc, argc, argv[argc]); */
				while (*p == ' ') p++;
				argv[++argc] = p;
			}
			else if (*p=='\n' || *p==13 || *p==10) { /*gab A8*/
				*p = '\0';
				break;
			}
			p++;
		}
		/*        printf("argc=%d argv[%d]=%s\n", argc, argc, argv[argc]); */
		argdecode(argc, argv, &filnamp, getenv("SFOUTYP")); /* Read an argv thing */
    }
    return FALSE;
}

static int createOrchestra(FILE *unf)
{
    char *p;
    FILE *orcf;
    printf("Creating...\n");

    tmpnam(orcname);		/* Generate orchestra name */
    if ((p=strchr(orcname, '.')) != NULL) *p='\0'; /* with extention */
    strcat(orcname, ".orc");
    orcf = fopen(orcname, "w");
    printf("Creating %s (%p)\n", orcname, orcf);
    if (orcf==NULL){
      perror("Failed to create\n");
      exit(1);
    }
    while (fgets(buffer, 200, unf)!= NULL) {
      if (strstr(buffer,"</CsInstruments>") == buffer) {
	fclose(orcf);
	atexit(deleteOrch);
	return TRUE;
      }
      else fprintf(orcf, buffer);
    }
    return FALSE;
}


static int createScore(FILE *unf)
{
    char *p;
    FILE *scof;

    tmpnam(sconame);		/* Generate score name */
    if ((p=strchr(sconame, '.')) != NULL) *p='\0'; /* with extention */
    strcat(sconame, ".sco");
    scof = fopen(sconame, "w");
    while (fgets(buffer, 200, unf)!= NULL) {
      if (strstr(buffer,"</CsScore>") == buffer) {
	fclose(scof);
	atexit(deleteScore);
	return TRUE;
      }
      else fprintf(scof, buffer);
    }
    return FALSE;
}

static int createMIDI(FILE *unf)
{
    int size;
    char *p;
    FILE *midf;

    tmpnam(midname);		/* Generate MIDI file name */
    if ((p=strchr(midname, '.')) != NULL) *p='\0'; /* with extention */
    strcat(midname, ".mid");
    midf = fopen(midname, "wb");
    fscanf(unf, "Size = %d", &size);
    for (; size > 0; size--) {
      int c = getc(unf);
      putc(c, midf);
    }
    fclose(midf);
    atexit(deleteMIDI);
    if (fgets(buffer, 200, unf)!= NULL) {
      if (strstr(buffer,"</CsMidifile>") == buffer) {
	return TRUE;
      }
    }
    return FALSE;
}


check_empty(char *buf)  /*gab A8*/
{
	while (*buf) {
		if (*buf !=' ' && *buf !='\t' && *buf !=13 &&  *buf !=10) {
			if (*buf == ';') return 1;
			else	return 0;
		}
		buf++;
	}
	return 1;
}


int read_unified_file(char *name, char **score, char **midi)
{
    extern void dies(char *s, char *t); /*gab A8*/
	FILE *unf  = fopen(name, "rb");
    int result = TRUE;
    orcname[0] = sconame[0] = midname[0] = '\0';
	if (unf == NULL) dies ("error opening unified file %s", name); /* gab A8 */
	printf("Calling unified file system with %s\n", name);
    while (fgets(buffer, 200, unf)) {
		if (strstr(buffer,"<CsoundSynthesizer>") == buffer ||
			strstr(buffer,"<CsoundSynthesiser>") == buffer) {
			printf("STARTING FILE\n");
		}
		else if (strstr(buffer,"</CsoundSynthesizer>") == buffer ||
			strstr(buffer,"</CsoundSynthesiser>") == buffer)	{
			strcpy(name, orcname);
			*score = sconame;
			*midi = midname;
			return result;
		}
		else if (strstr(buffer,"<CsOptions>") == buffer) {
			printf("Creating options\n");
			result = (result && readOptions(unf));
		}
		/*        else if (strstr(buffer,"<CsFunctions>") == buffer) { */
		/*  	importFunctions(unf); */
		/*        } */
		else if (strstr(buffer,"<CsInstruments>") == buffer) {
			printf("Creating orchestra\n");
			result = (result && createOrchestra(unf));
		}
		/*  	  else if (strstr(buffer,"<CsArrangement>") == buffer) { */
		/*  	    importArrangement(unf); */
		/*  	  } */
		else if (strstr(buffer,"<CsScore>") == buffer) {
			printf("Creating score\n");
			result = (result && createScore(unf));
		}
		/*  	  else if (strstr(buffer,"<CsTestScore>") == buffer) { */
		/*  	    importTestScore(unf); */
		/*  	  } */
		else if (strstr(buffer,"<CsMidifile>") == buffer) {
			result = (result && createMIDI(unf));
		}
		else if (check_empty(buffer)) ;/*gab A8*/
		else {
			printf("Unknown command :%s\n", buffer);
		}
    }
    return result;
}

#endif	//	CSOUND_REENTRANT_API
