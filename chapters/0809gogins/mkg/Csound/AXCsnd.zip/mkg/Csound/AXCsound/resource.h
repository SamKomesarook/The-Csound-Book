//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by AXCsound.rc
//
#define IDPAUSE                         6
#define IDOPEN                          11
#define IDSAVE                          12
#define IDSAVEAS                        13
#define IDIMPORT                        14
#define IDOPENSOUND                     16
#define IDS_PROJNAME                    100
#define IDB_AXCSOUND                    101
#define IDR_AXCSOUND                    102
#define IDD_AXCSOUND                    103
#define IDD_SCOREDIALOG                 104
#define IDD_ORCHESTRADIALOG             105
#define IDD_COMMANDDIALOG               106
#define IDD_COPYRIGHTDIALOG             107
#define IDC_MEDIAPLAYER                 201
#define IDC_TABS                        204
#define IDC_EDIT_INSTRUMENT_INDEX       205
#define IDC_EDIT_FILENAME               207
#define IDI_NOTE                        208
#define IDRESUME                        209
#define IDC_EDIT_ORCHESTRA              213
#define IDC_EDIT_COMMAND                227
#define IDC_LOG_LIST                    232
#define IDC_MAIN_SPIN_PLAY              237
#define IDC_EDIT_COPYRIGHT              240
#define IDC_EDIT_SCORE                  262
#define IDC_CLEAR_NOTES_ONLY            264
#define IDC_CLEAR_SCORE                 265
#define IDC_UPDATE                      266
#define IDC_UPDATE_SCORE                266
#define IDC_GENERATE__TEST_SCORE        267

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        206
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         206
#define _APS_NEXT_SYMED_VALUE           108
#endif
#endif
