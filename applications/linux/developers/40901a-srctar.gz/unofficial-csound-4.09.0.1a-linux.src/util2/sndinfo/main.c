/*
 * $Id: main.c,v 1.4 1999/06/23 11:53:36 nicb Exp $
 */
#include "execute.h"
#include "../../cs.h"

int main(int argc, char *argv[])
{
	return execute(sndinfo, argc, argv, "sndinfo", "sndinfo");
}
