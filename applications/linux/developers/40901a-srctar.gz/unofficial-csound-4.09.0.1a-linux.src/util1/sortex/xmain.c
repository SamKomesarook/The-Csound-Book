#include "../../sort.h"                                    /*   XMAIN.C  */
#include "../../text.h"
#include "../../new-src/natural-conversions.h"

int main(int ac, char **av)         /* stdio stub for standalone extract */
                                    /*     first opens the control xfile */
{
  FILE *xfp;
  
	init_getstring(ac, av);
	ac--;  av++;
	if (ac != 1) {
	  fprintf(stderr,"usage: extract xfile <in >out\n");
	  exit(1);
	}
	if ((xfp = fopen(*av,"r")) == NULL) {
	  fprintf(stderr,"extract: can't open %s\n", *av);
	  exit(1);
	}
        return(scxtract(stdin,stdout,xfp));
}
