#include "../../sort.h"                                        /*   SMAIN.C  */
#include "../../new-src/natural-conversions.h"

int main(void)                           /* stdio stub for standalone scsort */
{
	init_getstring(0, (char **) NULL);
	return(scsort(stdin,stdout));
}         
