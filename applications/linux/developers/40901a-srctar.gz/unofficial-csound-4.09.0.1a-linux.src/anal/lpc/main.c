/*
 * $Id: main.c,v 1.3 1999/06/23 11:53:04 nicb Exp $
 */
#include "execute.h"
#include "../../cs.h"

int main(int argc, char *argv[])
{
	return execute(lpanal, argc, argv, "LPC", "LPC");
}
