/*
 *
 * $Id: natural-conversions.h,v 1.1 1999/06/23 11:53:17 nicb Exp $
 *
 */

#if !defined(_new_src_natural_conversions_h_)
#	define	_new_src_natural_conversions_h_

short natshort(short sval);/* coerce a bigendian short into a natural short */
long natlong(long lval); /* coerce a bigendian long into a natural long */

#endif /* !defined(_new_src_natural_conversions_h_) */
