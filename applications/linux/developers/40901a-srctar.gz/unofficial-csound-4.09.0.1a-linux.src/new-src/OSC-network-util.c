/* ==============================================================
 * File:	OSC-network-util.c
 * Author:	Stefan Kersten <steve@k-hornz.de>
 * Contents:	OSC/UDP support routines
 * ==============================================================
 * $Id: OSC-network-util.c,v 1.2 2000/10/28 22:34:13 nicb Exp $
 * ==============================================================
 */

#include "OSC-network-util.h"

#if defined(WIN32)
#  include <winsock.h>
#else /* !WIN32 */
#  include <fcntl.h>
#  include <netdb.h>
#  include <netinet/in.h>
#  include <sys/time.h>
#  include <sys/types.h>
#  include <sys/socket.h>
#  include <unistd.h>
#endif /* WIN32 */

struct OSC_UDPSocketStruct
{
  SOCKET sockFD;
  OSCBoolean nonBlk;
  int timeOut;
};

struct OSC_UDPAddressStruct
{
  struct sockaddr_in addr;
  int addrLen;
};


int OSC_UDP_Startup(void)
{
  int	error = 0;

#if defined(WIN32)
  WORD		wVersionRequested;
  WSADATA	wsaData;

  wVersionRequested = MAKEWORD(2, 2);

  error = WSAStartup(wVersionRequested, &wsaData);

  if (error != 0)
  {
    return error;
  }

  if (LOBYTE(wsaData.wVersion) != 2 ||
      HIBYTE(wsaData.wVersion) != 2)
  {
    return WSACleanup();
  }
#endif /* WIN32 */

  return error;
}

int OSC_UDP_Shutdown(void)
{
  int error = 0;

#if defined(WIN32)
  error = WSACleanup();
#endif /* WIN32 */

  return error;
}

int osc_UDPSocket_FcntlNonBlocking(OSC_UDPSocket self)
{
#if defined(WIN32)
  unsigned long nonBlk = 1;
  return ioctlsocket(self->sockFD, FIONBIO, &nonBlk);
#else /* !WIN32 */
  return fcntl(self->sockFD, F_SETFL, FNDELAY);
#endif
}

OSC_UDPSocket OSC_UDPSocket_ServerNew(unsigned short thePort)
{
  OSC_UDPSocket self = NULL;
  struct sockaddr_in myAddr;

  if ((self = (OSC_UDPSocket)malloc(sizeof(struct OSC_UDPSocketStruct))) == NULL)
  {
    return NULL;
  }

  if ((self->sockFD = socket(AF_INET, SOCK_DGRAM, 0)) == SOCKET_ERROR)
  {
    free(self);
    return NULL;
  }

  memset(&myAddr, 0x0, sizeof(struct sockaddr_in));
  myAddr.sin_family = AF_INET;
  myAddr.sin_addr.s_addr = htonl(INADDR_ANY);
  myAddr.sin_port = htons(thePort);

  if (bind(self->sockFD, (struct sockaddr *)&myAddr, sizeof(myAddr)) == SOCKET_ERROR)
  {
    OSC_UDPSocket_Close(self);
    free(self);
    return NULL;
  }

  osc_UDPSocket_FcntlNonBlocking(self);

  self->nonBlk = FALSE;
  self->timeOut = 0;

  return self;
}

OSC_UDPSocket OSC_UDPSocket_ClientNew(OSCBoolean bindMe)
{
  OSC_UDPSocket self;
  struct sockaddr_in myAddr;

  if ((self = (OSC_UDPSocket)malloc(sizeof(struct OSC_UDPSocketStruct))) == NULL)
  {
    return NULL;
  }

  if ((self->sockFD = socket(AF_INET, SOCK_DGRAM, 0)) == SOCKET_ERROR)
  {
    free(self);
    return NULL;
  }

  memset(&myAddr, 0x0, sizeof(struct sockaddr_in));
  myAddr.sin_family = AF_INET;
  myAddr.sin_addr.s_addr = htonl(INADDR_ANY);
  myAddr.sin_port = htons(0);

  if (bindMe)
  {
    if (bind(self->sockFD, (struct sockaddr *)&myAddr, sizeof(myAddr)) == SOCKET_ERROR)
    {
      OSC_UDPSocket_Close(self);
      free(self);
      return NULL;
    }
  }

  osc_UDPSocket_FcntlNonBlocking(self);

  self->nonBlk = FALSE;
  self->timeOut = 0;

  return self;
}

void OSC_UDPSocket_SetNonBlocking(OSC_UDPSocket self, OSCBoolean value)
{
  self->nonBlk = value;
}

OSCBoolean OSC_UDPSocket_GetNonBlocking(OSC_UDPSocket self)
{
  return self->nonBlk;
}

SOCKET OSC_UDPSocket_GetSocketFD(OSC_UDPSocket self)
{
  return self->sockFD;
}

void OSC_UDPSocket_SetTimeOut(OSC_UDPSocket self, int seconds)
{
  self->timeOut = seconds;
}

int OSC_UDPSocket_GetTimeOut(OSC_UDPSocket self)
{
  return self->timeOut;
}

int OSC_UDPSocket_Close(OSC_UDPSocket self)
{
  if (self->sockFD != INVALID_SOCKET)
  {
#if defined(WIN32)
    return closesocket(self->sockFD);
#else /* !WIN32 */
    return close(self->sockFD);
#endif /* WIN32 */
  }
  return 0;
}

int OSC_UDPSocket_Delete(OSC_UDPSocket self)
{
  int res = 0;

  if (self != NULL)
  {
    res = OSC_UDPSocket_Close(self);
    free(self);
    self = NULL;
  }

  return res;
}

int OSC_UDPSocket_Connect(OSC_UDPSocket self, OSC_UDPAddress address)
{
  return connect(self->sockFD, (struct sockaddr *)&address->addr, address->addrLen);
}

/* Converts ascii text to in_addr struct.  NULL is returned if the
   address can not be found.
   Taken from the Socket FAQ.
*/
struct in_addr *osc_NameOrIPToAddress(const char *address) {
  struct hostent *host;
  static struct in_addr saddr;
  
  /* First try it as aaa.bbb.ccc.ddd. */
  saddr.s_addr = inet_addr(address);
  if (saddr.s_addr != -1) 
  {  
    return &saddr;
  }
  host = gethostbyname(address);
  if (host != NULL) 
  {
    return (struct in_addr *) *host->h_addr_list;
  }
  return NULL;
}             

OSC_UDPAddress OSC_UDPAddress_New(const char *hostName, unsigned short portNumber)
{
  OSC_UDPAddress self;
  struct in_addr *inAddr;

  self = (OSC_UDPAddress)malloc(sizeof(struct OSC_UDPAddressStruct));

  if (self == NULL)
  {
    return NULL;
  }

  if ((inAddr = osc_NameOrIPToAddress(hostName)) == NULL)
  {
    free(self);
    return NULL;
  }

  memset(&self->addr, 0x0, sizeof(struct sockaddr_in));
  (self->addr).sin_family = AF_INET;
  (self->addr).sin_addr = *inAddr;
  (self->addr).sin_port = htons(portNumber);

  self->addrLen = sizeof(struct sockaddr_in);

  return self;
}

int OSC_UDPAddress_Delete(OSC_UDPAddress self)
{
  if (self != NULL)
  {
    free(self);
    self = NULL;
  }
  return 0;
}

int OSC_UDPSocket_Receive(OSC_UDPSocket self, OSC_UDPAddress returnAddress)
{
  OSCPacketBuffer pBuf;
  fd_set readFD;
  struct timeval timeout;
  struct timeval *timeoutP;
  struct sockaddr_in *ra = NULL;
  int *raLen = NULL;
  int n;
  int bufLen = OSCGetReceiveBufferSize();
  char *buf;

  if (self->nonBlk)
  {
    timeout.tv_sec = 0;
    timeout.tv_usec = 0;
    timeoutP = &timeout;
  }
  else
  {
    if (self->timeOut > 0)
    {
      timeout.tv_sec = self->timeOut;
      timeout.tv_usec = 0;
      timeoutP = &timeout;
    }
    else
    {
      timeoutP = NULL;
    }
  }

  FD_ZERO(&readFD);
  FD_SET(self->sockFD, &readFD);

  if (select(self->sockFD+1, &readFD, (fd_set *)NULL, (fd_set *)NULL, timeoutP) < 0)
  {
#if defined(DEBUG)
    OSCWarning("OSC_UDPReceiveBuf: select failed!");
#endif /* DEBUG */
    return SOCKET_ERROR;
  }

  if(!FD_ISSET(self->sockFD, &readFD))
  {
    return 0;
  }

  pBuf = OSCAllocPacketBuffer();

  if (!pBuf)
  {
    OSCWarning("Out of memory for packet buffers - had to drop a packet!");
    return SOCKET_ERROR;
  }

  buf = OSCPacketBufferGetBuffer(pBuf);

  if (returnAddress != NULL)
  {
    ra = &(returnAddress->addr);
    raLen = &(returnAddress->addrLen);
  }

  n = recvfrom(self->sockFD, buf, bufLen, 0, (struct sockaddr *)ra, (int *)raLen);

  if (n > 0)
  {
    int *sizep = OSCPacketBufferGetSize(pBuf);
    *sizep = n;
    OSCAcceptPacket(pBuf);
    return 1;
  }
  else
  {
    OSCFreePacket(pBuf);
#if defined(DEBUG)
    OSCWarning("OSC_UDPReceiveBuf: error during receive!");
#endif /* DEBUG */
    return 0;
  }
}

int OSC_UDPSocket_Send(OSC_UDPSocket self, OSC_UDPAddress servAddr, OSCbuf *buf)
{
  fd_set writeFD;
  struct timeval timeout;
  struct timeval *timeoutP;

  if (self->nonBlk)
  {
    timeout.tv_sec = 0;
    timeout.tv_usec = 0;
    timeoutP = &timeout;
  }
  else
  {
    if (self->timeOut > 0)
    {
      timeout.tv_sec = self->timeOut;
      timeout.tv_usec = 0;
      timeoutP = &timeout;
    }
    else
    {
      timeoutP = NULL;
    }
  }

  FD_ZERO(&writeFD);
  FD_SET(self->sockFD, &writeFD);

  if (select(self->sockFD+1, (fd_set *)NULL, &writeFD, (fd_set *)NULL, timeoutP) < 0)
  {
    return SOCKET_ERROR;
  }

  if(!FD_ISSET(self->sockFD, &writeFD))
  {
    return SOCKET_ERROR;
  }

  if (servAddr == NULL)
  {
    return send(self->sockFD, OSC_getPacket(buf), OSC_packetSize(buf), 0);
  }
  else
  {
    return sendto(self->sockFD, OSC_getPacket(buf), OSC_packetSize(buf), 0,
		  (struct sockaddr *)&(servAddr->addr), servAddr->addrLen);
  }
}

/* EOF */
