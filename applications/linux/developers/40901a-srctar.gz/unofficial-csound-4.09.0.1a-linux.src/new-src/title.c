/*
 * $Id: title.c,v 1.5 2000/09/21 19:56:01 nicb Exp $
 *
 * Csound Linux source title.c
 *
 */
/*
 * print_title: no arguments
 */

#include "../cs.h"
#include "../new-src/version.h"

void
print_title()
{
	const char *fsize = (sizeof(MYFLT)==sizeof(double)) ? "doubles" : "floats";
	err_printf("Unofficial Linux Csound Version %s (%s)(floats are %s)\n",
		VERSIONSTRING, __DATE__, fsize);
}

void print_long_title()
{
	print_title();
	err_printf("BEWARE: this is not the canonical version! (caveat emptor)\n\
Please report bugs of this version to http://www.ilogic.com.au/cgi-bin/csound-bugs\n");
}
