typedef struct _DelayLine { 
	MYFLT	*data;
	int	length; 
	MYFLT	*pointer;
	MYFLT	*end; 
} DelayLine; 

typedef struct	{
	OPDS	h;
        MYFLT	*ar, *plk, *xamp, *icps, *pickup, *reflect;
        MYFLT   *ain;
        AUXCH	upper;
  	AUXCH	lower;
	AUXCH	up_data;
	AUXCH	down_data;
        MYFLT   state;
        int     scale;
        int     rail_len;
} WGPLUCK;

