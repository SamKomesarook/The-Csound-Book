/*
 * $Id: execute.h,v 1.2 1998/11/30 19:40:09 nicb Exp $
 *
 * Csound Linux source execute.h
 *
 * several utilities have a main built in basically always the same
 * way (a main that calls a specific function setting orchestra and
 * score to a standard name); I isolated this in a specific function
 * so that we know where to debug when we need to...
 * 					[nicb@axnet.it]
 */
#if !defined(_new_src_execute_h_)
#	define _new_src_execute_h_

/*
 * execute - arguments:
 * 	func:	the pointer to the function to execute
 * 	argc, argv: the parameters coming from main's arguments
 */
int
execute(int (*func)(int, char *[]), int argc, char *argv[], const char *sname,
	const char *oname);

#endif /* !defined(_new_src_execute_h_) */
