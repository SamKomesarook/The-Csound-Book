/* oscillator opcodes by Gabriel Maldonado */
#include "cs.h"

#if 0				/* this code is now include in uggab.[ch] */
#include "Gab_osc.h"
extern   FUNC   *ftnp2find(MYFLT*);       /* permit non-power-of-2 ftable (no masks) */

void posc_set( POSC *p)
{
    FUNC *ftp;

    if ((ftp = ftnp2find(p->ift)) == NULL)	   return;
	p->ftp = ftp;
    p->tablen = ftp->flen;
	p->phs =  *p->iphs * p->tablen;


}

void posc( POSC *p)
{
    register	MYFLT	*out = p->out, *ft = p->ftp->ftable ;
	register	MYFLT	*curr_samp, fract ;
	register	double	*phs= &p->phs,  si= *p->freq * p->tablen / esr;
    register	long	n = ksmps; 
    
	
	do {
		curr_samp= ft + (long)*phs;
	    fract= (MYFLT)(*phs - (long)*phs);
	    *out++ = *p->amp * (*curr_samp +(*(curr_samp+1)-*curr_samp)*fract);
	    if ((*phs += si) >= p->tablen) 	*phs -= p->tablen;
	} while (--n);
}


void kposc (POSC *p)
{
   	double	*phs= &p->phs;
   	double  si= *p->freq * p->tablen / ekr;
	MYFLT	*curr_samp = p->ftp->ftable + (long)*phs;
	MYFLT	fract = (MYFLT)(*phs - (long)*phs);
	
	*p->out = *p->amp * (*curr_samp +(*(curr_samp+1)-*curr_samp)*fract);
	if ((*phs += si) >= p->tablen) 	*phs -= p->tablen;
}

void lposc_set(LPOSC *p)
{
    FUNC *ftp;

    if ((ftp = ftnp2find(p->ift)) == NULL) return;
	if (!(p->fsr=ftp->gen01args.sample_rate)){
		  printf("losc: no sample rate stored in function assuming=sr\n");
		  p->fsr=esr;
	}
	p->ftp = ftp;
    p->tablen = ftp->flen;
	p->phs =  *p->iphs * p->tablen;
}


void lposc(LPOSC *p)
{
    register	MYFLT	*out = p->out, *ft = p->ftp->ftable;
	register	MYFLT	*curr_samp, fract; 
	register	double	*phs= &p->phs, si= *p->freq * (p->fsr/esr);
    register	long	n = ksmps;
    double	loop, end, looplength = p->looplength  ; 

	if ((loop= *p->kloop) < 0) loop=0;
	if ((end= *p->kend) > p->tablen || end <=0 ) end = p->tablen;
	looplength = end - loop;
		
	do {
		curr_samp= ft + (long)*phs;
	    fract= (MYFLT)(*phs - (long)*phs);
	    *out++ = *p->amp * (*curr_samp +(*(curr_samp+1)-*curr_samp)*fract);
	    if ((*phs += si) >= end) *phs -= looplength;
	}while (--n);
}
#endif /* 0 */			/* this code is now include in uggab.[ch] */

#include "../../uggab.h"

void lposcint(LPOSC *p)
{
    
   	register	double	*phs= &p->phs;
   	register	double	si= *p->freq * (p->fsr/esr);
    register	MYFLT	*out = p->out;
	register	short	*ft = (short *) p->ftp->ftable, *curr_samp;
	register	MYFLT	fract; 
    register	long	n = ksmps;
    double	loop, end, looplength = p->looplength  ; 

	if ((loop= *p->kloop) < 0) loop=0;
	if ((end= *p->kend) > p->tablen || end <=0) end = p->tablen;
	looplength = end - loop;
		
	do {
		curr_samp= ft + (long)*phs;
	    fract= (MYFLT)(*phs - (long)*phs);
	    *out++ = *p->amp * (*curr_samp +(*(curr_samp+1)-*curr_samp)*fract);
	    if ((*phs += si) >= end) *phs -= looplength;
	}while (--n);
}

