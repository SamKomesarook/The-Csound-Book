					
/* some routines for Windows by Gabriel Maldonado */
#include <stdio.h>
#if defined(WIN32)
#include <windows.h>
#include <wincon.h>
#endif /* defined(WIN32) */
#ifdef GAB_RT
#include "cs.h"
#include "version.h"

int rows=0 , columns=0;
int exit_soon_flag=0;
void exit_soon() { exit_soon_flag=1;}

void set_rows(int n) {
	rows = n;
}

void set_columns( int n) {
 	columns = n;
}
#if defined(WIN32)
void console_rows()
{
	HANDLE cons_handle;
	COORD coord, firstcell;
	DWORD scritti;
	int xret;

	if (!columns && rows) columns=81;
	if (!rows && columns) rows = 26;
	coord.X=columns;
	coord.Y=rows;
 	firstcell.X=0;
	firstcell.Y=0;
 	cons_handle=GetStdHandle(STD_OUTPUT_HANDLE	);
	//if (columns || rows)
	xret = SetConsoleScreenBufferSize(cons_handle, coord);
	xret = SetConsoleTextAttribute( cons_handle,
    						  BACKGROUND_BLUE
    						| BACKGROUND_GREEN
    						| BACKGROUND_RED
    						| BACKGROUND_INTENSITY 
	);

   	if (!columns) { coord.X = 100; coord.Y = 100; }
   	
   	FillConsoleOutputAttribute(
    	cons_handle,	// handle of screen buffer 
    	  BACKGROUND_BLUE
    	| BACKGROUND_GREEN
    	| BACKGROUND_RED
    	| BACKGROUND_INTENSITY,	// color attribute to write 
    	coord.X * coord.Y,	// number of character cells to write to 
    	firstcell,	// x- and y-coordinates of first cell 
    	&scritti	// address of number of cells written to 
    );
    if (columns || rows)  xret =  ShowWindow( cons_handle,  SW_SHOWMAXIMIZED	   );	

}

void console_title()
{
	char stringa[256];
	HANDLE cons_handle;
 	cons_handle=GetStdHandle(STD_OUTPUT_HANDLE	);
	sprintf(stringa, "DirectCsound 2.1 (updated to standard ver.%d.%d)", VERSION, SUBVER);
  	SetConsoleTitle(stringa);	
}
#endif /* defined(WIN32) */

void getgab() {
#if defined(WIN32)
	if (exit_soon_flag) return;
	printf("\npress <RETURN> to terminate program...");
	getchar();
#endif /* defined(WIN32) */
}
#endif
#if defined(WIN32)
 /*
void set_current_process_priority_critical()
{
 	 BOOL nRet;
 	 HANDLE currProcess, currThread;
 	 currProcess=GetCurrentProcess();
	 nRet=SetPriorityClass(  currProcess, REALTIME_PRIORITY_CLASS);
	 currThread = GetCurrentThread();
	 nRet=SetThreadPriority( currThread,  THREAD_PRIORITY_HIGHEST );
}


void set_current_process_priority_normal()
{
 	 BOOL nRet;
 	 HANDLE currProcess, currThread;
 	 currProcess=GetCurrentProcess();
	 nRet=SetPriorityClass(  currProcess, NORMAL_PRIORITY_CLASS	);
	 currThread = GetCurrentThread();
	 nRet=SetThreadPriority( currThread,  THREAD_PRIORITY_NORMAL );
}
*/
#endif /* defined(WIN32) */

void dieu_gab(char *s, char *title)
{
#if defined(WIN32)
 		MessageBox( NULL,	// handle of owner window
				s,	// address of text in message box
                title,	// address of title of message box  
                MB_SYSTEMMODAL | MB_ICONSTOP 	// style of message box
		);
#else
		die(s);
#endif /* defined(WIN32) */
}
