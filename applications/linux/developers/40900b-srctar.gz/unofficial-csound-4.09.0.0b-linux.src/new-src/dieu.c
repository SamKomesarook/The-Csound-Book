/*
 * $Id: dieu.c,v 1.2 1998/12/27 09:09:37 nicb Exp $
 */

#include <stdio.h>
#include <stdarg.h>
#include "getlongopts.h"
#include "../cs.h"

void dieu(const char *s, ...)
{
	char buf[256];
	extern void _do_opts_help(const char *s, va_list ap);
	va_list ap;
	va_start(ap, s);
	sprintf(buf, "Csound Command ERROR:\t%s\n", s);

	_do_opts_help(buf, ap);

	va_end(ap);

    if (!POLL_EVENTS()) exit(1);
}
