/*	Math functions for Csound coded by Paris Smaragdis 1994         */
/*	Berklee College of Music Csound development team                */

/* Changes 6 July 1998 - Robin Whittle http://www.firstpr.com.au
 *
 * 31 bit Park Miller "Minimal Standard" Pseudo Random Number Generator
 * now used for all these noise sources, with a seed setting function and a
 * raw 31 bit function available for other Csound functions too.
 *
 * This removes the dependency on the library function rand() which could
 * be as simple as a 16 bit PRNG, which would be lousy for audio purposes.
 *
 * Changes made to seedrand().  
 * A new function randint31() is created.
 * Macro "unirand()" is now defined in terms of randint31() instead of
 * the library call rand().  
 * New functions for bipolar uniform noise -1 to +1.  Three new lines
 * for this xbunirand family need to be added to entry.c, as well as
 * declaring the new function names:
 */

#include "cs.h"
#include "cmath.h"
#include <math.h>
#include <time.h>   /* for random seeding from the time - mkc July 1997 */

#ifndef RAND_MAX
#define RAND_MAX        (32767)
#endif

void ipow(POW *p)		/*      Power for i-rate */
{
    *p->sr = (MYFLT)pow(*p->in, *p->powerOf);	/*      sophisticated code!     */
}

void apow(POW *p)		/*      Power routine for a-rate  */
{
    long n = ksmps;
    MYFLT *in = p->in, *out = p->sr;

    do {
	*out++ = (MYFLT)pow(*in++, *p->powerOf) / *p->norm;
    } while (--n);
}

void kpow(POW *p)		/*      Power routine for k-rate        */
{
    *p->sr = (MYFLT)pow(*p->in, *p->powerOf) / *p->norm;
}

/*=========================================================================
 *
 * seedrand()  and the PRNG seed.
 *
 * Driven by opcode "seed".  Takes a float input parm and seeds the 
 * 31 bit state of the PRNG as follows:
 *
 * Input  = 0  Use time of day to generate seed.
 *
 * Input != 0  Make it positive, multiply by 1,000, mod it by
 *             (2^31 - 1) turn it into an integer using floor,
 *             so it can never be 2^31, make it 1 if the result
 *             was 0, and use this as the seed.
 *             The PRNG will put out 0s if its state is 0!
 *
 * The seed is a 32 bit integer. Initialise it with an 
 * auspicious number - pi to the 17th power.
 *
 * The seed opcode uses the same data structure PRAND as the generators
 * - its sole parameter, an input, is in the first position, which is
 * called "out".
 */ 

#define CS_RANDINT_MAX 2147483647L   /* 2**31 - 1 = 0x7FFFFFFF */ 

    			/* Add one in case y2k voodoo causes time()
			 * to return 0.
			 */
static long seed31 =  282844563L; 
       long holdrand = 2345678L;  /* gab d5 */

void seedrand(PRAND *p)
{
			/* Make sure that the time of day function is returning
			 * non-zero.
			 */
    if ( (*p->out == 0) && (time(NULL) != 0) ) 
    {
	printf(Str(X_458,"Seeding from current time\n"));
			
	/* Since the time changes rather slowly, and the 
	 * first generated randint31() result depends
	 * on it and therefore changes rather slowly
	 * call randint31() twice the mash the seed
	 * well before an opcode can use it.
	 */

	seed31 = (long) time(NULL);
	holdrand = seed31;  /* gab d5 - modified by nicb@axnet.it */
	seed31 = randint31(seed31);
	seed31 = randint31(seed31);
    }
    else 
    {
	seed31 = (long) floor( fmod( (double)(1000 * fabs(*p->out)), (double)2147483647 ) );
	printf(Str(X_459,"Seeding with %.3f\n"), *p->out);
        srand((unsigned int)(holdrand = (int)*p->out));
    }

    if (seed31 == 0) seed31 = 1;
    printf("Seed = %10lu \n", seed31) ;
}

/*
 * randint31() by Robin Whittle has been moved to ugens4.c by the
 * canonical maintainer, I guess. So we remove it from here.
 * 					[nicb@axnet.it]
 */

/*=========================================================================
 *
 * unirand() macro to call the above PRNG function.
 */

#define unirand() (MYFLT)((double)(seed31=randint31(seed31))/(double)CS_RANDINT_MAX)


/*=========================================================================
 *
 * Funcions for xbunirand opcodes in entry.c.
 * Based on auinform() and ikuniform() below.
 * unirand was 0 to +1.  bunirand is -1 to +1
 */

void abuniform(PRAND *p)	/* Uniform bipolar distribution */
{
    long n = ksmps;
    MYFLT *out = p->out;
    MYFLT arg1 = *p->arg1;

    do *out++ = arg1 * (unifrand(2) - 1);
    while( --n);
}

void ikbuniform(PRAND *p)
{
    MYFLT *out = p->out;

    *out = *p->arg1 * (unifrand(2) - 1);
}


/* Back to Paris' code.  - - - - - - - - - - - - - - - - - - - - - - - - - - */



void auniform(PRAND *p)		/* Uniform distribution */
{
    long n = ksmps;
    MYFLT *out = p->out;
    MYFLT arg1 = *p->arg1;

    do *out++ = unifrand(arg1);
    while( --n);
}

void ikuniform(PRAND *p)
{
    *p->out = unifrand(*p->arg1);
}

void alinear(PRAND *p)		/* Linear random functions      */
{
    long n = ksmps;
    MYFLT *out = p->out;

    do {
	*out++ = linrand(*p->arg1);
    } while (--n);
}

void iklinear(PRAND *p)
{
    *p->out = linrand(*p->arg1);
}

void atrian(PRAND *p)		/*      Triangle random functions       */
{
    long n = ksmps;
    MYFLT *out = p->out;

    do {
	*out++ = trirand(*p->arg1);
    } while (--n);
}

void iktrian(PRAND *p)
{
    *p->out = trirand(*p->arg1);
}

void aexp(PRAND *p)		/*      Exponential random functions    */
{
    long n = ksmps;
    MYFLT *out = p->out;

    do {
	*out++ = exprand(*p->arg1);
    } while (--n);
}

void ikexp(PRAND *p)
{
    *p->out = exprand(*p->arg1);
}

void abiexp(PRAND *p)		/*      Bilateral exponential rand. functions */
{
    long n = ksmps;
    MYFLT *out = p->out;

    do {
	*out++ = biexprand(*p->arg1);
    } while (--n);
}

void ikbiexp(PRAND *p)
{
    *p->out = biexprand(*p->arg1);
}

void agaus(PRAND *p)		/*      Gaussian random functions       */
{
    long n = ksmps;
    MYFLT *out = p->out;

    do {
	*out++ = gaussrand(*p->arg1);
    } while (--n);
}

void ikgaus(PRAND *p)
{
    *p->out = gaussrand(*p->arg1);
}

void acauchy(PRAND *p)		/*      Cauchy random functions */
{
    long n = ksmps;
    MYFLT *out = p->out;

    do {
	*out++ = cauchrand(*p->arg1);
    } while (--n);
}

void ikcauchy(PRAND *p)
{
    *p->out = cauchrand(*p->arg1);
}

void apcauchy(PRAND *p)		/*      Positive Cauchy random functions */
{
    long n = ksmps;
    MYFLT *out = p->out;

    do {
	*out++ = pcauchrand(*p->arg1);
    } while (--n);
}

void ikpcauchy(PRAND *p)
{
    *p->out = pcauchrand(*p->arg1);
}

void abeta(PRAND *p)		/*      Beta random functions   */
{
    long n = ksmps;
    MYFLT *out = p->out;

    do {
	*out++ = betarand(*p->arg1, *p->arg2, *p->arg3);
    } while (--n);
}

void ikbeta(PRAND *p)
{
    *p->out = betarand(*p->arg1, *p->arg2, *p->arg3);
}

void aweib(PRAND *p)		/*      Weibull randon functions        */
{
    long n = ksmps;
    MYFLT *out = p->out;

    do {
	*out++ = weibrand(*p->arg1, *p->arg2);
    } while (--n);
}

void ikweib(PRAND *p)
{
    *p->out = weibrand(*p->arg1, *p->arg2);
}

void apoiss(PRAND *p)		/*      Poisson random funcions */
{
    long n = ksmps;
    MYFLT *out = p->out;

    do {
	*out++ = poissrand(*p->arg1);
    } while (--n);
}

void ikpoiss(PRAND *p)
{
    *p->out = poissrand(*p->arg1);
}


/* * * * * * RANDOM NUMBER GENERATORS * * * * * */


/* This was the old macro which called the library function rand().
 * 
 *  #define unirand() (MYFLT)((double)rand()/(double)RAND_MAX)
 *
 * See above for the new unirand() macro.
 */
 
MYFLT unifrand(MYFLT range)
{
    return range*unirand();
}

MYFLT linrand(MYFLT range)	/*      linear distribution routine     */
{
    MYFLT r1, r2;

    r1 = unirand();
    r2 = unirand();

    if (r1 > r2)
	r1 = r2;

    return (r1 * range);
}

MYFLT trirand(MYFLT range)	/*      triangle distribution routine   */
{
    MYFLT r1, r2;

    r1 = unirand();
    r2 = unirand();

    return (((r1 + r2) - FL(1.0)) * range);
}
		
MYFLT exprand(MYFLT l)		/*      exponential distribution routine */
{
    MYFLT r1;

    if (l < FL(0.0)) return (FL(0.0));

    do {
	r1 = unirand();
    } while (r1 == FL(0.0));

    return (-(MYFLT)log(r1 *l));
}

MYFLT biexprand(MYFLT l)	/* bilateral exponential distribution routine */
{
    MYFLT r1;

    if (l < FL(0.0)) return (FL(0.0));

    do {
	r1 = FL(2.0) * unirand();
    } while (r1 == FL(0.0) || r1 == FL(2.0)); 

    if (r1 > FL(1.0))     {
	r1 = FL(2.0) - r1;
	return (-(MYFLT)log(r1 * l));
    }
    return ((MYFLT)log(r1 * l));
}

MYFLT gaussrand(MYFLT s)	/*      gaussian distribution routine   */
{
    MYFLT r1 = FL(0.0);
    int n = 12;
    s /= FL(3.83);

    do {
	r1 += unirand();
    } while (--n);

    return (s * (r1 - FL(6.0)));
}

MYFLT cauchrand(MYFLT a)	/*      cauchy distribution routine     */
{
    MYFLT r1;
    a /= FL(318.3);

    do {
      do {
	r1 = unirand();
      } while (r1 == FL(0.5));

      r1 = a * (MYFLT)tan(PI*(double)r1);
    } while (r1>FL(1.0) || r1<-FL(1.0)); /* Limit range artificially */
    return r1;
}

MYFLT pcauchrand(MYFLT a)	/*      positive cauchy distribution routine */
{
    MYFLT r1;
    a /= FL(318.3);

    do {
      do {
	r1 = unirand();
      } while (r1 == FL(1.0));

      r1 = a * (MYFLT)tan( PI * 0.5 * (double)r1);
    } while (r1>FL(1.0));
    return r1;
}

MYFLT betarand(MYFLT range, MYFLT a, MYFLT b) /* beta distribution routine  */
{
    MYFLT r1, r2;

    if (a < FL(0.0) || b < FL(0.0) ) return (FL(0.0)); 

    do {
	do {
	    r1 = unirand();
	} while (r1 == FL(0.0));
	
	do {
	    r2 = unirand();
	} while (r2 == FL(0.0));
	
	r1 = (MYFLT)pow(r1, 1.0 / (double)a);
	r2 = (MYFLT)pow(r2, 1.0 / (double)b);
    } while ((r1 + r2) > FL(1.0));

    return ((r1 / (r1 +r2)) * range);
}

MYFLT weibrand(MYFLT s, MYFLT t) /*      weibull distribution routine    */
{
    MYFLT r1, r2;

    if (t < FL(0.0) ) return (FL(0.0));

    do {
	r1 = unirand();
    } while (r1 == FL(0.0) || r1 == FL(1.0));

    r2 = FL(1.0) /  (FL(1.0) - r1);

    return (s * (MYFLT)pow (log((double)r2),  (1.0 /(double)t)));
}

MYFLT poissrand(MYFLT l)	/*      Poisson distribution routine    */
{
    MYFLT r1, r2, r3;

    if (l < FL(0.0) ) return (FL(0.0));

    r1 = unirand();
    r2 = (MYFLT)exp(-l);
    r3 = FL(0.0);

    while (r1 >= r2) {
	r3++;
	r1 *= unirand();
    }

    return (r3);
}
