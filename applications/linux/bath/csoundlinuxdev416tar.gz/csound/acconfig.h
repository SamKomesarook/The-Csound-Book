/*
 * $Id: acconfig.h,v 1.9 2000/12/30 08:11:37 nicb Exp $
 *
 * csound configuration file - This file is created automatically by
 * the configure process, so it should not be edited by hand.
 * If anything goes wrong and this file requires editing, please report to
 * nicb@axnet.it specifying the platform you're compiling on and the
 * csound version you're trying to compile (./configure should be telling
 * you that towards the end of the process).
 *
 */
#if !defined(_new_src_config_h_)
#	define _new_src_config_h_
@TOP@
@BOTTOM@

/* Define if you need the safe_close() function */
#undef NEEDS_SAFE_FCLOSE

/* Define if you need the safe_close() function */
#undef NEEDS_MINSHORT

/* Define if you need the safe_close() function */
#undef FORCE_STDOUT_LBUF

/* Define if your compiler supports the inline keyword */
#undef HAVE_INLINE

#if defined(NEEDS_MINSHORT)
#	if HAVE_LIMITS_H
#		include	<limits.h>
#	endif /* HAVE_LIMITS_H */
#	define	MINSHORT	SHRT_MIN
#endif /* defined(HAVE_SHRT_MIN) */

#if defined(NEEDS_SAFE_FCLOSE)
#	include <stdio.h>
#	define	fclose	safe_fclose

	int safe_fclose(FILE *);
#endif /* defined(NEEDS_SAFE_FCLOSE) */

#if defined(HAVE_INLINE)
#	define INLINE	inline
#else
#	define INLINE	/* empty on purpose */
#endif /* defined(HAVE_INLINE) */
#endif /* !defined(_new_src_config_h_) */
