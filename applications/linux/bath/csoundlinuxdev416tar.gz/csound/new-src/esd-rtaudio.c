/***************************************************************************
 * vi:set nowrap ts=4:
 *
 * $Id: esd-rtaudio.c,v 1.1 2000/12/30 08:11:39 nicb Exp $
 *
 * This module is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation version 2.
 *
 * As an exception to clause 2b of the GPL under which this code is
 * released, this source code and all of its associated files may be used
 * (compiled and/or statically or dynamically) linked and/or executed)
 * with the program known as Csound (any version released under the MIT
 * license associated with Barry Vercoe's original version).
 *
 * Csound was originally written by Barry Vercoe and released to the public
 * under a license from MIT. 
 *
 * This exception is not intended as a general waiver of the requirement
 * in clause 2b. In particular, this exception does not permit the use of
 * this source code with versions of Csound released under licenses other
 * than the MIT license associated with the "public" version of the
 * program."Extended Csound" from Analog Devices would be one example of
 * a "different version" of Csound.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 ***************************************************************************/
/* 
   --- esd-rtaudio.c ---

   $Id: esd-rtaudio.c,v 1.1 2000/12/30 08:11:39 nicb Exp $

   This is my attempt to insert native esd (enlightened sound daemon)
   support to csound. Esd allows multiple sound sources to use the sound
   devices of a given machine. More info on esd can be found at:
   http://www.esound.org

   The planned development for the esd driver is:

   - output support			[DONE]
   - input support			[DONE]
   - full-duplex support	[DONE but very weak]
   - support of a number of options:
     - volume				[can't currently be done on esd 0.2.8]
     - esd host selection	[DONE]

   [Nicola Bernardini - nicb@axnet.it]

   This module is included when RTAUDIO is defined at compile time.
   It provides an interface between Csound realtime record/play calls
   and the device-driver code that controls the actual hardware.
*/

#include <sys/socket.h>

#include <esd.h>

#include "../cs.h"
#include "../soundio.h"
#include "syserrs.h"

/*
 * please check configure.in (for those distributions which support it...)
 * for an explanation on why this is done this way
 */
#if !defined(INLINE)
#	define	INLINE	/* empty on purpose */
#endif /* !defined(INLINE) */

/*
 * internal data structure and methods
 */
typedef struct
{
	int		input;		/* input socket descriptor	*/
	int		output;		/* output socket descriptor	*/
	char	*name;		/* fallback name, usually NULL */
	char 	*host;		/* esd host name */
} EsdGlobalData;

EsdGlobalData esd =
{
	-1,
	-1,
	(char *) NULL,
	(char *) NULL
};

void
input_socket_set(int sock)
{
	esd.input = sock;
}

void
output_socket_set(int sock)
{
	esd.output = sock;
}

int
input_socket()
{
	return esd.input;
}

int
output_socket()
{
	return esd.output;
}

void
esd_name_set(char *string)
{
	esd.name = string;
}

void
esd_host_set(char *string)
{
	esd.host = string;
}

char *
esd_name()
{
	return esd.name;
}

char *
esd_host()
{
	return esd.host;
}
/*
 * map_channels - as of version 0.2.8, esd supports only two channels
 *                so we remap any higher number of channel to two
 */
static int
map_channels(const int numchannels)
{
	int channels[] = { '\0', ESD_MONO, ESD_STEREO };
	int size = sizeof(channels);
	int result = channels[size-1];

	if (numchannels < size)
		result = channels[numchannels];

	return result;
}

static int
map_numbits(const int sample_size_in_bytes)
{
	int result = ESD_BITS16;

	switch(sample_size_in_bytes)
	{
		case 1:
				result = ESD_BITS8;
				break;
		case 2:
				result = ESD_BITS16;
				break;
		default:
		{
				char buf[256] = { '\0' };
				sprintf(buf, "%d bits: format not recognized by the esd server", sample_size_in_bytes);
				die(buf);
				break;
		}
	};

	return result;
}

/*
 * public functions, called by csound
 */
extern void setscheduler(void);
void setsndparms(int fd, int data_format, int num_channels,
				 MYFLT sample_rate, unsigned int buffer_size);

void
recopen(int numchannels, int data_size, MYFLT sampling_rate, int scale)
{
	/* open soundcard in specified mode */
	int	oMaxLag = O.oMaxLag;	/* import DAC setting from command line	*/
    int	bits = map_numbits(data_size), channels = map_channels(numchannels);
    int	mode = ESD_STREAM;
	int sr	 = (int) sampling_rate;
	int	sock = -1;
	int func = ESD_RECORD ;
   	int format = bits | channels | mode | func;


	if (oMaxLag <= 0)			/* if DAC sampframes ndef in command line */
		oMaxLag = IODACSAMPS;	/* use the default value				*/

	if ((sock = esd_record_stream_fallback(format, sr, esd_host(), esd_name())) <= 0)
		die("esd-rtaudio: error while querying esd server for audio input");

	input_socket_set(sock);

	setsndparms(input_socket(), O.informat, numchannels, (MYFLT) sampling_rate,
				(unsigned int) oMaxLag * O.insampsiz);
}

void
playopen(int numchannels, int data_size, MYFLT sampling_rate, int scale)
{
	int	oMaxLag = O.oMaxLag;	/* import DAC setting from command line	*/
    int	bits = map_numbits(data_size), channels = map_channels(numchannels);
    int	mode = ESD_STREAM;
	int sr	 = (int) sampling_rate;
	int	sock = -1;
	int func = ESD_PLAY ;
   	int format = bits | channels | mode | func;

	if (oMaxLag <= 0)			/* if DAC sampframes ndef in command line */
		oMaxLag = IODACSAMPS;	/* use the default value				*/

	if ((sock = esd_play_stream_fallback(format, sr, esd_host(), esd_name())) <= 0)
		die("esd-rtaudio: error while querying esd server for audio output");

	output_socket_set(sock);

	setscheduler();

	setsndparms(output_socket(), O.outformat, numchannels, (MYFLT) sampling_rate,
				(unsigned int) oMaxLag * O.outsampsiz);
}

int
rtrecord(char *inbuf, int inbytes)
{
	int outbytes = 0;
	int sock = input_socket();

#if 0 /* this is not right yet, but printing error messages makes it even worse */
    if ((outbytes = read(sock, inbuf, (unsigned int) inbytes)) != inbytes)
		printf("error while reading esd server for audio input (%d bytes expected, %d bytes read)\n", inbytes, outbytes);
#else
    outbytes = read(sock, inbuf, (unsigned int) inbytes);
#endif

    return(outbytes);
}

void
rtplay(char *outbuf, int inbytes) /* put samples to server  */
{
	extern	long nrecs;
	int		outbytes	= 0;
	int		sock		= output_socket();

    if ((outbytes = write(sock, outbuf, (unsigned int) inbytes)) != inbytes)
		printf("error while writing to esd server for audio output (%d bytes expected, %d bytes read)\n", inbytes, outbytes);

    nrecs++;
}

INLINE static void
rt_esd_close(int sock, char *message)
{
	if (sock > 0)
	{
    	if (esd_close(sock) < -1)
      		die(message);
	}
}

void
rtclose(void)              /* close the I/O device entirely  */
{                          /* called only when both complete */
	rt_esd_close(input_socket(), "esd-rtaudio: error in closing input audio stream");
	rt_esd_close(output_socket(), "esd-rtaudio: error in closing output audio stream");

    if (O.Linein)
	{
		extern int Linefd;

#ifdef PIPES
		extern FILE *Linepipe;

    	if (O.Linename[0]=='|') pclose(Linepipe);
		else
#endif
		if (strcmp(O.Linename, "stdin")!=0)
			close(Linefd);
    }
}

void
setvolume( unsigned volume )
{
	/* sorry - yet to be implemented */
	puts("esd-rtaudio: volume function is not (yet :) available");
}

void
setsndparms(int fd, int data_format, int num_channels, MYFLT sample_rate,
			unsigned int buffer_size)
{
	/*
	 * This is a villain hack that does not work too well, yet [nicb@axnet.it]
	 */
    int buf_size = buffer_size > ESD_BUF_SIZE ? buffer_size : ESD_BUF_SIZE;

    syscall_warning(setsockopt(fd, SOL_SOCKET, SO_SNDBUF, &buf_size, sizeof( buf_size )), "esd-rtaudio: set send buffer size to %d failed", buf_size);
    syscall_warning(setsockopt(fd, SOL_SOCKET, SO_RCVBUF, &buf_size, sizeof( buf_size )), "esd-rtaudio: set receive buffer size to %d failed", buf_size);
}
