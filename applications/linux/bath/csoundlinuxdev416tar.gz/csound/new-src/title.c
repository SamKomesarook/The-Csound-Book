/*
 * $Id: title.c,v 1.6 2002/01/02 16:21:47 nicb Exp $
 *
 * Csound Linux source title.c
 *
 */
/*
 * print_title: no arguments
 */

#include "../cs.h"
#include "../new-src/version.h"

void
print_title()
{
	const char *fsize = (sizeof(MYFLT)==sizeof(double)) ? "doubles" : "floats";
	err_printf("\n=============> [cool name here] Linux Csound <=============\n\
==> Version %s (%s)(floats are %s) <==\n\n",
		VERSIONSTRING, __DATE__, fsize);
}

void print_long_title()
{
	print_title();
	err_printf("BEWARE: this is not the canonical version! (caveat emptor)\n\
Please report bugs of this version to\n\
http://www.ilogic.com.au/cgi-bin/csound-bugs\n");
}
