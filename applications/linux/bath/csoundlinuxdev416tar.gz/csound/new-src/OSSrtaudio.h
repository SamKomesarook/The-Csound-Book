/* OSSrtaudio.h */

#ifndef _OSS_RTAUDIO_INCLUDED
#define _OSS_RTAUDIO_INCLUDED

#define OSS_RECORD 0
#define OSS_PLAY   1
#define OSS_DUPLEX 2

extern char* oss_in;  /* used in soundio.c and OSSrtaudio.c  */
extern char* oss_out;

/* open DSP */
extern void oss_open(int, int, MYFLT, int, int);

/*
  extern void oss_openDuplex (int, int, float, int);
  extern void oss_openRecord (int, int, float, int);
  extern void oss_openPlay   (int, int, float, int);
*/

#endif /* _OSS_RTAUDIO_INCLUDED */

