/* new-src/config.h.  Generated automatically by configure.  */
/* new-src/config.h.in.  Generated automatically from configure.in by autoheader.  */
/*
 * $Id: config.h.in,v 1.12 2001/05/17 00:19:45 nicb Exp $
 *
 * csound configuration file - This file is created automatically by
 * the configure process, so it should not be edited by hand.
 * If anything goes wrong and this file requires editing, please report to
 * nicb@axnet.it specifying the platform you're compiling on and the
 * csound version you're trying to compile (./configure should be telling
 * you that towards the end of the process).
 *
 */
#if !defined(_new_src_config_h_)
#	define _new_src_config_h_

/* Define to empty if the keyword does not work.  */
/* #undef const */

/* Define if you don't have vprintf but do have _doprnt.  */
/* #undef HAVE_DOPRNT */

/* Define if you have <vfork.h>.  */
/* #undef HAVE_VFORK_H */

/* Define if you have the vprintf function.  */
#define HAVE_VPRINTF 1

/* Define to `long' if <sys/types.h> doesn't define.  */
/* #undef off_t */

/* Define to `int' if <sys/types.h> doesn't define.  */
/* #undef pid_t */

/* Define as the return type of signal handlers (int or void).  */
#define RETSIGTYPE void

/* Define if the `setpgrp' function takes no argument.  */
#define SETPGRP_VOID 1

/* Define to `unsigned' if <sys/types.h> doesn't define.  */
/* #undef size_t */

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

/* Define if you can safely include both <sys/time.h> and <time.h>.  */
#define TIME_WITH_SYS_TIME 1

/* Define if your <sys/time.h> declares struct tm.  */
/* #undef TM_IN_SYS_TIME */

/* Define vfork as fork if vfork does not work.  */
/* #undef vfork */

/* Define if you have the getcwd function.  */
#define HAVE_GETCWD 1

/* Define if you have the getopt_long function.  */
#define HAVE_GETOPT_LONG 1

/* Define if you have the putenv function.  */
#define HAVE_PUTENV 1

/* Define if you have the select function.  */
#define HAVE_SELECT 1

/* Define if you have the strerror function.  */
#define HAVE_STRERROR 1

/* Define if you have the strstr function.  */
#define HAVE_STRSTR 1

/* Define if you have the strtod function.  */
#define HAVE_STRTOD 1

/* Define if you have the strtoul function.  */
#define HAVE_STRTOUL 1

/* Define if you have the itoa function.  */
/* #undef HAVE_ITOA */

/* Define if you have the <fcntl.h> header file.  */
#define HAVE_FCNTL_H 1

/* Define if you have the <limits.h> header file.  */
#define HAVE_LIMITS_H 1

/* Define if you have the <malloc.h> header file.  */
#define HAVE_MALLOC_H 1

/* Define if you have the <sgtty.h> header file.  */
#define HAVE_SGTTY_H 1

/* Define if you have the <strings.h> header file.  */
#define HAVE_STRINGS_H 1

/* Define if you have the <sys/file.h> header file.  */
#define HAVE_SYS_FILE_H 1

/* Define if you have the <sys/ioctl.h> header file.  */
#define HAVE_SYS_IOCTL_H 1

/* Define if you have the <sys/time.h> header file.  */
#define HAVE_SYS_TIME_H 1

/* Define if you have the <unistd.h> header file.  */
#define HAVE_UNISTD_H 1

/* Define if you need the safe_close() function */
#define NEEDS_SAFE_FCLOSE 1

/* Define if you need the safe_close() function */
#define NEEDS_MINSHORT 1

/* Define if you need the safe_close() function */
/* #undef FORCE_STDOUT_LBUF */

/* Define if your compiler supports the inline keyword */
#define HAVE_INLINE 1

/* Define if you have the fltk toolkit library */
#define HAVE_FLTK 1

#if defined(NEEDS_MINSHORT)
#	if HAVE_LIMITS_H
#		include	<limits.h>
#	endif /* HAVE_LIMITS_H */
#	define	MINSHORT	SHRT_MIN
#endif /* defined(HAVE_SHRT_MIN) */

#if defined(NEEDS_SAFE_FCLOSE)
#	include <stdio.h>
#	define	fclose	safe_fclose

	int safe_fclose(FILE *);
#endif /* defined(NEEDS_SAFE_FCLOSE) */

#if defined(HAVE_INLINE)
#	define INLINE	inline
#else
#	define INLINE	/* empty on purpose */
#endif /* defined(HAVE_INLINE) */

#if !defined(HAVE_ITOA)
#	if defined(__cplusplus)
	extern "C"
	{
#	endif /* defined(__cplusplus) */
		char* itoa(int, char *, int);/* add substitute definition */
#	if defined(__cplusplus)
	};
#	endif /* defined(__cplusplus) */
#endif /* !defined(HAVE_ITOA) */

#endif /* !defined(_new_src_config_h_) */
