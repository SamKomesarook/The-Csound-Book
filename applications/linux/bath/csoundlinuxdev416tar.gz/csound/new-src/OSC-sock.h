/* ===================================================================
 * File:	OSC-sock.h
 * Time-stamp:	<2000-12-13 05:36:31 steve>
 * Author:	Stefan Kersten <steve@k-hornz.de>
 * Contents:	Csound/OSC support
 * ===================================================================
 * $Id: OSC-sock.h,v 1.5 2001/01/13 11:22:55 nicb Exp $
 * ===================================================================
 */

#if !defined(_OSC_sock_h_)
#define _OSC_sock_h_

#include <OSC/OSC-client.h>

#include "cs.h"
#include <OSC/OSC-network-util.h>

/* ===================================================================
 * OSCinit
 */
typedef struct 
{
  OPDS		h;
  MYFLT		*_port;
} OSCINIT;

/* ===================================================================
 * OSCslot
 */
#define MSlot_MaxAddrLen	128
#define MSlot_MaxBufSize	2048	/* Max size of incoming UDP buffers */

typedef struct ControlContextStruct* ControlContext;

typedef struct
{
  OPDS		h;
  MYFLT		*_ins;
  MYFLT		*_numtags;
  MYFLT		*_meth;
  MYFLT		*_init;	/* opt (0) */
  MYFLT		*_min;	/* opt (0) */
  MYFLT		*_max;	/* opt (0) */
} OSCSLOT;

typedef struct 
{
  OPDS			h;
  MYFLT			*_result;
  MYFLT			*_meth;
  MYFLT			*_instag; /* opt (-1) */
  ControlContext	context;
} OSCSLOTR;

typedef struct
{
  OPDS		h;
  MYFLT		*_arg;
  MYFLT		*_meth;
  MYFLT		*_instag;
  MYFLT		*_min;		/* opt (0) */
  MYFLT		*_max;		/* opt (0) */
  char		address[MSlot_MaxAddrLen];
  OSCbuf	buf;
  char		byteArr[MSlot_MaxBufSize];  
} OSCSLOTW;

void osc_init(void*);
void osc_slot(void*);
void osc_slotr_set(void*), osc_slotr(void*);
void osc_slotw_set(void*), osc_slotw(void*);

/* ===================================================================
 * OSCpeer
 */
typedef struct
{
  OPDS		h;
  MYFLT		*_host;
  MYFLT		*_port;
  MYFLT		*_id;		/* opt (0) */
  MYFLT		*_notify;	/* opt (0), unused */
} OSCPEER;

/* ===================================================================
 * OSCsend
 */
#define MSend_MaxAddrLen	256
#define MSend_MaxBufSize	2048	/* should be enough ... */

typedef struct 
{
  OPDS 		h;
  MYFLT		*_arg;
  MYFLT		*_addr;
  MYFLT		*_id;
  char 		address[MSend_MaxAddrLen];
  OSCbuf	buf;
  char		byteArr[MSend_MaxBufSize];
  OSC_UDPSocket sock;
} OSCSEND;

void osc_peer(void*);
void osc_send_set(void*), osc_send(void*);

#endif /* !defined(_OSC_sock_h_) */
