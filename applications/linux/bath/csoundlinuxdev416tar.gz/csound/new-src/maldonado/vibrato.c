#include "cs.h"
#include <math.h>
#include "vibrato.h"
#include "../../uggab.h"
/*-------------- START Gab --------------------------------------------*/ /* gab d5*/

void ikDiscreteUserRand(DURAND *p) { /* gab d5*/
    if (p->pfn != (long)*p->tableNum) {
		if ( (p->ftp = ftfindp(p->tableNum) ) == NULL) {
			sprintf(errmsg, "invalid table no. %f", *p->tableNum);
			perferror(errmsg);
			return ;
		}
		p->pfn = (long)*p->tableNum;
    }
	*p->out = p->ftp->ftable[(long)(randGab * p->ftp->flen+.5)];
}

void ikContinuousUserRand(CURAND *p) { /* gab d5*/
	long indx;
	MYFLT findx, fract,v1,v2;
    if (p->pfn != (long)*p->tableNum) {
		if ( (p->ftp = ftfindp(p->tableNum) ) == NULL) {
			sprintf(errmsg, "invalid table no. %f", *p->tableNum);
			perferror(errmsg);
			return ;
		}
		p->pfn = (long)*p->tableNum;
    }
	findx = (MYFLT) (randGab * p->ftp->flen+.5);
	indx = (long) findx;
	fract = findx - indx;
    v1 = *(p->ftp->ftable + indx);
    v2 = *(p->ftp->ftable + indx + 1);
    *p->out = (v1 + (v2 - v1) * fract) * (*p->max - *p->min) + *p->min;
}

void krsnsetx(KRESONX *p) /* Gabriel Maldonado, modifies for arb order */
{
    int scale;
    p->scale = scale = (int) *p->iscl;
    if((p->loop = (int) (*p->ord + .5)) < 1) p->loop = 4; /*default value*/
    if (!*p->istor && (p->aux.auxp == NULL ||
                      (int)(p->loop*2*sizeof(MYFLT)) > p->aux.size))
      auxalloc((long)(p->loop*2*sizeof(MYFLT)), &p->aux);
    p->yt1 = (MYFLT*)p->aux.auxp; p->yt2 = (MYFLT*)p->aux.auxp + p->loop;
    if (scale && scale != 1 && scale != 2) {
      sprintf(errmsg,"illegal reson iscl value, %f",*p->iscl);
      initerror(errmsg);
    }
    p->prvcf = p->prvbw = -100.0f;

    if (!(*p->istor)) {
      int j;
      for (j=0; j< p->loop; j++) p->yt1[j] = p->yt2[j] = 0.0f;
    }
}

void kresonx(KRESONX *p) /* Gabriel Maldonado, modified  */
{
    int	flag = 0, j;
    MYFLT	*ar, *asig;
    MYFLT	c3p1, c3t4, omc3, c2sqr;
    MYFLT *yt1, *yt2, c1,c2,c3; 
	
    if (*p->kcf != p->prvcf) {
		p->prvcf = *p->kcf;
		p->cosf = (MYFLT) cos((double)(*p->kcf * tpidsr * ksmps));
		flag = 1;
    }
    if (*p->kbw != p->prvbw) {
		p->prvbw = *p->kbw;
		p->c3 = (MYFLT) exp((double)(*p->kbw * mtpdsr * ksmps));
		flag = 1;
    }
    if (flag) {
		c3p1 = p->c3 + 1.0f;
		c3t4 = p->c3 * 4.0f;
		omc3 = 1.0f - p->c3;
		p->c2 = c3t4 * p->cosf / c3p1;		/* -B, so + below */
		c2sqr = p->c2 * p->c2;
		if (p->scale == 1)
			p->c1 = omc3 * (MYFLT)sqrt(1.0 - (double)(c2sqr / c3t4));
		else if (p->scale == 2)
			p->c1 = (MYFLT)sqrt((double)((c3p1*c3p1-c2sqr) * omc3/c3p1));
		else p->c1 = 1.0f;
    }
    c1=p->c1; 
    c2=p->c2;
    c3=p->c3;
    yt1= p->yt1;
    yt2= p->yt2;
    asig = p->asig;
	ar = p->ar;
    for (j=0; j< p->loop; j++) {
		*ar = c1 * *asig + c2 * *yt1 - c3 * *yt2;
		*yt2 = *yt1;
		*yt1 = *ar;
		yt1++;
		yt2++;
		asig= p->ar;
    }
}

/*-------------- END Gab --------------------------------------------*/ /* gab d5*/

/*//////////////////////////////////////////*/

/*--------------------------------*/
#define FZERO	FL(0.0)
#define FONE	FL(1.0)

void metro_set(METRO *p)
{
    MYFLT	phs;
    long  longphs;
	if ((phs = *p->iphs) >= FZERO) {
		if ((longphs = (long)phs))
			warning("metro:init phase truncation");
		p->curphs = phs - (MYFLT)longphs;
	}
	p->flag=1;
}


void metro(METRO *p)
{
    double	phs= p->curphs;
	if(phs == FZERO && p->flag) {
		*p->sr = FONE;
		p->flag = 0;
	}
	else if ((phs += *p->xcps * onedkr) >= FONE) {
		*p->sr = FONE;
		phs -= FONE;
		p->flag = 0;
	}
	else 
		*p->sr = FZERO;
	p->curphs = phs;
	
}





/*--------------------------------*/

void mtable_i(MTABLEI *p)
{
	
	FUNC *ftp;
	int j, nargs;
	MYFLT *table, xbmul, **out = p->outargs;
	if ((ftp = ftfind(p->xfn)) == NULL) {
		  initerror("mtablei: incorrect table number");
          return;
	}
	table = ftp->ftable;
	nargs = p->INOCOUNT-4;
	if (*p->ixmode)
		xbmul = (MYFLT) (ftp->flen / nargs);

	if (*p->kinterp) {
		MYFLT 	v1, v2 ;
		MYFLT fndx = (*p->ixmode) ? *p->xndx * xbmul : *p->xndx;
		long indx = (long) fndx;
		MYFLT fract = fndx - indx;
		for (j=0; j < nargs; j++) {
		    v1 = table[indx * nargs + j];
			v2 = table[(indx + 1) * nargs + j];
			**out++ = v1 + (v2 - v1) * fract;
		}
	}
	else {
		long indx = (*p->ixmode) ? (long)(*p->xndx * xbmul) : (long) *p->xndx;
		for (j=0; j < nargs; j++)
			**out++ =  table[indx * nargs + j];
	}
}

void mtable_set(MTABLE *p)	 /* mtab by G.Maldonado */
{
	FUNC *ftp;
	if ((ftp = ftfind(p->xfn)) == NULL) {
		  initerror("mtable: incorrect table number");
          return;
	}
	p->ftable = ftp->ftable;
	p->nargs = p->INOCOUNT-4;
	p->len = ftp->flen / p->nargs;
	p->pfn = (long) *p->xfn;
	if (*p->ixmode)
		p->xbmul = (MYFLT) ftp->flen / p->nargs;
}

void mtable_k(MTABLE *p)
{
	int j, nargs = p->nargs;
	MYFLT **out = p->outargs;
	MYFLT *table;
	long len;
    if (p->pfn != (long)*p->xfn) {
		FUNC *ftp;
		if ( (ftp = ftfindp(p->xfn) ) == NULL) {
			perferror("mtable: incorrect table number");
			return;
		}
		p->pfn = (long)*p->xfn;
		p->ftable = ftp->ftable;
		p->len = ftp->flen / nargs;
		if (*p->ixmode)
			p->xbmul = (MYFLT) ftp->flen / nargs;
    }
	table= p->ftable;
	len = p->len;
	if (*p->kinterp) {
		MYFLT fndx;
		long indx;
		MYFLT fract;
		long indxp1;
		MYFLT 	v1, v2 ;
		fndx = (*p->ixmode) ? *p->xndx * p->xbmul : *p->xndx;
		if (fndx >= len)
			fndx = (MYFLT) fmod(fndx, len);
		indx = (long) fndx;
		fract = fndx - indx;
		indxp1 = (indx < len-1) ? (indx+1) * nargs : 0;
		indx *=nargs;
		for (j=0; j < nargs; j++) {
		    v1 = table[indx + j];
			v2 = table[indxp1 + j];
			**out++ = v1 + (v2 - v1) * fract;
		}
	}
	else {
		long indx = (*p->ixmode) ? ((long)(*p->xndx * p->xbmul) % len) * nargs : ((long) *p->xndx % len ) * nargs ;
		for (j=0; j < nargs; j++)
			**out++ =  table[indx + j];
	}
}

void mtable_a(MTABLE *p)
{
	int j, nargs = p->nargs;
	int	nsmps = ksmps, ixmode = (int) *p->ixmode, k=0;
	MYFLT **out = p->outargs;
	MYFLT *table;
	MYFLT *xndx = p->xndx, xbmul;
	long len;

    if (p->pfn != (long)*p->xfn) {
		FUNC *ftp;
		if ( (ftp = ftfindp(p->xfn) ) == NULL) {
			perferror("mtable: incorrect table number");
			return;
		}
		p->pfn = (long)*p->xfn;
		p->ftable = ftp->ftable;
		p->len = ftp->flen / nargs;
		if (ixmode)
			p->xbmul = (MYFLT) ftp->flen / nargs;
    }
	table = p->ftable;
	len = p->len;
	xbmul = p->xbmul;
	if (*p->kinterp) {
		MYFLT fndx;
		long indx;
		MYFLT fract;
		long indxp1;
		do {
			MYFLT 	v1, v2 ;
			fndx = (ixmode) ? *xndx++ * xbmul : *xndx++;
			if (fndx >= len)
				fndx = (MYFLT) fmod(fndx, len);
			indx = (long) fndx;
			fract = fndx - indx;
			indxp1 = (indx < len-1) ? (indx+1) * nargs : 0;
			indx *=nargs;
			for (j=0; j < nargs; j++) {
				v1 = table[indx + j];
				v2 = table[indxp1 + j];
				out[j][k] = v1 + (v2 - v1) * fract;
				
			}
			k++;
		} while(--nsmps);

	}
	else {
		do {
			long indx = (ixmode) ? ((long)(*xndx++ * xbmul)%len) * nargs : ((long) *xndx++ %len) * nargs;
			for (j=0; j < nargs; j++) {
				out[j][k] =  table[indx + j];
			}
			k++;
		} while(--nsmps);
	}
}




//////////// mtab start /////////////


void mtab_i(MTABI *p)
{
	FUNC *ftp;
	int j, nargs;
	long indx;
	MYFLT *table, **out = p->outargs;
	if ((ftp = ftfind(p->xfn)) == NULL) {
		  initerror("mtabi: incorrect table number");
          return;
	}
	table = ftp->ftable;
	nargs = p->INOCOUNT-2;

	indx = (long) *p->xndx;
	for (j=0; j < nargs; j++)
			**out++ =  table[indx * nargs + j];
}

void mtab_set(MTAB *p)	 /* mtab by G.Maldonado */
{
	FUNC *ftp;
	if ((ftp = ftfind(p->xfn)) == NULL) {
		  initerror("mtable: incorrect table number");
          return;
	}
	p->ftable = ftp->ftable;
	p->nargs = p->INOCOUNT-2;
	p->len = ftp->flen / p->nargs;
	p->pfn = (long) *p->xfn;
}

void mtab_k(MTAB *p)
{
	int j, nargs = p->nargs;
	MYFLT **out = p->outargs;
	MYFLT *table;
	long len, indx;

	table= p->ftable;
	len = p->len;
	indx = ((long) *p->xndx % len ) * nargs ;
	for (j=0; j < nargs; j++)
			**out++ =  table[indx + j];
}

void mtab_a(MTAB *p)
{
	int j, nargs = p->nargs;
	int	nsmps = ksmps, k=0;
	MYFLT **out = p->outargs;
	MYFLT *table;
	MYFLT *xndx = p->xndx;
	long len;
	table = p->ftable;
	len = p->len;
	do {
			long indx = ((long) *xndx++ %len) * nargs;
			for (j=0; j < nargs; j++) {
				out[j][k] =  table[indx + j];
			}
			k++;
	} while(--nsmps);
	
}


//////////// mtab end ///////////////


void mtablew_i(MTABLEIW *p)
{
	
	FUNC *ftp;
	int j, nargs;
	long indx;
	MYFLT *table, xbmul, **in = p->inargs;
	if ((ftp = ftfind(p->xfn)) == NULL) {
		  initerror("mtablewi: incorrect table number");
          return;
	}
	table = ftp->ftable;
	nargs = p->INOCOUNT-3;
	if (*p->ixmode)
		xbmul = (MYFLT) (ftp->flen / nargs);
	indx = (*p->ixmode) ? (long)(*p->xndx * xbmul) : (long) *p->xndx;
	for (j=0; j < nargs; j++)
		table[indx * nargs + j] = **in++;
}

void mtablew_set(MTABLEW *p)	 /* mtabw by G.Maldonado */
{
	FUNC *ftp;
	if ((ftp = ftfind(p->xfn)) == NULL) {
		  initerror("mtabw: incorrect table number");
          return;
	}
	p->ftable = ftp->ftable;
	p->nargs = p->INOCOUNT-3;
	p->len = ftp->flen / p->nargs;
	p->pfn = (long) *p->xfn;
	if (*p->ixmode)
		p->xbmul = (MYFLT) ftp->flen / p->nargs;
}

void mtablew_k(MTABLEW *p)
{
	int j, nargs = p->nargs;
	MYFLT **in = p->inargs;
	MYFLT *table;
	long len, indx;
    if (p->pfn != (long)*p->xfn) {
		FUNC *ftp;
		if ( (ftp = ftfindp(p->xfn) ) == NULL) {
			perferror("mtabw: incorrect table number");
			return;
		}
		p->pfn = (long)*p->xfn;
		p->ftable = ftp->ftable;
		p->len = ftp->flen / nargs;
		if (*p->ixmode)
			p->xbmul = (MYFLT) ftp->flen / nargs;
    }
	table= p->ftable;
	len = p->len;
	indx = (*p->ixmode) ? ((long)(*p->xndx * p->xbmul) % len) * nargs : ((long) *p->xndx % len ) * nargs ;
	for (j=0; j < nargs; j++)
		table[indx + j] = **in++;
}

void mtablew_a(MTABLEW *p)
{
	int j, nargs = p->nargs;
	int	nsmps = ksmps, ixmode = (int) *p->ixmode, k=0;
	MYFLT **in = p->inargs;
	MYFLT *table;
	MYFLT *xndx = p->xndx, xbmul;
	long len;

    if (p->pfn != (long)*p->xfn) {
		FUNC *ftp;
		if ( (ftp = ftfindp(p->xfn) ) == NULL) {
			perferror("mtabw: incorrect table number");
			return;
		}
		p->pfn = (long)*p->xfn;
		p->ftable = ftp->ftable;
		p->len = ftp->flen / nargs;
		if (ixmode)
			p->xbmul = (MYFLT) ftp->flen / nargs;
    }
	table = p->ftable;
	len = p->len;
	xbmul = p->xbmul;
	do {
		long indx = (ixmode) ? ((long)(*xndx++ * xbmul)%len) * nargs : ((long) *xndx++ %len) * nargs;
		for (j=0; j < nargs; j++) {
			table[indx + j] = in[j][k];
		}
		k++;
	} while(--nsmps);
}

////////////////////////////////////////

void mtabw_i(MTABIW *p)
{
	FUNC *ftp;
	int j, nargs;
	long indx;
	MYFLT *table, **in = p->inargs;
	if ((ftp = ftfind(p->xfn)) == NULL) {
		  initerror("mtabwi: incorrect table number");
          return;
	}
	table = ftp->ftable;
	nargs = p->INOCOUNT-2;
	indx = (long) *p->xndx;
	for (j=0; j < nargs; j++)
		table[indx * nargs + j] = **in++;
}

void mtabw_set(MTABW *p)	 /* mtabw by G.Maldonado */
{
	FUNC *ftp;
	if ((ftp = ftfind(p->xfn)) == NULL) {
		  initerror("mtabw: incorrect table number");
          return;
	}
	p->ftable = ftp->ftable;
	p->nargs = p->INOCOUNT-2;
	p->len = ftp->flen / p->nargs;
	p->pfn = (long) *p->xfn;
}

void mtabw_k(MTABW *p)
{
	int j, nargs = p->nargs;
	MYFLT **in = p->inargs;
	MYFLT *table;
	long len, indx;
    if (p->pfn != (long)*p->xfn) {
		FUNC *ftp;
		if ( (ftp = ftfindp(p->xfn) ) == NULL) {
			perferror("mtablew: incorrect table number");
			return;
		}
		p->pfn = (long)*p->xfn;
		p->ftable = ftp->ftable;
		p->len = ftp->flen / nargs;
    }
	table= p->ftable;
	len = p->len;
	indx = ((long) *p->xndx % len ) * nargs ;
	for (j=0; j < nargs; j++)
		table[indx + j] = **in++;
}

void mtabw_a(MTABW *p)
{
	int j, nargs = p->nargs;
	int	nsmps = ksmps, k=0;
	MYFLT **in = p->inargs;
	MYFLT *table;
	MYFLT *xndx = p->xndx;
	long len;

    if (p->pfn != (long)*p->xfn) {
		FUNC *ftp;
		if ( (ftp = ftfindp(p->xfn) ) == NULL) {
			perferror("mtabw: incorrect table number");
			return;
		}
		p->pfn = (long)*p->xfn;
		p->ftable = ftp->ftable;
		p->len = ftp->flen / nargs;
    }
	table = p->ftable;
	len = p->len;
	do {
		long indx = ((long) *xndx++ %len) * nargs;
		for (j=0; j < nargs; j++) {
			table[indx + j] = in[j][k];
		}
		k++;
	} while(--nsmps);
}

/*/////////////////////////////////////////////*/

void fastab_set(FASTAB *p)
{
	if ((p->ftp = ftfind(p->xfn)) == NULL) {
		  initerror("fastab: incorrect table number");
          return;
	}
	if (*p->ixmode)
		p->xbmul = (MYFLT) p->ftp->flen;
	else 
		p->xbmul = FONE;
 
}

void fastabw (FASTAB *p)
{
	int	nsmps = ksmps;
	MYFLT *tab = p->ftp->ftable;
	MYFLT *rslt = p->rslt, *ndx = p->xndx;
	if (*p->ixmode) {
		do *(tab + (long) (*ndx++ * p->xbmul)) = *rslt++;
		while(--nsmps);
	}
	else {
		do *(tab + (long) *ndx++) = *rslt++;
		while(--nsmps);
	}
}

void fastabk(FASTAB *p) 
{
	if (*p->ixmode)
		*p->rslt =  *(p->ftp->ftable + (long) (*p->xndx * p->xbmul));
	else
		*p->rslt =  *(p->ftp->ftable + (long) *p->xndx);
}

void fastabkw(FASTAB *p) 
{
	
	if (*p->ixmode) 
		*(p->ftp->ftable + (long) (*p->xndx * p->xbmul)) = *p->rslt;		
	else
		*(p->ftp->ftable + (long) *p->xndx) = *p->rslt;
}


void fastabi(FASTAB *p) 
{
	
	FUNC *ftp;
	//ftp = ftfind(p->xfn);

	if ((ftp = ftfind(p->xfn)) == NULL) {
		  initerror("tab_i: incorrect table number");
          return;
	}
	if (*p->ixmode)
		*p->rslt =  *(ftp->ftable + (long) (*p->xndx * ftp->flen));
	else
		*p->rslt =  *(ftp->ftable + (long) *p->xndx);
}

void fastabiw(FASTAB *p) 
{
	FUNC *ftp;
	//ftp = ftfind(p->xfn);
	if ((ftp = ftfind(p->xfn)) == NULL) {
		  initerror("tabw_i: incorrect table number");
          return;
	}
	if (*p->ixmode)
		*(ftp->ftable + (long) (*p->xndx * ftp->flen)) = *p->rslt;
	else
		*(ftp->ftable + (long) *p->xndx) = *p->rslt;
}


void fastab(FASTAB *p)
{
	int	nsmps = ksmps;
	MYFLT *tab = p->ftp->ftable;
	MYFLT *rslt = p->rslt, *ndx = p->xndx;
	if (*p->ixmode) {
		do *rslt++ = *(tab + (long) (*ndx++ * p->xbmul));
		while(--nsmps);
	}
	else {
		do *rslt++ = *(tab + (long) *ndx++ );
		while(--nsmps);
	}
}











/* ************************************************************ */
/* Opcodes from Peter Neub�cker                              */
/* ************************************************************ */


void printi(PRINTI *p)
{
    char    *sarg;

    if ((*p->ifilcod != sstrcod) || (*p->STRARG == 0)) 
    {   sprintf(errmsg, "printi parameter was not a \"quoted string\"\n");
        initerror(errmsg);
        return;
    }
    else 
    {   sarg = p->STRARG;
        do 
        { putchar(*sarg);
        } while (*++sarg != 0);
        putchar(10);
        putchar(13);
    }
}


/*====================
opcodes from Jens Groh
======================*/

void nlalp_set(NLALP *p) {
   if (!(*p->istor)) {
      p->m0 = 0.;
      p->m1 = 0.;
   }
}



void nlalp(NLALP *p) {
   int nsmps;
   MYFLT *rp;
   MYFLT *ip;
   double m0;
   double m1;
   double tm0;
   double tm1;
   double klfact;
   double knfact;

   nsmps = ksmps;
   rp = p->aresult;
   ip = p->ainsig;
   klfact = (double)*p->klfact;
   knfact = (double)*p->knfact;
   tm0 = p->m0;
   tm1 = p->m1;
   if (knfact == 0.) { /* linear case */
      if (klfact == 0.) { /* degenerated linear case */
         m0 = (double)*ip++ - tm1;
         *rp++ = (MYFLT)(tm0);
         while (--nsmps) {
            *rp++ = (MYFLT)(m0);
            m0 = (double)*ip++;
         }
         tm0 = m0;
         tm1 = 0.;
      } else { /* normal linear case */
         do {
            m0 = (double)*ip++ - tm1;
            m1 = m0 * klfact;
            *rp++ = (MYFLT)(tm0 + m1);
            tm0 = m0;
            tm1 = m1;
         } while (--nsmps);
      }
   } else { /* non-linear case */
      if (klfact == 0.) { /* simplified non-linear case */
         do {
            m0 = (double)*ip++ - tm1;
            m1 = fabs(m0) * knfact;
            *rp++ = (MYFLT)(tm0 + m1);
            tm0 = m0;
            tm1 = m1;
         } while (--nsmps);
      } else { /* normal non-linear case */
         do {
            m0 = (double)*ip++ - tm1;
            m1 = m0 * klfact + fabs(m0) * knfact;
            *rp++ = (MYFLT)(tm0 + m1);
            tm0 = m0;
            tm1 = m1;
         } while (--nsmps);
      }
   }
   p->m0 = tm0;
   p->m1 = tm1;
}

/* -----------------------------------------------*/

void adsynt2_set(ADSYNT2 *p)
{
    FUNC    *ftp;
    int     count;
    long    *lphs;
	MYFLT	*pAmp;
    p->inerr = 0;

    if ((ftp = ftfind(p->ifn)) != NULL) {
      p->ftp = ftp;
    }
    else {
      p->inerr = 1;
      initerror(Str(X_173,"adsynt: wavetable not found!"));
      return;
    }

    count = (int)*p->icnt;
    if (count < 1)
      count = 1;
    p->count = count;

    if ((ftp = ftfind(p->ifreqtbl)) != NULL) {
      p->freqtp = ftp;
    }
    else {
      p->inerr = 1;
      initerror(Str(X_309,"adsynt: freqtable not found!"));
      return;
    }
    if (ftp->flen < count) {
      p->inerr = 1;
      initerror(Str(X_1424,"adsynt: partial count is greater than freqtable size!"));
      return;
    }

    if ((ftp = ftfind(p->iamptbl)) != NULL) {
      p->amptp = ftp;
    }
    else {
      p->inerr = 1;
      initerror(Str(X_1473, "adsynt: amptable not found!"));
      return;
    }
    if (ftp->flen < count) {
      p->inerr = 1;
      initerror(Str(X_1474,"adsynt: partial count is greater than amptable size!"));
      return;
    }

    if (p->lphs.auxp==NULL || p->lphs.size < (long)(sizeof(long)+sizeof(MYFLT))*count)
      auxalloc((sizeof(long)+sizeof(MYFLT))*count, &p->lphs);

    lphs = (long*)p->lphs.auxp;
    if (*p->iphs > 1) {
      do
        *lphs++ = ((long)((MYFLT)((double)rand()/(double)RAND_MAX)
                          * fmaxlen)) & PHMASK;
      while (--count);
    }
    else if (*p->iphs >= 0){
      do
        *lphs++ = ((long)(*p->iphs * fmaxlen)) & PHMASK;
      while (--count);
    }
	pAmp = p->previousAmp = (MYFLT *) lphs + sizeof(MYFLT)*count;
	count = (int)*p->icnt;
	do 
		*pAmp++ = FL(0.);
    while (--count);
}

void adsynt2(ADSYNT2 *p)
{
    FUNC    *ftp, *freqtp, *amptp;
    MYFLT   *ar, *ar0, *ftbl, *freqtbl, *amptbl, *prevAmp;
    MYFLT   amp0, amp, cps0, cps, ampIncr,amp2;
    long    phs, inc, lobits;
    long    *lphs;
    int     nsmps, count;

    if (p->inerr) {
      initerror(Str(X_1475,"adsynt: not initialized"));
      return;
    }
    ftp = p->ftp;
    ftbl = ftp->ftable;
    lobits = ftp->lobits;
    freqtp = p->freqtp;
    freqtbl = freqtp->ftable;
    amptp = p->amptp;
    amptbl = amptp->ftable;
    lphs = (long*)p->lphs.auxp;
	prevAmp = p->previousAmp;

    cps0 = *p->kcps;
    amp0 = *p->kamp;
    count = p->count;

    ar0 = p->sr;
    ar = ar0;
    nsmps = ksmps;
    do
      *ar++ = FL(0.0);
    while (--nsmps);

    do {
      ar = ar0;
      nsmps = ksmps;
      amp2 = *prevAmp;
	  amp = *amptbl++ * amp0;
      cps = *freqtbl++ * cps0;
      inc = (long) (cps * sicvt);
      phs = *lphs;
	  ampIncr = (amp - *prevAmp) / ensmps;
      do {
        *ar++ += *(ftbl + (phs >> lobits)) * amp2;
        phs += inc;
        phs &= PHMASK;
		amp2 += ampIncr;
      }
      while (--nsmps);
	  *prevAmp++ = amp;
      *lphs++ = phs;
    }
    while (--count);
}


