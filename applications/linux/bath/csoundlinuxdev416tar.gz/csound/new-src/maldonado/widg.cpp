#include "widg.h"

SNAPSHOT::SNAPSHOT (vector<ADDR_SET_VALUE>& valuators)
{ // the constructor captures current values of all widgets by copying all current
  //  values from "valuators" vector (AddrSetValue) to the "fields" vector	
	is_empty =0;
	for ( int i=0; i < valuators.size(); i++) {
			string  opcode_name, widg_name;
			ADDR_SET_VALUE& v  = valuators[i];
			if (fields.size() < i+1) 
				fields.resize(i+1);
			VALUATOR_FIELD& fld = fields[i];
			float val, min, max;
			opcode_name = fld.opcode_name = ((OPDS *) (v.opcode))->optext->t.opcod;
			if (opcode_name == "FLslider") {
				FLSLIDER *p = (FLSLIDER *) (v.opcode);
				fld.widg_name = GetString(*p->name, p->STRARG);
				val = *p->kout; min = *p->imin; max =*p->imax;
				if (val < min) val=min;
				else if(val>max) val=max;
				fld.value = val; 
				fld.min = *p->imin; fld.max = *p->imax; fld.exp = (int) *p->iexp;
			} else if (opcode_name == "FLknob") {
				FLKNOB *p = (FLKNOB *) (v.opcode);
				fld.widg_name = GetString(*p->name, p->STRARG);
				val = *p->kout; min = *p->imin; max =*p->imax;
				if (val < min) val=min;
				else if(val>max) val=max;
				fld.value = val; 
				fld.min = *p->imin; fld.max = *p->imax; fld.exp = (int) *p->iexp;
			} else if (opcode_name == "FLroller") {
				FLROLLER *p = (FLROLLER *) (v.opcode);
				fld.widg_name = GetString(*p->name, p->STRARG);
				val = *p->kout; min = *p->imin; max =*p->imax;
				if (val < min) val=min;
				else if(val>max) val=max;
				fld.value = val; 
				fld.min = *p->imin; fld.max = *p->imax; fld.exp = (int) *p->iexp;
			} else if (opcode_name == "FLtext") {
				FLTEXT *p = (FLTEXT *) (v.opcode);
				fld.widg_name = GetString(*p->name, p->STRARG);
				val = *p->kout; min = *p->imin; max =*p->imax;
				if (val < min) val=min;
				else if(val>max) val=max;
				fld.value = val; 
				fld.min = *p->imin; fld.max = *p->imax; fld.exp = LIN_;
			} else if (opcode_name == "FLjoy") {
				FLJOYSTICK *p = (FLJOYSTICK *) (v.opcode);
				fld.widg_name = GetString(*p->name, p->STRARG);
				val = *p->koutx; min = *p->iminx; max =*p->imaxx;
				if (val < min) val=min;
				else if(val>max) val=max;
				fld.value = val;
				val = *p->kouty; min = *p->iminy; max =*p->imaxy;
				if (val < min) val=min;
				else if(val>max) val=max;
				fld.value2 =val;
				fld.min =  *p->iminx; fld.max  = *p->imaxx; fld.exp  = (int) *p->iexpx;
				fld.min2 = *p->iminy; fld.max2 = *p->imaxy; fld.exp2 = (int) *p->iexpy;
			} else if (opcode_name == "FLbutton") {
				FLBUTTON *p = (FLBUTTON *) (v.opcode);
				fld.widg_name = GetString(*p->name, p->STRARG);
				fld.value = *p->kout;
				fld.min = 0; fld.max = 1; fld.exp = LIN_;
			} else if (opcode_name == "FLcount") {
				FLCOUNTER *p = (FLCOUNTER *) (v.opcode);
				fld.widg_name = GetString(*p->name, p->STRARG);
				val = *p->kout; min = *p->imin; max =*p->imax;
				if (min != max) {
					if (val < min) val=min;
					else if(val>max) val=max;
				}
				fld.value = val; 
				fld.min = *p->imin; fld.max = *p->imax; fld.exp = LIN_;
			} else if (opcode_name == "FLvalue") {
				FLVALUE *p = (FLVALUE *) (v.opcode);
				fld.widg_name = GetString(*p->name, p->STRARG);
			}
			else if (opcode_name == "FLbox") {
				FL_BOX *p = (FL_BOX *) (v.opcode);
				fld.widg_name = GetString(*p->itext, p->STRARG);
			}
	}
}

void SNAPSHOT::get(vector<ADDR_SET_VALUE>& valuators) 
{  
	if(is_empty) {
		initerror("empty snapshot");
		return;
	}
	for (int j =0; j< valuators.size(); j++) {
		Fl_Widget* o = (Fl_Widget*) (valuators[j].WidgAddress);
		void *opcode = valuators[j].opcode;
		VALUATOR_FIELD& fld = fields[j];
		string opcode_name = fld.opcode_name;
		
		MYFLT val = fld.value, min=fld.min, max=fld.max, range,base;
		if (val < min) val =min;
		else if (val >max) val = max;

		if (opcode_name == "FLjoy") {
			switch(fld.exp) {
				case LIN_:	((Fl_Positioner*) o)->xvalue(val); 
					break;
				case EXP_:	
					range  = fld.max - fld.min;
					base = pow(fld.max / fld.min, 1/range);
					((Fl_Positioner*) o)->xvalue(log(val/fld.min) / log(base)) ;
					break;
				default:
					warning("not implemented yet");
					break;
			}
			val = fld.value2; min = fld.min2; max = fld.max2;
			if (val < min) val =min;
			else if (val >max) val = max;
			switch(fld.exp2) {
				case LIN_:	((Fl_Positioner*) o)->yvalue(val); 
					break;
				case EXP_:	
					range  = fld.max2 - fld.min2;
					base = pow(fld.max2 / fld.min2, 1/range);
					((Fl_Positioner*) o)->yvalue(log(val/fld.min2) / log(base)) ;
					break;
				default:
					warning("not implemented yet");
					break;
			}
			o->do_callback(o, opcode); 
		}
		else if (opcode_name == "FLbutton") {
			FLBUTTON *p = (FLBUTTON*) (opcode);
			if (*p->itype < 10) {//  don't allow to retreive its value if >= 10
				((Fl_Button*) o)->value(fld.value);
				o->do_callback(o, opcode); 
			}
		}
		else if (opcode_name == "FLcount") {
			FLCOUNTER *p = (FLCOUNTER*) (opcode);
			if (*p->itype < 10) { //  don't allow to retreive its value if >= 10
				((Fl_Counter*) o)->value(fld.value);
				o->do_callback(o, opcode); 
			}
		}
		else {
			switch(fld.exp) {
				case LIN_:	
					if (opcode_name == "FLbox" || opcode_name == "FLvalue" ) continue;
					((Fl_Valuator*) o)->value(val); 
					break;
				case EXP_:	
					range  = fld.max - fld.min;
					base = pow(fld.max / fld.min, 1/range);
					((Fl_Valuator*) o)->value(log(val/fld.min) / log(base)) ;
					break;
				default:
					warning("not implemented yet (bogus)");
					break;
			}
			o->do_callback(o, opcode); 
		}
	}
	Fl::check();
}
