/*
 * $Id: Fl_linux_stubs.cpp,v 0.0 2001/05/17 00:17:22 nicb Exp $
 *
 * this is a file used in the linux distribution to be able to use
 * the DirectCsound 5.1 widget code by Gabriel Maldonado on linux
 * systems.
 *
 * This code has been written by Nicola Bernardini (nicb@centrotemporeale.it)
 * mostly based on ideas by Dave Phillips (dlphip@bright.net)
 *
 */

#if defined(LINUX)

#include <FL/Fl_Window.h>
#include "../config.h"

int
FLkeyboard_sensing()
{
	/*
	 * since we still don't know what is FLkeyboard_sensing()
	 * should be returning, but we know that 0 will avoid troubles (?)
	 * we return this for now... [nicb@axnet.it]
	 */

	 return (0);
}

Fl_Window *
FLkeyboard_init()
{
	/*
	 * here too - we don't know what is going on...
	 * we fake it through and hope for the best...
	 */
	Fl_Window *result = new Fl_Window(0, 0);

	return result;
}

#if defined(__cplusplus)
extern "C"
{
#endif /* defined(__cplusplus) */

#if !defined(HAVE_ITOA)

#include <stdlib.h>

char *
itoa(int value, char *buffer, int radix)
{
	const char *r10 = "%d";
	const char *r16 = "%x";
	const char *default_radix_fmt = "unknown radix value";
	char *radix_fmt = (char *) NULL;
	char *result = buffer != (char *) NULL ? buffer :
						 ((char *) malloc(256));


	switch(radix)
	{
		case 10:	radix_fmt = (char *) r10;
				break;
		case 16:	radix_fmt = (char *) r16;
				break;
		default:	radix_fmt = (char *) default_radix_fmt;
				break;
	};

	sprintf(result, radix_fmt, value);

	return result;
}

#endif /* !defined(HAVE_ITOA) */

#if defined(__cplusplus)
}
#endif /* defined(__cplusplus) */

#endif /* defined(LINUX) */
