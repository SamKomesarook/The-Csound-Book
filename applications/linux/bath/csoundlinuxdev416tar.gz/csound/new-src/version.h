/*
 * $Id: version.h.in,v 0.1 2002/01/02 16:21:47 nicb Exp $
 *
 * Csound Linux source version.h replacement
 *
 * Since quite a lot of things (including configuration processes, etc.)
 * rely on the format of this file to run properly, we have replaced
 * the standard version.h (which was sitting in the canonical directory)
 * with this one (future patches should be easy, anyway, and we will have
 * better control on what happens in this file)
 * 					[nicb@axnet.it]
 *
 * The file version.h is created automatically by the configure process:
 * any changes you make to this file gets discarded at every ./configure
 * run - if you really have to edit this file, edit the version.h.in file
 * instead
 */
#if !defined(_new_src_version_h_)
#	define _new_src_version_h_

#define VERSION 4
#define SUBVER "16.0"
#define LINUX_PATCHLEVEL 0a
#define VERSIONSTRING "4.16.0.0a"

#endif /* !defined(_new_src_version_h_) */
