/* ALSArtaudio.c - hacked version of rtaudio.c to enable realtime full-duplex
 audio support for csound under Linux/ALSA.
This file incorporates the functions from LINUXaudio.c (with the exception of
sndsetvolume() which isn't used in this hacked version) so that file is no
longer needed  - fcf */
/*
 * $Id: ALSArtaudio-block.c,v 1.3 2000/10/21 16:31:08 nicb Exp $
 */

/*  This module is included when RTAUDIO is defined at compile time.
    It provides an interface between Csound realtime record/play calls
    and the device-driver code that controls the actual hardware.
*/

/* This is an updated version of the csound to ALSA interface,
   and works with latest ALSA 0.9.
   The code in this file (ALSArtaudio-block.c) uses the ALSA block transfer
   mode.
   -
   Gerard van Dongen  <gml@xs4all.nl>
   */

#include <alsa/asoundlib.h>
#include "cs.h"
#include "soundio.h"

static snd_pcm_t *capture_handle = NULL, *playback_handle = NULL;
static snd_pcm_status_t* out_status;
static snd_pcm_uframes_t period_size,buffer_size,size_returned;
extern  long    nrecs;
extern  OPARMS  O;
extern char incard[];
extern  char outcard[];
#ifdef PIPES
extern FILE* Linepipe;
#define _pclose pclose
#endif

char errorstring[1024];

int playback_go = 1;
int capture_go  = 1;

static int xrun_recovery(snd_pcm_t *handle, int err)
 {
         if (err == -EPIPE) {    /* underrun */
                 err = snd_pcm_prepare(handle);
                 if (err < 0)
                         printf("Can't recovery from underrun, prepare failed: %s\n", snd_strerror(err));
                 return 0;
         } else if (err == -ESTRPIPE) {
                 while ((err = snd_pcm_resume(handle)) == -EAGAIN)
                         sleep(1);       /* wait until suspend flag is released */
                 if (err < 0) {
                         err = snd_pcm_prepare(handle);
                         if (err < 0)
                                 printf("Can't recovery from suspend, prepare failed: %s\n", snd_strerror(err));
                 }
                 return 0;
         }
         return err;
 }




static int getformat()
{
	int p = 0;

	switch ( O.informat ) {
		case AE_UNCH:  /* unsigned char - standard Linux 8-bit format */
			p = SND_PCM_FORMAT_U8;
			break;
		case AE_CHAR:  /* signed char. supported by ALSA */
			p = SND_PCM_FORMAT_S8;
			break;
		case AE_ULAW:
			p = SND_PCM_FORMAT_MU_LAW; 
			break;
		case AE_ALAW:
			p = SND_PCM_FORMAT_A_LAW;
			break;
		case AE_SHORT:
			p = SND_PCM_FORMAT_S16_LE; /* Linux on Intel x86 is little-endian */
			break;
		case AE_LONG:
		  p = SND_PCM_FORMAT_S32_LE; /*shouldn't there be check for endianess (for linux-ppc?)*/
		case AE_FLOAT:
		        p = SND_PCM_FORMAT_FLOAT_LE;
		default:
			die("unknown sample format");
	}
	return (p);
}

void recopen(int nchnls, int dsize, MYFLT esr, int scale)
                                /* open for audio input */
{


	snd_pcm_hw_params_t* hw_params;
	int err,format,dir;
	
	snd_pcm_hw_params_alloca(&hw_params);


	err=snd_pcm_open(&capture_handle, incard, SND_PCM_STREAM_CAPTURE,0);
	if (err<0){
	  sprintf(errorstring, "Opening CAPTURE channel: %s\n", snd_strerror(err));
	  die(errorstring);
	}
	snd_pcm_nonblock(capture_handle,0);/* make sure the card is set to blocking mode */

	err = snd_pcm_hw_params_malloc(&hw_params);
	if (err<0){
	  sprintf(errorstring, "allocating memory for the hw_parameters: %s\n", snd_strerror(err));
	  die(errorstring);
	}
	
	err = snd_pcm_hw_params_any(capture_handle, hw_params);
	if (err<0){
	  sprintf(errorstring, "setting default parameters: %s\n", snd_strerror(err));
	  die(errorstring);
	}

	// set interleaved access - FIXME deal with other access types
	err = snd_pcm_hw_params_set_access(capture_handle, hw_params,SND_PCM_ACCESS_RW_INTERLEAVED);
	if (err<0){
	  sprintf(errorstring, "setting access type: %s\n", snd_strerror(err));
	  die(errorstring);
	}

	// set format
	format=getformat();
	err = snd_pcm_hw_params_set_format(capture_handle, hw_params,format);
	if (err<0){
	  sprintf(errorstring, "setting sample format: %s\n", snd_strerror(err));
	  die(errorstring);
	}

	// set the subformat, I wonder what this actually is
	err = snd_pcm_hw_params_set_subformat(capture_handle, hw_params,SND_PCM_SUBFORMAT_STD);
	if (err<0){
	  sprintf(errorstring, "setting subformat: %s\n", snd_strerror(err));
	  die(errorstring);
	}
	
	// set the number of channels
	err = snd_pcm_hw_params_set_channels(capture_handle,hw_params, nchnls);
	if (err<0){
	  sprintf(errorstring, "setting nchnls: %s\n", snd_strerror(err));
	  die(errorstring);
	}

	// set the sampling rate
	err = snd_pcm_hw_params_set_rate_near(capture_handle, hw_params,(int) esr, 0);
	if (err<0){
	  sprintf(errorstring, "setting sample rate: %s\n", snd_strerror(err));
	  die(errorstring);
	}
	if (err!=esr) {
	  printf("unable to set sr, requested %f, got %i\n",esr,err);
	  esr=err;
	}

	/* set the period and buffer size */
	/*  period size is -b buffer_size is -B*/
	/* somewhere between getlongopt.c and here the O.inbufsamps is multiplied by nchnls for some reason, */
	/* to get back to the actual softbuffer size in sample frames we have to divide again, */
	/* must be a lot of this going on */ 
	  
	period_size = O.inbufsamps/nchnls;
	buffer_size=O.oMaxLag;

	size_returned=snd_pcm_hw_params_set_buffer_size_near(capture_handle,hw_params,buffer_size);
	if (O.oMaxLag!=size_returned){
	  printf("unable to set hw buffersize, requested %i, got %i\n", buffer_size,size_returned);
	  O.oMaxLag=size_returned;
	}
	
        size_returned=snd_pcm_hw_params_set_period_size_near(capture_handle,hw_params,period_size,0);
	if (period_size!=size_returned){
	  printf("unable to set sw buffersize, requested %i, got %i\n", period_size,size_returned);
	  period_size=size_returned;
	  O.inbufsamps=size_returned*nchnls;
	}
		
	
	err = snd_pcm_hw_params(capture_handle, hw_params);
	if (err<0){
	  sprintf(errorstring, "setting parameters on pcm device: %s\n", snd_strerror(err));
	  die(errorstring);
	}	
	
	snd_pcm_hw_params_free(hw_params);
	
/* 	I tried some code here for snd_pcm_sw_params but it seemed to force the card to nonblocking mode, */
/* this could still be a bug in ALSA. */


    
		setscheduler();
}



void playopen(int nchnls, int dsize, MYFLT esr, int scale)
                                /* open for audio output */
{

	snd_pcm_hw_params_t* hw_params;

	int err,format,dir;

	snd_pcm_hw_params_alloca(&hw_params);


	err=snd_pcm_open(&playback_handle, outcard, SND_PCM_STREAM_PLAYBACK,0);
	if (err<0){
	  sprintf(errorstring, "Opening PLAYBACK channel: %s\n", snd_strerror(err));
	  die(errorstring);
	}
	snd_pcm_nonblock(playback_handle,0);


	err = snd_pcm_hw_params_malloc(&hw_params);
	if (err<0){
	  sprintf(errorstring, "allocating memory for the hw_parameters: %s\n", snd_strerror(err));
	  die(errorstring);
	}
    
	// get the default params
	err = snd_pcm_hw_params_any(playback_handle, hw_params);
	if (err<0){
	  sprintf(errorstring, "setting default parameters: %s\n", snd_strerror(err));
	  die(errorstring);
	}
	
	
	// set interleaved access - FIXME deal with other access types
	err = snd_pcm_hw_params_set_access(playback_handle, hw_params,SND_PCM_ACCESS_RW_INTERLEAVED);

	// set format

	format=getformat();
	err = snd_pcm_hw_params_set_format(playback_handle, hw_params,format);
	if (err<0){
	  sprintf(errorstring, "setting sample format: %s\n", snd_strerror(err));
	  die(errorstring);
	}
	
	// set the subformat
	err = snd_pcm_hw_params_set_subformat(playback_handle, hw_params,SND_PCM_SUBFORMAT_STD);
	if (err<0){
	  sprintf(errorstring, "setting subformat: %s\n", snd_strerror(err));
	  die(errorstring);
	}
	
	// set the number of channels
	
	err = snd_pcm_hw_params_set_channels(playback_handle,hw_params, nchnls);
	if (err<0){
	  sprintf(errorstring, "setting nchnls: %s\n", snd_strerror(err));
	  die(errorstring);
	}

	// set the sampling rate
	err = snd_pcm_hw_params_set_rate_near(playback_handle, hw_params,(int) esr, 0);


	// set the period and buffer size
	period_size = O.outbufsamps/nchnls;
	buffer_size=O.oMaxLag;

	size_returned=snd_pcm_hw_params_set_buffer_size_near(playback_handle,hw_params,buffer_size);
	if (O.oMaxLag!=size_returned){
	  printf("unable to set hw buffersize, requested %i, got %i\n", buffer_size,size_returned);
	  O.oMaxLag=size_returned;
	  
	}
	
        size_returned=snd_pcm_hw_params_set_period_size_near(playback_handle,hw_params,period_size,0);
	if (period_size!=size_returned){
	  printf("unable to set sw buffersize, requested %i, got %i\n", period_size,size_returned);
	  period_size=size_returned;
	  O.outbufsamps=size_returned*nchnls;
	}
	

	err = snd_pcm_hw_params(playback_handle, hw_params);
	if (err<0){
	  sprintf(errorstring, "setting parameters on pcm device: %s\n", snd_strerror(err));
	  die(errorstring);
	}	
	
	
	snd_pcm_hw_params_free(hw_params);
}
int rtrecord(char *inbuf, int nbytes) /* get samples from ADC */
{
	int count,limit;
	if((count = snd_pcm_readi(capture_handle, (void *) inbuf, period_size)) < 0) {
	  sprintf(errorstring, "Capture error: %s", snd_strerror(count));
	  count=0;
	}
	count=count*nchnls*O.outsampsiz;
	limit = (count > nbytes ? nbytes : count);


	return(limit);
}

void rtplay(char *outbuf, int nbytes) /* put samples to DAC - see notes in rtaudio.c */
{
	int err;

	err = snd_pcm_writei(playback_handle, (void *)outbuf, period_size);
	if (err < 0) {
	  if (xrun_recovery(playback_handle, err) < 0) {
	    printf("Write error: %s\n", snd_strerror(err));
	    exit(EXIT_FAILURE);
	  }
	}
	nrecs++;
}

void rtclose(void)              /* close the I/O device entirely  */
{                               /* called only when both complete */
	int err;
	if(capture_handle) {
	  snd_pcm_drain(capture_handle);
	  snd_pcm_close(capture_handle);
	}

	if(playback_handle) {
	  snd_pcm_drain(playback_handle);
	  snd_pcm_close(playback_handle);
	}
	
	if (O.Linein) {
#ifdef PIPES
	  if (O.Linename[0]=='|') _pclose(Linepipe);
#endif
	}
}
