/* 
   --- OSSrtaudio.c ---

   Enhanced OSS support including full-duplex and device selection 
   most of the stuff is from rtlinux.c; some is borrowed from ALSArtaudio.c
   both are NOT required to enable OSSRTAUDIO
   define OSSRTAUDIO at compile time
   ** no commandline volume support! **
   Steve Kersten, contact steve-k@gmx.net 
   
   This module is included when RTAUDIO is defined at compile time.
   It provides an interface between Csound realtime record/play calls
   and the device-driver code that controls the actual hardware.
*/

#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/soundcard.h>

#include "cs.h"
#include "soundio.h"
#include "OSSrtaudio.h"

char *oss_in  = "/dev/dsp";
char *oss_out = "/dev/dsp";

static int dspfd;
void setsndparms(int, int, int, MYFLT, unsigned);

static  int     ishift = 0, oshift = 0, oMaxLag;
extern  long    nrecs;
        long    inrecs;
extern  OPARMS  O;
extern int Linefd;
#ifdef PIPES
extern FILE* Linepipe;
#  define _pclose pclose
#endif

static int getshift(int dsize)  /* turn sample- or frame-size into shiftsize */
{
  switch(dsize) {
  case 1:  return(0);
  case 2:  return(1);
  case 4:  return(2);
  case 8:  return(3);
  default: die("rtaudio: illegal dsize");
	return(-1);		/* Not reached */
        }
}
  

void oss_open(int nchnls, int dsize, MYFLT esr, int scale, int oss_mode) {
  /* open soundcard in specified mode */
  int dup;
  extern void setscheduler(void);

  oMaxLag = O.oMaxLag;        /* import DAC setting from command line   */
  if (oMaxLag <= 0)           /* if DAC sampframes ndef in command line */
	oMaxLag = IODACSAMPS;     /* use the default value                  */
  switch (oss_mode) {

  case OSS_RECORD:
	if ((dspfd = open(oss_in, O_RDONLY)) == -1)
	  die("error while opening soundcard for audio input");
	/* initialize data format, channels, sample rate, and buffer size */
	setsndparms(dspfd, O.informat, nchnls, esr, oMaxLag * O.insampsiz);
	ishift = getshift(dsize);  
	break;

  case OSS_PLAY:
	if ((dspfd = open(oss_out, O_WRONLY)) == -1)
	  die("error while opening soundcard for audio output");
	/* set sample size/format, rate, channels, and DMA buffer size */
	setsndparms( dspfd, O.outformat, nchnls, esr, oMaxLag * O.outsampsiz);
	/* 'oshift' is not currently used by the Linux driver, but ... */
	oshift = getshift(nchnls * dsize);
	break;

  case OSS_DUPLEX:
	if ((dspfd = open(oss_in, O_RDWR)) == -1) 
	  die("error during soundcard duplex mode query:");
	if (ioctl(dspfd, SNDCTL_DSP_SETDUPLEX, 0) == -1) 	      /* set OSS duplex mode */
	  die("error while setting duplex mode");
	if (ioctl(dspfd, SNDCTL_DSP_GETCAPS, &dup) == -1)
	  die("error while retrieving soundcard capabilities");
	if (!(dup & DSP_CAP_DUPLEX))                              /* check duplex cap */
	  die("error while validating duplex capability");
	/* initialize data format, channels, sample rate, and buffer size */
	setsndparms( dspfd, O.outformat, nchnls, esr, oMaxLag * O.outsampsiz);
	/* are these functions both required? */
	oshift = getshift(nchnls * dsize);
	ishift = getshift(dsize);
	break;
  default:
	fprintf(stderr, "mode specification error in oss_open: unknown argument %d", oss_mode);
	exit(1);
  }

  setscheduler();

#ifdef _DEBUG_OSS
  printf("O.oMaxLag %d * O.insampsiz%d\n", O.oMaxLag, O.insampsiz);
  printf("O.outbufsamps %d * O.outsampsiz%d\n", O.outbufsamps, O.outsampsiz);
#endif 
}

int rtrecord(char *inbuf, int nbytes) /* get samples from ADC */
{
    /*  J. Mohr  1995 Oct 17 */
    if ( (nbytes = read(dspfd, inbuf, nbytes)) == -1 )
      die("error while reading DSP device for audio input");
    return(nbytes);
}

void rtplay(char *outbuf, int nbytes) /* put samples to DAC  */
    /* N.B. This routine serves as a THROTTLE in Csound Realtime Performance, */
    /* delaying the actual writes and return until the hardware output buffer */
    /* passes a sample-specific THRESHOLD.  If the I/O BLOCKING functionality */
    /* is implemented ACCURATELY by the vendor-supplied audio-library write,  */
    /* that is sufficient.  Otherwise, requires some kind of IOCTL from here. */
    /* This functionality is IMPORTANT when other realtime I/O is occurring,  */
    /* such as when external MIDI data is being collected from a serial port. */
    /* Since Csound polls for MIDI input at the software synthesis K-rate     */
    /* (the resolution of all software-synthesized events), the user can      */
    /* eliminate MIDI jitter by requesting that both be made synchronous with */
    /* the above audio I/O blocks, i.e. by setting -b to some 1 or 2 K-prds.  */
{
        long sampframes = nbytes >> oshift;
        /*  J. Mohr  1995 Oct 17 */
        if (write(dspfd, outbuf, nbytes) < nbytes)
            printf("/dev/dsp: couldn't write all bytes requested\n");
        nrecs++;
}

void rtclose(void)              /* close the I/O device entirely  */
{                               /* called only when both complete */
    /*  J. Mohr  1995 Oct 17 */
    if (close(dspfd) == -1)
      die("unable to close DSP device");
    if (O.Linein) {
#ifdef PIPES
      if (O.Linename[0]=='|') _pclose(Linepipe);
      else
#endif
        if (strcmp(O.Linename, "stdin")!=0) close(Linefd);
    }
}
