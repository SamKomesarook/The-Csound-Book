/*
 * $Id: execute.c,v 1.4 1999/06/23 11:53:15 nicb Exp $
 *
 * Csound Linux source execute.c
 *
 * several utilities have a main built in basically always the same
 * way (a main that calls a specific function setting orchestra and
 * score to a standard name); I isolated this in a specific function
 * so that we know where to debug when we need to...
 * 					[nicb@axnet.it]
 */
#include <string.h>
#include "../cs.h"

extern char scorename[];
extern char orchname[];

/*
 * execute - arguments:
 * 	func:	the pointer to the function to execute
 * 	argc, argv: the parameters coming from main's arguments
 */
int
execute(int (*func)(int, char *[]), int argc, char *argv[], const char *sname,
	const char *oname)
{
    strcpy(scorename, sname);
    strcpy(orchname,  oname);
    init_getstring(argc, argv);
    return (*func)(argc,argv);
}
