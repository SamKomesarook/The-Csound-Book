/*
 * vi:set nowrap ts=4:
 *
 * $Id: safe_fclose.c,v 1.1 2000/02/03 21:52:03 nicb Exp $
 *
 * This module is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */
/*
 * fclose()'ing a file twice with glibc 2.1.1 results in a segmentation
 * violation because some internal structures get free()'ed twice; I
 * wrote this to circumvent this problem [nicb@axnet.it]
 */

#include <stdio.h>
#include <unistd.h>
#include <errno.h>

int
safe_fclose(FILE *fp)
{
	int result = -1;

	/*
	 * file number handle is set to -1 upon closing, so we can use
	 * that as a marker
	 */
	if (fp != (FILE *) NULL && fileno(fp) >= 0)
			result = fclose(fp);
	else
			errno = EBADF;

	return result;
}
