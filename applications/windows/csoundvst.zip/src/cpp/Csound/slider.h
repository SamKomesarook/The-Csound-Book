//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
#define IDD_DIALOG1                     901
#define IDC_SLIDER1                     9001
#define IDC_EDIT1                       9002
#define IDC_BUTTON1                     9003
#define IDC_SLIDER1                     9004
#define IDC_EDIT1                       9005
#define IDC_BUTTON1                     9006
#define IDC_SLIDER1                     9007
#define IDC_EDIT1                       9008
#define IDC_BUTTON1                     9009
#define IDC_SLIDER1                     9010
#define IDC_EDIT1                       9011
#define IDC_BUTTON1                     9012
#define IDC_SLIDER1                     9013
#define IDC_EDIT1                       9014
#define IDC_BUTTON1                     9015
#define IDC_SLIDER1                     9016
#define IDC_EDIT1                       9017
#define IDC_BUTTON1                     9018
#define IDC_SLIDER1                     9019
#define IDC_EDIT1                       9020
#define IDC_BUTTON1                     9021
#define IDC_SLIDER1                     9022
#define IDC_EDIT1                       9023
#define IDC_BUTTON1                     9024
#define IDC_SLIDER1                     9025
#define IDC_EDIT1                       9026
#define IDC_BUTTON1                     9027
#define IDC_SLIDER1                     9028
#define IDC_EDIT1                       9029
#define IDC_BUTTON1                     9030

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        902
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         9031
#define _APS_NEXT_SYMED_VALUE           901
#endif
#endif
