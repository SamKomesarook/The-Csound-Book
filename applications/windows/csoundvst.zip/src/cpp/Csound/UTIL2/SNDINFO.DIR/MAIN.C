#include <stdio.h>
#include "../../cs.h"
#include "../../ustub.h"

main(argc,argv)
  int argc;
  char **argv;
{
    sndinfo(argc,argv);
}

