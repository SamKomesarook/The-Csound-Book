/* ***************************************************************** */
/* ******** Program to import lpanal files from tabular format. **** */
/* ***************************************************************** */

/* ***************************************************************** */
/* John ffitch 1996 Dec 27                                           */
/* ***************************************************************** */
     
#include <stdio.h>
#include <stdlib.h>
#include "lpc.h"

void usage(void);

float getnum(FILE* inf, char *term)
{
    char buff[100];
    int  cc;
    int p = 0;
    while ((cc=getc(inf))!=',' && cc!='\n') buff[p++] = cc;
    buff[p]='\0';
    *term = cc;
    return (float)atof(buff);
}

int main(int argc, char **argv)
{
    FILE *infd;
    FILE *outf;
    LPHEADER hdr;
    int i,j;

    if (argc!= 3)
	usage();

    infd = fopen(argv[1], "r");
    if (infd == NULL) {
	fprintf(stderr, "Cannot open input comma file%s\n", argv[1]);
	exit(1);
    }
    outf = fopen(argv[2], "w");
    if (infd == NULL) {
	fprintf(stderr, "Cannot open output lpanal file %s\n", argv[2]);
	exit(1);
    }

    fscanf(infd, "%ld,%ld,%ld,%ld,%f,%f,%f",
	    &hdr.headersize, &hdr.lpmagic, &hdr.npoles, &hdr.nvals,
	    &hdr.framrate, &hdr.srate, &hdr.duration);
    for (i=0; i<hdr.headersize-sizeof(LPHEADER)+4; i++)
      hdr.text[i]=getc(infd);
    fwrite(&hdr, sizeof(LPHEADER), 1, outf);
    while (getc(infd)!= '\n');

    for (i = 0; i<hdr.nvals; i++) {
      for (j=0; j<hdr.npoles; j++) {
	char term;
	float coef = getnum(infd, &term);
	fwrite(&coef, 1, sizeof(float), outf);
	if (term!=',' && term!='\n') fprintf(stderr, "Sync error\n");
      }
    }
    fclose(outf);
    fclose(infd);
}

void usage(void)
{
    fprintf(stderr, "Usage: lpc_import commafile lpanalfile\n");
    exit(1);
}

