
/* ------ oscils, lphasor, and tablexkt by Istvan Varga (Jan 5 2002) ------ */

#ifndef CSOUND_OSCILS_H
#define CSOUND_OSCILS_H

/* oscils opcode struct */

typedef struct {
    OPDS    h;
    MYFLT   *ar, *iamp, *icps, *iphs, *iflg;                /* opcode args  */
    /* internal variables */
    int     use_double;
    double  xd, cd, vd;
    MYFLT   x, c, v;
} OSCILS;

/* lphasor opcode struct */

typedef struct {
    OPDS    h;
    MYFLT   *ar, *xtrns, *ilps, *ilpe;                      /* opcode       */
    MYFLT   *imode, *istrt, *istor;                         /* args         */
    /* internal variables */
    int     loop_mode;
    double  phs, lps, lpe;
    int     dir;            /* playback direction (0: backward, 1: forward) */
} LPHASOR;

/* tablexkt opcode struct */

typedef struct {
    OPDS    h;
    MYFLT   *ar, *xndx, *kfn, *kwarp, *iwsize;              /* opcode       */
    MYFLT   *ixmode, *ixoff, *iwrap;                        /* args         */
    /* internal variables */
    int     raw_ndx, ndx_scl, wrap_ndx, wsize;
    MYFLT   win_fact;
/*  double  wsized2_d, pidwsize_d; */           /* for oscils_hann.c */
} TABLEXKT;

/* these functions are exported to entry*.c */

#ifndef CSOUND_OSCILS_C
extern void oscils_set (void*);
extern void oscils (void*);
extern void lphasor_set (void*);
extern void lphasor (void*);
extern void tablexkt_set (void*);
extern void tablexkt (void*);
#endif

#endif              /* CSOUND_OSCILS_H */

