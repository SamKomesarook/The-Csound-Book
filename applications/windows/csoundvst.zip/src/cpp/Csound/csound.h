#ifndef CSOUND_H
#define CSOUND_H
/**
* S I L E N C E
* 
* An auto-extensible system for making music on computers by means of software alone.
* Copyright (c) 2001 by Michael Gogins. All rights reserved.
*
* L I C E N S E
*
* This software is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2.1 of the License, or (at your option) any later version.
*
* This software is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with this software; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*
* P U R P O S E
*
* Declares the public C application programming interface to Csound.
*/
#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

	/*
	* Platform-dependent definitions and declarations.
	*/
#if defined(WIN32)
#define PUBLIC __declspec(dllexport) 
#define LIBRARY_CALL WINAPI
#elif defined(LINUX)
#define PUBLIC
#define LIBRARY_CALL
#endif
#include <Csound/cs.h>

	/**
	* Compiles and renders a Csound performance, 
	* as directed by the supplied command-line arguments,
	* in one pass. Returns true for success, or false for failure.
	*/
	int csoundPerform(int argc, char **argv);

	/**
	* Compiles Csound input files (such as an orchestra and score)
	* as directed by the supplied command-line arguments,
	* but does not perform them. Returns true for success, or false for failure.
	* <p>
	* In this (host-driven) mode, the sequence of calls should be as follows:
	* <pre>
	csoundCompile(argc, argv);
	while(!csoundPerformKsmps());
	csoundCleanup();
	csoundReset();
	</pre>
	*/
	int csoundCompile(int argc, char **argv);

	/**
	* Senses input events, and performs one control sample worth (ksmps) of audio output.
	* Note that csoundCompile must be called first.
	* Returns false during performance, and true when performance is finished.
	* If called until it returns true, will perform an entire score.
	* Enables external software to control the execution of Csound,
	* and to synchronize performance with audio input and output.
	*/
	int csoundPerformKsmps(void);

	/**
	* Returns the address of the Csound audio input working buffer (spin).
	* Enables external software to write audio into Csound before calling csoundPerformKsmps.
	*/
	MYFLT *csoundGetSpin(void);

	/**
	* Returns the address of the Csound audio output working buffer (spout).
	* Enables external software to read audio from Csound after calling csoundPerformKsmps.
	*/
	MYFLT *csoundGetSpout(void);

	/**
	* Prints information about the end of a performance.
	* Must be called after the final call to csoundPerformKsmps.
	*/
	void csoundCleanup(void);

	/**
	* Resets all internal memory and state in preparation for a new performance.
	* Enables external software to run successive Csound performances
	* without reloading Csound.
	*/
	void csoundReset(void);

	/**
	* Sets a function to be called by Csound to print an informational message.
	*/
	void csoundSetMessageCallback(void (*CsoundMessageCallback)(const char *message));

	/**
	* Called by Csound to print an informational message.
	*/
	void csoundMessage(const char *message);

	/**
	* Stops execution with an error message or exception.
	*/
	void csoundThrowMessage(const char *exception);

	/**
	* Called by external software to set a funtion for Csound to stop execution
	* with an error message or exception.
	*/
	void csoundSetThrowMessageCallback(void (*throwCallback)(const char *message));

	/**
	* Returns 1 if MIDI input from external software is enabled, or 0 if not.
	*/
	int csoundIsExternalMidiEnabled(void);

	/**
	* Sets whether MIDI input from external software is enabled.
	*/
	void csoundSetExternalMidiEnabled(int enabled);

	/**
	* Called by external software to set a function for Csound to call to open MIDI input.
	*/
	void csoundSetExternalMidiOpenCallback(void (*midiOpen)(void));

	/**
	* Called by Csound to open a MIDI input in external software.
	*/
	void csoundExternalMidiOpen(void);

	/**
	* Called by external software to set a function for Csound to call to read MIDI messages.
	*/
	void csoundSetExternalMidiReadCallback(int (*readMidi)(char *mbuf, int size));

	/**
	* Called by Csound to read MIDI messages from external software.
	*/
	int csoundExternalMidiRead(char *mbuf, int size);

	/**
	* Called by external software to set a function for Csound to call to close MIDI input.
	*/
	void csoundSetExternalMidiCloseCallback(void (*closeMidi)(void));

	/**
	* Called by Csound to close MIDI input from external software.
	*/
	void csoundExternalMidiClose(void);

	/**
	* Returns the number of audio sample frames per control sample.
	*/
	int csoundGetKsmps(void);

	/**
	* Returns the number of audio output channels.
	*/
	int csoundGetNchnls(void);

	/**
	* Sets the Csound message level (from 0 to 7).
	*/
	void csoundSetMessageLevel(int messageLevel);

	/**
	* Returns the Csound message level (from 0 to 7).
	*/
	int csoundGetMessageLevel(void);

	/**
	* Appends an opcode implemented by external software
	* to Csound's internal opcode list.
	* The opcode list is extended by one slot,
	* and the data pointed to by opcodeEntry is copied
	* into the new slot.
	*/
	int csoundAppendOpcode(OENTRY *opcodeEntry);

	/**
	* Returns whether Csound's score is synchronized with external software.
	*/
	int csoundIsScorePending(void);

	/**
	* Sets whether Csound's score is synchronized with external software.
	*/
	void csoundSetScorePending(int pending);

	/**
	* Csound events prior to the offset are consumed and discarded prior to beginning performance.
	* Can be used by external software to begin performance midway through a Csound score.
	*/
	MYFLT csoundGetScoreOffsetSeconds(void);

	/**
	* Csound events prior to the offset are consumed and discarded prior to beginning performance.
	* Can be used by external software to begin performance midway through a Csound score.
	*/
	void csoundSetScoreOffsetSeconds(MYFLT offset);

	/**
	* Rewinds a compiled Csound score to its beginning.
	*/
	void csoundRewindScore(void);

	/**
	* Returns the number of audio sample frames per second.
	*/
	MYFLT csoundGetSr(void);

	/**
	* Returns the number of control samples per second.
	*/
	MYFLT csoundGetKr(void);

	/*
	* Platform-independent function 
	* to open a shared library.
	*/
	void *csoundOpenLibrary(const char *libraryPath);

	/*
	* Platform-independent function 
	* to close a shared library.
	*/
	void *csoundCloseLibrary(void *library);

	/*
	* Platform-independent function 
	* to get a function address
	* in a shared library.
	*/
	void *csoundFindLibraryProcedure(void *library,
		const char *procedureName);

	/*
	* Signature for opcode registration function.
	* Both Csound and opcode must be compiled 
	* with 8 byte structure member alignment (for OENTRY).
	* This function returns true if an opcode exists at index, or false otherwise.
	* The opcode may store and call ftfind_, csoundGetSr_, csoundGetKr_,
	* and csoundGetNchnls_.
	*/
	typedef PUBLIC int (*CsoundEnumerateOpcodesType)(int index,
		OENTRY *oentry, 
		FUNC *(*ftfind_)(MYFLT *), 
		MYFLT (*csoundGetSr_)(), 
		MYFLT (*csoundGetKr_)(),
		int (*csoundGetNchnls_)());

	/*
	* Registers all opcodes in the library.
	*/
	long csoundLoadOpcodes(const char *libraryPath);

	/*
	* Registers all opcodes in all libraries in the opcodes directory.
	*/
	long csoundLoadAllOpcodes(void);

	/**
	* Deinitializes all opcodes in the instrument instance.
	*/
	void csoundOpcodeDeinitialize(INSDS *instrumentInstance);

	/**
	* Puxeddu configuration API.
	*/

	int configure_from_cmd_line(int argc, char **argv);

	/*
	Return 1 if the configuration is locked, that is
	modifing it would be futile or dangerous, typically
	because the engine is running.
	Return 0 if the configuration can be changed.
	*/
	int csoundIsConfigurationLocked(void);

	/*
	Reset internal configuration to its default value.
	Return 0. Return 1 on error.
	*/
	int csoundResetConfiguration(void);

	/*
	Set orchestra file name.
	The string is duplicated.
	Return 0. Return 1 on error.
	*/
	int csoundSetScoreFilename(const char *filename);

	/*
	Return the orchestra file name or 0
	if no orchestra is selected.
	*/
	const char *csoundGetScoreFilename(void);

	/*
	Set score file name.
	The string is duplicated.
	Return 0. Return 1 on error.
	*/
	int csoundSetOrchestraFilename(const char *filename);

	/*
	Return the score file name or 0 if
	no score is selected.
	*/
	const char *csoundGetOrchestraFilename(void);

	/*
	Set output sample format.

	Return 0. Return 1 on error.
	*/
	int csoundSetOutputSampleFormat(int code);

	/*
	Convert sample format code to standard long name.

	Return a statically allocated string or 0 on error.
	*/
	const char *csoundSampleFormatToLongName(int code);

	/*
	Convert sample format code to standard short name.

	Return a char or '\0' on error.
	*/
	char csoundSampleFormatToShortName(int code);

	/*
	Convert a standard long name to sample format code.

	Return the sample format code. Return 0 on error.
	*/
	int csoundLongNameToSampleFormat(const char *s);

	/*
	Convert a standard short name to sample format code.

	Return the sample format code. Return 0 on error.
	*/
	int csoundShortNameToSampleFormat(char s);

	/*
	Set the output file format.

	Return 0. Return 1 on error.
	*/
	int csoundSetOutputFileFormat(int code);

	/*
	Convert file format code to standard long name.

	Return a statically allocated string or 0 on error.
	*/
	const char *csoundFileFormatToLongName(int code);

	/*
	Convert file format code to standard short name.

	Return a char or '\0' on error.
	*/
	char csoundFileFormatToShortName(int code);

	/*
	Convert a standard long name to file format code.

	Return the file format code. Return 0 on error.
	*/
	int csoundLongNameToFileFormat(const char *s);

	/*
	Convert a standard short name to file format code.

	Return the sample format code. Return 0 on error.
	*/
	int csoundShortNameToFileFormat(char c);

	/*
	Enable (status = 1) or disable (status = 0)
	sound file header generation.

	Return 0. Return 1 on error.
	*/
	int csoundSetSoundfileHeaderGeneration(int status);

	/*
	Enable (status = 1) or disable (status = 0)
	sound file header update during performace.

	Return 0. Return 1 on error.
	*/
	int csoundSetHeaderUpdate(int status);

	/*
	Enable (status = 1) or disable (status = 0)
	peak chunk generation in output sound file.

	Return 0. Return 1 on error.
	*/
	int csoundSetPeakChunkGeneration(int status);

	/*
	Enable (value > 0) or disable (value = 0)
	uninterpreted beat.
	Initial tempo is set to value.

	Return 0. Return 1 on error.
	*/
	int csoundSetUninterpretedBeat(int value);

	/*
	Enable (status = 1) or disable (status = 0)
	deletion of temporary files.

	Return 0. Return 1 on error.
	*/
	int csoundSetTempFileDeletion(int status);

	/*
	Set size of software and hardware I/O buffers
	to nbytes.

	XXX: There is a real difference???

	Return 0. Return 1 on error.
	*/
	int csoundSetSoftwareIoBufferSize(int nbytes);
	int csoundSetHardwareIoBufferSize(int nbytes);

	/*
	Enable (status = 1) or disable (status = 0)
	Cscore score preprocessing.

	Return 0. Return 1 on error.
	*/
	int csoundSetCscorePreprocessing(int status);

	/*
	Set function table display.

	Return 0. Return 1 on error.
	*/
	int csoundSetDisplay(int code);

	/*
	Convert display code to standard long name.

	Return a statically allocated string or 0 on error.
	*/
	const char *csoundDisplayToLongName(int code);

	/*
	Convert display code to standard short name.

	Return a char or '\0' on error.
	*/
	char csoundDisplayToShortName(int code);

	/*
	Convert a standard long name to display code.

	Return the display code. Return 0 on error.
	*/
	int csoundLongNameToDisplay(const char *s);

	/*
	Convert a standard short name to display code.

	Return the display code. Return 0 on error.
	*/
	int csoundShortNameToDisplay(char c);

	/*
	Enable (status = 1) or disable (status = 0)
	deferred sample load (GEN1).

	Return 0. Return 1 on error.
	*/
	int csoundSetDeferredSampleLoad(int status);

	/*
	Set MIDI input file name to filename.

	Return 0. Return 1 on error.
	*/
	int csoundSetMidiInputFile(const char *filename);

	/*
	Enable (status = 1) or disable (status = 0)

	Return 0. Return 1 on error.
	*/
	int csoundSetTerminateOnMidi(int status);

	/*
	Set heartbeat to value.

	Return 0. Return 1 on error.
	*/
	int csoundSetHeartbeat(int value);

	/*
	Set input input file name to filename.
	The string is duplicated.

	Return 0. Return 1 on error.
	*/
	int csoundSetInputFilename(const char *filename);

	/*
	Set output file name to filename.
	The string is duplicated.

	Return 0. Return 1 on error.
	*/
	int csoundSetOutputFilename(const char *filename);

	/*
	Set log file name to filename.
	The string is duplicated.

	Return 0. Return 1 on error.
	*/
	int csoundSetLogFilename(const char *filename);

	/*
	Enable (status = 1) or disable (status = 0)
	output suppression.

	Return 0. Return 1 on error.
	*/
	int csoundSetMutePerformance(int status);

	/*
	Set realtime event device name name to devname.
	The string is duplicated.

	Return 0. Return 1 on error.
	*/
	int csoundSetRealtimeEventDevice(const char *devname);

	/*
	Enable (status = 1) or disable (status = 0)
	i-time only performance.

	Return 0. Return 1 on error.
	*/
	int csoundEnableItimeRun(void);

	/*
	Set sample rate override value to value.

	Return 0. Return 1 on error.
	*/
	int csoundSetSrOverride(long value);

	/*
	Set control rate override value to value.

	Return 0. Return 1 on error.
	*/
	int csoundSetKrOverride(long value);

	/*
	Set message mask.

	Return 0. Return 1 on error.
	*/
	int csoundSetMessageMask(int mask);

	/*
	Enable (status = 1) or disable (status = 0)
	debugging messages.

	Return 0. Return 1 on error.
	*/
	int csoundSetDebuggingMessages(int status);

	/*
	Enable (status = 1) or disable (status = 0)
	notification on completion.

	Return 0. Return 1 on error.
	*/
	int csoundSetNotificationOnCompletion(int status);

	/*
	Enable (status = 1) or disable (status = 0)
	dithering on output.

	Return 0. Return 1 on error.
	*/
	int csoundSetDithering(int value);

#ifdef __cplusplus
};
#endif // __cplusplus

#endif // CSOUND_H




