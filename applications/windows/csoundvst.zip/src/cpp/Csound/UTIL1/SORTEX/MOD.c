float MOD(float a, float bb)
{
    if (bb==0.0f) return 0.0f;
    else {
      float b = (bb<0 ? -bb : bb);
      int d = (int)(a / b);
      a -= d * b;
      while (a>b) a -= b;
      while (-a>b) a += b;
      return a;
    }
}
