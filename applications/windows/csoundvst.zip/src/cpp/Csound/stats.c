#include <stdio.h>

int a[101];

int main(void)
{
    int i;
    FILE *o;

    for (i=0; i<101; i++) a[i]=0;
    for (i=0; i<4096; i++) {
      double x;
      int b;
      scanf("%d", &b);
      /*      printf("read %d\n", b);*/
      a[b]++;
    }
    o = fopen("/tmp/d1", "w");
    for (i=0; i<101; i++) fprintf(o, "%d\n", a[i]);
}
