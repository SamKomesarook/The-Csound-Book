#include <stdio.h>
#include <stdarg.h>
/**
* S I L E N C E
*
* An auto-extensible system for making music on computers by means of software alone.
* Copyright (c) 2001 by Michael Gogins. All rights reserved.
*
* L I C E N S E
*
* This software is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2.1 of the License, or (at your option) any later version.
*
* This software is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with this software; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*
* P U R P O S E
*
* Defines the public C application programming interface to Csound.
*/

#ifdef __cplusplus
extern "C" {
#endif

#include <Csound/csound.h>
#include <Csound/cs.h>
#include <Csound/midiops.h>
#include <Csound/oload.h>
#include <Csound/soundio.h>

#ifndef MAX_PATH
#define MAX_PATH 0xff
#endif

	/**
	* Csound symbols referenced in this file.
	*/
	extern int csoundMain(int argc, char **argv);
	extern void mainRESET();
	extern int kperf(int kcnt);
	extern int kcnt;
	extern OPARMS O;
	extern GLOBALS glob;

	/**
	* Csound functions that need stub definitions in this file.
	*/

	char *getDB(void)
	{
		return 0;
	}

	/**
	* Matt Ingalls symbols referenced in this file.
	*/
	extern int runincomponents;
	extern int sensevents();
	extern int cleanup();

	int csoundPerform(int argc, char **argv)
	{
		csoundReset();
		runincomponents = 0;
		return csoundMain(argc, argv);
	}

	int csoundCompile(int argc, char **argv)
	{
		int returnValue = 0;
		fprintf(stderr, "BEGAN csoundCompile(%d, 0x%x)...\n", argc, argv);
		csoundReset();
		runincomponents = 1;
		returnValue = csoundMain(argc, argv);
		fprintf(stderr, "ENDED csoundCompile() with %d\n", returnValue);
		return returnValue;
	}

	int csoundPerformKsmps(void)
	{
		int sensed = 0;
		int rtEvents = O.RTevents;
		sensed = sensevents();
		//      Rather than overriding real-time event handling in kperf,
		//      turn it off before calling kperf, and back on afterwards.
		O.RTevents = 0;
		kperf(1);
		kcnt -= 1;
		O.RTevents = rtEvents;
		return sensed;
	}

	MYFLT* csoundGetSpin(void)
	{
		return spin;
	}

	MYFLT* csoundGetSpout(void)
	{
		return spout;
	}

	void csoundCleanup(void)
	{
		orcompact();
		cleanup();
		csoundMainCleanup();
	}

	static void csoundDefaultMessage(const char *message)
	{
		fprintf(stderr, message);
	}

	static void (*csoundMessageCallback_)(const char *message) = csoundDefaultMessage;

	void csoundSetMessageCallback(void (*csoundMessageCallback)(const char *message))
	{
		csoundMessageCallback_ = csoundMessageCallback;
	}

	void csoundMessage(const char *message)
	{
		csoundMessageCallback_(message);
	}

	static void (*csoundThrowMessageCallback_)(const char *exception) = csoundDefaultMessage;

	void csoundSetThrowMessageCallback(void (*csoundThrowMessageCallback)(const char *exception))
	{
		csoundThrowMessageCallback_ = csoundThrowMessageCallback;
	}

	void csoundThrowMessage(const char *message)
	{
		csoundThrowMessageCallback_(message);
	}

	static int csoundExternalMidiEnabled_ = 0;

	int csoundIsExternalMidiEnabled(void)
	{
		return csoundExternalMidiEnabled_;
	}

	void csoundSetExternalMidiEnabled(int enabled)
	{
		csoundExternalMidiEnabled_ = enabled;
	}

	extern void csoundDefaultMidiOpen(void);

	static void (*csoundExternalMidiOpenCallback_)(void) = csoundDefaultMidiOpen;

	void csoundSetExternalMidiOpenCallback(void (*csoundMidiOpen)(void))
	{
		csoundExternalMidiOpenCallback_ = csoundMidiOpen;
	}

	void csoundExternalMidiOpen(void)
	{
		csoundExternalMidiOpenCallback_();
	}

	static int defaultCsoundMidiRead(char *mbuf, int size)
	{
		return 0;
	}

	static int (*csoundExternalMidiReadCallback_)(char *mbuf, int size) = defaultCsoundMidiRead;

	void csoundSetExternalMidiReadCallback(int (*midiReadCallback)(char *mbuf, int size))
	{
		csoundExternalMidiReadCallback_ = midiReadCallback;
	}

	int csoundExternalMidiRead(char *mbuf, int size)
	{
		return csoundExternalMidiReadCallback_(mbuf, size);
	}

	static void csoundDefaultMidiCloseCallback(void)
	{
	}

	static void (*csoundExternalMidiCloseCallback_)(void) = csoundDefaultMidiCloseCallback;

	void csoundSetExternalMidiCloseCallback(void (*csoundExternalMidiCloseCallback)(void))
	{
		csoundExternalMidiCloseCallback_ = csoundExternalMidiCloseCallback;
	}

	void csoundExternalMidiClose(void)
	{
		csoundExternalMidiCloseCallback_();
	}

	int csoundGetKsmps(void)
	{
		return ksmps;
	}

	int csoundGetNchnls(void)
	{
		return nchnls;
	}

	int csoundGetMessageLevel(void)
	{
		return O.msglevel;
	}

	void csoundSetMessageLevel(int messageLevel)
	{
		O.msglevel = messageLevel;
	}

	int csoundAppendOpcode(OENTRY *opcodeEntry)
	{
		OENTRY *old_opcodlst = opcodlst;
		int size = (int)((char *)oplstend - (char *)opcodlst);
		int count = size / sizeof(OENTRY);
		opcodlst = (OENTRY *) mrealloc(opcodlst, size + sizeof(OENTRY));
		if(!opcodlst)
		{
			opcodlst = old_opcodlst;
			err_printf("Failed to allocate new opcode entry.");
			return 0;
		}
		else
		{
			memcpy(oplstend, opcodeEntry, sizeof(OENTRY));
			printf("Appended opcode %s: in %s out %s.", opcodlst[count].opname, opcodlst[count].intypes, opcodlst[count].outypes);
			oplstend++;
			return 1;
		}
	}

	static int csoundIsScorePending_ = 0;

	int csoundIsScorePending(void)
	{
		return csoundIsScorePending_;
	}

	void csoundSetScorePending(int pending)
	{
		csoundIsScorePending_ = pending;
	}

	static MYFLT csoundScoreOffsetSeconds_ = (MYFLT) 0.0;

	void csoundSetScoreOffsetSeconds(MYFLT offset)
	{
		csoundScoreOffsetSeconds_ = offset;
	}

	MYFLT csoundGetScoreOffsetSeconds(void)
	{
		return csoundScoreOffsetSeconds_;
	}

	static OPARMS O_ = {0,0, 0,1,1,0, 0,0, 0,0, 0,0, 1,0,0,7, 0,0,0, 0,0,0,0, 0,0 };
	static GLOBALS glob_ = {  DFLT_KSMPS, /* 	ksmps */
		DFLT_NCHNLS,	/*	nchnls */
		FL(0.0),	/*	esr */
		FL(0.0),	/*	ekr */
		NULL, NULL, NULL,	/* orchname, scorename, xfilename */
		NLABELS,	/*	nlabels */
		NGOTOS,	/*	ngotos */
		0,	/*	strsmax */
		NULL,
		1, 	/* peakchunks */
		NULL, /* zastart */
		0,    /* zalast */
		0,	/*  kcounter */
		NULL,	/*  currevent */
		FL(0.0), /*	onedkr */
		FL(0.0), /*	onedsr */
		FL(0.0),	/*	kicvt */
		FL(0.0),	/*	sicvt */
		NULL,	/*	spin */
		NULL,	/*	spout */
		0,	/*	nspin */
		0,	/*	nspout */
		0,	/*	spoutactive */
		0,	/*	keep_tmp */
		0,	/*	dither_output */
		NULL,	/*	opcodlst */
		NULL,	/*	opcodlstend */
		NULL,  /*	dribble */
		2345678L,	/* holdrand */
		MAXINSNO,	/* maxinsno */
		NULL,	/*	curip */
		NULL,	/*	Livevtblk */
		0,	/*	nrecs */
#ifdef PIPES
		NULL,	/*	Linepipe */
#endif
		0,	/*	Linefd */
		NULL,	/*	ls_table */
		FL(0.0),	/*     curr_func_sr */
		NULL,	/*	retfilnam */
		NULL,	/*	instrtxtp */
		"",	/*	errmsg */
		NULL,	/*	scfp */
		NULL,	/*	oscfp */
	{ FL(0.0)},	/*	maxamp */
	{ FL(0.0)},	/*	smaxamp */
	{ FL(0.0)},	/*	omaxamp */
	NULL,	/*	maxampend */
	{0}, {0}, {0},	/*	maxpos, smaxpos, omaxpos */
	0,	/*	tieflag */
	NULL, NULL,	/* ssdirpath, sfdirpath */
	NULL,	/*	tokenstring */
	NULL,	/*	polish */
	NULL, NULL,	/* scorein, scorout */
	FL(0.0), FL(0.0),	/*	ensmps, hfkprd */
	NULL,	/*	pool */
	NULL,	/*	argoffspace */
	NULL,	/*	frstoff */
	0,	/*	sensType */
	{0},	/*	exitjmp of type jmp_buf */
	NULL,	/*	frstbp */
	0,	/*	sectcnt */
	{0},	/*	m_chnbp */
	NULL, NULL,	/*  cpsocint, cpsocfrc */
	0, 0, 0,	/* inerrcnt, synterrcnt, perferrcnt */
	0,	/*	MIDIoutDONE */
#ifdef LINUX
	-1,	/*	midi_out */
#endif
	"",	/*	strmsg */
	{NULL},	/*	instxtanchor */
	{NULL},	/*	actanchor */
	{0L },	/*	rngcnt */
	0, 0,	/*	rngflg, multichan */
	{NULL},	/*	OrcTrigEvts */
	"",	/*	full_name */
	0, 0, 0,	/*	Mforcdecs, Mxtroffs, MTrkend */
	FL(-1.0), FL(-1.0), FL(-1.0),	/* tran_sr,tran_kr,tran_ksmps */
	DFLT_NCHNLS,	/*	tran_nchnls */
	FL(-1.0), FL(-1.0), FL(-1.0),	/* tpidsr, mpidsr, mtpdsr */
	NULL	/*	sadirpath */
	};

	void csoundReset(void)
	{
		fprintf(stderr, "BEGAN csoundReset()...\n");
		fprintf(stderr, "memcpy(0x%x, 0x%x, %d, %d)\n", &O, &O_, sizeof(O), sizeof(O_));
		memcpy(&O, &O_, sizeof(O));
		fprintf(stderr, "memcpy(0x%x, 0x%x, %d, %d)\n", &glob, &glob_, sizeof(glob), sizeof(glob_));
		memcpy(&glob, &glob_, sizeof(glob));
		mainRESET();
		SfReset();
		O.Midiin = 0;
		csoundIsScorePending_ = 1;
		csoundScoreOffsetSeconds_ = (MYFLT) 0.0;
		fprintf(stderr, "ENDED csoundResetmake()\n");
	}

	void csoundRewindScore(void)
	{
		if(scfp)
		{
			fseek(scfp, 0, SEEK_SET);
		}
	}

	MYFLT csoundGetSr(void)
	{
		return esr;
	}

	MYFLT csoundGetKr(void)
	{
		return ekr;
	}

	int csoundOpcodeCompare(const void *v1, const void *v2)
	{
		return strcmp(((OENTRY*)v1)->opname, ((OENTRY*)v2)->opname);
	}

	void csoundOpcodeDeinitialize(INSDS *ip_)
	{
		INSDS *ip = ip_;
		OPDS *pds;
		while(ip = (INSDS *)ip->nxti)
		{
			pds = (OPDS *)ip;
			while(pds = pds->nxti)
			{
				if(pds->dopadr)
				{
					(*pds->dopadr)(pds);
				}
			}
		}
		ip = ip_;
		while(ip = (INSDS *)ip->nxtp)
		{
			pds = (OPDS *)ip;
			while(pds = pds->nxtp)
			{
				if(pds->dopadr)
				{
					(*pds->dopadr)(pds);
				}
			}
		}
	}

	static void MEGAFREE(void *p) 
	{ 
		if (p) 
		{ 
			free(p); 
			p = 0; 
		} 
	}

	int csoundIsConfigurationLocked(void)
	{
		// XXX: somehow detect if csound has started to process the orchestra
		return 0;
	}

	int csoundResetConfiguration(void)
	{
		if (csoundIsConfigurationLocked())
			return 1;

		// XXX: where is it currently reset?

		MEGAFREE(orchname);
		MEGAFREE(scorename);
		MEGAFREE(O.FMidiname);
		MEGAFREE(O.infilename);
		MEGAFREE(O.outfilename);

		return 1;
	}

	int csoundSetOrchestraFilename(const char *filename)
	{
		MEGAFREE(orchname);

		orchname = strdup(filename);

		if (orchname == 0)
			return 1;

		return 0;
	}

	const char *csoundGetOrchestraFilename(void)
	{
		return orchname;
	}

	int csoundSetScoreFilename(const char *filename)
	{
		MEGAFREE(scorename);
		scorename = strdup(filename);
		if (scorename == 0)
			return 1;
		return 0;
	}

	const char *csoundGetScoreFilename(void)
	{
		return scorename;
	}

	/* XXX: we could use the same data structure
	and the same access functions here */

	typedef struct {
		char *longname;
		char shortname;
		int code;
	} SAMPLE_FORMAT_ENTRY;

	static
		SAMPLE_FORMAT_ENTRY sample_format_map[] = {
			{"alaw", 'a', AE_ALAW},
			{"schar", 'c', AE_CHAR},
			{"uchar", '8', AE_UNCH},
			{"float", 'f', AE_FLOAT},
			{"short", 's', AE_SHORT},
			{"ulaw", 'u', AE_ULAW},
			{"24bit", '3', AE_24INT},
			{0, 0, 0}
		};

	typedef struct {
		char *longname;
		char shortname;
		int code;
	} FILE_FORMAT_ENTRY;

	static
		FILE_FORMAT_ENTRY file_format_map[] = {
			{"ircam", 'J', TYP_IRCAM},
			{"aiff", 'A', TYP_AIFF},
			{"wav", 'W', TYP_WAV},
			{"aifc", '5', TYP_AIFC},
			{"raw", 'h', 4 /* TYP_RAW */ },
			{0, 0, 0}
		};

	typedef struct {
		char *longname;
		char shortname;
		int code;
	} DISPLAY_ENTRY;

#define DISPLAY_ASCII 1
#define DISPLAY_POSTSCRIPT 2
#define DISPLAY_WINDOW 3
#define DISPLAY_NONE 4

	static
		DISPLAY_ENTRY display_map[] = {
			{"ascii", 'g', DISPLAY_ASCII},
			{"postscript", 'G', DISPLAY_POSTSCRIPT},
			{"graphic", '6', DISPLAY_WINDOW},
			{"none", 'd', DISPLAY_NONE},
			{0, 0, 0}
		};

	int csoundSetOutputSampleFormat(int value)
	{

		switch (value)
		{
		case AE_ALAW:
		case AE_CHAR:
		case AE_UNCH:
		case AE_FLOAT:
		case AE_SHORT:
		case AE_LONG:
		case AE_ULAW:
		case AE_24INT:
			O.outformat = value;
			return 0;
		default:
			return 1;
		}
	}

	const char *csoundSampleFormatToLongName(int code)
	{
		SAMPLE_FORMAT_ENTRY *p = sample_format_map;
		while (p->longname != 0)
		{
			if (p->code == code)
				return p->longname;
			++p;
		}
		return 0;
	}

	char csoundSampleFormatToShortName(int code)
	{
		SAMPLE_FORMAT_ENTRY *p = sample_format_map;
		while (p->longname != 0)
		{
			if (p->code == code)
				return p->shortname;
			++p;
		}
		return 0;
	}

	int csoundLongNameToSampleFormat(const char *s)
	{
		SAMPLE_FORMAT_ENTRY *p = sample_format_map;
		while (p->longname != 0)
		{
			if (strcmp(p->longname, s) == 0)
				return p->code;
			++p;
		}
		return 0;
	}

	int csoundShortNameToSampleFormat(char c)
	{
		SAMPLE_FORMAT_ENTRY *p = sample_format_map;
		while (p->longname != 0)
		{
			if (p->shortname == c)
				return p->code;
			++p;
		}
		return 0;
	}

	int csoundSetOutputFileFormat(int value)
	{
		switch (value)
		{
		case TYP_IRCAM:
		case TYP_AIFF:
		case TYP_WAV:
		case TYP_AIFC:
			O.filetyp = value;
			O.sfheader = 1;
			return 0;
		case 4 /* TYP_RAW */:
			O.sfheader = 0;
			return 0;
		}
		return 1;
	}

	const char *csoundFileFormatToLongName(int code)
	{
		FILE_FORMAT_ENTRY *p = file_format_map;
		while (p->longname != 0)
		{
			if (p->code == code)
				return p->longname;
			++p;
		}
		return 0;
	}

	char csoundFileFormatToShortName(int code)
	{
		FILE_FORMAT_ENTRY *p = file_format_map;
		while (p->longname != 0)
		{
			if (p->code == code)
				return p->shortname;
			++p;
		}
		return 0;
	}

	int csoundLongNameToFileFormat(const char *s)
	{
		FILE_FORMAT_ENTRY *p = file_format_map;
		while (p->longname != 0)
		{
			if (strcmp(p->longname, s) == 0)
				return p->code;
			++p;
		}
		return 0;
	}

	int csoundShortNameToFileFormat(char c)
	{
		FILE_FORMAT_ENTRY *p = file_format_map;
		while (p->longname != 0)
		{
			if (p->shortname == c)
				return p->code;
			++p;
		}
		return 0;
	}

	int csoundSetHeaderUpdate(int status)
	{
		O.rewrt_hdr = status ? 1 : 0;
		return 0;
	}

	int csoundSetUninterpretedBeat(int value)
	{
		if (value > 0)
		{
			O.Beatmode = 1;
			O.cmdTempo = value;
		}
		else
		{
			O.Beatmode = 0;
		}
		return 0;
	}

	int csoundSetTempFileDeletion(int status)
	{
		keep_tmp = status ? 1 : 0;
		return 0;
	}

	int csoundSetSoftwareIoBufferSize(int nbytes)
	{
		O.inbufsamps = O.outbufsamps = nbytes;
		return 0;
	}

	int csoundSetHardwareIoBufferSize(int nbytes)
	{
		O.inbufsamps = O.outbufsamps = nbytes;
		return 0;
	}

	int csoundSetCscorePreprocessing(int status)
	{
		O.usingcscore = status ? 1 : 0;
		return 0;
	}

	int csoundSetDisplay(int code)
	{
		switch (code)
		{
		case DISPLAY_ASCII:
			O.displays = 1;
			O.graphsoff = 1;
			break;
		case DISPLAY_POSTSCRIPT:
			O.displays = 1;
			O.graphsoff = 0;
			O.postscript = 1;
			break;
		case DISPLAY_WINDOW:
			O.displays = 1;
			O.graphsoff = 0;
			O.postscript = 0;
			break;
		case DISPLAY_NONE:
			O.displays = 0;
			break;
		default:
			return 1;
		};
		return 0;
	}

	const char *csoundDisplayToLongName(int code)
	{
		DISPLAY_ENTRY *p = display_map;
		while (p->longname != 0)
		{
			if (p->code == code)
				return p->longname;
			++p;
		}
		return 0;
	}

	char csoundDisplayToShortName(int code)
	{
		DISPLAY_ENTRY *p = display_map;
		while (p->longname != 0)
		{
			if (p->code == code)
				return p->shortname;
			++p;
		}
		return 0;
	}

	int csoundLongNameToDisplay(const char *s)
	{
		DISPLAY_ENTRY *p = display_map;

		while (p->longname != 0)
		{
			if (strcmp(p->longname, s) == 0)
				return p->code;
			++p;
		}
		return 0;
	}

	int csoundShortNameToDisplay(char c)
	{
		DISPLAY_ENTRY *p = display_map;
		while (p->longname != 0)
		{
			if (p->shortname == c)
				return p->code;
			++p;
		}
		return 0;
	}


	int csoundSetDeferredSampleLoad(int status)
	{
		O.gen01defer = status ? 1 : 0;
		return 0;
	}

	int csoundSetMidiInputFile(const char *filename)
	{
		MEGAFREE(O.FMidiname);

		if (filename == 0 || filename[0] == '\0')
		{
			O.FMidiin = 0;
		}
		else
		{
			O.FMidiname = strdup(filename);
			if (O.FMidiname)
				return 1;
			O.FMidiin = 1;
		}

		return 0;
	}

	int csoundSetTerminateOnMidi(int status)
	{
		O.termifend = status ? 1 : 0;
		return 0;
	}

	int csoundSetHeartbeat(int value)
	{
		O.heartbeat = value;
		return 0;
	}

	int csoundSetInputFilename(const char *filename)
	{
		MEGAFREE(O.infilename);

		if (filename == 0 || filename[0] == '\0')
			return 0;

		if (strcmp(filename, "stdout") == 0)
		{
			// XXX: we need a something to store an error message here!
			return 1;
		}

		if (strcmp(filename, "stdin") == 0)
		{
#if defined mills_macintosh || defined SYMANTEC
			// stdin audio not supported
			return 1;
#endif
		}
		O.infilename = strdup(filename);
		if (O.infilename)
			return 1;

		O.sfread = 1;
		return 0;
	}

	int csoundSetOutputFilename(const char *filename)
	{
		MEGAFREE(O.outfilename);
		if (filename == 0 || filename[0] == '\0')
		{
			O.sfwrite = 0;
			return 0;
		}
		if (strcmp(filename, "stdin") == 0)
		{
			// XXX: we need a something to store an error message here!
			return 1;
		}

#if defined mac_classic || defined SYMANTEC || defined BCC || defined __WATCOMC__ || defined WIN32
		if (strcmp(O.outfilename, "stdout") == 0)
		{
			// not supported
			return 1;
		}
#endif

		O.outfilename = strdup(filename);
		if (O.outfilename)
			return 1;
		O.sfwrite = 1;

#if !defined mac_classic && !defined SYMANTEC && !defined BCC && !defined __WATCOMC__ && !defined WIN32
		if (strcmp(O.outfilename, "stdout") == 0)
		{
			// Do it somewhere else
			if ((O.stdoutfd = dup(1)) < 0) /* redefine stdout */
				die(Str(X_1290,"too many open files"));
			dup2(2,1);                /* & send 1's to stderr */
		}
#endif

		return 0;
	}

	int csoundSetLogFilename(const char *filename)
	{
		if (filename == 0 || filename[0] == '\0')
			return 0;

		// XXX: do it somewhere else
		dribble = fopen(filename, "w");

		return 0;
	}

	int csoundSetItimeRun(int status)
	{
		O.initonly = status ? 1 : 0;
		return 0;
	}

	int csoundSetSrOverride(long value)
	{
		O.sr_override = value;
		return 0;
	}

	int csoundSetKrOverride(long value)
	{
		O.kr_override = value;
		return 0;
	}

	int csoundSetPeakChunkGeneration(int status)
	{
		peakchunks = status ? 1 : 0;
		return 0;
	}

	int csoundSetRealtimeEventDevice(const char *devname)
	{
		MEGAFREE(O.Linename);

		if (devname == 0 || devname[0] == '\0')
		{
			O.Linein = 0;
		}
		else
		{
			O.Linename = strdup(devname);
			if (O.Linename)
				return 1;
			O.Linein = 1;
		}
		return 0;
	}

	int csoundSetMessageMask(int mask)
	{
		O.msglevel = mask;
		return 0;
	}

	int csoundSetDebuggingMessages(int status)
	{
		O.odebug = status ? 1 : 0;
		return 1;
	}

	int csoundSetSoundfileOutput(int status)
	{
		O.sfwrite = status ? 1 : 0;
		return 0;
	}

	int csoundSetNotificationOnCompletion(int status)
	{
		O.ringbell = status ? 1 : 0;
		return 0;
	}

	int csoundSetDithering(int status)
	{
		dither_output = status ? 1 : 0;
		return 0;
	}

#ifdef __cplusplus
};
#endif
