/**
* S I L E N C E
* 
* An auto-extensible system for making music on computers by means of software alone.
* Copyright (c) 2001 by Michael Gogins. All rights reserved.
*
* L I C E N S E
*
* This software is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2.1 of the License, or (at your option) any later version.
*
* This software is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with this software; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#if defined(WIN32)
#include <io.h>
#include <direct.h>
#include <windows.h>
#elif defined(LINUX)
#include <dlfcn.h>
#include <dirent.h>
#include <string.h>
#endif

#include "cs.h"
#include "csound.h"

void *csoundLoadLibrary(const char *libraryPath)
{
  void *library = 0;
#if defined(WIN32)
  library = (void *) LoadLibrary(libraryPath);
#elif defined(LINUX)
  library = dlopen(libraryPath, RTLD_NOW);
#endif
  return library;
}

void *csoundLibraryProcedureAddressGet(void *library, const char *procedureName)
{
  void *procedureAddress = NULL;
#if defined(WIN32)
  procedureAddress = GetProcAddress((HMODULE) library, procedureName);
#elif defined(LINUX)
  procedureAddress = dlsym((void *)library, procedureName);
#endif
  return procedureAddress;
}

long csoundLoadOpcodes(const char* libraryPath)
{
  long returnValue = 0;
  long opcodeSubscript;
  char procedureName[0x200];
  char libraryName[0x100];
  struct oentry opcode;
  CsoundEnumerateOpcodesType csoundEnumerateOpcodes = 0;
  /*      
   *       Load the opcode's shared library.
   */      
  int opcodesRegistered = 0;
  void *library = csoundLoadLibrary(libraryPath);
  if(library == 0)        
    {
      return 0;
    }
  /*
   *       Get the address of the opcode's registration function.
   */
#if defined(WIN32)
  _splitpath(libraryPath, 
	     0, 
	     0, 
	     libraryName, 
	     0);
  strcpy(libraryPath, libraryName);
#elif defined(LINUX)
  strcpy((char *)libraryName, (char *)basename(libraryPath));
#endif        
  sprintf(procedureName, "%s_csoundEnumerateOpcodes", libraryName);
  csoundEnumerateOpcodes = (CsoundEnumerateOpcodesType) csoundLibraryProcedureAddressGet(library, 
											 procedureName);
  if(csoundEnumerateOpcodes == NULL)
    {
      return 0;
    }
  /*      
   *       Iterate through and register all the opcodes in the library.
   */
  for(opcodeSubscript = 0, opcodesRegistered = 0; ; opcodeSubscript++)
    {
      returnValue = csoundEnumerateOpcodes(opcodeSubscript,
					   &opcode,
					   ftfind,
					   csoundGetSr,
					   csoundGetKr,
					   csoundGetNchnls);
      if(returnValue <= 0)
	{
	  break;
	}
      csoundAppendOpcode(&opcode);
    }
  return opcodesRegistered;
}

#if defined(WIN32)

long csoundLoadAllOpcodes()
{
  long returnValue = 0;
  char opcodeDirectory[MAX_PATH + 1];
  char opcodePath[MAX_PATH + 1];
  char drive[_MAX_DRIVE];
  char dir[_MAX_DIR];
  char *opcodeEnvironmentDirectory = NULL;
  struct _finddata_t findData;
  long search = 0;
  int opcodesRegistered = 0;
  if(returnValue)
    {
      returnValue = putenv("CSOUND_HOME=C:\\Gogins\\Develop\\Silence\\Install");
    }
  opcodeEnvironmentDirectory = getenv("CSOUND_HOME");
  if(opcodeEnvironmentDirectory != NULL)
    {
      strncpy(opcodeDirectory, 
	      opcodeEnvironmentDirectory,
	      MAX_PATH);
      sprintf(opcodePath, 
	      "%s\\%s\0",
	      opcodeDirectory,
	      "*.OPC");
    }
  /*
   *       Otherwise, use the current working directory,
   *       hopefully the Csound directory.
   */
  else
    {
      GetModuleFileName(0,
                        opcodeDirectory, 
                        _MAX_PATH);
      _splitpath(opcodeDirectory,
		 drive,
		 dir, 
		 0,
		 0);
      sprintf(opcodeDirectory,
	      "%s%s\0", 
	      drive,
	      dir);
      sprintf(opcodePath,
	      "%s%s%s\0", 
	      drive,
	      dir, 
	      "*.OPC");
    }
  search = _findfirst(opcodePath, &findData);
  if(search == -1)
    {
      _findclose(search);
      return 0;
    }
  sprintf(opcodePath,
	  "%s\\%s\0", 
	  opcodeDirectory,
	  findData.name);
  opcodesRegistered += csoundLoadOpcodes(opcodePath);
  /*
   *       Register all OPC libraries in the opcode directory.
   */
  while(_findnext(search,
		  &findData) == 0)
    {
      sprintf(opcodePath,
	      "%s\\%s\0",
	      opcodeDirectory, 
	      findData.name);
      returnValue = csoundLoadOpcodes(opcodePath);
    }
  _findclose(search);
  return returnValue;
}

#elif defined(LINUX)

long csoundLoadAllOpcodes()
{
  long returnValue = 0;
  char opcodeDirectory[NAME_MAX + 1];
  char opcodePath[NAME_MAX + 1];
  char drive[NAME_MAX];
  char dir[NAME_MAX];
  char *opcodeEnvironmentDirectory = NULL;
  DIR *directory;
  struct dirent *directoryEntry;
  long search = 0;
  int opcodesRegistered = 0;
  if(returnValue)
    {
      returnValue = putenv("CSOUND_HOME=/home/mkg/Silence");
    }
  opcodeEnvironmentDirectory = getenv("CSOUND_HOME");
  if(opcodeEnvironmentDirectory != NULL)
    {
      strncpy(opcodeDirectory, 
	      opcodeEnvironmentDirectory,
	      NAME_MAX);
      sprintf(opcodePath, 
	      "%s\\%s\0",
	      opcodeDirectory,
	      "*.OPC");
    }
  /*
   *       Otherwise, use the current working directory,
   *       hopefully the Csound directory.
   */
  else
    {
      getcwd(opcodeDirectory,
	     NAME_MAX);
      sprintf(opcodePath,
	      "%s/%s\0", 
	      opcodeDirectory,
	      "*.OPC");
    }
  directory = opendir(opcodePath);
  if(!directory)
    {
      closedir(directory);
      return 0;
    }
  while(directoryEntry = readdir(directory))
    {
      switch(directoryEntry->d_type)
	{
	case DT_DIR:
	  break;
	case DT_REG:
	  sprintf(opcodePath,
		  "%s/%s\0", 
		  opcodeDirectory,
		  directoryEntry->d_name);
	  opcodesRegistered += csoundLoadOpcodes(opcodePath);
	  break;
	}
    }
  closedir(directory);
  return opcodesRegistered;
}

#endif
