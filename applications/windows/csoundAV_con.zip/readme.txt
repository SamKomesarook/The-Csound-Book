CsoundAV, a version of Csound supporting Audio and Animated Graphics
====================================================================
                             
                       by Gabriel Maldonado
                       g.maldonado@agora.it
                    http://csounds.com/maldonado
 --------------
|  IMPORTANT!  |
 --------------
This version of Csound contains several enhancements 
and bug fixes. Read carefully all this short document, even if you 
already know standard Csound! 


INSTALLATION:
------------
Very simple. Unzip the program in a folder of your choice. That's all folks!
Better using a long-name unzip program (such as Winzip).

MANUAL:
-------
The manual in HTML format specific to CsoundAV can be downloaded from my site in a zipped archive. You have to carefully read this manual.

However this manual is, by any means, not sufficient to learn CsoundAV for people that don't know Csound. In particular, main CSOUND REFERENCE MANUAL is absolutely needed.
There are many different formats of main Csound Reference Manual and many tutorials that can be downloaded at the following sites:

http://www.csound.org

http://www.csounds.com

A special format of Csound Reference Manual is Winhelp format, by Rasmus Ekman. I highly recommend to get it. It can be downloaded at:

http://hem.passagen.se/rasmuse/Csound.htm

There are also some printed books about Csound that I recommend to read:
The Csound Book - published by MIT Press
Virtual Sound - published by Contempo editions
Il suono virtuale (italian version of Virtual Sound) - published by Contempo editions

EXECUTABLES:
------------
CsoudAV is provided in four types of executables:

CsoundAV_Win.exe - Win32 GUI version with 32-bit floating-point precision
CsoundAV_Win64.exe - Win32 GUI version with 64-bit floating-point precision
CsoundAV_Con.exe - Win32 console version with 32-bit floating-point precision
CsoundAV_Con64.exe - Win32 console version with 64-bit floating-point precision

The most stable is probably CsoundAV_Win.exe because it is the reference version for testing and debugging.

SOURCES:
--------
The sources are provided with a project for MSVC5 in a separate archive. Read CsoundAV manual for more information.

QUICK START:
------------
This archive contains some trivial .csd files to be used to check CsoundAV is correctly installed.
Just double-click to CsoundAV_Win.exe icon, two windows will appear, one in front of the other. Simply drag the icon of a .csd file on the dialog-box titled "CsoundAV - Set Command Line Arguments" (that with the picture) and click the "OK" button. Then, eventually, answer to the following dialog boxes that ask the Audio and MIDI port number you want to use (keep attention on this point) and CsoundAV will start...
However, to use CsoundAV more seriously, you HAVE TO read the CsoundAV manual that is distributed in a separate archive also located in my web site.

Further .csd examples are available in my web site.


