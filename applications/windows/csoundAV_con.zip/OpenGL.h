#define GL_MODELVIEW #0#
#define GL_PROJECTION #1#
#define GL_TEXTURE #2#


#define GL_CURRENT_BIT  #1#
#define GL_POINT_BIT    #2#
#define GL_LINE_BIT     #4#
#define GL_POLYGON_BIT  #8#
#define GL_POLYGON_STIPPLE_BIT  #16#
#define GL_PIXEL_MODE_BIT       #32#
#define GL_LIGHTING_BIT         #64#
#define GL_FOG_BIT              #128#
#define GL_DEPTH_BUFFER_BIT     #256#
#define GL_ACCUM_BUFFER_BIT     #512#
#define GL_STENCIL_BUFFER_BIT   #1024#
#define GL_VIEWPORT_BIT         #2048#
#define GL_TRANSFORM_BIT        #4096#
#define GL_ENABLE_BIT           #8192#
#define GL_COLOR_BUFFER_BIT     #16384#
#define GL_HINT_BIT             #32768#
#define GL_EVAL_BIT             #65536#
#define GL_LIST_BIT             #131072#
#define GL_TEXTURE_BIT          #262144#
#define GL_SCISSOR_BIT          #524288#
#define GL_ALL_ATTRIB_BITS      #1048575#


#define GL_COLOR_DEPTH_BUFFER_BITS #GL_COLOR_BUFFER_BIT + GL_DEPTH_BUFFER_BIT#

#define GLM_NONE     #0#     /* render with only vertices */
#define GLM_FLAT     #1#     /* render with facet normals */
#define GLM_SMOOTH   #2#       /* render with vertex normals */
#define GLM_TEXTURE  #4#       /* render with texture coords */
#define GLM_COLOR    #8#       /* render with colors */
#define GLM_MATERIAL #16#       /* render with materials */

#define GL_FRONT	#0#
#define GL_BACK	#1#
#define GL_LEFT	#2#
#define GL_RIGHT	#3#
#define GL_FRONT_AND_BACK #4#
#define GL_FRONT_LEFT  #5#
#define GL_FRONT_RIGHT #6#
#define GL_BACK_LEFT   #7#
#define GL_BACK_RIGHT  #8#

#define GL_AUX0	#9#
#define GL_AUX1	#10#
#define GL_AUX2	#11#
#define GL_AUX3	#12#
#define GL_NONE	#100#

#define GL_MAP_COLOR   #0#
#define GL_MAP_STENCIL #1#
#define GL_INDEX_SHIFT #2#
#define GL_INDEX_OFFSET #3#
#define GL_RED_SCALE   #4#   
#define GL_RED_BIAS    #5#    
#define GL_GREEN_SCALE #6# 
#define GL_GREEN_BIAS  #7#  
#define GL_BLUE_SCALE  #8#  
#define GL_BLUE_BIAS   #9#   
#define GL_ALPHA_SCALE #10# 
#define GL_ALPHA_BIAS  #1#  
#define GL_DEPTH_SCALE #12# 
#define GL_DEPTH_BIAS  #13#  


#define GL_PIXEL_MAP_I_TO_I #0#
#define GL_PIXEL_MAP_S_TO_S #1#
#define GL_PIXEL_MAP_I_TO_R #2#
#define GL_PIXEL_MAP_I_TO_G #3#
#define GL_PIXEL_MAP_I_TO_B #4#
#define GL_PIXEL_MAP_I_TO_A #5#
#define GL_PIXEL_MAP_R_TO_R #6#
#define GL_PIXEL_MAP_G_TO_G #7#
#define GL_PIXEL_MAP_B_TO_B #8#
#define GL_PIXEL_MAP_A_TO_A #9#
#define GL_PIXEL_MAP_I_TO_I_SIZE #10#
#define GL_PIXEL_MAP_S_TO_S_SIZE #11#
#define GL_PIXEL_MAP_I_TO_R_SIZE #12#
#define GL_PIXEL_MAP_I_TO_G_SIZE #13#
#define GL_PIXEL_MAP_I_TO_B_SIZE #14#
#define GL_PIXEL_MAP_I_TO_A_SIZE #15#
#define GL_PIXEL_MAP_R_TO_R_SIZE #16#
#define GL_PIXEL_MAP_G_TO_G_SIZE #17#
#define GL_PIXEL_MAP_B_TO_B_SIZE #18#
#define GL_PIXEL_MAP_A_TO_A_SIZE #19#

#define GL_FALSE #0#
#define GL_TRUE  #1#

#define GL_POINT #0#
#define GL_LINE  #1#
#define GL_FILL  #2#

#define GLU_MAP1_TRIM_2 #0#
#define GLU_MAP1_TRIM_3 #1#

#define GLU_SAMPLING_TOLERANCE #0#
#define GLU_DISPLAY_MODE #1#
#define GLU_CULLING #2#
#define GLU_AUTO_LOAD_MATRIX #3#
#define GLU_PARAMETRIC_TOLERANCE #4#
#define GLU_SAMPLING_METHOD #5#
#define GLU_U_STEP #6#
#define GLU_V_STEP #7#

#define GLU_PATH_LENGTH #100215#	;only for MSVC 5.0
#define GLU_PARAMETRIC_ERROR #100216#	;only for MSVC 5.0
#define GLU_DOMAIN_DISTANCE #100217#	;only for MSVC 5.0

#define GL_CCW #0#
#define GL_CW  #1#

#define GL_ALPHA_TEST #0#
#define GL_AUTO_NORMAL #1#
#define GL_BLEND #2#
#define GL_CLIP_PLANE0 #3#
#define GL_CLIP_PLANE1 #4#
#define GL_CLIP_PLANE2 #5#
#define GL_CLIP_PLANE3 #6#
#define GL_CLIP_PLANE4 #7#
#define GL_CLIP_PLANE5 #8#
#define GL_COLOR_MATERIAL #9#
#define GL_CULL_FACE #10#
#define GL_DEPTH_TEST #11#
#define GL_DITHER #12#
#define GL_FOG #13#
#define GL_LIGHT0 #14#
#define GL_LIGHT1 #15#
#define GL_LIGHT2 #16#
#define GL_LIGHT3 #17#
#define GL_LIGHT4 #18#
#define GL_LIGHT5 #19#
#define GL_LIGHT6 #20#
#define GL_LIGHT7 #21#
#define GL_LIGHTING #22#
#define GL_LINE_SMOOTH #23#
#define GL_LINE_STIPPLE #24#
#define GL_LOGIC_OP #25#
#define GL_MAP1_COLOR_4 #26#
#define GL_MAP1_INDEX #27#
#define GL_MAP1_NORMAL #28#
#define GL_MAP1_TEXTURE_COORD_1 #29#
#define GL_MAP1_TEXTURE_COORD_2 #30#
#define GL_MAP1_TEXTURE_COORD_3 #31#
#define GL_MAP1_TEXTURE_COORD_4 #32#
#define GL_MAP1_VERTEX_3 #33#
#define GL_MAP1_VERTEX_4 #34#
#define GL_MAP2_COLOR_4 #35#
#define GL_MAP2_INDEX #36#
#define GL_MAP2_NORMAL #37#
#define GL_MAP2_TEXTURE_COORD_1 #38#
#define GL_MAP2_TEXTURE_COORD_2 #39#
#define GL_MAP2_TEXTURE_COORD_3 #40#
#define GL_MAP2_TEXTURE_COORD_4 #41#
#define GL_MAP2_VERTEX_3 #42#
#define GL_MAP2_VERTEX_4 #43#
#define GL_NORMALIZE #44#
#define GL_POINT_SMOOTH #45#
#define GL_POLYGON_SMOOTH #46#
#define GL_POLYGON_STIPPLE #47#
#define GL_SCISSOR_TEST #48#
#define GL_STENCIL_TEST #49#
#define GL_TEXTURE_1D #50#
#define GL_TEXTURE_2D #51#
#define GL_TEXTURE_GEN_Q #52#
#define GL_TEXTURE_GEN_R #53#
#define GL_TEXTURE_GEN_S #54#
#define GL_TEXTURE_GEN_T #55#	 
#define GL_STEREO #56#	

#define GL_SMOOTH #0#
#define GL_FLAT #1#

#define GL_AMBIENT #0#
#define GL_DIFFUSE; #1#
#define GL_SPECULAR #2#
#define GL_EMISSION #3#
#define GL_SHININESS #4#
#define GL_AMBIENT_AND_DIFFUSE #5#
#define GL_COLOR_INDEXES #6#
#define GL_POSITION #7#
#define GL_SPOT_DIRECTION #8#
#define GL_SPOT_EXPONENT #9#
#define GL_SPOT_CUTOFF #10#
#define GL_CONSTANT_ATTENUATION #11#
#define GL_LINEAR_ATTENUATION #12#
#define GL_QUADRATIC_ATTENUATION #13#

#define GL_LIGHT_MODEL_LOCAL_VIEWER #0#
#define GL_LIGHT_MODEL_TWO_SIDE #1#
#define GL_LIGHT_MODEL_AMBIENT #2#

#define GL_ZERO #0#
#define GL_ONE #1#
#define GL_DST_COLOR #2#
#define GL_ONE_MINUS_DST_COLOR #3#
#define GL_SRC_ALPHA #4#
#define GL_ONE_MINUS_SRC_ALPHA #5#
#define GL_DST_ALPHA #6#
#define GL_ONE_MINUS_DST_ALPHA #7#
#define GL_SRC_ALPHA_SATURATE #8#
#define GL_DST_COLOR #9#
#define GL_ONE_MINUS_DST_COLOR #10#

#define PNG_ALPHA #0#
#define PNG_SOLID #1#
#define PNG_STENCIL #2#
#define PNG_BLEND1 #3#
#define PNG_BLEND2 #4#
#define PNG_BLEND3 #5#
#define PNG_BLEND4 #6#
#define PNG_BLEND5 #7#
#define PNG_BLEND6 #8#
#define PNG_BLEND7 #9#
#define PNG_BLEND8 #10#

#define GL_CLAMP #0#
#define GL_REPEAT #1#

#define GL_POINTS #0#
#define GL_LINES #1#
#define GL_LINE_LOOP #2#
#define GL_LINE_STRIP #3#
#define GL_TRIANGLES #4#
#define GL_TRIANGLE_STRIP #5#
#define GL_TRIANGLE_FAN #6#
#define GL_QUADS #7#
#define GL_QUAD_STRIP #8#
#define GL_POLYGON #9#


#define GLU_FILL #0#
#define GLU_LINE #1#
#define GLU_SILHOUETTE #2#
#define GLU_POINT #3#

#define GLU_NONE #0#
#define GLU_FLAT #1#
#define GLU_SMOOTH #2#

#define GL_MODULATE #0#
#define GL_DECAL #1#
#define GL_BLEND #2#

#define GL_S #0#
#define GL_T #1#
#define GL_R #2#
#define GL_Q #3#

#define GL_OBJECT_LINEAR #0#
#define GL_EYE_LINEAR #1#
#define GL_SPHERE_MAP #2#

#define GL_OBJECT_LINEAR #0#
#define GL_EYE_LINEAR #1#
#define GL_SPHERE_MAP #2#

#define GL_TEXTURE_GEN_MODE #0#
#define GL_OBJECT_PLANE #1#
#define GL_EYE_PLANE #2#

#define GL_VERTEX_ARRAY #0#
#define GL_NORMAL_ARRAY #1#
#define GL_COLOR_ARRAY #2#
#define GL_INDEX_ARRAY #3#
#define GL_TEXTURE_COORD_ARRAY #4#
#define GL_EDGE_FLAG_ARRAY #5#

#define GL_PERSPECTIVE_CORRECTION_HINT #0#
#define GL_POINT_SMOOTH_HINT #1#
#define GL_LINE_SMOOTH_HINT #2#
#define GL_POLYGON_SMOOTH_HINT #3#
#define GL_FOG_HINT #4#

#define GL_DONT_CARE #0#
#define GL_FASTEST #1#
#define GL_NICEST #2#

#define GL_CLAMP #0#
#define GL_REPEAT #1#

#define GL_INIT #-1#
#define GL_NOT_VALID #0#
#define EQ  #0#
#define GET  #1#
#define GT  #2#
#define LET  #1#
#define LT  #1#

#define GL_NEAREST #0#
#define GL_LINEAR #1#

#define GLUT_STROKE_ROMAN		#0#
#define GLUT_STROKE_MONO_ROMAN	#1#
#define GLUT_BITMAP_9_BY_15		#2#
#define GLUT_BITMAP_8_BY_13		#3#
#define GLUT_BITMAP_TIMES_ROMAN_10	#4#
#define GLUT_BITMAP_TIMES_ROMAN_24	#5#
#define GLUT_BITMAP_HELVETICA_10	#6#
#define GLUT_BITMAP_HELVETICA_12	#7#
#define GLUT_BITMAP_HELVETICA_18	#8#

; GLE

#define TUBE_JN_RAW          #1#
#define TUBE_JN_ANGLE        #2#
#define TUBE_JN_CUT          #3#
#define TUBE_JN_ROUND        #4#
#define TUBE_JN_MASK         #15#    
#define TUBE_JN_CAP          #16#

#define TUBE_NORM_FACET      #256#
#define TUBE_NORM_EDGE       #512#
#define TUBE_NORM_PATH_EDGE  #1024# 
#define TUBE_NORM_MASK       #3840#
#define TUBE_CONTOUR_CLOSED  #4096#

#define GLE_TEXTURE_ENABLE			#65536#
#define GLE_TEXTURE_STYLE_MASK		#255#
#define GLE_TEXTURE_VERTEX_FLAT		#1#
#define GLE_TEXTURE_NORMAL_FLAT		#2#
#define GLE_TEXTURE_VERTEX_CYL		#3#
#define GLE_TEXTURE_NORMAL_CYL		#4#
#define GLE_TEXTURE_VERTEX_SPH		#5#
#define GLE_TEXTURE_NORMAL_SPH		#6#
#define GLE_TEXTURE_VERTEX_MODEL_FLAT	#7#
#define GLE_TEXTURE_NORMAL_MODEL_FLAT	#8#
#define GLE_TEXTURE_VERTEX_MODEL_CYL	#9#
#define GLE_TEXTURE_NORMAL_MODEL_CYL	#10#
#define GLE_TEXTURE_VERTEX_MODEL_SPH	#11#
#define GLE_TEXTURE_NORMAL_MODEL_SPH	#12#

