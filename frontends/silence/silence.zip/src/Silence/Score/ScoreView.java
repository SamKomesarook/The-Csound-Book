package Silence.Score;
import Silence.PluginInterface;
import Silence.Global;
import java.io.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.event.*;
/**
Provides a graphical user interface for a Score.
@author Copyright (C) 2000 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class ScoreView extends JPanel
{
  public static void main (String[]args)
  {
    Score.main (args);
  }
  public Score score = new Score ();
  BorderLayout borderLayout1 = new BorderLayout ();
  JToolBar menuToolBar = new JToolBar ();
  JToolBar statusToolBar = new JToolBar ();
  public JTabbedPane tabs = new JTabbedPane ();
  JButton newButton = new JButton ();
  JButton openButton = new JButton ();
  JButton saveButton = new JButton ();
  JButton saveAsButton = new JButton ();
  JButton exitButton = new JButton ();
  JLabel statusLabel = new JLabel ();
  JCheckBox useEqualTemperamentCheckBox = new JCheckBox ();
  JCheckBox useMasonNumbersCheckBox = new JCheckBox ();
  JLabel spacerLabel = new JLabel ();
  JLabel spacerLabel1 = new JLabel ();
  DisplayPanel displayPanel = new DisplayPanel ();
  NoteScalePanel noteScalePanel = null;
  NoteEditorPanel noteEditorPanel = null;
  MidiPanel midiPanel = null;
  JButton midiPlayButton = new JButton ();
  public class DisplayPanel extends JPanel
  {
    public void paint (Graphics g)
    {
      score.paint (DisplayPanel.this, g);
    }
  }
  public ScoreView ()
  {
    this (new Score ());
  }
  public ScoreView (Score score)
  {
    System.out.println ("BEGAN ScoreView()...");
    try
    {
      this.score = score;
      noteEditorPanel = new NoteEditorPanel (score);
      noteScalePanel = new NoteScalePanel (score);
      midiPanel = new MidiPanel (score);
      jbInit ();
      updateView ();
    }
    catch (Exception ex)
    {
      ex.printStackTrace ();
    }
    System.out.println ("ENDED ScoreView().");
  }
  public void updateView ()
  {
    noteScalePanel.updateView ();
    midiPanel.updateView ();
    noteEditorPanel.repaint ();
    statusLabel.setText (score.getName () + " : " + score.size () + " notes");
    useMasonNumbersCheckBox.setSelected (score.conformPitchesToMasonNumbers);
    this.useEqualTemperamentCheckBox.setSelected (score.useEqualTemperament);
  }
  void jbInit () throws Exception
  {
    this.setLayout (borderLayout1);
    newButton.setText ("  New  ");
    newButton.addActionListener (new java.awt.event.ActionListener ()
                                 {

        public void actionPerformed (ActionEvent e)
        {
          newButton_actionPerformed (e);
        }
      }
    );
    openButton.setText ("  Open...  ");
    openButton.addActionListener (new java.awt.event.ActionListener ()
                                  {
        public void actionPerformed (ActionEvent e)
        {
          openButton_actionPerformed (e);
        }
      }
    );
    saveButton.setText ("  Save  ");
    saveButton.addActionListener (new java.awt.event.ActionListener ()
                                  {
        public void actionPerformed (ActionEvent e)
        {
          saveButton_actionPerformed (e);
        }
      }
    );
    saveAsButton.setText ("  Save as...  ");
    saveAsButton.addActionListener (new java.awt.event.ActionListener ()
                                    {
        public void actionPerformed (ActionEvent
                                     e)
        {
          saveAsButton_actionPerformed (e);
        }
      }
    );
    statusLabel.setText (" ");
    useEqualTemperamentCheckBox.setText ("Use equal temperament");
    useEqualTemperamentCheckBox.addActionListener (new java.awt.
                                                   event.ActionListener ()
                                                   {
        public void
          actionPerformed
          (ActionEvent e)
        {
          useEqualTemperamentCheckBox_actionPerformed
            (e);
        }
      }
    );
    useMasonNumbersCheckBox.setText ("Use Mason numbers");
    useMasonNumbersCheckBox.addActionListener (new java.awt.
                                               event.ActionListener ()
                                               {
        public void
          actionPerformed (ActionEvent e)
        {
          useMasonNumbersCheckBox_actionPerformed
            (e);
        }
      }
    );
    tabs.addChangeListener (new javax.swing.event.ChangeListener ()
                            {

        public void stateChanged (ChangeEvent e)
        {
          tabs_stateChanged (e);
        }
      }
    );
    spacerLabel.setText ("    ");
    spacerLabel1.setText ("    ");
    menuToolBar.setFloatable (false);
    statusToolBar.setFloatable (false);
    exitButton.setText ("  Exit  ");
    exitButton.addActionListener (new java.awt.event.ActionListener ()
                                  {
        public void actionPerformed (ActionEvent e)
        {
          exitButton_actionPerformed (e);
        }
      }
    );
    midiPanel.setBorder (null);
    midiPlayButton.setText ("  Play Midi  ");
    midiPlayButton.addActionListener (new java.awt.event.ActionListener ()
                                      {

        public void actionPerformed (ActionEvent
                                     e)
        {
          midiPlayButton_actionPerformed (e);
        }
      }
    );
    this.add (menuToolBar, BorderLayout.NORTH);
    menuToolBar.add (newButton, null);
    menuToolBar.add (openButton, null);
    menuToolBar.add (saveButton, null);
    menuToolBar.add (saveAsButton, null);
    menuToolBar.add (midiPlayButton, null);
    menuToolBar.add (exitButton, null);
    menuToolBar.add (spacerLabel, null);
    menuToolBar.add (useEqualTemperamentCheckBox, null);
    menuToolBar.add (spacerLabel1, null);
    menuToolBar.add (useMasonNumbersCheckBox, null);
    this.add (statusToolBar, BorderLayout.SOUTH);
    statusToolBar.add (statusLabel, null);
    this.add (tabs, BorderLayout.CENTER);
    tabs.add (displayPanel, "Display");
    tabs.add (noteEditorPanel, "Edit");
    tabs.add (noteScalePanel, "Scale");
    tabs.add (midiPanel, "Midi");
  }

  void newButton_actionPerformed (ActionEvent e)
  {
    score.clear ();
    updateView ();
  }
  void openButton_actionPerformed (ActionEvent e)
  {
    Cursor cursor = getCursor ();
    JFileChooser fileDialog = Global.createFileDialog ("Open");




    fileDialog.addChoosableFileFilter (Global.createFileFilter
                                       ("Score files", ".scr"));
    if (fileDialog.showOpenDialog (null) == fileDialog.APPROVE_OPTION)
    {
      setCursor (Cursor.getPredefinedCursor (Cursor.WAIT_CURSOR));
      File file = fileDialog.getSelectedFile ();
      String filename = file.getAbsolutePath ();
      if (filename.endsWith (".scr"))
      {
        try
        {
          score = (Score) score.deserialize (file.getAbsolutePath ());
          Container container = getParent ();
          container.remove (this);
          ScoreView scoreView = (ScoreView) score.getView ();
          container.add (scoreView);
          scoreView.updateView ();
          container.repaint ();
        }
        catch (Exception x)
        {
          x.printStackTrace ();
        }
      }
    }
    setCursor (cursor);
  }

  void saveButton_actionPerformed (ActionEvent e)
  {
    String filename = score.getRootFilename () + ".scr";
    try
    {
      score.serialize (filename);
    }
    catch (IOException x)
    {
      x.printStackTrace ();
    }
    catch (IllegalAccessException x)
    {
      x.printStackTrace ();
    }
  }
  void saveAsButton_actionPerformed (ActionEvent e)
  {
    JFileChooser fileDialog = Global.createFileDialog ("Save as");




    fileDialog.addChoosableFileFilter (Global.createFileFilter
                                       ("Score files", ".scr"));
    if (fileDialog.showSaveDialog (ScoreView.this) ==
        fileDialog.APPROVE_OPTION)
    {
      File file = fileDialog.getSelectedFile ();
      String filename = file.getAbsolutePath ();
      if (filename.indexOf (".") == -1)
      {
        filename += ".scr";
      }
      score.setName (filename);
      filename = score.getRootFilename () + ".scr";
      score.setName (filename);
      try
      {
        score.serialize (filename);
      }
      catch (Exception x)
      {
        x.printStackTrace ();
      }
    }
  }
  void useEqualTemperamentCheckBox_actionPerformed (ActionEvent e)
  {
    score.useEqualTemperament = useEqualTemperamentCheckBox.isSelected ();
    displayPanel.repaint ();
  }
  void useMasonNumbersCheckBox_actionPerformed (ActionEvent e)
  {
    score.conformPitchesToMasonNumbers =
      useMasonNumbersCheckBox.isSelected ();
    displayPanel.repaint ();
  }
  void exitButton_actionPerformed (ActionEvent e)
  {
    System.exit (0);
  }
  public void midiPlay()
  {
    midiPanel.playButton_actionPerformed (null);
  }
  void midiPlayButton_actionPerformed (ActionEvent e)
  {
    midiPanel.playButton_actionPerformed (e);
  }
  public void setModel (Score score)
  {
    this.score = score;
    noteEditorPanel.setModel (score);
    noteScalePanel.setModel (score);
    midiPanel.setModel (score);
  }
  void tabs_stateChanged (ChangeEvent e)
  {
    if (tabs.getSelectedComponent () == noteScalePanel)
    {
      score.findActualScale ();
      noteScalePanel.updateView ();
    }
  }
}
