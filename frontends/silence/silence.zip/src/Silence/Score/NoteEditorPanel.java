package Silence.Score;
import Silence.Orchestra.Event;
import javax.swing.*;
import java.awt.*;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.table.JTableHeader;
import javax.swing.event.*;
import javax.swing.JButton;
import java.awt.event.*;
/**
@author Copyright (C) 1998, 2000 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class NoteEditorPanel extends javax.swing.JPanel
  {
  Score score = null;
  javax.swing.JToolBar buttonPanel = new JToolBar ();
  javax.swing.JButton insertButton = new JButton ();
  javax.swing.JButton deleteButton = new JButton ();
  JScrollPane tableScrollPane = new JScrollPane ();
  JTable table = new JTable ();
  BorderLayout borderLayout1 = new BorderLayout ();
  public NoteEditorPanel (Score score)
  {
    try
    {
      setModel (score);
      jbInit ();
    }
    catch (Exception e)
    {
      e.printStackTrace ();
    }
  }
  class SymAction implements java.awt.event.ActionListener
    {
    public void actionPerformed (java.awt.event.ActionEvent event)
    {
      Object object = event.getSource ();
      if (object == insertButton)
        insertButton_ActionPerformed (event);
      else if (object == deleteButton)
        deleteButton_ActionPerformed (event);
    }
  }
  void insertButton_ActionPerformed (java.awt.event.ActionEvent event)
  {
    int row = table.getSelectedRow ();
    if (row == -1)
    {
      row = 0;
    }
    score.add (row, Event.createNote ());
    table.getSelectionModel ().setSelectionInterval (row, row);
    TableModelEvent tableModelEvent =
      new TableModelEvent (table.getModel (), row, row,
                           TableModelEvent.ALL_COLUMNS,
                           TableModelEvent.INSERT);
    table.tableChanged (tableModelEvent);
  }
  void deleteButton_ActionPerformed (java.awt.event.ActionEvent event)
  {
    int[] selectedRows = table.getSelectedRows ();
    if (selectedRows.length == 0)
    {
      return;
    }
    for (int i = 0, j = selectedRows.length - 1; i < selectedRows.length;
        i++, j--)
    {
      score.remove (selectedRows[j]);
    }
    TableModelEvent tableModelEvent =
      new TableModelEvent (table.getModel (), selectedRows[0],
                           selectedRows[selectedRows.length - 1],
                           TableModelEvent.ALL_COLUMNS,
                           TableModelEvent.DELETE);
    table.tableChanged (tableModelEvent);
  }
  public void setModel (Score score)
  {
    this.score = score;
    table.setModel (score.new TableModel ());
  }
  private void jbInit () throws Exception
  {
    setLayout (borderLayout1);
    setVisible (false);
    tableScrollPane.getViewport ().add (table);
    tableScrollPane.setBorder (BorderFactory.createLoweredBevelBorder ());
    add (tableScrollPane, BorderLayout.CENTER);
    setSize (686, 503);
    add (buttonPanel, BorderLayout.NORTH);
    insertButton.setText ("  Insert  ");
    insertButton.setActionCommand ("Insert");
    insertButton.setBounds (12, 12, 72, 25);
    buttonPanel.add (insertButton);
    deleteButton.setText ("  Delete  ");
    deleteButton.setActionCommand ("Delete");
    deleteButton.setBounds (96, 12, 72, 25);
    buttonPanel.add (deleteButton);
    SymAction lSymAction = new SymAction ();
    insertButton.addActionListener (lSymAction);
    deleteButton.addActionListener (lSymAction);
    buttonPanel.setFloatable (false);
    this.addComponentListener (new NoteEditorPanel_this_componentAdapter (this));
  }
  void this_componentShown (ComponentEvent e)
  {
    TableModelEvent tableModelEvent = new TableModelEvent (table.getModel ());
    table.tableChanged (tableModelEvent);
  }
}
class NoteEditorPanel_this_componentAdapter extends java.awt.
  event.ComponentAdapter
  {
  NoteEditorPanel adaptee;

  NoteEditorPanel_this_componentAdapter (NoteEditorPanel adaptee)
  {
    this.adaptee = adaptee;
  }
  public void componentShown (ComponentEvent e)
  {
    adaptee.this_componentShown (e);
  }
}
