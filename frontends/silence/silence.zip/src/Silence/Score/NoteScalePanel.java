package Silence.Score;
import java.awt.*;
import javax.swing.*;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.table.AbstractTableModel;
import java.awt.event.*;
/**
Dialog for rescaling a score to fit within a bounding hypercube of note space.
@author Copyright (C) 1998, 2000 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class NoteScalePanel extends javax.swing.JPanel
  {
  public Score score = null;
  public AbstractTableModel tableModel = null;
  public void updateView ()
  {
    autoRescaleCheckbox.setSelected (score.autoRescale);
    tableModel.fireTableDataChanged ();
  }
  public void updateModel ()
  {
    score.autoRescale = autoRescaleCheckbox.isSelected ();
    updateView ();
  }
  public NoteScalePanel ()
  {
    this (new Score ());
  }
  public NoteScalePanel (Score score)
  {
    setModel (score);
    updateView ();
    setLayout (new BorderLayout ());
    this.add (scalePanel, BorderLayout.CENTER);
    scalePanel.getViewport ().add (table);
    setSize (634, 478);
    autoRescaleCheckbox.setText ("Auto-rescale");
    autoRescaleCheckbox.setActionCommand ("Auto-rescale");
    autoRescaleCheckbox.setBounds (12, 12, 96, 21);
    autoRescaleCheckbox.setFont (new Font ("Dialog", Font.PLAIN, 12));
    try
    {
      jbInit ();
    }
    catch (Exception e)
    {
      e.printStackTrace ();
    }
  }
  javax.swing.JTable table = new JTable ();
  javax.swing.JCheckBox autoRescaleCheckbox = new JCheckBox ();
  JToolBar scaleToolBar = new JToolBar ();
  JButton scoreScaleUpdateButton = new JButton ();
  JButton scoreScaleTargetToActualButton = new JButton ();
  JButton scoreScaleActualToTargetButton = new JButton ();
  JLabel spacerLabel = new JLabel ();
  BorderLayout borderLayout1 = new BorderLayout ();
  JScrollPane scalePanel = new JScrollPane ();
  private void jbInit () throws Exception
  {
    this.addComponentListener (new
                               NoteScalePanel_this_componentAdapter (this));
    scoreScaleUpdateButton.setText (" Update ");
    scoreScaleUpdateButton.addActionListener (new
                                              NoteScalePanel_scoreScaleUpdateButton_actionAdapter
                                              (this));
    scoreScaleTargetToActualButton.setText (" Scale target to actual ");
    scoreScaleTargetToActualButton.addActionListener (new
                                                      NoteScalePanel_scoreScaleTargetToActualButton_actionAdapter
                                                      (this));
    scoreScaleActualToTargetButton.setText (" Scale actual to target ");
    scoreScaleActualToTargetButton.addActionListener (new
                                                      NoteScalePanel_scoreScaleActualToTargetButton_actionAdapter
                                                      (this));
    scaleToolBar.setFloatable (false);
    spacerLabel.setText ("    ");
    this.setLayout (borderLayout1);
    scalePanel.setBorder (BorderFactory.createLoweredBevelBorder ());
    autoRescaleCheckbox.setText ("Auto rescale");
    this.add (scalePanel, BorderLayout.CENTER);
    this.add (scaleToolBar, BorderLayout.NORTH);
    scaleToolBar.add (scoreScaleUpdateButton, null);
    scaleToolBar.add (scoreScaleTargetToActualButton, null);
    scaleToolBar.add (scoreScaleActualToTargetButton, null);
    scaleToolBar.add (spacerLabel, null);
    scaleToolBar.add (autoRescaleCheckbox, null);
  }
  void this_componentShown (ComponentEvent e)
  {
    score.findActualScale ();
    updateView ();
  }
  void scoreScaleUpdateButton_actionPerformed (ActionEvent e)
  {
    updateModel ();
    score.findActualScale ();
    updateView ();
  }
  void scoreScaleTargetToActualButton_actionPerformed (ActionEvent e)
  {
    updateModel ();
    score.findActualScale ();
    score.setTargetScaleToActual ();
    updateView ();
  }
  void scoreScaleActualToTargetButton_actionPerformed (ActionEvent e)
  {
    updateModel ();
    score.setActualScaleToTarget ();
    updateView ();
  }
  public void setModel (Score score)
  {
    this.score = score;
    tableModel = score.new RescaleTableModel ();
    table.setModel (tableModel);
  }
}
class NoteScalePanel_this_componentAdapter extends java.awt.
  event.ComponentAdapter
  {
  NoteScalePanel adaptee;

  NoteScalePanel_this_componentAdapter (NoteScalePanel adaptee)
  {
    this.adaptee = adaptee;
  }
  public void componentShown (ComponentEvent e)
  {
    adaptee.this_componentShown (e);
  }
}
class NoteScalePanel_scoreScaleUpdateButton_actionAdapter implements java.
  awt.event.ActionListener
  {
  NoteScalePanel adaptee;

  NoteScalePanel_scoreScaleUpdateButton_actionAdapter (NoteScalePanel adaptee)
  {
    this.adaptee = adaptee;
  }
  public void actionPerformed (ActionEvent e)
  {
    adaptee.scoreScaleUpdateButton_actionPerformed (e);
  }
}
class NoteScalePanel_scoreScaleTargetToActualButton_actionAdapter implements
  java.awt.event.ActionListener
  {
  NoteScalePanel adaptee;


























  NoteScalePanel_scoreScaleTargetToActualButton_actionAdapter (NoteScalePanel adaptee)
  {
    this.adaptee = adaptee;
  }
  public void actionPerformed (ActionEvent e)
  {
    adaptee.scoreScaleTargetToActualButton_actionPerformed (e);
  }
}
class NoteScalePanel_scoreScaleActualToTargetButton_actionAdapter implements
  java.awt.event.ActionListener
  {
  NoteScalePanel adaptee;


























  NoteScalePanel_scoreScaleActualToTargetButton_actionAdapter (NoteScalePanel adaptee)
  {
    this.adaptee = adaptee;
  }
  public void actionPerformed (ActionEvent e)
  {
    adaptee.scoreScaleActualToTargetButton_actionPerformed (e);
  }
}
