package Silence.Score;
import Silence.Conversions;
import Silence.Mathematics.Matrix;
import Silence.Orchestra.Event;
import java.io.*;
import java.util.*;
import javax.swing.JOptionPane;
import javax.swing.DefaultComboBoxModel;
/**
Defines operations on pitches in 12-tone equal temperament
(or any equally tempered scale), using a method derived from Mason numbers
(Robert M. Mason, "An Encoding Algorithm and Tables for the Digital Analysis
of Harmony," Journal of Research in Music Education 17 (1969): 286-300, 369-387).
The Mason number of a pitch-class is 2 to power of that pitch-class
starting with C = 0 (it was fifths starting with F in Mason's original paper):
M(C) = 2^0 = 1, M(C#) = 2^1 = 2, M(D) = 2^2 = 4....
The Mason number of an unordered pitch-class set is the sum of
the Mason numbers of the distinct pitch-classes in the set: M(C major) = 145.
Pitch-class sets may be transposed, mutated, or otherwise permuted by
multiplying their Mason numbers modulo 4095:
M(C major) * 2^5 = M(F major) = 545,
M(C major scale) * 0.53228748631886172929587741700109 = M(F harmonic minor scale) = 1459.
The pitch-classes of any set can be recovered from its Mason number
by factoring out powers of 2 and dividing the logarithm of each power of 2
by the logarithm of 2.
@author Copyright (C) 1998, 2000 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/

public class MasonNumbers
{
  public static void main(String[] args)
  {
    try
    {
      Object[] keys = pcsNames.keySet().toArray();
      Object[] values = pcsNames.values().toArray();
      for(int i = 0; i < keys.length; i++)
      {
        System.out.println(keys[i] + " = " + values[i]);
      }
      System.out.println("Conform E to C#m:");
      System.out.println("E = " + pcFromKey(64));
      System.out.println("C#m = " + getPcs("C#m"));
      System.out.println(conformKey(64, getPcs("C#m")));
    }
    catch(Exception x)
    {
    }
  }
  public static double tones = 12.0;
  public static double modulus = 4095.0;
  public static TreeMap pcNames = new TreeMap();
  public static TreeMap pcsNames = new TreeMap();
  public static final String[] names;
  public static class PcsNamesComboBoxModel extends DefaultComboBoxModel
  {
    public PcsNamesComboBoxModel(Object[] list)
    {
      super(list);
    }
  }
  public static final PcsNamesComboBoxModel pcsNamesComboBoxModel;
  static
    {
    modulus = Math.pow(2, tones) - 1;
    pcNames.put("C",  new Double(Math.pow(2, 0)));
    pcNames.put("C#", new Double(Math.pow(2, 1)));
    pcNames.put("Db", new Double(Math.pow(2, 1)));
    pcNames.put("D",  new Double(Math.pow(2, 2)));
    pcNames.put("D#", new Double(Math.pow(2, 3)));
    pcNames.put("Eb", new Double(Math.pow(2, 3)));
    pcNames.put("E",  new Double(Math.pow(2, 4)));
    pcNames.put("F",  new Double(Math.pow(2, 5)));
    pcNames.put("F#", new Double(Math.pow(2, 6)));
    pcNames.put("Gb", new Double(Math.pow(2, 6)));
    pcNames.put("G",  new Double(Math.pow(2, 7)));
    pcNames.put("G#", new Double(Math.pow(2, 8)));
    pcNames.put("Ab", new Double(Math.pow(2, 8)));
    pcNames.put("A",  new Double(Math.pow(2, 9)));
    pcNames.put("A#", new Double(Math.pow(2, 10)));
    pcNames.put("Bb", new Double(Math.pow(2, 10)));
    pcNames.put("B",  new Double(Math.pow(2, 11)));
    for(Iterator it = pcNames.keySet().iterator(); it.hasNext(); )
    {
      String key = (String) it.next();
      pcsNames.put(key, pcNames.get(key));
      double pc = getPc(key);
      pcsNames.put(key + " major",
                   new Double((pc * parsePcs("C  D  E  F  G  A  B")) % modulus));
      pcsNames.put(key + " natural minor",
                   new Double((pc * parsePcs("C  D  Eb F  G  Ab Bb")) % modulus));
      pcsNames.put(key + " harmonic minor",
                   new Double((pc * parsePcs("C  D  Eb F  G  Ab B ")) % modulus));
      pcsNames.put(key + " melodic minor",
                   new Double((pc * parsePcs("C  D  E  F  G  A  B ")) % modulus));
      pcsNames.put(key + " whole tone",
                   new Double((pc * parsePcs("C  D  E  F# G# A#")) % modulus));
      pcsNames.put(key + " diminished",
                   new Double((pc * parsePcs("C  D  Eb F  Gb Ab A  B")) % modulus));
      pcsNames.put(key + "M",
                   new Double((pc * parsePcs("C  E  G")) % modulus));
      pcsNames.put(key + "m",
                   new Double((pc * parsePcs("C  Eb G")) % modulus));
      pcsNames.put(key + "-",
                   new Double((pc * parsePcs("C  Eb Gb")) % modulus));
      pcsNames.put(key + "+",
                   new Double((pc * parsePcs("C  E  G#")) % modulus));
      pcsNames.put(key + "7",
                   new Double((pc * parsePcs("C  E  G  Bb")) % modulus));
      pcsNames.put(key + "M7",
                   new Double((pc * parsePcs("C  E  G  B")) % modulus));
      pcsNames.put(key + "m7",
                   new Double((pc * parsePcs("C  Eb G  Bb")) % modulus));
      pcsNames.put(key + "-7",
                   new Double((pc * parsePcs("C  Eb G  A")) % modulus));
      pcsNames.put(key + "7#5",
                   new Double((pc * parsePcs("C  E  G# Bb")) % modulus));
      pcsNames.put(key + "7b5",
                   new Double((pc * parsePcs("C  E  Gb Bb")) % modulus));
      pcsNames.put(key + "m7b5",
                   new Double((pc * parsePcs("C  Eb Gb Bb")) % modulus));
      pcsNames.put(key + "m7#5",
                   new Double((pc * parsePcs("C  Eb G# Bb")) % modulus));
      pcsNames.put(key + "9",
                   new Double((pc * parsePcs("C  E  G  Bb D")) % modulus));
      pcsNames.put(key + "M9",
                   new Double((pc * parsePcs("C  E  G  B  D")) % modulus));
      pcsNames.put(key + "m9",
                   new Double((pc * parsePcs("C  Eb G  Bb D")) % modulus));
      pcsNames.put(key + "7b9",
                   new Double((pc * parsePcs("C  E  G  Bb Db")) % modulus));
      pcsNames.put(key + "7b9b13",
                   new Double((pc * parsePcs("C  E  G  Bb Db F Ab")) % modulus));
      pcsNames.put(key + "9#5",
                   new Double((pc * parsePcs("C  E  G# Bb D")) % modulus));
      pcsNames.put(key + "9b5",
                   new Double((pc * parsePcs("C  E  Gb Bb D")) % modulus));
      pcsNames.put(key + "69",
                   new Double((pc * parsePcs("C  E  G  A  D")) % modulus));
      pcsNames.put(key + "11",
                   new Double((pc * parsePcs("C  E  G  Bb D  F")) % modulus));
      pcsNames.put(key + "m11",
                   new Double((pc * parsePcs("C  Eb G  Bb Db F")) % modulus));
      pcsNames.put(key + "9#11",
                   new Double((pc * parsePcs("C  E  G  Bb D  F#")) % modulus));
      pcsNames.put(key + "13",
                   new Double((pc * parsePcs("C  E  G  Bb D  F  A")) % modulus));
      for(int i = 0; i < modulus; i++)
      {
        pcsNames.put(String.valueOf(i),
                     Double.valueOf(String.valueOf(i)));
      }
    }
    names = (String[]) pcsNames.keySet().toArray(new String[0]);
    pcsNamesComboBoxModel = new PcsNamesComboBoxModel(names);
  }
  public static double getPc(String name)
  {
    Double d = (Double) pcNames.get(name);
    if(d == null)
    {
      return 0;
    }
    else
    {
      return d.doubleValue();
    }
  }
  public static double getPcs(String name)
  {
    Double d = (Double) pcsNames.get(name);
    if(d == null)
    {
      return 0;
    }
    else
    {
      return d.doubleValue();
    }
  }
  public static double parsePcs(String pcNames)
  {
    double pcs = 0;
    StringTokenizer stringTokenizer = new StringTokenizer(pcNames);
    while(stringTokenizer.hasMoreTokens())
    {
      String pcName = stringTokenizer.nextToken();
      pcs += getPc(pcName);
    }
    return pcs;
  }
  public static double plus(double a, double b)
  {
    return Math.round(a + b) % modulus;
  }
  public static double times(double a, double b)
  {
    return Math.round(a * b) % modulus;
  }
  public static double divide(double a, double b)
  {
    return Math.round(a / b) % modulus;
  }
  public static double complement(int a, int b)
  {
    int a1 = Math.round(a);
    int b1 = Math.round(b);
    return a1 & (~ b1);
  }
  public static double complement(int a)
  {
    int a1 = Math.round(a);
    return (~a1) & ((int) modulus);
  }
  public static boolean getPc(double pcs, double pc)
  {
    int pcs1 = (int) Math.round(pcs);
    int pc1 = (int) Math.round(pc);
    return (pcs1 & (int) Math.pow(2, pc1)) == (int) Math.pow(2, pc1);
  }
  public static double setPc(double pcs, double pc)
  {
    int pcs1 = (int) Math.round(pcs);
    int pc1 = (int) Math.round(pc);
    return pcs1 + Math.pow(2, pc1);
  }
  public static double findClosest(double pcs, double pc)
  {
    int pcs1 = (int) Math.round(pcs);
    int pc1 = (int) Math.round(pc);
    int lower = 0;
    int upper = 0;
    int i;
    int p2;
    for(i = (int) keyFromPc(pc); i < tones; i++)
    {
      p2 = (int) Math.pow(2, i);
      if((pcs1 & p2) == p2)
      {
        upper = i;
        break;
      }
    }
    for(i = (int) keyFromPc(pc); i >= 0; i--)
    {
      p2 = (int) Math.pow(2, i);
      if((pcs1 & p2) == p2)
      {
        lower = i;
        break;
      }
    }
    int deltaLower = pc1 - lower;
    int deltaUpper = upper - pc1;
    if(deltaLower < deltaUpper)
    {
      return lower;
    }
    else
    {
      return upper;
    }
  }
  public static double keyFromPc(double pc)
  {
    return Math.log(pc) / Math.log(2.0);
  }
  public static double pcFromKey(double midiKey)
  {
    double key = Math.round(midiKey);
    double pitch = key % tones;
    return Math.pow(2, (int) Math.round(pitch));
  }
  public static double conformKey(double midiKey, double pcs)
  {
    pcs = Math.abs(pcs) % modulus;
    double pitch = midiKey % tones;
    double base = midiKey - pitch;
    double conformedPc = findClosest(pcs, pcFromKey(pitch));
    double conformedMidiKey = base + conformedPc;
    //System.out.println("midiKey = " + midiKey + ", pcs = " + pcs + ", conformedMidiKey = " + conformedMidiKey + ".");
    return conformedMidiKey;
  }
  public static double[] conformToMasonNumber(double[] note)
  {
    double[] copy = (double[]) note.clone();
    double midiKey = Event.getMidiKey(note);
    double mason = Event.getMason(note);
    Event.setMidiKey(copy, conformKey(midiKey, mason));
    return copy;
  }
  public static void conformToMasonNumber(double[] note, double masonNumber)
  {
    Event.setMason(note, masonNumber);
  }
  public static double getMasonNumber(Score score)
  {
    //System.out.println("BEGAN MasonNumbers.getMasonNumber(score)...");
    Set set = new HashSet ();
    for(int i = 0, n = score.size (); i < n; i++)
    {
      double[] note = score.getEvent (i);
      //System.out.println(note.getCsoundString());
      set.add (new Double (pcFromKey (note[Event.KEY])));
    }
    double masonNumber = 0;
    java.util.Iterator i = set.iterator ();
    while(i.hasNext ())
    {
      masonNumber += ((Double) i.next ()).doubleValue ();
    }
    //System.out.println("masonNumber = " + masonNumber);
    //System.out.println("ENDED MasonNumbers.getMasonNumber(score).");
    return masonNumber;
  }
  public static void conformScoreToMasonNumber(double masonNumber,
                                               Score score)
  {
    System.out.println("BEGAN MasonNumbers.conformScoreToMasonNumber(masonNumber, score)...");
    System.out.println("masonNumber = " + masonNumber);
    int n = score.size();
    System.out.println("Note count = " + n);
    for (int i = 0; i < n; i++)
    {
      double[] note = score.getEvent (i);
      conformToMasonNumber (note, masonNumber);
    }
    System.out.println("Result = " + getMasonNumber (score));
    System.out.println("ENDED MasonNumbers.conformScoreToMasonNumber(masonNumber, score).");
  }
  public static void multiply(double masonNumber, double[] note)
  {
    conformToMasonNumber(note, note[Event.MASON] * masonNumber);
  }
  public static void multiply(double masonNumber, Score score)
  {
    double[] event = null;
    for(int i = 0, n = score.size(); i < n; i++)
    {
      event = score.getEvent(i);
      if(Event.isNote(event))
      {
        multiply(masonNumber, event);
      }
    }
  }
}
