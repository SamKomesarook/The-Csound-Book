package Silence.Score;
import Silence.Global;
import Silence.PluginInterface;
import Silence.Plugin;
import Silence.Conversions;
import Silence.Orchestra.Event;
import Silence.Orchestra.Timebase;
import Silence.Mathematics.Matrix;
import Silence.Viewable;
import Silence.XMLSerializer;
import java.awt.Color;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.ClipboardOwner;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Image;
import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Collections;
import javax.sound.midi.InvalidMidiDataException;
import javax.sound.midi.MetaMessage;
import javax.sound.midi.MidiEvent;
import javax.sound.midi.MidiMessage;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.Sequence;
import javax.sound.midi.ShortMessage;
import javax.sound.midi.Track;
import javax.swing.JFrame;
import javax.swing.table.AbstractTableModel;
/**
Manages a score of Event objects,
with facilities for rescaling the score,
importing MIDI files into the score,
exporting it or playing it as a MIDI file,
coercing the score to equal temperament,
or manipulating the Mason numbers of its notes.
@author Copyright (C) 2000 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class Score extends ArrayList implements PluginInterface,
  Viewable, ClipboardOwner
{
  public static void main (String[]args)
  {
    Score score = new Score ();
    score.openView ();
  }
  public class TableModel extends AbstractTableModel
  {
    public boolean isCellEditable (int i, int j)
    {
      return true;
    }
    public int getRowCount ()
    {
      return size ();
    }
    public int getColumnCount ()
    {
      return Event.ELEMENT_COUNT;
    }
    public Object getValueAt (int i, int j)
    {
      double[] event = getEvent (i);
      return new Double (event[j]);
    }
    public void setValueAt (Object value, int i, int j)
    {
      double[] event = getEvent (i);
      event[j] = ((Double) value).doubleValue ();
    }
    public String getColumnName (int j)
    {
      return Event.labels[j];
    }
    public Class getColumnClass (int j)
    {
      return Double.class;
    }
  }
  public class RescaleTableModel extends AbstractTableModel
  {
    public int getRowCount ()
    {
      return Event.ELEMENT_COUNT;
    }
    public int getColumnCount ()
    {
      return 7;
    }
    public Object getValueAt (int row, int column)
    {
      if (column < 0 || column > 6)
      {
        return null;
      }
      try
      {
        switch (column)
        {
        case 0:
          return Event.labels[row];
        case 1:return new Boolean (rescaleMinima[row]);
        case 2:return new Double (scaleTargetMinima[row]);
        case 3:return new Boolean (rescaleRanges[row]);
        case 4:return new Double (scaleTargetRanges[row]);
        case 5:return new Double (scaleActualMinima[row]);
        case 6:return new Double (scaleActualRanges[row]);
        }
      }
      catch (Exception x)
      {
        x.printStackTrace ();
      }
      return null;
    }
    public void setValueAt (Object value, int row, int column)
    {
      if (column < 0 || column > 4 || row >= Event.HOMOGENEITY)
      {
        return;
      }
      boolean b = false;
      double d = 0;
      switch (column)
      {
      case 1:
        b = ((Boolean) value).booleanValue ();
        rescaleMinima[row] = b;
        return;
      case 2:
        d = Double.parseDouble (value.toString ());
        scaleTargetMinima[row] = d;
        return;
      case 3:
        b = ((Boolean) value).booleanValue ();
        rescaleRanges[row] = b;
        return;
      case 4:
        d = Double.parseDouble (value.toString ());
        scaleTargetRanges[row] = d;
        return;
      }
    }
    public Class getColumnClass (int column)
    {
      switch (column)
      {
      case 0:
        return String.class;
      case 1:return Boolean.class;
      case 2:return Double.class;
      case 3:return Boolean.class;
      case 4:return Double.class;
      case 5:return Double.class;
      case 6:return Double.class;
      }
      return String.class;
    }
    public boolean isCellEditable (int row, int column)
    {
      if (column == 0)
      {
        return false;
      }
      if (row >= Event.HOMOGENEITY || column > 4)
      {
        return false;
      }
      return true;
    }
    public String getColumnName (int column)
    {
      switch (column)
      {
      case 0:
        return "Dimension";
      case 1:return "Rescale?";
      case 2:return "Target Minima";
      case 3:return "Rescale?";
      case 4:return "Target Ranges";
      case 5:return "Actual Minima";
      case 6:return "Actual Ranges";
      }
      return "Error";
    }
  }
  public String filename = null;
  transient Clipboard clipboard = new JFrame().getToolkit().getSystemClipboard();
  public Timebase timebase = null;
  public transient TableModel tableModel = new TableModel ();
  public transient RescaleTableModel rescaleTableModel =
    new RescaleTableModel ();
  public int pendingEventIndex = 0;
  public double[] scaleTargetMinima = null;
  public double[] scaleTargetRanges = null;
  public transient double[] scaleActualMinima = null;
  public transient double[] scaleActualRanges = null;
  public boolean[] rescaleMinima = null;
  public boolean[] rescaleRanges = null;
  public int[] midiPrograms = null;
  public double tonesPerOctave;
  public boolean useEqualTemperament;
  public boolean conformPitchesToMasonNumbers;
  public boolean importNotesOnly;
  public boolean autoRescale;
  public Score (Timebase timebase)
  {
    this.timebase = timebase;
    scoreDefaults ();
  }
  public Score ()
  {
    timebase = new Timebase ();
    scoreDefaults ();
  }
  public Score copy()
  {
    Score copy = new Score(timebase);
    copy.filename = filename;
    copy.pendingEventIndex = pendingEventIndex;
    copy.scaleTargetMinima = (double[]) scaleTargetMinima.clone();
    copy.scaleTargetRanges = (double[]) scaleTargetRanges.clone();
    copy.rescaleMinima = (boolean[]) rescaleMinima.clone();
    copy.rescaleRanges = (boolean[]) rescaleRanges.clone();
    copy.midiPrograms = (int[]) midiPrograms.clone();
    copy.tonesPerOctave = tonesPerOctave;
    copy.useEqualTemperament = useEqualTemperament;
    copy.conformPitchesToMasonNumbers = conformPitchesToMasonNumbers;
    copy.importNotesOnly = importNotesOnly;
    copy.autoRescale = autoRescale;
    for(Iterator it = iterator(); it.hasNext(); )
    {
      copy.add(((double[]) it.next()).clone());
    }
    return copy;
  }
  public void scoreDefaults ()
  {
    clear ();
    filename = "score.scr";
    pendingEventIndex = 0;
    scaleTargetMinima =
      Event.createEvent (144, 1, 0, 1, 36, 72, 0, 0, 0, 0, 0);
    scaleTargetRanges =
      Event.createEvent (0, 4, 240, 4, 60, 20, 0, 0, 0, 0, 4095);
    scaleActualMinima =
      Event.createEvent (144, 0, 0, 1, 36, 72, 0, 0, 0, 0, 0);
    scaleActualRanges =
      Event.createEvent (0, 4, 240, 4, 60, 20, 0, 0, 0, 0, 4095);
    boolean[] temp =
      {
      false, true, true, true, true, true, true, true, true, true, false,
        false
    };
    rescaleMinima = temp;
    boolean[]temp1 =
      {
      false, true, true, true, true, true, true, true, true, true, false,
        false
    };
    rescaleRanges = temp1;
    midiPrograms = new int[16];
    tonesPerOctave = 12;
    useEqualTemperament = true;
    conformPitchesToMasonNumbers = false;
    importNotesOnly = true;
    autoRescale = false;
  }
  public void findActualScale ()
  {
    for (int dimension = 0; dimension < Event.HOMOGENEITY; dimension++)
    {
      findActualScale (dimension);
    }
  }
  public void findActualScale (int dimension)
  {
    findActualScale (0, size (), dimension);
  }
  public void findActualScale (int beginIndex, int endIndex)
  {
    for (int dimension = 0; dimension < Event.HOMOGENEITY; dimension++)
    {
      findActualScale (beginIndex, endIndex, dimension);
    }
  }
  public void findActualScale (int beginIndex, int endIndex, int dimension)
  {
    int i;
    double[] note = null;
    double[] scaleActualMaxima = Event.createNote ();
    scaleActualMinima[dimension] = Double.MAX_VALUE;
    scaleActualMaxima[dimension] = -Double.MAX_VALUE;
    double d = 0;
    double min = 0;
    double max = 0;
    for (i = beginIndex; i < endIndex; i++)
    {
      note = getEvent (i);
      if (Event.isNote (note))
      {
        d = note[dimension];
        min = scaleActualMinima[dimension];
        max = scaleActualMaxima[dimension];
        if (d <= min)
        {
          scaleActualMinima[dimension] = d;
        }
        if (d >= max)
        {
          scaleActualMaxima[dimension] = d;
        }
      }
    }
    double range = 0;
    double minimum = 0;
    double maximum = 0;
    minimum = scaleActualMinima[dimension];
    maximum = scaleActualMaxima[dimension];
    //      Avoid exceptions on too small a range.
    if (minimum == Double.NaN || maximum == Double.NaN)
    {
      range = 0;
    }
    else
    {
      range = maximum - minimum;
    }
    scaleActualRanges[dimension] = range;
  }
  public void setActualScaleToTarget ()
  {
    for (int dimension = 0; dimension < Event.HOMOGENEITY; dimension++)
    {
      setActualScaleToTarget (dimension);
    }
  }
  public void setActualScaleToTarget (int dimension, double minimum,
                                      double range)
  {
    boolean tempRescaleMinimum = rescaleMinima[dimension];
    boolean tempRescaleRange = this.rescaleRanges[dimension];
    rescaleMinima[dimension] = true;
    rescaleRanges[dimension] = true;
    scaleTargetMinima[dimension] = minimum;
    scaleTargetRanges[dimension] = range;
    setActualScaleToTarget (dimension);
    rescaleMinima[dimension] = tempRescaleMinimum;
    rescaleRanges[dimension] = tempRescaleRange;
  }
  public void setActualScaleToTarget (int dimension)
  {
    setActualScaleToTarget (0, size (), dimension);
  }
  public void setActualScaleToTarget (int beginIndex, int endIndex)
  {
    for (int dimension = 0; dimension < Event.HOMOGENEITY; dimension++)
    {
      setActualScaleToTarget (beginIndex, endIndex, dimension);
    }
  }
  public void setActualScaleToTarget (int beginIndex, int endIndex,
                                      int dimension)
  {
    try
    {
      findActualScale (beginIndex, endIndex, dimension);
      int i;
      double[] note = null;
      double[] rescale = Event.createNote ();
      double scale;
      double moveToTarget;
      double a;
      double t;
      double d;
      if (Math.abs (scaleActualRanges[dimension]) > Float.MIN_VALUE)
      {
        t = scaleTargetRanges[dimension];
        a = scaleActualRanges[dimension];
        d = t / a;
        rescale[dimension] = d;
      }
      else
      {
        rescale[dimension] = 1;
      }
      for (i = beginIndex; i < endIndex; i++)
      {
        note = getEvent (i);
        if (note != null)
        {
          if (Event.isNote (note))
          {
            double moveToOrigin = scaleActualMinima[dimension];
            if (rescaleRanges[dimension])
            {
              scale = rescale[dimension];
            }
            else
            {
              scale = 1.0;
            }
            if (rescaleMinima[dimension])
            {
              moveToTarget = scaleTargetMinima[dimension];
            }
            else
            {
              moveToTarget = moveToOrigin;
            }
            d = note[dimension];
            d = d - moveToOrigin;
            d = d * scale;
            d = d + moveToTarget;
            note[dimension] = d;
          }
        }
      }
      findActualScale (beginIndex, endIndex, dimension);
    }
    catch (Exception e)
    {
      e.printStackTrace ();
    }
  }
  public void setTargetScaleToActual ()
  {
    scaleTargetMinima = (double[]) scaleActualMinima.clone ();
    scaleTargetRanges = (double[]) scaleActualRanges.clone ();
  }
  public double[] getEvent (int index)
  {
    return (double[]) get (index);
  }
  public double[] addEvent (double[]event)
  {
    double[] clone = (double[]) event.clone ();
    add (clone);
    return clone;
  }
  public double[] addNote (double instrument, double time, double duration,
                           double key, double decibels, double phase,
                           double x, double y, double z, double mason)
  {
    double[] event =
      Event.createNote (instrument,
                        time, duration, key, decibels, phase, x,
                        y, z, mason);
    add (event);
    return event;
  }
  public void sort ()
  {
    Collections.sort (this, Event.timeComparator);
  }
  public void setSequence (Sequence sequence, boolean importNotesOnly)
  {
    System.out.println ("BEGAN Score.setSequence()...");
    System.out.println ("File        : " + filename);
    System.out.println ("Length      : " + sequence.getTickLength () +
                        " ticks");
    System.out.println ("Duration    : " + sequence.getMicrosecondLength () +
                        " microseconds");
    float fDivisionType = sequence.getDivisionType ();
    String strDivisionType = null;
    if (fDivisionType == Sequence.PPQ)
    {
      strDivisionType = "PPQ";
    }
    else if (fDivisionType == Sequence.SMPTE_24)
    {
      strDivisionType = "SMPTE, 24 frames per second";
    }
    else if (fDivisionType == Sequence.SMPTE_25)
    {
      strDivisionType = "SMPTE, 25 frames per second";
    }
    else if (fDivisionType == Sequence.SMPTE_30DROP)
    {
      strDivisionType = "SMPTE, 29.97 frames per second";
    }
    else if (fDivisionType == Sequence.SMPTE_30)
    {
      strDivisionType = "SMPTE, 30 frames per second";
    }
    System.out.println ("DivisionType: " + strDivisionType);
    String strResolutionType = null;
    if (sequence.getDivisionType () == Sequence.PPQ)
    {
      strResolutionType = " ticks per beat";
    }
    else
    {
      strResolutionType = " ticks per frame";
    }
    clear ();
    double microSecondsPerBeat = 500000;
    double ticksPerBeat = sequence.getResolution ();
    double microSecondsPerTick = microSecondsPerBeat / ticksPerBeat;
    double secondsPerTick = microSecondsPerTick / 1000000.0;
    System.out.println ("Resolution  : " + ticksPerBeat + strResolutionType);
    Track[]tracks = sequence.getTracks ();
    for (int i = 0; i < tracks.length; i++)
    {
      System.out.println ("BEGAN track " + i + "...");
      Track track = tracks[i];
      for (int j = 0, n = track.size (); j < n; j++)
      {
        MidiEvent midiEvent = track.get (j);
        double ticks = midiEvent.getTick ();
        MidiMessage midiMessage = midiEvent.getMessage ();
        int command = 0;
        double[] note = null;
        double[] onEvent = null;
        if (midiMessage instanceof ShortMessage)
        {
          ShortMessage shortMessage = (ShortMessage) midiMessage;
          command = shortMessage.getCommand ();
          double[] event = Event.fromShortMessage (shortMessage,
                                                   ticks *
                                                   secondsPerTick);
          switch (command)
          {
          case Event.CHANNEL_NOTE_OFF:
            for (int m = size () - 1; m >= 0; m--)
            {
              note = getEvent (m);
              onEvent = note;
              if (Event.isMatchingNoteOffEvent (onEvent, event))
              {
                onEvent[Event.DURATION] =
                  event[Event.TIME] - onEvent[Event.TIME];
                break;
              }
            }
            break;
          case Event.CHANNEL_PROGRAM_CHANGE:
            if (!importNotesOnly)
            {
              midiPrograms[shortMessage.getChannel ()] =
                shortMessage.getData1 ();
            }
            break;
          case Event.CHANNEL_NOTE_ON:
            note = addEvent (event);
            break;
          default:
            if (!importNotesOnly)
            {
              note = addEvent (event);
            }
            break;
          }
          //if(note != null)
          //{
          //  System.out.print(ScoreEvent.staticGetCommandDescription(command) + ": ");
          //  System.out.println(note.toString());
          //}
        }
        else if (midiMessage instanceof MetaMessage)
        {
          MetaMessage metaMessage = (MetaMessage) midiMessage;
          command = metaMessage.getType () + 0xff00;
          System.out.println (Event.getCommandDescription (command));
          switch (command)
          {
          case Event.META_TEMPO_CHANGE:
            byte[]data = metaMessage.getData ();
            microSecondsPerBeat = (data[0] << 16);
            microSecondsPerBeat += (data[1] << 8);
            microSecondsPerBeat += data[2];
            System.out.println ("Microseconds per beat: " +
                                microSecondsPerBeat);
            microSecondsPerTick = microSecondsPerBeat / ticksPerBeat;
            secondsPerTick = microSecondsPerTick / 1000000.0;
            break;
          }
        }
      }
      System.out.println ("ENDED track " + i + ".");
    }
    //  Get durations for NOTE ON events, and remove the NOTE OFF events.
    System.out.println ("ENDED Score.setSequence(): " + size () + " notes.");
  }
  public Sequence getSequence ()
  {
    System.out.println ("BEGAN Score.getSequence()...");
    Sequence sequence = null;
    try
    {
      int ticksPerQuarterNote = 384;
      double secondsPerQuarterNote = 60.0 / 120.0 * 4.0;
      int ticksPerSecond =
        (int) (ticksPerQuarterNote * secondsPerQuarterNote);
      System.out.println ("Ticks per second: " + ticksPerSecond);
      sequence = new Sequence (Sequence.PPQ, ticksPerQuarterNote);
      ArrayList events = new ArrayList ();
      double[] note = null;
      for (int i = 0, n = size (); i < n; i++)
      {
        note = getEvent (i);
        int command = (int) Math.round (Event.getMidiStatus (note));
        switch (command)
        {
        case Event.CHANNEL_NOTE_ON:
          if (conformPitchesToMasonNumbers)
          {
            double[] copy = MasonNumbers.conformToMasonNumber (note);

            events.add (Event.toNoteOn (copy, ticksPerSecond));
            events.add (Event.toNoteOff (copy, ticksPerSecond));
          }
          else
          {
            events.add (Event.toNoteOn (note, ticksPerSecond));
            events.add (Event.toNoteOff (note, ticksPerSecond));
          }
          break;
        default:
          events.add (Event.toShortEvent (note, ticksPerSecond));
          break;
        }
      }
      Collections.sort (events, Event.midiEventComparator);
      Track track = sequence.createTrack ();
      for (int k = 0; k < 16; k++)
      {
        ShortMessage shortMessage = new ShortMessage ();
        int status = Event.CHANNEL_PROGRAM_CHANGE | k;
        int data1 = (int) midiPrograms[k];
        shortMessage.setMessage (status, data1, 0);
        MidiEvent midiEvent = new MidiEvent (shortMessage, 0);
        track.add (midiEvent);
      }
      for (int j = 0, m = events.size (); j < m; j++)
      {
        track.add ((MidiEvent) events.get (j));
      }
    }
    catch (InvalidMidiDataException e)
    {
      e.printStackTrace ();
    }
    System.out.println ("ENDED Score.getSequence().");
    return sequence;
  }
  public void reset ()
  {
    sort ();
    pendingEventIndex = 0;
  }
  public boolean hasPendingEvents ()
  {
    return (pendingEventIndex < size ());
  }
  /**
  Returns the next current event, or null if there is none.
  */
  public double[] getCurrentEvent ()
  {
    double[] currentEvent = getEvent (pendingEventIndex);
    if (currentEvent[Event.TIME] > timebase.currentTime)
    {
      return null;
    }
    pendingEventIndex++;
    return currentEvent;
  }
  /**
  Adds the event and conforms all other events
  beginning at the same time or later,
  but within the duration of this event, to its Mason number.
  Adding events in this matter ensures that Mason number is
  purely a function of time.
  */
  public void addAndConformToMason (double[]event)
  {
    if (Event.getDuration (event) > 0.0 && Event.getDecibels (event) > 0.0)
    {
      add (event);
    }
    Collections.sort (this, Event.timeComparator);
    double mason = event[Event.MASON];
    double endTime = event[Event.TIME] + event[Event.DURATION];
    int startAt =
      Collections.binarySearch (this, event, Event.timeComparator);
    if (startAt < 0)
    {
      startAt = (-startAt + 1);
    }
    for (int i = startAt, n = size (); i < n; i++)
    {
      double[] eventToConform = getEvent (i);
      if (eventToConform[Event.TIME] > endTime)
      {
        return;
      }
      MasonNumbers.conformToMasonNumber (eventToConform, mason);
    }
  }
  public void temper (double tonesPerOctave)
  {
    double octave = 0;
    double[] note = null;
    for (int i = 0, n = size (); i < n; i++)
    {
      note = getEvent (i);
      octave = Conversions.temper (Event.getOctave (note),
                                   tonesPerOctave);
      Event.setOctave (note, octave);
    }
  }
  public double getTotalDurationSeconds ()
  {
    double totalDurationSeconds = 0;
    double endsAt = 0;
    Iterator iterator = iterator ();
    double[] note = null;
    while (iterator.hasNext ())
    {
      note = (double[]) iterator.next ();
      endsAt = Event.getTime (note) + Event.getDuration (note);
      if (endsAt > totalDurationSeconds)
      {
        totalDurationSeconds = endsAt;
      }
    }
    return totalDurationSeconds;
  }
  public boolean importMidifile (String midiFilename)
  {
    try
    {
      File file = new File (midiFilename);
      Sequence sequence = MidiSystem.getSequence (file);
      setSequence (sequence, importNotesOnly);
      return true;
    }
    catch (Exception x)
    {
      x.printStackTrace ();
      return false;
    }
  }
  public boolean exportMidifile (String midiFilename)
  {
    try
    {
      System.out.println ("BEGAN EXPORTING MIDIFILE " + midiFilename + "...");
      File file = new File (midiFilename);
      Sequence sequence = getSequence ();
      int[] midiFileTypes = MidiSystem.getMidiFileTypes (sequence);
      boolean written =
        MidiSystem.write (sequence, midiFileTypes[0], file) > 0;
      System.out.println ("ENDED EXPORTING MIDIFILE " + midiFilename + ".");
      return written;
    }
    catch (IOException x)
    {
      x.printStackTrace ();
      return false;
    }
  }
  public void setScore (double[][]score)
  {
    clear ();
    addScore (score);
  }
  public void addScore (double[][]score)
  {
    for (int i = 0; i < score.length; i++)
    {
      addEvent (score[i]);
    }
  }
  public double[][] getScore ()
  {
    int noteCount = size ();
    double[] note = null;
    double[][] score = new double[noteCount][];
    for (int i = 0; i < noteCount; i++)
    {
      score[i] = getEvent (i);
    }
    return score;
  }
  public Container getView ()
  {
    return new ScoreView (this);
  }
  protected String name = null;
  public String getName ()
  {
    if (name == null)
    {
      return String.valueOf (hashCode ());
    }
    return name;
  }
  public void setName (String newName)
  {
    String oldName = getName ();
    if (oldName != null)
    {
      if (oldName.compareTo (String.valueOf (hashCode ())) != 0)
      {
        Plugin.instances.remove (oldName);
      }
    }
    if (newName != null)
    {
      Plugin.instances.put (newName, this);
    }
  }
  /**
  The base class implementation uses serialization and deserialization
  to copy the object.
  */
  public Object clone ()
  {
    try
    {
      ByteArrayOutputStream byteArrayOutputStream =
        new ByteArrayOutputStream ();
      ObjectOutputStream objectOutputStream =
        new ObjectOutputStream (byteArrayOutputStream);
      objectOutputStream.writeObject (this);
      objectOutputStream.flush ();
      byteArrayOutputStream.close ();
      byte[] objectBuffer = byteArrayOutputStream.toByteArray ();
      ByteArrayInputStream byteArrayInputStream =
        new ByteArrayInputStream (objectBuffer);
      ObjectInputStream objectInputStream =
        new ObjectInputStream (byteArrayInputStream);
      Object myClone = objectInputStream.readObject ();
      return myClone;
    }
    catch (IOException x)
    {
      x.printStackTrace ();
    }
    catch (ClassNotFoundException x)
    {
      x.printStackTrace ();
    }
    return null;
  }
  public void serialize (OutputStream outputStream) throws IOException,
    IllegalAccessException
  {
    OutputStreamWriter outputStreamWriter =
      new OutputStreamWriter (outputStream);
    PrintWriter printWriter = new PrintWriter (outputStream);
    XMLSerializer xmlSerializer = new XMLSerializer ();
    xmlSerializer.write (printWriter, this);
    printWriter.flush ();
  }
  public Serializable deserialize (InputStream inputStream) throws
    StreamCorruptedException, IOException, ClassNotFoundException,
    InstantiationException, IllegalAccessException, NoSuchFieldException,
    InvocationTargetException
  {
    InputStreamReader inputStreamReader = new InputStreamReader (inputStream);
    BufferedReader bufferedReader = new BufferedReader (inputStreamReader);
    XMLSerializer xmlSerializer = new XMLSerializer ();
    return (Serializable) xmlSerializer.read (bufferedReader);
  }
  public void serialize (String filename) throws FileNotFoundException,
    IOException, IllegalAccessException
  {
    FileOutputStream fileOutputStream = new FileOutputStream (filename);
    serialize (fileOutputStream);
  }
  public Serializable deserialize (String filename) throws
    FileNotFoundException, ClassNotFoundException, IOException,
    NoSuchFieldException, IllegalAccessException, InstantiationException,
    InvocationTargetException
  {
    FileInputStream fileInputStream = new FileInputStream (filename);
    return deserialize (fileInputStream);
  }
  public String getRootFilename ()
  {
    return Global.stripExtension (getName ());
  }
  public void paint (Container c, Graphics g)
  {
    Cursor cursor = c.getCursor ();
    try
    {
      //      Do not paint if there are no notes.
      int n = size ();
      if (n < 1)
      {
        return;
      }
      //      Find the bounding hypercube of note space.
      sort ();
      findActualScale ();
      //      Do not paint if any of its to-be-rendered spans is not a floating point number.
      if ((scaleActualRanges[Event.TIME] < Float.MIN_VALUE)



          || (scaleActualRanges[Event.KEY] < Float.MIN_VALUE))
      {
        return;
      }
      int width = c.getSize ().width;
      int height = c.getSize ().height;
      Image image = c.createImage (width, height);
      int margin = 5;
      int leftMargin = c.getInsets().left + margin;
      int rightMargin = c.getInsets ().right + margin;
      int topMargin = c.getInsets ().top + margin;
      int bottomMargin = c.getInsets ().bottom + margin;
      int gridWidth = width - (leftMargin + rightMargin);
      int gridHeight = height - (topMargin + bottomMargin);
      //      Create a graphics context for it.
      Graphics graphics = image.getGraphics ();
      //      Corresponding ranges and grid things.
      double startMin = scaleActualMinima[Event.TIME];
      double startMax = this.getTotalDurationSeconds ();
      double startIncrement = 10;
      double octaveMin = Event.getOctave (scaleActualMinima);
      double octaveMax =
        octaveMin + Math.round (scaleActualRanges[Event.KEY] / 12.0);
      double octaveIncrement = 1;
      //      Scaling factors.
      double startMove = -startMin;
      double startScale = gridWidth / (startMax - startMin);
      double octaveMove = -octaveMin;
      double octaveScale = gridHeight / (octaveMax - octaveMin);
      double instrumentMove = -scaleActualMinima[Event.INSTRUMENT];
      double instrumentScale = scaleActualRanges[Event.INSTRUMENT];
      //      Avoid black notes if ranges == 0.
      if (instrumentScale == .0)
      {
        instrumentScale = 1;
        instrumentMove += .25;
      }
      else
      {
        instrumentScale = .8 / instrumentScale;
        instrumentMove += .2;
      }
      double decibelsMove = -scaleActualMinima[Event.DECIBELS];
      double decibelsScale = scaleActualRanges[Event.DECIBELS];
      if (decibelsScale == .0)
      {
        decibelsScale = 1;
        decibelsMove += .75;
      }
      else
      {
        decibelsScale = .8 / decibelsScale;
        decibelsMove += .2;
      }
      //      Everything we paint is just a line segment.
      int x1;
      int y1;
      int x2;
      int y2;
      graphics.setColor (Color.white);
      graphics.fillRect (0, 0, width, height);
      //      Draw a blue-green grid at intervals of 1 octave and 10 seconds.
      //      Vertical lines.
      graphics.setColor (new Color (0, 127, 127));
      graphics.drawRect (leftMargin, topMargin, gridWidth, gridHeight);
      double startSubscript;
      for (startSubscript = startMin; startSubscript <= startMax;
          startSubscript += startIncrement)
      {
        x1 = (int) ((startSubscript + startMove) * startScale);
        x2 = x1;
        if (startSubscript > 0 && (startSubscript % 60) == 0)
        {
          graphics.setColor (Color.magenta);
        }
        else
        {
          graphics.setColor (new Color (0, 127, 127));
        }
        graphics.drawLine (x1 + leftMargin,
                           0 + topMargin, x2 + leftMargin,
                           gridHeight + topMargin);
      }
      //      Horizontal lines.
      double octaveSubscript;
      for (octaveSubscript = octaveMin; octaveSubscript <= octaveMax;
          octaveSubscript += octaveIncrement)
      {
        //      Middle C is red.
        if (octaveSubscript > 7.5 && octaveSubscript < 8.5)
        {
          graphics.setColor (Color.red);
        }
        else
        {
          graphics.setColor (new Color (0, 127, 127));
        }
        y1 = (int) ((octaveSubscript + octaveMove) * octaveScale);
        y2 = y1;
        graphics.drawLine (leftMargin, gridHeight - y1 + topMargin,
                           gridWidth + leftMargin,
                           gridHeight - y1 + topMargin);
      }
      //      Draw the notes themselves.
      double[] note = null;
      //      Instrument is mapped onto hue, decibels onto brightness.
      //      No note should be too white of hue or too bright.
      //      Try to compensate for rounding errors when displaying
      //      already tempered scores as tempered.
      double temperamentRound = (1 / tonesPerOctave) / 2;
      double time;
      double end;
      double instrument;
      double octave;
      double decibels;
      double pan;
      double phase;
      float hue;
      float brightness;
      int i;
      double[] note_ = null;
      for (i = 0; i < n; ++i)
      {
        note_ = getEvent (i);
        {
          if (conformPitchesToMasonNumbers)
          {
            note = MasonNumbers.conformToMasonNumber (note_);
          }
          else
          {
            note = note_;
          }
          time = note[Event.TIME];
          end = time + note[Event.DURATION];
          octave = Event.getOctave (note);
          instrument = note[Event.INSTRUMENT];
          decibels = note[Event.DECIBELS];
          x1 = (int) ((time + startMove) * startScale);
          x2 = (int) ((end + startMove) * startScale);
          if (useEqualTemperament)
          {
            octave = Conversions.temper (octave, tonesPerOctave);
          }
          y1 = (int) ((octave + octaveMove) * octaveScale);
          y2 = y1;
          //      Round instrument down to nearest integer as Csound does.
          hue =
            (float) ((((int) instrument) + instrumentMove) *
                     instrumentScale);
          brightness =
            (float) ((decibels + decibelsMove) * decibelsScale);
          graphics.setColor (Color.
                             getHSBColor (hue,
                                          (float) 1.0, brightness));
          if (x1 == x2)
          {
            ++x2;
          }
          graphics.drawLine (x1 + leftMargin,
                             gridHeight - y1 + topMargin,
                             x2 + leftMargin,
                             gridHeight - y2 + topMargin);
        }
      }
      //      Copy the image buffer onto the actual graphics screen.
      boolean returnValue = g.drawImage (image, 0, 0, Color.black, c);
    }
    catch (Exception e)
    {
      e.printStackTrace ();
    }
    c.setCursor (cursor);
  }
  public void setFilename (String filename)
  {
    int index = filename.lastIndexOf (".");
    if (index != -1)
    {
      this.filename = filename.substring (0, index) + ".scr";
    }
    else
    {
      this.filename = filename + ".scr";
    }
  }
  public String getFilename ()
  {
    return filename;
  }
  public void openView ()
  {
    Container view = getView ();
    JFrame jframe = new JFrame (getClass ().getName ());
    jframe.getContentPane ().add (view);
    jframe.setBounds (50, 50, 800, 600);
    jframe.setVisible (true);
  }
   /**
* Permits the repetitive addition of copies of a cell,
* or of transformed copies of a cell, to this score.
* The position parameter is a "cursor"
* in the form of a local transformation of coordinate system
* that moves the cell to a new position.
* The increment parameter is a transformation,
    * such as moving forward in time by the duration of the cell,
* that is applied to the position for each addition.
* The offset parameter is an additional transformation,
* such as a transposition of pitch, that, if not null,
* is applied after the cell is added at the current position.
* The Mason number parameter, if not null,
* is applied to the pitches of the resulting cell.
* Normally, position is set to zero, increment is set to some
* value, and add is then called repeatedly with one or more cells.
*/
  public void add (double[][]position, double[][]increment, double[][]offset,
                   Double Mason, Score cell)
  {
    //      Applies the offset to the position?
    double[][] offsetPosition = null;
    if (offset == null)
    {
      offsetPosition = position;
    }
    else
    {
      offsetPosition = Matrix.times (position, offset);
    }
    //      Adds the cell at the final position.
    double[] event = null;
    for (int i = 0, n = cell.size (); i < n; i++)
    {
      event = Matrix.times (offsetPosition, cell.getEvent (i));
      //      Conforms to the specified Mason number?
      if (Mason != null)
      {
        MasonNumbers.conformToMasonNumber (event, Mason.doubleValue ());
      }
      add (event);
    }
    //      Advances the position by the increment.
    Matrix.times (position, Matrix.copy (position), increment);
  }
    /**
Conforms the entire score to one Mason number.
*/
  public void conformToMasonNumber (double mason)
  {
    MasonNumbers.conformScoreToMasonNumber (mason, this);
  }
  /**
  Quantizes the dimension.
  */
  public void quantize (int dimension, double modulus)
  {
    for (int i = 0, n = size (); i < n; i++)
    {
      double[] event = getEvent (i);
      double value;
      if (Event.isNote (event))
      {
        value = event[dimension];
        value = value / modulus;
        value = Math.rint (value);
        value = value * modulus;
        if (value == 0.0)
        {
          value = modulus;
        }
        event[dimension] = value;
      }
    }
  }
  public void transform (double[][]transformation)
  {
    for (int i = 0, n = size (); i < n; i++)
    {
      double[] event = getEvent (i);
      double[] clone = (double[]) event.clone ();
      Matrix.times (event, transformation, clone);
    }
  }
  public void append (Score score, double transpose, double mason)
  {
    double appendAt = getTotalDurationSeconds ();
    Iterator iterator = score.iterator ();
    double[] event;
    while (iterator.hasNext ())
    {
      event = (double[]) iterator.next ();
      event = (double[]) event.clone ();
      event[Event.TIME] += appendAt;
      event[Event.KEY] += transpose;
      if (mason > 0)
      {
        MasonNumbers.conformToMasonNumber (event, mason);
      }
      add (event);
    }
  }
  public void removeRange (int from, int to)
  {
    super.removeRange (from, to);
  }
  public class ScoreTransferable implements Transferable
  {
    public Object getTransferData(DataFlavor dataFlavor)
    {
      try
      {
        String midiFilename = getRootFilename() + ".mid";
        File file = new File (midiFilename);
        Sequence sequence = getSequence ();
        int[] midiFileTypes = MidiSystem.getMidiFileTypes (sequence);
        boolean written =
          MidiSystem.write (sequence, midiFileTypes[0], file) > 0;
        FileInputStream fileInputStream = new FileInputStream(file);
        return fileInputStream;
      }
      catch(Exception x)
      {
        x.printStackTrace();
      }
      return null;
    }
    public DataFlavor[] getTransferDataFlavors()
    {
      try
      {
        DataFlavor[] dataFlavors = new DataFlavor[1];
        dataFlavors[0] = new DataFlavor("audio/mid");
        return dataFlavors;
      }
      catch(Exception x)
      {
        x.printStackTrace();
      }
      return null;
    }
    public boolean isDataFlavorSupported(DataFlavor flavor)
    {
      return flavor.getMimeType().equals("audio/mid");
    }
  }
  public void copyMidiToClipboard()
  {
    try
    {
      System.out.println ("BEGAN COPYING MIDIFILE TO CLIPBOARD...");
      //  Mime-type is audio/mid
      Transferable transferable = clipboard.getContents(this);
      if(transferable == null)
      {
        return;
      }
      DataFlavor[] dataFlavors = transferable.getTransferDataFlavors();
      for(int i = 0; i < dataFlavors.length; i++)
      {
        System.out.println(dataFlavors[i].getMimeType());
      }
      clipboard.setContents(new ScoreTransferable(), this);
    }
    catch (Exception x)
    {
      x.printStackTrace ();
    }
    System.out.println ("ENDED COPYING MIDIFILE TO CLIPBOARD...");
  }
  public void lostOwnership(Clipboard clipboard, Transferable contents)
  {
    System.out.println("Lost ownership of " + contents);
  }
}
