package Silence.Score;
import Silence.PluginInterface;
import Silence.Mathematics.*;
import java.awt.*;
import java.io.*;
/**
A directed acyclic graph of NodeInterface objects, or music graph,
can geometrically model any work of music.
Each Node is associated with a local transformation of coordinate system.
Any Node can contain a collection of child Nodes, and so on, hierarchically.
Sound can be directly modeled by using one Node per grain of sound.
@author Copyright (C) 1998, 2000 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public interface NodeInterface extends PluginInterface,
  javax.swing.tree.TreeNode
{
	/**
	If this is a transformation node,
	returns a copy of the elements in this,
	that is, the row-major homogeneous matrix representing
	an affine transformation;
	otherwise, returns identity.
	*/ public double[][] getLocalTransformation ();
	/**
	If this is a transformation node,
	sets the elements in this to a clone of the matrix;
	otherwise, does nothing.
	*/
  public void setLocalTransformation (double[][]matrix);
	/**
	Called by IMMLManager on the root node to traverse the music graph
	for the purpose of producing or transforming notes.
	In Group, the code for this is as follows:
	<pre>
	//  Record the number of notes already in the score
	//  before traversing any child nodes of this.
	int preTraversalCount = score.getChildNodeCount();
	//  The local transformation of coordinate systems
	//  is identity for non-transformation nodes,
	//  or some other affine transformation for transformation nodes.
	double[][] compositeTransformation = Matrix.times(parentTransformation, getLocalTransformation());
	//  Iterate over the immediate child nodes of this...
	for(int i = 0, n = getChildNodeCount(); i < n; i++)
	{
		//  ...calling traverseMusicGraph on each one.
		//  This has the effect of performing a recursive,
		//  depth-first traversal of the music graph.
		((NodeInterface) getChildNode(i)).traverseMusicGraph(compositeTransformation, score);
	}
	//  Record the number of notes in the score
	//  after traversing the child nodes.
	//  This number will have increased by the number of new notes
	//  produced by all child nodes of this.
	int postTraversalCount = score.getChildNodeCount();
	//  Finally, either produce new notes, or transform all notes
	//  that were produced by the child nodes of this.
	return produceOrTransformNotes(compositeTransformation, score, preTraversalCount, postTraversalCount);
	</pre>
	It is the produceOrTransformNotes function that does the work of transforming or producing actual notes.
	*/
  public double[][] traverseMusicGraph (double[][]parentTransformation,
					Score score);
	/**
    Traverse the music graph with identity as the original transformation.
    */
  public double[][] traverseMusicGraph (Score score);
	/**
	Called by traverseChildNotes to perform the transformation or production of actual notes.
	For producing notes: notes are generated, cloned to ensure that their value is not later changed,
	multiplied by compositeTransform to place them properly in music space, and then added to the score.
	For transforming notes: notes in the score beginning with preTraversalCount and going
	up to but not including postTraversalCount are gotten out of the score,
	multiplied by compositeTransform to place them properly in music space,
	and otherwise transformed by this. They do not need to be returned to the score because
	they were retrieved by reference.
	*/
  public double[][] produceOrTransformNotes (double[][]compositeTransform,
					     Score score,
					     int preTraversalCount,
					     int postTraversalCount);
  /**
   * Deep copy by value.
   */
  public NodeInterface copy();
  /**
   * Not Java classname,
   * but "template" instance name.
   */
  public void setClassname(String name);
  /**
   * Not Java classname,
   * but "template" instance name.
   */
  public String getClassname();
	/**
	Sets the parent node of this.
	*/
  public void setParent (NodeInterface parent);
	/**
	Replaces the child node in this at the indicated index with a new node,
	and calls child.setParent(this).
	*/
  public boolean setChildAt (int index, NodeInterface child);
	/**
	Inserts a child node in this at the indicated index,
	moving any other children at that index up one,
	and calls child.setParent(this).
	*/
  public void insertChildAt (int index, NodeInterface child);
	/**
	Appends a child node to this,
	and calls child.setParent(this).
	*/
  public void addChild (NodeInterface child);
	/**
	Removes the child node at the indicated index.
	*/
  public boolean removeChildAt (int index);
	/**
	Removes the child node.
	*/
  public boolean removeChild (NodeInterface node);
	/**
	Removes all child nodes from this.
	*/
  public void clear ();
	/**
	Returns the global score, if this has one.
	The global score is the one that contains
	and synthesizes the notes produced by the music graph.
	*/
  public Score getGlobalScore ();
	/**
	Sets the global score, if this can have one.
	The global score is the one that contains
	and synthesizes the notes produced by the music graph.
	*/
  public void setGlobalScore (Score score);
	/**
	Returns the local score, if this has one.
	The local score can be used, for example, to contain
	notes generated by this node's generator or translator.
	*/
  public Score getLocalScore ();
	/**
	Sets the local score, if this can have one.
	The local score can be used, for example, to contain
	notes generated by this node's generator or translator.
	*/
  public void setLocalScore (Score score);
	/**
   	Returns a view for displaying and editing the state of this Node,
    or null if there is no view.
    The view is a panel of some sort.
    */
  public Container getView ();
}
