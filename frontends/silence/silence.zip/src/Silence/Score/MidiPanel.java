package Silence.Score;
import Silence.Global;
import java.util.*;
import java.awt.*;
import java.io.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.table.*;
import javax.sound.midi.*;
import java.util.ArrayList;
/**
Plays a Score using the default JavaSound MIDI synthesizer.
Allows the user to select MIDI programs for each channel by name.
Copyright (C) 1999 by Michael Gogins. All rights reserved.
This file is licensed under the terms of the GNU General Public License.
@author Copyright (C) 1999, 2000 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class MidiPanel extends JPanel
{
  public static void main (String args[])
  {
    JFrame frame = new JFrame ();
    frame.getContentPane ().add (new MidiPanel ());
    frame.setBounds (100, 100, 400, 400);
    frame.setVisible (true);
  }
  public Score score = null;
  public static javax.sound.midi.Synthesizer synthesizer = null;
  public static MidiDevice outputMidiDevice = null;
  public static Sequencer sequencer = null;
  public static Soundbank soundbank = null;
  public static javax.sound.midi.Instrument[] instruments = null;
  public static ArrayList names = new ArrayList ();
  public class MidiDeviceModel extends DefaultComboBoxModel
  {
    MidiDeviceModel()
    {
      open();
      MidiDevice.Info[] infos = MidiSystem.getMidiDeviceInfo();
      for(int i = 0; i < infos.length; i++)
      {
        addElement(infos[i]);
      }
    }
  }
  public class MidiProgramModel extends AbstractTableModel
  {
    public JComboBox comboBox = null;
    public MidiProgramModel()
    {
      open ();
      instruments = synthesizer.getAvailableInstruments ();
      names.clear ();
      for (int j = 0; j < instruments.length; j++)
      {
        String name = instruments[j].getName ();
        names.add (name);
      }
      comboBox = new JComboBox (names.toArray ());
      //close();
    }
    public boolean isCellEditable (int rowIndex, int columnIndex)
    {
      if (rowIndex >= 0 && rowIndex <= 15 && columnIndex == 1)
      {
        return true;
      }
      return false;
    }
    public int getRowCount ()
    {
      return 16;
    }
    public int getColumnCount ()
    {
      return 2;
    }
    public String getColumnName (int column)
    {
      if (column == 0)
      {
        return "MIDI channel";
      }
      else if (column == 1)
      {
        return "Program name";
      }
      return null;
    }
    public Object getValueAt (int row, int column)
    {
      if (column == 0)
      {
        return "Channel " + (row + 1);
      }
      else if (column == 1)
      {
        return names.get ((int) score.midiPrograms[row]);
      }
      return null;
    }
    public void setValueAt (Object object, int row, int column)
    {
      if (column == 1)
      {
        score.midiPrograms[row] = (int) names.indexOf ((String) object);
      }
    }
  }
  MidiDeviceModel midiDeviceModel = null;
  MidiProgramModel midiProgramModel = null;
  JScrollPane programTableScrollPane = new JScrollPane ();
  JToolBar midiToolBar = new JToolBar ();
  BorderLayout borderLayout1 = new BorderLayout ();
  JButton playButton = new JButton ();
  JButton exportButton = new JButton ();
  JButton importButton = new JButton ();
  JTable programTable = new JTable ();
  boolean isPlaying = false;
  JCheckBox importNotesOnlyCheckBox = new JCheckBox ();
  JLabel spacer = new JLabel ();
  JLabel spacerLabel = new JLabel ();
  JLabel spacerLabel1 = new JLabel ();
  JButton copyButton = new JButton ();
  JLabel midiOutLabel = new JLabel();
  JComboBox midiOutComboBox = new JComboBox();
  public MidiPanel (Score score)
  {
    System.out.println ("BEGAN MidiPanel()...");
    try
    {
      setModel (score);
      jbInit ();
      updateView ();
    }
    catch (Exception ex)
    {
      ex.printStackTrace ();
    }
    System.out.println ("ENDED MidiPanel().");
  }
  public MidiPanel ()
  {
    this (new Score ());
  }
  public void clear ()
  {
    for (int i = 0; i < score.midiPrograms.length; i++)
    {
      score.midiPrograms[i] = 0;
    }
  }
  private void jbInit () throws Exception
  {
    this.setLayout (borderLayout1);
    programTableScrollPane.setBorder (BorderFactory.createLoweredBevelBorder ());
    playButton.setBorder (BorderFactory.createEtchedBorder ());
    playButton.setMaximumSize (new Dimension (55, 21));
    playButton.setMinimumSize (new Dimension (55, 21));
    playButton.setPreferredSize (new Dimension (55, 21));
    playButton.setActionCommand ("Play");
    Font font = playButton.getFont ();
    importButton.setFont (new java.awt.Font ("Dialog", 1, 12));
    exportButton.setFont (new java.awt.Font ("Dialog", 1, 12));
    playButton.setFont (new java.awt.Font ("Dialog", 1, 12));
    playButton.setText ("  Play  ");
    playButton.addActionListener (new MidiPanel_playButton_actionAdapter (this));
    midiToolBar.setFloatable (false);
    exportButton.setBorder (BorderFactory.createEtchedBorder ());
    exportButton.setMaximumSize (new Dimension (84, 21));
    exportButton.setMinimumSize (new Dimension (55, 21));
    exportButton.setPreferredSize (new Dimension (84, 21));
    exportButton.setText (" Export...  ");
    exportButton.addActionListener (new MidiPanel_exportButton_actionAdapter (this));
    importButton.setBorder (BorderFactory.createEtchedBorder ());
    importButton.setMaximumSize (new Dimension (84, 21));
    importButton.setMinimumSize (new Dimension (55, 21));
    importButton.setPreferredSize (new Dimension (84, 21));
    importButton.setText ("  Import...  ");
    importButton.addActionListener (new MidiPanel_importButton_actionAdapter (this));
    importNotesOnlyCheckBox.setPreferredSize (new Dimension (128, 21));
    importNotesOnlyCheckBox.setMaximumSize (new Dimension (128, 21));
    importNotesOnlyCheckBox.setMinimumSize (new Dimension (84, 21));
    importNotesOnlyCheckBox.setText ("Import notes only");
    importNotesOnlyCheckBox.setFont (new java.awt.Font ("Dialog", 1, 12));
    importNotesOnlyCheckBox.addActionListener (new MidiPanel_importNotesOnlyCheckBox_actionAdapter (this));
    spacer.setText ("   ");
    this.setBorder (BorderFactory.createLoweredBevelBorder ());
    spacerLabel.setText ("    ");
    spacerLabel1.setText ("    ");
    copyButton.setText("Copy");
    copyButton.addActionListener(new java.awt.event.ActionListener()
                                 {
        public void actionPerformed(ActionEvent e)
        {
          copyButton_actionPerformed(e);
        }
      }
    );
    copyButton.setPreferredSize(new Dimension (84, 21));
    copyButton.setMinimumSize(new Dimension (55, 21));
    copyButton.setMaximumSize(new Dimension (84, 21));
    copyButton.setBorder(BorderFactory.createEtchedBorder ());
    copyButton.setFont(new java.awt.Font ("Dialog", 1, 12));
    midiOutLabel.setText("  MIDI out ");
    midiOutComboBox.addActionListener(new java.awt.event.ActionListener()
                                      {
        public void actionPerformed(ActionEvent e)
        {
          midiOutComboBox_actionPerformed(e);
        }
      }
    );
    this.add (midiToolBar, BorderLayout.NORTH);
    midiToolBar.add (playButton, null);
    midiToolBar.add(midiOutLabel, null);
    midiToolBar.add(midiOutComboBox, null);
    midiToolBar.add (importButton, null);
    midiToolBar.add (spacer, null);
    midiToolBar.add (importNotesOnlyCheckBox, null);
    midiToolBar.add (spacerLabel, null);
    midiToolBar.add (exportButton, null);
    midiToolBar.add(copyButton, null);
    midiToolBar.add (spacerLabel1, null);
    this.add (programTableScrollPane, BorderLayout.CENTER);
    programTableScrollPane.getViewport ().add (programTable);
    midiDeviceModel = new MidiDeviceModel();
    midiOutComboBox.setModel(midiDeviceModel);
    midiProgramModel = new MidiProgramModel ();
    programTable.setModel (midiProgramModel);
    TableColumn tableColumn = programTable.getColumn ("Program name");
    tableColumn.setCellEditor (new DefaultCellEditor (midiProgramModel.comboBox));
  }
  void playButton_actionPerformed (ActionEvent e)
  {
    try
    {
      if (isPlaying)
      {
        isPlaying = false;
        close ();
      }
      else
      {
        isPlaying = true;
        open();
        sequencer.start();
      }
    }
    catch (Exception x)
    {
      x.printStackTrace ();
    }
  }
  void stopButton_actionPerformed (ActionEvent e)
  {
    close ();
  }
  /**
   * Imports a Format 0 or Format 1 MIDI file using {@link Silence.Score.setSequence Silence.Score.setSequence}.
   */ public boolean importMidifile (String filename)
  {
    try
    {
      score.importNotesOnly = importNotesOnlyCheckBox.isSelected ();
      return score.importMidifile (filename);
    }
    catch (Exception x)
    {
      x.printStackTrace ();
      return false;
    }
  }
  /**
   * Exports a Format 0 MIDI file using {@link Silence.Score.setSequence Silence.Score.setSequence}.
   */
  public boolean exportMidifile (String filename)
  {
    return score.exportMidifile (filename);
  }
  void importButton_actionPerformed (ActionEvent e)
  {
    JFileChooser fileDialog = Global.createFileDialog ("Open");
    fileDialog.addChoosableFileFilter (Global.createFileFilter("Midi files",
                                                               ".mid"));
    if (fileDialog.showOpenDialog (null) == fileDialog.APPROVE_OPTION)
    {
      Cursor cursor = fileDialog.getCursor ();
      fileDialog.setCursor (Cursor.getPredefinedCursor (Cursor.WAIT_CURSOR));
      File file = fileDialog.getSelectedFile ();
      String filename = file.getAbsolutePath ();
      importMidifile (filename);
      fileDialog.setCursor (cursor);
    }
  }
  void exportButton_actionPerformed (ActionEvent e)
  {
    JFileChooser fileDialog = Global.createFileDialog ("Open");
    fileDialog.addChoosableFileFilter (Global.createFileFilter("Midi files",
                                                               ".mid"));
    if (fileDialog.showSaveDialog (null) == fileDialog.APPROVE_OPTION)
    {
      Cursor cursor = fileDialog.getCursor ();
      fileDialog.setCursor (Cursor.getPredefinedCursor (Cursor.WAIT_CURSOR));
      File file = fileDialog.getSelectedFile ();
      String filename = file.getAbsolutePath ();
      exportMidifile (filename);
      fileDialog.setCursor (cursor);
    }
  }
  void importNotesOnlyCheckBox_actionPerformed (ActionEvent e)
  {
    score.importNotesOnly = importNotesOnlyCheckBox.isSelected ();
  }
  public void updateView ()
  {
    importNotesOnlyCheckBox.setSelected (score.importNotesOnly);
  }
  public void setModel (Score score)
  {
    this.score = score;
  }
  public synchronized void open ()
  {
    System.out.println ("BEGAN MidiPanel.open()...");
    try
    {
      if(synthesizer == null)
      {
        synthesizer = MidiSystem.getSynthesizer();
        System.out.println("synthesizer = " + synthesizer);
        sequencer = MidiSystem.getSequencer();
        System.out.println("sequencer = " + sequencer);
        Transmitter transmitter = sequencer.getTransmitter();
        System.out.println("transmitter = " + transmitter);
        MidiDevice.Info info = (MidiDevice.Info) midiOutComboBox.getSelectedItem();
        System.out.println("Selected output = " + info);
        MidiDevice outputMidiDevice = null;
        if(info == null)
        {
          outputMidiDevice = synthesizer;
        }
        else
        {
          outputMidiDevice = MidiSystem.getMidiDevice(info);
        }
        System.out.println("outputMidiDevice = " + outputMidiDevice);
        if(synthesizer == outputMidiDevice)
        {
          if (!synthesizer.isOpen ())
          {
            synthesizer.open ();
          }
          if (soundbank == null)
          {
            soundbank = synthesizer.getDefaultSoundbank ();
          }
          if (instruments == null)
          {
            instruments = soundbank.getInstruments ();
            synthesizer.loadInstrument (instruments[0]);
          }
        }
        else
        {
          synthesizer.close();
        }
        if(!outputMidiDevice.isOpen())
        {
          outputMidiDevice.open();
        }
        Receiver receiver = outputMidiDevice.getReceiver();
        System.out.println("receiver = " + receiver);
        transmitter.setReceiver(receiver);
        if (!sequencer.isOpen ())
        {
          sequencer.open ();
        }
        Sequence sequence = score.getSequence ();
        System.out.println("sequence = " + sequence);
        sequencer.setSequence(sequence);
      }
    }
    catch (Exception x)
    {
      x.printStackTrace ();
    }
    System.out.println ("ENDED MidiPanel.open().");
  }
  public synchronized void close ()
  {
    System.out.println ("BEGAN MidiPanel.close()...");
    if (synthesizer != null)
    {
      try
      {
        synthesizer.close ();
        synthesizer = null;
      }
      catch (Exception x)
      {
      }
      try
      {
        sequencer.close ();
        sequencer = null;
      }
      catch (Exception x)
      {
      }
    }
    if (sequencer != null)
    {
      try
      {
        sequencer.close ();
        sequencer = null;
      }
      catch (Exception x)
      {
      }
    }
    soundbank = null;
    instruments = null;
    System.out.println ("ENDED MidiPanel.close().");
  }
  public void finalize ()
  {
    close ();
  }
  void copyButton_actionPerformed(ActionEvent e)
  {
    score.copyMidiToClipboard();
  }
  void midiOutComboBox_actionPerformed(ActionEvent e)
  {
    try
    {
    }
    catch(Exception x)
    {
      x.printStackTrace();
    }
  }
}
class MidiPanel_playButton_actionAdapter implements java.awt.event.ActionListener
  {
  MidiPanel adaptee;
  MidiPanel_playButton_actionAdapter (MidiPanel adaptee)
  {
    this.adaptee = adaptee;
  }
  public void actionPerformed (ActionEvent e)
  {
    adaptee.playButton_actionPerformed (e);
  }
}
class MidiPanel_stopButton_actionAdapter implements java.awt.event.ActionListener
  {
  MidiPanel adaptee;
  MidiPanel_stopButton_actionAdapter (MidiPanel adaptee)
  {
    this.adaptee = adaptee;
  }
  public void actionPerformed (ActionEvent e)
  {
    adaptee.stopButton_actionPerformed (e);
  }
}
class MidiPanel_importButton_actionAdapter implements java.awt.event.ActionListener
  {
  MidiPanel adaptee;
  MidiPanel_importButton_actionAdapter (MidiPanel adaptee)
  {
    this.adaptee = adaptee;
  }
  public void actionPerformed (ActionEvent e)
  {
    adaptee.importButton_actionPerformed (e);
  }
}
class MidiPanel_exportButton_actionAdapter implements java.awt.event.ActionListener
  {
  MidiPanel adaptee;
  MidiPanel_exportButton_actionAdapter (MidiPanel adaptee)
  {
    this.adaptee = adaptee;
  }
  public void actionPerformed (ActionEvent e)
  {
    adaptee.exportButton_actionPerformed (e);
  }
}
class MidiPanel_importNotesOnlyCheckBox_actionAdapter implements java.awt.event.ActionListener
  {
  MidiPanel adaptee;
  MidiPanel_importNotesOnlyCheckBox_actionAdapter (MidiPanel adaptee)
  {
    this.adaptee = adaptee;
  }
  public void actionPerformed (ActionEvent e)
  {
    adaptee.importNotesOnlyCheckBox_actionPerformed (e);
  }
}
