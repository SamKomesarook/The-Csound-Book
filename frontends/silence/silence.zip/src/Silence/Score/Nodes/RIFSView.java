package Silence.Score.Nodes;
import Silence.Global;
import Silence.MatrixEditor;
import Silence.Score.Score;
import Silence.Score.ScoreView;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import java.awt.*;
import java.io.File;
import java.awt.image.*;
import javax.swing.*;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
/**
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class RIFSView extends javax.swing.JInternalFrame
  {
  Frame frame = null;
  RIFS rifs = null;
  int currentMatrixIndex;
  MemoryImageSource memoryImageSource = null;
  int[] pixels = null;
  Image image = null;
  ScoreView scoreView = null;
  public RIFSView (RIFS r)
  {
    this ("Silence RIFS Node");
    rifs = r;
    scoreView = (ScoreView) rifs.getLocalScore ().getView ();
    scoreView.setVisible (true);
    tabPanel.add ("scoreViewTab", scoreView);
    currentMatrixIndex = 0;
    updateView ();
  }
  public void generate ()
  {
    pixels = new int[rifs.timeBinCount * rifs.octaveBinCount];

    memoryImageSource =
      new MemoryImageSource (rifs.timeBinCount,
                             rifs.octaveBinCount, pixels,
                             0, rifs.timeBinCount);
    memoryImageSource.setAnimated (true);
    image = displayPanel.createImage (memoryImageSource);
    Generator generator = new Generator ();
    generator.start ();
  }
  class Generator extends Thread
  {
    public void run ()
    {
      System.out.println ("Began iterating in RIFSView$Generator.run()...");
      rifs.prepareForIteration ();
      for (rifs.keepIterating = true; rifs.keepIterating;)
      {
        if (!rifs.iterate ())
        {
          rifs.translate ();
          return;
        }
        if (rifs.iterationCount % 1000 == 0)
        {
          updateView ();
          int color;
          //  Hue is instrument.
          float hue;
          float maximumHue = 0;
          //  Saturation is constant.
          float saturation = (float) 1.0;
          //  Brightness is amplitude, normalized.
          float brightness;
          float maximumBrightness = 0;
          for (int i = 0; i < rifs.timeBinCount; i++)
          {
            for (int j = 0; j < rifs.octaveBinCount; j++)
            {
              hue = (float) 0.25;
              brightness = 0;
              for (int k = 0; k < rifs.instrumentBinCount; k++)
              {
                hue += rifs.measure[i][j][k] * k;
                brightness += rifs.measure[i][j][k];
              }
              if (hue > maximumHue)
              {
                maximumHue = hue;
              }
              if (brightness > maximumBrightness)
              {
                maximumBrightness = brightness;
              }
            }
          }
          for (int i = 0; i < rifs.timeBinCount; i++)
          {
            for (int j = 0; j < rifs.octaveBinCount; j++)
            {
              color = 0;
              hue = (float) 0.25;
              brightness = 0;
              for (int k = 0; k < rifs.instrumentBinCount; k++)
              {
                hue += rifs.measure[i][j][k] * k;
                brightness += rifs.measure[i][j][k];
              }
              hue = hue / maximumHue;
              brightness = brightness / maximumBrightness;
              color = Color.HSBtoRGB (hue,
                                      saturation, brightness);
              pixels[j * rifs.timeBinCount + i] = color;
            }
          }
          updateView ();
        }
      }
      System.out.println ("Ended iterating in RIFSView$Generator.run().");
    }
  }
  public void paint (Graphics g)
  {
    super.paint (g);
    if (memoryImageSource == null || pixels == null
        || !displayPanel.isVisible ())
    {
      return;
    }
    Graphics graphics = displayPanel.getGraphics ();
    Dimension dimension = displayPanel.getSize ();
    graphics.drawImage (image, 0, 0, dimension.width - 1,
                        dimension.height - 1, 0, rifs.octaveBinCount - 1,
                        rifs.timeBinCount - 1, 0, displayPanel);
  }
  public synchronized void updateView ()
  {
    if (currentMatrixIndex >= rifs.hutchinsonOperator.size ())
    {
      currentMatrixIndex = rifs.hutchinsonOperator.size () - 1;
    }
    if (currentMatrixIndex < 0)
    {
      currentMatrixIndex = 0;
    }
    nameField.setText (rifs.getName ());
    autoRescaleCheckbox.setSelected (rifs.getLocalScore ().autoRescale);
    renderAsSoundfileCheckbox.setSelected (rifs.renderAsSound);
    countLabel.setText (String.valueOf (rifs.hutchinsonOperatorMatrixCount));
    indexLabel.setText (String.valueOf (currentMatrixIndex + 1));
    totalDurationSecondsField.
      setText (String.valueOf (rifs.totalDurationSeconds));
    timeBinCountField.setText (String.valueOf (rifs.timeBinCount));
    octaveBinCountField.setText (String.valueOf (rifs.octaveBinCount));
    instrumentBinCountField.setText (String.
                                     valueOf (rifs.instrumentBinCount));
    voiceCountPerInstrumentField.setText (String.valueOf (rifs.voiceCount));
    tonesPerOctaveField.
      setText (String.valueOf (rifs.getLocalScore ().tonesPerOctave));
    secondsToIterateField.setText (String.valueOf (rifs.secondsToIterate));
    secondsToDateField.setText (String.valueOf (rifs.secondsToDate));
    iterationCountField.setText (String.valueOf (rifs.iterationCount));
    if (rifs.hutchinsonOperator.size () > 0)
    {
      double[][] currentMatrix =
        (double[][]) rifs.hutchinsonOperator.get (currentMatrixIndex);
      String[]rowLabels =
        {
        "Time", "Octave", "Instrument", "Homogeneity"
      };
      String[]columnLabels =
        {
        "Dimension", "Time", "Octave", "Instrument", "Move"
      };
      hutchinsonView.create (currentMatrix, columnLabels, rowLabels);
    }
    String[]columnLabels = new String[rifs.markovOperator.length + 1];
    columnLabels[0] = "Dimension";
    String[]rowLabels = new String[rifs.markovOperator.length];
    for (int i = 0; i < rifs.markovOperator.length; i++)
    {
      rowLabels[i] = "If " + String.valueOf (i);
      columnLabels[i + 1] = "P of " + String.valueOf (i);
    }
    markovView.create (rifs.markovOperator, columnLabels, rowLabels);
    if (memoryImageSource == null || pixels == null
        || !displayPanel.isVisible ())
    {
      return;
    }
    Graphics graphics = displayPanel.getGraphics ();
    Dimension dimension = displayPanel.getSize ();
    graphics.drawImage (image, 0, 0, dimension.width - 1,
                        dimension.height - 1, 0, rifs.octaveBinCount - 1,
                        rifs.timeBinCount - 1, 0, displayPanel);
  }
  public void updateModel ()
  {
    rifs.setName (nameField.getText ());
    rifs.getLocalScore ().autoRescale = autoRescaleCheckbox.isSelected ();
    rifs.renderAsSound = renderAsSoundfileCheckbox.isSelected ();
    rifs.totalDurationSeconds =
      Double.parseDouble (totalDurationSecondsField.getText ());
    rifs.secondsToIterate =
      Double.parseDouble (secondsToIterateField.getText ());
    rifs.timeBinCount =
      Integer.parseInt (timeBinCountField.getText ());
    rifs.octaveBinCount =
      Integer.parseInt (octaveBinCountField.getText ());
    rifs.instrumentBinCount =
      Integer.parseInt (instrumentBinCountField.getText ());
    rifs.voiceCount =
      Integer.parseInt (voiceCountPerInstrumentField.getText ());
    rifs.getLocalScore ().tonesPerOctave =
      Double.parseDouble (tonesPerOctaveField.getText ());
    updateView ();
  }
  public RIFSView ()
  {
    setTitle ("RIFS");
    GridBagLayout gridBagLayout;
    gridBagLayout = new GridBagLayout ();
    getContentPane ().setLayout (gridBagLayout);
    setVisible (false);
    setSize (734, 543);
    setBackground (new Color (8421504));
    tabButtonPanel = new javax.swing.JPanel ();
    tabButtonPanel.setLayout (null);
    tabButtonPanel.setBounds (12, 12, 708, 48);
    tabButtonPanel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    tabButtonPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    GridBagConstraints gbc;
    gbc = new GridBagConstraints ();
    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.weightx = 1.0;
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.insets = new Insets (12, 12, 0, 14);
    gbc.ipadx = 707;
    gbc.ipady = 47;



























    ((GridBagLayout) getContentPane ().getLayout ()).setConstraints (tabButtonPanel, gbc);
    getContentPane ().add (tabButtonPanel);
    selectFilePanelButton = new javax.swing.JButton ();
    selectFilePanelButton.setText ("File");
    selectFilePanelButton.setActionCommand ("File");
    selectFilePanelButton.setBounds (12, 12, 82, 25);
    selectFilePanelButton.setFont (new Font ("Dialog", Font.PLAIN, 12));
    tabButtonPanel.add (selectFilePanelButton);
    selectHutchinsonOperatorButton = new javax.swing.JButton ();
    selectHutchinsonOperatorButton.setText ("Hutchinson");
    selectHutchinsonOperatorButton.setActionCommand ("Hutchinson");
    selectHutchinsonOperatorButton.setBounds (108, 12, 108, 25);
    selectHutchinsonOperatorButton.setFont (new Font ("Dialog",
                                                      Font.PLAIN, 12));
    tabButtonPanel.add (selectHutchinsonOperatorButton);
    selectMarkovOperatorButton = new javax.swing.JButton ();
    selectMarkovOperatorButton.setText ("Markov");
    selectMarkovOperatorButton.setActionCommand ("Markov");
    selectMarkovOperatorButton.setBounds (228, 12, 108, 25);
    selectMarkovOperatorButton.setFont (new Font ("Dialog",
                                                  Font.PLAIN, 12));
    tabButtonPanel.add (selectMarkovOperatorButton);
    selectDisplayButton = new javax.swing.JButton ();
    selectDisplayButton.setText ("Display");
    selectDisplayButton.setActionCommand ("Display");
    selectDisplayButton.setBounds (348, 12, 108, 25);
    selectDisplayButton.setFont (new Font ("Dialog", Font.PLAIN, 12));
    tabButtonPanel.add (selectDisplayButton);
    tabPanel = new javax.swing.JPanel ();
    tabPanel.setLayout (new CardLayout (0, 0));
    tabPanel.setBounds (12, 72, 708, 456);
    tabPanel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    tabPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    gbc = new GridBagConstraints ();
    gbc.gridx = 0;
    gbc.gridy = 1;
    gbc.weightx = 1.0;
    gbc.weighty = 1.0;
    gbc.fill = GridBagConstraints.BOTH;
    gbc.insets = new Insets (12, 12, 15, 14);


























    ((GridBagLayout) getContentPane ().getLayout ()).setConstraints (tabPanel,
                                                                     gbc);
    getContentPane ().add (tabPanel);
    markovOperatorPanel = new javax.swing.JPanel ();
    markovOperatorPanel.setLayout (new BorderLayout (0, 0));
    markovOperatorPanel.setBounds (0, 0, 708, 456);
    markovOperatorPanel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    tabPanel.add ("markovOperatorPanel", markovOperatorPanel);
    displayPanel = new javax.swing.JPanel ();
    displayPanel.setLayout (null);
    displayPanel.setBounds (0, 0, 708, 456);
    displayPanel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    displayPanel.setBackground (new Color (0));
    tabPanel.add ("displayPanel", displayPanel);
    filePanel = new javax.swing.JPanel ();
    filePanel.setLayout (null);
    filePanel.setBounds (0, 0, 708, 456);
    filePanel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    tabPanel.add ("filePanel", filePanel);
    namePanel = new javax.swing.JPanel ();
    namePanel.setLayout (null);
    namePanel.setBounds (12, 12, 684, 57);
    namePanel.setFont (new Font ("Dialog", Font.BOLD, 12));
    filePanel.add (namePanel);
    nameField = new javax.swing.JTextField ();
    nameField.setBounds (12, 24, 660, 21);
    nameField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    namePanel.add (nameField);
    nameLabel = new javax.swing.JLabel ();
    nameLabel.setText ("Name");
    nameLabel.setHorizontalAlignment (0);
    nameLabel.setBounds (12, 0, 660, 24);
    nameLabel.setFont (new Font ("Dialog", Font.BOLD, 12));
    namePanel.add (nameLabel);
    namePanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    parametersPanel = new javax.swing.JPanel ();
    parametersPanel.setLayout (null);
    parametersPanel.setBounds (12, 84, 684, 300);
    parametersPanel.setFont (new Font ("Dialog", Font.BOLD, 12));
    parametersPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    filePanel.add (parametersPanel);
    autoRescaleCheckbox = new javax.swing.JCheckBox ();
    autoRescaleCheckbox.setText ("Auto rescale");
    autoRescaleCheckbox.setActionCommand ("Auto rescale");
    autoRescaleCheckbox.setBounds (12, 240, 160, 25);
    autoRescaleCheckbox.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (autoRescaleCheckbox);
    renderAsSoundfileCheckbox = new javax.swing.JCheckBox ();
    renderAsSoundfileCheckbox.setText ("Render as soundfile");
    renderAsSoundfileCheckbox.setActionCommand ("Render as soundfile");
    renderAsSoundfileCheckbox.setBounds (12, 264, 160, 25);
    renderAsSoundfileCheckbox.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (renderAsSoundfileCheckbox);
    measurePanel = new javax.swing.JPanel ();
    measurePanel.setLayout (null);
    measurePanel.setBounds (372, 36, 300, 192);
    measurePanel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    measurePanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    parametersPanel.add (measurePanel);
    instrumentBinCountField = new javax.swing.JTextField ();
    instrumentBinCountField.setBounds (180, 36, 108, 23);
    instrumentBinCountField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    measurePanel.add (instrumentBinCountField);
    instrumentBinCount = new javax.swing.JLabel ();
    instrumentBinCount.setText ("Instrument count");
    instrumentBinCount.setBounds (12, 36, 168, 24);
    instrumentBinCount.setFont (new Font ("Dialog", Font.PLAIN, 12));
    measurePanel.add (instrumentBinCount);
    timeBinCountField = new javax.swing.JTextField ();
    timeBinCountField.setBounds (180, 72, 108, 23);
    timeBinCountField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    measurePanel.add (timeBinCountField);
    timeBinCountLabel = new javax.swing.JLabel ();
    timeBinCountLabel.setText ("Timestep count");
    timeBinCountLabel.setBounds (12, 72, 168, 24);
    timeBinCountLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    measurePanel.add (timeBinCountLabel);
    octaveBinCountField = new javax.swing.JTextField ();
    octaveBinCountField.setBounds (180, 108, 108, 23);
    octaveBinCountField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    measurePanel.add (octaveBinCountField);
    octaveBinCountLabel = new javax.swing.JLabel ();
    octaveBinCountLabel.setText ("Octave step count");
    octaveBinCountLabel.setBounds (12, 108, 168, 24);
    octaveBinCountLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    measurePanel.add (octaveBinCountLabel);
    tonesPerOctaveField = new javax.swing.JTextField ();
    tonesPerOctaveField.setBounds (180, 144, 108, 23);
    tonesPerOctaveField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    measurePanel.add (tonesPerOctaveField);
    tonesPerOctaveLabel = new javax.swing.JLabel ();
    tonesPerOctaveLabel.setText ("Tones per octave");
    tonesPerOctaveLabel.setBounds (12, 144, 168, 24);
    tonesPerOctaveLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    measurePanel.add (tonesPerOctaveLabel);
    measureLabel = new javax.swing.JLabel ();
    measureLabel.setText ("Measure");
    measureLabel.setHorizontalAlignment (0);
    measureLabel.setBounds (24, 0, 264, 24);
    measureLabel.setFont (new Font ("Dialog", Font.BOLD, 12));
    measurePanel.add (measureLabel);
    secondsToIterateField = new javax.swing.JTextField ();
    secondsToIterateField.setBounds (180, 36, 108, 23);
    secondsToIterateField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (secondsToIterateField);
    secondsToIterateLabel = new javax.swing.JLabel ();
    secondsToIterateLabel.setText ("Seconds to iterate");
    secondsToIterateLabel.setBounds (12, 36, 168, 24);
    secondsToIterateLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (secondsToIterateLabel);
    voiceCountPerInstrumentField = new javax.swing.JTextField ();
    voiceCountPerInstrumentField.setBounds (180, 144, 108, 23);
    voiceCountPerInstrumentField.setFont (new Font ("Dialog",
                                                    Font.PLAIN, 12));
    parametersPanel.add (voiceCountPerInstrumentField);
    voiceCountLabel = new javax.swing.JLabel ();
    voiceCountLabel.setText ("Voice count per instrument");
    voiceCountLabel.setBounds (12, 144, 168, 24);
    voiceCountLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (voiceCountLabel);
    totalDurationSecondsField = new javax.swing.JTextField ();
    totalDurationSecondsField.setBounds (180, 180, 108, 23);
    totalDurationSecondsField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (totalDurationSecondsField);
    totalDurationSecondsLabel = new javax.swing.JLabel ();
    totalDurationSecondsLabel.setText ("Total duration (seconds)");
    totalDurationSecondsLabel.setBounds (12, 180, 168, 24);
    totalDurationSecondsLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (totalDurationSecondsLabel);
    secondsToDateField = new javax.swing.JTextField ();
    secondsToDateField.setEditable (false);
    secondsToDateField.setBounds (180, 72, 108, 23);
    secondsToDateField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (secondsToDateField);
    secondsToDateLabel = new javax.swing.JLabel ();
    secondsToDateLabel.setText ("Seconds to date");
    secondsToDateLabel.setBounds (12, 72, 168, 24);
    secondsToDateLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (secondsToDateLabel);
    iterationCountField = new javax.swing.JTextField ();
    iterationCountField.setEditable (false);
    iterationCountField.setBounds (180, 108, 108, 23);
    iterationCountField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (iterationCountField);
    iterationCountLabel = new javax.swing.JLabel ();
    iterationCountLabel.setText ("Iteration count");
    iterationCountLabel.setBounds (12, 108, 168, 24);
    iterationCountLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (iterationCountLabel);
    parametersLabel = new javax.swing.JLabel ();
    parametersLabel.setText ("Parameters");
    parametersLabel.setHorizontalAlignment (0);
    parametersLabel.setBounds (12, 0, 660, 24);
    parametersLabel.setFont (new Font ("Dialog", Font.BOLD, 12));
    parametersPanel.add (parametersLabel);
    buttonPanel = new javax.swing.JPanel ();
    buttonPanel.setLayout (null);
    buttonPanel.setBounds (12, 396, 684, 48);
    buttonPanel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    buttonPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    filePanel.add (buttonPanel);
    updateButton = new javax.swing.JButton ();
    updateButton.setText ("Update");
    updateButton.setActionCommand ("button");
    updateButton.setBounds (108 + (84 + 12) * 3, 12, 84, 24);
    updateButton.setFont (new Font ("Dialog", Font.PLAIN, 12));
    buttonPanel.add (updateButton);
    iterateButton = new javax.swing.JButton ();
    iterateButton.setText ("Iterate");
    iterateButton.setActionCommand ("button");
    iterateButton.setBounds (12, 12, 84, 24);
    iterateButton.setFont (new Font ("Dialog", Font.PLAIN, 12));
    buttonPanel.add (iterateButton);
    translateButton = new javax.swing.JButton ();
    translateButton.setText ("Translate");
    translateButton.setActionCommand ("button");
    translateButton.setBounds (108, 12, 84, 24);
    translateButton.setFont (new Font ("Dialog", Font.PLAIN, 12));
    buttonPanel.add (translateButton);
    stopButton = new javax.swing.JButton ();
    stopButton.setText ("Stop");
    stopButton.setActionCommand ("button");
    stopButton.setBounds (108 + 84 + 12, 12, 84, 24);
    stopButton.setFont (new Font ("Dialog", Font.PLAIN, 12));
    buttonPanel.add (stopButton);
    scoreButton = new javax.swing.JButton ();
    scoreButton.setText ("Score");
    scoreButton.setActionCommand ("button");
    scoreButton.setBounds (348 + 108 + 12, 12, 108, 25);
    scoreButton.setFont (new Font ("Dialog", Font.PLAIN, 12));
    tabButtonPanel.add (scoreButton);
    importIFSButton = new javax.swing.JButton ();
    importIFSButton.setText ("Import IFS");
    importIFSButton.setActionCommand ("button");
    importIFSButton.setBounds (108 + (84 + 12) * 2, 12, 84, 24);
    importIFSButton.setFont (new Font ("Dialog", Font.PLAIN, 12));
    buttonPanel.add (importIFSButton);
    hutchinsonOperatorPanel = new javax.swing.JPanel ();
    gridBagLayout = new GridBagLayout ();
    hutchinsonOperatorPanel.setLayout (new BorderLayout (0, 0));
    hutchinsonOperatorPanel.setBounds (0, 0, 708, 456);
    hutchinsonOperatorPanel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    tabPanel.add ("hutchinsonOperatorPanel", hutchinsonOperatorPanel);
    borderPanelButtons = new javax.swing.JPanel ();
    gridBagLayout = new GridBagLayout ();
    borderPanelButtons.setLayout (gridBagLayout);
    borderPanelButtons.setBounds (0, 0, 708, 60);
    borderPanelButtons.setFont (new Font ("Dialog", Font.PLAIN, 12));
    hutchinsonOperatorPanel.add ("North", borderPanelButtons);
    newButton = new javax.swing.JButton ();
    newButton.setText ("New");
    newButton.setActionCommand ("button");
    newButton.setBounds (16, 15, 60, 24);
    newButton.setFont (new Font ("Dialog", Font.PLAIN, 12));
    gbc = new GridBagConstraints ();
    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.gridheight = 2;
    gbc.weighty = 1.0;
    gbc.fill = GridBagConstraints.VERTICAL;
    gbc.insets = new Insets (15, 14, 21, 0);
    gbc.ipadx = 1;
    gbc.ipady = -1;
    ((GridBagLayout) borderPanelButtons.getLayout ()).setConstraints (newButton,
                                                                      gbc);
    borderPanelButtons.add (newButton);
    deleteButton = new javax.swing.JButton ();
    deleteButton.setText ("Delete");
    deleteButton.setActionCommand ("button");
    deleteButton.setBounds (88, 15, 60, 24);
    deleteButton.setFont (new Font ("Dialog", Font.PLAIN, 12));
    gbc = new GridBagConstraints ();
    gbc.gridx = 1;
    gbc.gridy = 0;
    gbc.gridheight = 2;
    gbc.weighty = 1.0;
    gbc.fill = GridBagConstraints.VERTICAL;
    gbc.insets = new Insets (15, 12, 21, 0);
    gbc.ipadx = -11;
    gbc.ipady = -1;
    ((GridBagLayout) borderPanelButtons.getLayout ()).setConstraints (deleteButton, gbc);
    borderPanelButtons.add (deleteButton);
    firstButton = new javax.swing.JButton ();
    firstButton.setText ("First");
    firstButton.setActionCommand ("button");
    firstButton.setBounds (160, 15, 60, 24);
    firstButton.setFont (new Font ("Dialog", Font.PLAIN, 12));
    gbc = new GridBagConstraints ();
    gbc.gridx = 2;
    gbc.gridy = 0;
    gbc.gridheight = 2;
    gbc.weighty = 1.0;
    gbc.fill = GridBagConstraints.VERTICAL;
    gbc.insets = new Insets (15, 12, 21, 0);
    gbc.ipadx = 1;
    gbc.ipady = -1;
    ((GridBagLayout) borderPanelButtons.getLayout ()).setConstraints (firstButton, gbc);
    borderPanelButtons.add (firstButton);
    nextButton = new javax.swing.JButton ();
    nextButton.setText ("Next");
    nextButton.setActionCommand ("button");
    nextButton.setBounds (232, 15, 58, 24);
    nextButton.setFont (new Font ("Dialog", Font.PLAIN, 12));
    gbc = new GridBagConstraints ();
    gbc.gridx = 3;
    gbc.gridy = 0;
    gbc.gridheight = 2;
    gbc.weighty = 1.0;
    gbc.fill = GridBagConstraints.VERTICAL;
    gbc.insets = new Insets (15, 12, 21, 0);
    gbc.ipadx = -1;
    gbc.ipady = -1;
    ((GridBagLayout) borderPanelButtons.getLayout ()).setConstraints (nextButton,

                                                                      gbc);
    borderPanelButtons.add (nextButton);
    priorButton = new javax.swing.JButton ();
    priorButton.setText ("Prior");
    priorButton.setActionCommand ("button");
    priorButton.setBounds (302, 15, 58, 24);
    priorButton.setFont (new Font ("Dialog", Font.PLAIN, 12));
    gbc = new GridBagConstraints ();
    gbc.gridx = 4;
    gbc.gridy = 0;
    gbc.gridheight = 2;
    gbc.weighty = 1.0;
    gbc.fill = GridBagConstraints.VERTICAL;
    gbc.insets = new Insets (15, 12, 21, 0);
    gbc.ipadx = -3;
    gbc.ipady = -1;
    ((GridBagLayout) borderPanelButtons.getLayout ()).setConstraints (priorButton, gbc);
    borderPanelButtons.add (priorButton);
    lastButton = new javax.swing.JButton ();
    lastButton.setText ("Last");
    lastButton.setActionCommand ("button");
    lastButton.setBounds (372, 15, 60, 24);
    lastButton.setFont (new Font ("Dialog", Font.PLAIN, 12));
    gbc = new GridBagConstraints ();
    gbc.gridx = 5;
    gbc.gridy = 0;
    gbc.gridheight = 2;
    gbc.weighty = 1.0;
    gbc.fill = GridBagConstraints.VERTICAL;
    gbc.insets = new Insets (15, 12, 21, 0);
    gbc.ipadx = 1;
    gbc.ipady = -1;
    ((GridBagLayout) borderPanelButtons.getLayout ()).setConstraints (lastButton,

                                                                      gbc);
    borderPanelButtons.add (lastButton);
    indexLabel = new javax.swing.JLabel ();
    indexLabel.setText ("text");
    indexLabel.setBounds (456, 15, 48, 21);
    indexLabel.setFont (new Font ("Dialog", Font.BOLD, 12));
    gbc = new GridBagConstraints ();
    gbc.gridx = 6;
    gbc.gridy = 0;
    gbc.fill = GridBagConstraints.NONE;
    gbc.insets = new Insets (15, 24, 0, 0);
    gbc.ipadx = 26;
    gbc.ipady = 6;
    ((GridBagLayout) borderPanelButtons.getLayout ()).setConstraints (indexLabel,

                                                                      gbc);
    borderPanelButtons.add (indexLabel);
    ofLabel = new javax.swing.JLabel ();
    ofLabel.setText ("of");
    ofLabel.setBounds (516, 15, 48, 21);
    ofLabel.setFont (new Font ("Dialog", Font.BOLD, 12));
    gbc = new GridBagConstraints ();
    gbc.gridx = 7;
    gbc.gridy = 0;
    gbc.fill = GridBagConstraints.NONE;
    gbc.insets = new Insets (15, 12, 0, 0);
    gbc.ipadx = 37;
    gbc.ipady = 6;
    ((GridBagLayout) borderPanelButtons.getLayout ()).setConstraints (ofLabel,
                                                                      gbc);
    borderPanelButtons.add (ofLabel);
    countLabel = new javax.swing.JLabel ();
    countLabel.setText ("text");
    countLabel.setBounds (576, 15, 48, 21);
    countLabel.setFont (new Font ("Dialog", Font.BOLD, 12));
    gbc = new GridBagConstraints ();
    gbc.gridx = 8;
    gbc.gridy = 0;
    gbc.fill = GridBagConstraints.NONE;
    gbc.insets = new Insets (15, 12, 0, 82);
    gbc.ipadx = 26;
    gbc.ipady = 6;
    ((GridBagLayout) borderPanelButtons.getLayout ()).setConstraints (countLabel,

                                                                      gbc);
    borderPanelButtons.add (countLabel);
    hutchinsonView = new MatrixEditor ();
    hutchinsonOperatorPanel.add ("Center", hutchinsonView);
    markovView = new MatrixEditor ();
    markovOperatorPanel.add ("Center", markovView);
    SymAction lSymAction = new SymAction ();
    updateButton.addActionListener (lSymAction);
    newButton.addActionListener (lSymAction);
    deleteButton.addActionListener (lSymAction);
    firstButton.addActionListener (lSymAction);
    priorButton.addActionListener (lSymAction);
    nextButton.addActionListener (lSymAction);
    lastButton.addActionListener (lSymAction);
    iterateButton.addActionListener (lSymAction);
    translateButton.addActionListener (lSymAction);
    stopButton.addActionListener (lSymAction);
    scoreButton.addActionListener (lSymAction);
    selectFilePanelButton.addActionListener (lSymAction);
    selectHutchinsonOperatorButton.addActionListener (lSymAction);
    selectMarkovOperatorButton.addActionListener (lSymAction);
    selectDisplayButton.addActionListener (lSymAction);
    ((CardLayout) tabPanel.getLayout ()).show (tabPanel, "filePanel");
  }
  public RIFSView (String title)
  {
    this ();
    setTitle (title);
  }
  javax.swing.JPanel tabButtonPanel;
  javax.swing.JButton selectFilePanelButton;
  javax.swing.JButton selectHutchinsonOperatorButton;
  javax.swing.JButton selectMarkovOperatorButton;
  javax.swing.JButton selectDisplayButton;
  javax.swing.JPanel tabPanel;
  javax.swing.JPanel markovOperatorPanel;
  javax.swing.JPanel displayPanel;
  javax.swing.JPanel filePanel;
  javax.swing.JPanel namePanel;
  javax.swing.JTextField nameField;
  javax.swing.JLabel nameLabel;
  javax.swing.JPanel parametersPanel;
  javax.swing.JCheckBox autoRescaleCheckbox;
  javax.swing.JCheckBox renderAsSoundfileCheckbox;
  javax.swing.JPanel measurePanel;
  javax.swing.JTextField instrumentBinCountField;
  javax.swing.JLabel instrumentBinCount;
  javax.swing.JTextField timeBinCountField;
  javax.swing.JLabel timeBinCountLabel;
  javax.swing.JTextField octaveBinCountField;
  javax.swing.JLabel octaveBinCountLabel;
  javax.swing.JTextField tonesPerOctaveField;
  javax.swing.JLabel tonesPerOctaveLabel;
  javax.swing.JLabel measureLabel;
  javax.swing.JTextField secondsToIterateField;
  javax.swing.JLabel secondsToIterateLabel;
  javax.swing.JTextField voiceCountPerInstrumentField;
  javax.swing.JLabel voiceCountLabel;
  javax.swing.JTextField totalDurationSecondsField;
  javax.swing.JLabel totalDurationSecondsLabel;
  javax.swing.JTextField secondsToDateField;
  javax.swing.JLabel secondsToDateLabel;
  javax.swing.JTextField iterationCountField;
  javax.swing.JLabel iterationCountLabel;
  javax.swing.JLabel parametersLabel;
  javax.swing.JPanel buttonPanel;
  javax.swing.JButton updateButton;
  javax.swing.JButton iterateButton;
  javax.swing.JButton translateButton;
  javax.swing.JButton stopButton;
  javax.swing.JButton scoreButton;
  javax.swing.JButton importIFSButton;
  javax.swing.JPanel hutchinsonOperatorPanel;
  javax.swing.JPanel borderPanelButtons;
  javax.swing.JButton newButton;
  javax.swing.JButton deleteButton;
  javax.swing.JButton firstButton;
  javax.swing.JButton nextButton;
  javax.swing.JButton priorButton;
  javax.swing.JButton lastButton;
  javax.swing.JLabel indexLabel;
  javax.swing.JLabel ofLabel;
  javax.swing.JLabel countLabel;
  MatrixEditor hutchinsonView;
  MatrixEditor markovView;
  class SymAction implements java.awt.event.ActionListener
    {
    public void actionPerformed (java.awt.event.ActionEvent event)
    {
      Object object = event.getSource ();
      if (object == updateButton)
        updateButton_Action (event);
      else if (object == newButton)
        newButton_Action (event);
      else if (object == deleteButton)
        deleteButton_Action (event);
      else if (object == firstButton)
        firstButton_Action (event);
      else if (object == priorButton)
        priorButton_Action (event);
      else if (object == nextButton)
        nextButton_Action (event);
      else if (object == lastButton)
        lastButton_Action (event);
      else if (object == iterateButton)
        iterateButton_Action (event);
      else if (object == translateButton)
        translateButton_Action (event);
      else if (object == scoreButton)
        ((CardLayout) tabPanel.getLayout ()).show (tabPanel,
                                                   "scoreViewTab");
      else if (object == stopButton)
        stopButton_Action (event);
      else if (object == selectFilePanelButton)
        selectFilePanelButton_actionPerformed (event);
      else if (object == selectHutchinsonOperatorButton)
        selectHutchinsonOperatorButton_actionPerformed (event);
      else if (object == selectMarkovOperatorButton)
        selectMarkovOperatorButton_actionPerformed (event);
      else if (object == selectDisplayButton)
        selectDisplayButton_actionPerformed (event);
    }
  }
  void updateButton_Action (java.awt.event.ActionEvent event)
  {
    updateModel ();
  }
  void newButton_Action (java.awt.event.ActionEvent event)
  {
    updateModel ();
    rifs.addHutchinsonOperatorMatrix ();
    updateView ();
  }
  void deleteButton_Action (java.awt.event.ActionEvent event)
  {
    updateModel ();
    rifs.removeHutchinsonOperatorMatrix (currentMatrixIndex);
    updateView ();
  }
  void firstButton_Action (java.awt.event.ActionEvent event)
  {
    updateModel ();
    currentMatrixIndex = 0;
    updateView ();
  }
  void priorButton_Action (java.awt.event.ActionEvent event)
  {
    updateModel ();
    currentMatrixIndex--;
    updateView ();
  }
  void nextButton_Action (java.awt.event.ActionEvent event)
  {
    updateModel ();
    currentMatrixIndex++;
    updateView ();
  }
  void lastButton_Action (java.awt.event.ActionEvent event)
  {
    updateModel ();
    currentMatrixIndex = rifs.hutchinsonOperator.size () - 1;
    updateView ();
  }
  void tabPanel_propertyChange (java.beans.PropertyChangeEvent event)
  {
    updateModel ();
  }
  void iterateButton_Action (java.awt.event.ActionEvent event)
  {
    generate ();
  }
  void translateButton_Action (java.awt.event.ActionEvent event)
  {
    stopButton_Action (null);
    rifs.translate ();
    stopButton_Action (null);
  }
  void stopButton_Action (java.awt.event.ActionEvent event)
  {
    rifs.keepIterating = false;
  }
  void importIFSButton_MouseClicked (java.awt.event.MouseEvent event)
  {
    JFileChooser fileDialog = Global.createFileDialog ("Import file");



























    fileDialog.setFileFilter (Global.createFileFilter ("Fractint IFS files",
                                                       ".ifs"));
    if (fileDialog.showOpenDialog (this) == fileDialog.APPROVE_OPTION)
    {
      File file = fileDialog.getSelectedFile ();
      rifs.importIFS (file.getAbsolutePath ());
      updateView ();
    }
  }
  void selectFilePanelButton_actionPerformed (java.awt.event.
                                              ActionEvent event)
  {
    ((CardLayout) tabPanel.getLayout ()).show (tabPanel, "filePanel");
    updateView ();
  }
  void selectHutchinsonOperatorButton_actionPerformed (java.awt.
                                                       event.ActionEvent
                                                       event)
  {

    ((CardLayout) tabPanel.getLayout ()).show (tabPanel,
                                               "hutchinsonOperatorPanel");
    updateView ();
  }
  void selectMarkovOperatorButton_actionPerformed (java.awt.
                                                   event.ActionEvent event)
  {
    ((CardLayout) tabPanel.getLayout ()).show (tabPanel,
                                               "markovOperatorPanel");
    updateView ();
  }
  void selectDisplayButton_actionPerformed (java.awt.event.ActionEvent event)
  {
    ((CardLayout) tabPanel.getLayout ()).show (tabPanel, "displayPanel");
    displayPanel.invalidate ();
    updateView ();
  }
}
