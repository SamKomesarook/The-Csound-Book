package Silence.Score.Nodes;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import java.awt.*;
import javax.swing.*;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
/**
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class MultipleReductionCopyMachineView extends javax.
  swing.JInternalFrame
{
  Frame frame = null;
  MultipleReductionCopyMachine multipleReductionCopyMachine = null;

  public MultipleReductionCopyMachineView (MultipleReductionCopyMachine g)
  {
    this ("MultipleReductionCopyMachine");
    multipleReductionCopyMachine = g;
    updateView ();
  }
  void updateView ()
  {
    nameField.setText (multipleReductionCopyMachine.getName ());
    iterationCountField.
      setText (String.valueOf (multipleReductionCopyMachine.iterationCount));
  }
  public void updateModel ()
  {
    multipleReductionCopyMachine.setName (nameField.getText ());
    multipleReductionCopyMachine.iterationCount = Integer.parseInt (iterationCountField.getText ());
    updateView ();
  }
  public MultipleReductionCopyMachineView ()
  {
    setTitle ("MultipleReductionCopyMachine");
    getContentPane ().setLayout (null);
    setVisible (false);
    setSize (442, 156);
    namePanel = new javax.swing.JPanel ();
    namePanel.setLayout (null);
    namePanel.setBounds (12, 12, 420, 72);
    namePanel.setFont (new Font ("Dialog", Font.BOLD, 12));
    namePanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (namePanel);
    nameField = new javax.swing.JTextField ();
    nameField.setBounds (12, 36, 396, 24);
    nameField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    namePanel.add (nameField);
    nameLabel = new javax.swing.JLabel ();
    nameLabel.setText ("Name");
    nameLabel.setHorizontalAlignment (0);
    nameLabel.setHorizontalTextPosition (0);
    nameLabel.setBounds (12, 0, 392, 26);
    nameLabel.setFont (new Font ("Dialog", Font.BOLD, 12));
    namePanel.add (nameLabel);
    buttonPanel = new javax.swing.JPanel ();
    buttonPanel.setLayout (null);
    buttonPanel.setBounds (12, 96, 420, 48);
    buttonPanel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    buttonPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (buttonPanel);
    updateButton = new javax.swing.JButton ();
    updateButton.setText ("Update");
    updateButton.setActionCommand ("button");
    updateButton.setBounds (12, 12, 84, 24);
    updateButton.setFont (new Font ("Dialog", Font.PLAIN, 12));
    buttonPanel.add (updateButton);
    iterationCountLabel = new JLabel ("Iterations");
    iterationCountLabel.setBounds (108, 12, 72, 24);
    buttonPanel.add (iterationCountLabel);
    iterationCountField = new JTextField ();
    iterationCountField.setBounds (204 - 24, 12, 84, 24);
    buttonPanel.add (iterationCountField);
    SymAction lSymAction = new SymAction ();
      updateButton.addActionListener (lSymAction);
  }
  public MultipleReductionCopyMachineView (String title)
  {
    this ();
    setTitle (title);
  }
  javax.swing.JPanel namePanel;
    javax.swing.JTextField nameField;
    javax.swing.JLabel nameLabel;
    javax.swing.JPanel buttonPanel;
    javax.swing.JButton updateButton;
    javax.swing.JLabel iterationCountLabel;
    javax.swing.JTextField iterationCountField;
  class SymAction implements java.awt.event.ActionListener
  {
    public void actionPerformed (java.awt.event.ActionEvent event)
    {
      Object object = event.getSource ();
      if (object == updateButton)
	  updateButton_Action (event);
    }
  }
  void updateButton_Action (java.awt.event.ActionEvent event)
  {
    updateModel ();
  }
}
