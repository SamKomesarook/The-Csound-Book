package Silence.Score.Nodes;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import Silence.calc.expression.*;
import Silence.calc.ui.*;
import java.awt.*;
import java.io.*;
import java.util.*;
/**
Uses a symbolic expression parser
(courtesty of <A HREF="mailto:davidliu@mti.sgi.com">David Liu</A>) to apply
symbolic functions from one dimension of music space to another.
Expressions can contain nested parentheses, the variables X, Y, and/or Z,
and common functions such as SIN(), COS(), or EXP().
X represents the selected domain dimension of note space,
and Y represents the selected range dimension.
If multiply is true, then the original value of y is replaced by
the original value of y times the computed value of y; otherwise,
the original value of y is replaced by the computed value of y.
Here is the <A HREF="calc/doc/packages.html">PRECISE package documentation</A>.
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class Expression extends Rescale implements NodeInterface,
  java.io.Serializable
{
  String text = null;
  int rangeDimension;
  int domainDimension;
  double minimumX;
  double maximumX;
  boolean normalizeOverX;
  boolean multiply = false;
    Silence.calc.expression.Expression expression = null;
  public Expression ()
  {
  }
  public NodeInterface copy()
  {
    Expression copy = new Expression();
    copyFieldsInto(copy);
    return copy;
  }
  public void copyFieldsInto(NodeInterface copy_)
  {
    Expression copy = (Expression) copy_;
    super.copyFieldsInto(copy);
    copy.text = text;
    rangeDimension = rangeDimension;
    domainDimension = domainDimension;
    copy.text = text;
    copy.rangeDimension = rangeDimension;
    copy.domainDimension = domainDimension;
    copy.minimumX = minimumX;
    copy.maximumX = maximumX;
    copy.normalizeOverX = normalizeOverX;
    copy.multiply = multiply;
  }
  public double[][] produceOrTransformNotes (double[][]compositeTransform,
					     Score score,
					     int preTraversalCount,
					     int postTraversalCount)
  {
    findActualScale (score, preTraversalCount, postTraversalCount);
    //  Apply the expression to the child nodes.
    double[] note = null;
    double scoreMinimumX = scaleActualMinima[domainDimension];
    double scoreRangeX = scaleActualRanges[domainDimension];
    double scoreMaxmumX = scoreMinimumX + scoreRangeX;
    double rangeX = maximumX - minimumX;
    double fractionX;
      try
    {
      expression = new Silence.calc.expression.Expression (text);
    }
    catch (Exception x)
    {
      x.printStackTrace ();
      return compositeTransform;
    }
    Variable variable = new Silence.calc.expression.Variable ();
    double x;
    double y;
    try
    {
      for (int i = preTraversalCount; i < postTraversalCount; i++)
	{
	  note = (double[]) score.getEvent (i);
	  x = note[domainDimension];
	  y = note[rangeDimension];
	  if (normalizeOverX)
	    {
	      fractionX = (x - scoreMinimumX) / scoreRangeX;
	      x = minimumX + (fractionX * rangeX);
	    }
	  Variable.X.val = x;
	  variable.Y.val = y;
	  if (multiply)
	    {
	      y *= expression.eval ();
	    }
	  else
	    {
	      y = expression.eval ();
	    }
	  note[rangeDimension] = y;
	}
    }
    catch (Exception e)
    {
      e.printStackTrace ();
    }
    return compositeTransform;
  }
  public void defaults ()
  {
    defaultsExpression ();
  }
  public void defaultsExpression ()
  {
    expression = null;
    text = null;
  }
  public String getText ()
  {
    return text;
  }
  public void setText (String Value)
  {
    try
    {
      text = Value;
      expression = new Silence.calc.expression.Expression (text);
    }
    catch (ExpressionParseException e)
    {
      e.printStackTrace ();
    }
  }
  public Silence.calc.expression.Expression getExpression ()
  {
    return expression;
  }
  public void openView ()
  {
    ExpressionView view = new ExpressionView (this);
      view.setVisible (true);
  }
  public Container getView ()
  {
    return new ExpressionView (this);
  }
}
