package Silence.Score.Nodes;
import cern.jet.random.Normal;
import cern.jet.random.engine.RandomEngine;
import Silence.Global;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import Silence.Mathematics.*;
import java.awt.*;
import java.io.*;
import java.util.*;
/**
Like RandomizeUniform, except that the random variable has a Gaussian distribution.
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class RandomizeGaussian extends RandomizeUniform implements
  NodeInterface, java.io.Serializable
{
  transient Normal gaussian = null;
  double standardDeviation = 1.0;
  double mean = 0.0;
  public RandomizeGaussian ()
  {
    gaussian = new Normal (mean, standardDeviation, Global.randomEngine);
    defaultsRandomizeGaussian ();
  }
  public NodeInterface copy()
  {
    RandomizeGaussian copy = new RandomizeGaussian();
    copyFieldsInto(copy);
    return copy;
  }
  public void copyFieldsInto(NodeInterface copy_)
  {
    RandomizeGaussian copy = (RandomizeGaussian) copy_;
    super.copyFieldsInto(copy);
    copy.standardDeviation = standardDeviation;
    copy.mean = mean;
  }
  public void defaultsRandomizeGaussian ()
  {
    standardDeviation = 1.0;
    mean = 0.0;
    gaussian.setState (mean, standardDeviation);
  }
  public double getSample ()
  {
    return gaussian.nextDouble ();
  }
  public void openView ()
  {
    RandomizeGaussianView view = new RandomizeGaussianView (this);
      view.setVisible (true);
  }
  public Container getView ()
  {
    return new RandomizeGaussianView (this);
  }
}
