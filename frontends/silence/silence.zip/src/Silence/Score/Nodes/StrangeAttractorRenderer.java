package Silence.Score.Nodes;

public interface StrangeAttractorRenderer
{
  public void initialize (int NMAX, double XMIN, double YMIN, double ZMIN,
			  double WMIN, double XMAX, double YMAX, double ZMAX,
			  double WMAX);
  public void render (int N, double X, double Y, double Z, double W);
}
