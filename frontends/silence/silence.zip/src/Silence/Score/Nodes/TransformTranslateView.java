package Silence.Score.Nodes;
import Silence.Orchestra.Event;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import java.awt.*;
import javax.swing.*;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.table.*;
/**
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class TransformTranslateView extends javax.swing.JInternalFrame
{
  Frame frame = null;
  TransformTranslate transformTranslate = null;
  public class TableModel extends AbstractTableModel
  {
    public int getRowCount ()
    {
      return Event.ELEMENT_COUNT;
    }
    public int getColumnCount ()
    {
      return 2;
    }
    public Object getValueAt (int row, int column)
    {
      if (transformTranslate == null || row < 0 || row > Event.HOMOGENEITY)
	{
	  return null;
	}
      if (column == 0)
	{
	  return Event.labels[row];
	}
      else
	{
	  return new Double (transformTranslate.M[row][row]);
	}
    }
    public void setValueAt (Object value, int row, int column)
    {
      if (column == 1)
	{
	  double d = Double.parseDouble (value.toString ());
	    transformTranslate.M[Event.STATUS][Event.STATUS] = d;
	}
    }
    public Class getColumnClass (int column)
    {
      if (column == 0)
	{
	  return String.class;
	}
      else if (column == 1)
	{
	  return Double.class;
	}
      return null;
    }
    public boolean isCellEditable (int row, int column)
    {
      if (column == 1 && row >= 0 && row < Event.HOMOGENEITY)
	{
	  return true;
	}
      return false;
    }
    public String getColumnName (int column)
    {
      if (column == 0)
	{
	  return "Dimension";
	}
      else if (column == 1)
	{
	  return "Value";
	}
      return null;
    }
  }
  TableModel tableModel = null;
  public TransformTranslateView (TransformTranslate value)
  {
    this ("TransformTranslate");
    transformTranslate = value;
    updateView ();
  }

  void updateView ()
  {
    nameField.setText (transformTranslate.getName ());
  }
  public void updateModel ()
  {
    transformTranslate.setName (nameField.getText ());
    updateView ();
  }
  public TransformTranslateView ()
  {
    super ();
    setTitle ("TransformTranslate");
    getContentPane ().setLayout (null);
    setVisible (false);
    setSize (457, 549);
    setFont (new Font ("Dialog", Font.PLAIN, 12));
    setForeground (new Color (0));
    setBackground (new Color (8421504));
    namePanel = new javax.swing.JPanel ();
    namePanel.setLayout (null);
    namePanel.setBounds (12, 12, 432, 72);
    namePanel.setFont (new Font ("Dialog", Font.BOLD, 12));
    namePanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (namePanel);
    nameField = new javax.swing.JTextField ();
    nameField.setBounds (12, 36, 408, 24);
    nameField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    namePanel.add (nameField);
    nameLabel = new javax.swing.JLabel ();
    nameLabel.setText ("Name");
    nameLabel.setHorizontalAlignment (0);
    nameLabel.setHorizontalTextPosition (0);
    nameLabel.setBounds (12, 0, 408, 24);
    nameLabel.setFont (new Font ("Dialog", Font.BOLD, 12));
    namePanel.add (nameLabel);
    scalePanel = new javax.swing.JPanel ();
    scalePanel.setLayout (new BorderLayout ());
    scalePanel.setBounds (12, 96, 432, 384);
    scalePanel.setFont (new Font ("Dialog", Font.BOLD, 12));
    scalePanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (scalePanel);
    parametersLabel = new javax.swing.JLabel ();
    parametersLabel.setText ("Parameters");
    parametersLabel.setFont (new Font ("Dialog", Font.BOLD, 12));
    scalePanel.add (parametersLabel, BorderLayout.NORTH);
    table = new JTable ();
    scrollPane = new JScrollPane ();
    scrollPane.getViewport ().add (table);
    tableModel = new TableModel ();
    table.setModel (tableModel);
    scalePanel.add (scrollPane, BorderLayout.CENTER);
    buttonPanel = new javax.swing.JPanel ();
    buttonPanel.setLayout (null);
    buttonPanel.setBounds (12, 492, 432, 48);
    buttonPanel.setFont (new Font ("Dialog", Font.BOLD, 12));
    buttonPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (buttonPanel);
    okButton = new javax.swing.JButton ();
    okButton.setText ("Update");
    okButton.setActionCommand ("button");
    okButton.setBounds (12, 12, 96, 24);
    okButton.setFont (new Font ("Dialog", Font.PLAIN, 12));
    buttonPanel.add (okButton);
    defaultsButton = new javax.swing.JButton ();
    defaultsButton.setText ("Defaults");
    defaultsButton.setActionCommand ("button");
    defaultsButton.setBounds (12, 96, 96, 24);
    defaultsButton.setFont (new Font ("Dialog", Font.PLAIN, 12));
    buttonPanel.add (defaultsButton);
    setTitle ("Rescale");
    SymAction lSymAction = new SymAction ();
      okButton.addActionListener (lSymAction);
      table.setModel (tableModel);
  }
  javax.swing.JPanel namePanel;
  javax.swing.JTextField nameField;
  javax.swing.JLabel nameLabel;
  javax.swing.JPanel scalePanel;
  javax.swing.JLabel parametersLabel;
  javax.swing.JScrollPane scrollPane;
  javax.swing.JTable table;
  javax.swing.JPanel buttonPanel;
  javax.swing.JButton okButton;
  javax.swing.JButton defaultsButton;
  public TransformTranslateView (String title)
  {
    this ();
    setTitle (title);
  }
  class SymAction implements java.awt.event.ActionListener
  {
    public void actionPerformed (java.awt.event.ActionEvent event)
    {
      Object object = event.getSource ();
      if (object == okButton)
	  updateTransformTranslate_Action (event);
      else if (object == defaultsButton)
	  defaultsButton_Action (event);
    }
  }
  void updateTransformTranslate_Action (java.awt.event.ActionEvent event)
  {
    updateModel ();
  }
  void defaultsButton_Action (java.awt.event.ActionEvent event)
  {
    transformTranslate.defaultsTransformTranslate ();
    updateView ();
  }
}
