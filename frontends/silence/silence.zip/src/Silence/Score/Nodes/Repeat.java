package Silence.Score.Nodes;
import Silence.Orchestra.Event;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import java.awt.*;
import java.io.*;
import java.util.*;
/**
Defines the number of repetitions, and the period of repetition,
for which all the child notes of this node are to be repeated in the score.
Can be used to create canons, repeat sections of music, and so on.
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class Repeat extends Rescale implements NodeInterface,
  java.io.Serializable
{
  int repeatCount = 1;
  boolean relativeDuration = true;
  double durationSeconds = 0;
  public Repeat ()
  {
  }
  public NodeInterface copy()
  {
    Repeat copy = new Repeat();
    copyFieldsInto(copy);
    return copy;
  }
  public void copyFieldsInto(NodeInterface copy_)
  {
    Repeat copy = (Repeat) copy_;
    super.copyFieldsInto(copy);
    copy.repeatCount = repeatCount;
    copy.relativeDuration = relativeDuration;
    copy.durationSeconds = durationSeconds;
  }
  public void defaults ()
  {
    super.defaults ();
    repeatCount = 1;
    relativeDuration = true;
    durationSeconds = 0;
  }
  public double[][] produceOrTransformNotes (double[][]compositeTransform,
					     Score score,
					     int preTraversalCount,
					     int postTraversalCount)
  {
    //  Find the total duration of notes produced by the child nodes of this.
    double[] note = score.getEvent (preTraversalCount);
    if (note == null)
      {
	return compositeTransform;
      }
    double beginSeconds = Event.getTime (note);
    double endSeconds = beginSeconds;
    double totalDurationSeconds = 0;
    for (int i = preTraversalCount; i < postTraversalCount; i++)
      {
	note = score.getEvent (i);
	if (beginSeconds > Event.getTime (note))
	  {
	    beginSeconds = Event.getTime (note);
	  }
	if (endSeconds < (Event.getTime (note) + Event.getDuration (note)))
	  {
	    endSeconds = (Event.getTime (note) + Event.getDuration (note));
	  }
      }
    if (relativeDuration)
      {
	totalDurationSeconds = durationSeconds + (endSeconds - beginSeconds);
      }
    else
      {
	totalDurationSeconds = durationSeconds;
      }
    System.out.println ("Repeat section.");
    System.out.println (" Began " + beginSeconds);
    System.out.println (" Ended " + endSeconds);
    System.out.println (" Duration " + totalDurationSeconds);
    //  Repeatedly clone the notes produced by the child nodes of this,
    //  incrementing the time as required.
    double currentTime = beginSeconds;
    //  First "repeat" is already there!
    for (int i = 1; i < repeatCount; i++)
      {
	currentTime += totalDurationSeconds;
	System.out.println ("  Repetition " + i + " time " + currentTime);
	for (int j = preTraversalCount; j < postTraversalCount; j++)
	  {
	    note = (double[]) score.getEvent (j).clone ();
	    Event.setTime (note, Event.getTime (note) + currentTime);
	    score.addEvent (note);
	  }
      }
    return compositeTransform;
  }
  public void openView ()
  {
    RepeatView view = new RepeatView (this);
      view.setVisible (true);
  }
  public Container getView ()
  {
    return new RepeatView (this);
  }
}
