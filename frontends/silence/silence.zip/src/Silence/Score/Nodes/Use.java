package Silence.Score.Nodes;
import Silence.Composition.MusicModel;
import Silence.PluginManager;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import Silence.Score.Nodes.Definition;
import java.awt.*;
import java.io.*;
import java.util.*;
/**
Use the node named by this node, and all of its child nodes, grandchildren,
and so on, at this node's location in the music graph.
Can be used to copy a section of music into another location of the score,
where in addition it might be otherwise transformed, and so on.
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class Use extends Node implements NodeInterface, java.io.Serializable
{
  String symbol = null;
  int iterationIndex = 0;
  int iterationCount;
  public Use ()
  {
    super ();
    defaultsUse ();
  }
  public NodeInterface copy()
  {
    Use copy = new Use();
    copyFieldsInto(copy);
    return copy;
  }
  public void copyFieldsInto(NodeInterface copy_)
  {
    Use copy = (Use) copy_;
    super.copyFieldsInto(copy);
    copy.iterationIndex = iterationIndex;
    copy.iterationCount = iterationCount;
    copy.symbol = symbol;
  }
  public void defaultsUse ()
  {
    symbol = null;
    iterationIndex = 0;
    iterationCount = 0;
  }
  public String getSymbol ()
  {
    return symbol;
  }
  public void setSymbol (String Value)
  {
    symbol = Value;
  }
  public double[][] traverseMusicGraph (double[][]parentTransformation,
					Score score)
  {
    //  If definition really is a Definition,
    //  traversing it only returns its transformation context,
    //  so that its children are not traversed outside the context of Use;
    //  therefore Use must traverse the definition's children for it.
    NodeInterface instance = (NodeInterface) Node.instances.get (symbol);
    if (instance instanceof Definition)
      {
	System.out.println ("Using definition: " + instance.getName () + ".");
	int n = instance.getChildCount ();
	for (int i = 0; i < n; i++)
	  {

	    ((NodeInterface) instance.getChildAt (i)).traverseMusicGraph
	      (parentTransformation, score);
	  }
      }
    else
      {
	instance.traverseMusicGraph (parentTransformation, score);
      }
    return parentTransformation;
  }
  public void openView ()
  {
    UseView view = new UseView (this);
      view.setVisible (true);
  }
  public Container getView ()
  {
    return new UseView (this);
  }
}
