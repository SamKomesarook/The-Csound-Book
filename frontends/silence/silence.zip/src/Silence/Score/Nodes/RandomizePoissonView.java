package Silence.Score.Nodes;
import Silence.MatrixEditor;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import Silence.Orchestra.Event;
import java.awt.*;
import javax.swing.*;
import javax.swing.JPanel;
import javax.swing.*;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
/**
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class RandomizePoissonView extends javax.swing.JInternalFrame
{
  RandomizePoisson randomizePoisson = null;
  MatrixEditor matrixEditor = null;
  public RandomizePoissonView (RandomizePoisson t)
  {
    this ();
    randomizePoisson = t;
    matrixEditor = new MatrixEditor ();
    String[] rowLabels = Event.labels;
    String[] columnLabels =
    {
      "Dim", "Status", "Instr", "Time", "Duration", "Octave", "Decibels",
	"Phase", "X", "Y", "Z", "Mason", "Move"};
      matrixEditor.create (t.M, columnLabels, rowLabels);
      matrixEditor.setFont (new Font ("Dialog", Font.PLAIN, 12));
      transformPanel.setLayout (new BorderLayout ());
      transformPanel.add ("Center", matrixEditor);
      updateView ();
      setTitle ("RandomizePoisson");
  }
  void updateView ()
  {
    nameField.setText (randomizePoisson.getName ());
    meanField.setText (String.valueOf (randomizePoisson.mean));
    notesToGenerateField.
      setText (String.valueOf (randomizePoisson.notesToGenerateCount));
    incrementTimeCheckbox.setSelected (randomizePoisson.getIncrementTime ());
  }
  void updateModel ()
  {
    randomizePoisson.setName (nameField.getText ());
    randomizePoisson.mean =
      Double.parseDouble (meanField.getText ());
    randomizePoisson.notesToGenerateCount =
      Integer.parseInt (notesToGenerateField.getText ());
    randomizePoisson.setIncrementTime (incrementTimeCheckbox.isSelected ());
  }
  public RandomizePoissonView ()
  {
    super ("RandomizePoisson");
    setTitle ("RandomizePoisson");
    getContentPane ().setLayout (null);
    setVisible (false);
    setSize (640, 480);
    setBackground (new Color (8421504));
    namePanel = new javax.swing.JPanel ();
    namePanel.setLayout (null);
    namePanel.setBounds (12, 12, 672, 72);
    namePanel.setFont (new Font ("Dialog", Font.BOLD, 12));
    namePanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (namePanel);
    nameField = new javax.swing.JTextField ();
    nameField.setBounds (12, 36, 648, 24);
    nameField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    namePanel.add (nameField);
    nameLabel = new javax.swing.JLabel ();
    nameLabel.setText ("Name");
    nameLabel.setHorizontalAlignment (0);
    nameLabel.setHorizontalTextPosition (0);
    nameLabel.setBounds (12, 0, 648, 26);
    nameLabel.setFont (new Font ("Dialog", Font.BOLD, 12));
    namePanel.add (nameLabel);
    transformPanel = new javax.swing.JPanel ();
    transformPanel.setBounds (12, 96, 672, 300);
    transformPanel.setFont (new Font ("Dialog", Font.BOLD, 12));
    transformPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (transformPanel);
    parametersPanel = new javax.swing.JPanel ();
    parametersPanel.setLayout (null);
    parametersPanel.setBounds (12, 408, 672, 75);
    parametersPanel.setFont (new Font ("Dialog", Font.BOLD, 12));
    parametersPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (parametersPanel);
    meanLabel = new javax.swing.JLabel ();
    meanLabel.setText ("Mean");
    meanLabel.setBounds (12, 36, 44, 23);
    meanLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (meanLabel);
    meanField = new javax.swing.JTextField ();
    meanField.setBounds (60, 36, 68, 23);
    parametersPanel.add (meanField);
    notesToGenerateLabel = new javax.swing.JLabel ();
    notesToGenerateLabel.setText ("Notes to generate");
    notesToGenerateLabel.setBounds (156, 36, 112, 23);
    notesToGenerateLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (notesToGenerateLabel);
    notesToGenerateField = new javax.swing.JTextField ();
    notesToGenerateField.setBounds (276, 36, 72, 23);
    parametersPanel.add (notesToGenerateField);
    incrementTimeCheckbox = new javax.swing.JCheckBox ();
    incrementTimeCheckbox.setText ("Increment time");
    incrementTimeCheckbox.setActionCommand ("Increment time");
    incrementTimeCheckbox.setBounds (372, 36, 112, 23);
    incrementTimeCheckbox.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (incrementTimeCheckbox);
    parametersLabel = new javax.swing.JLabel ();
    parametersLabel.setText ("Parameters");
    parametersLabel.setHorizontalAlignment (0);
    parametersLabel.setHorizontalTextPosition (0);
    parametersLabel.setBounds (0, 0, 648, 26);
    parametersLabel.setFont (new Font ("Dialog", Font.BOLD, 12));
    parametersPanel.add (parametersLabel);
    buttonPanel = new javax.swing.JPanel ();
    buttonPanel.setLayout (null);
    buttonPanel.setBounds (12, 492, 672, 48);
    buttonPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (buttonPanel);
    okButton = new javax.swing.JButton ();
    okButton.setText ("Update");
    okButton.setBounds (12, 12, 104, 24);
    buttonPanel.add (okButton);
    SymAction lSymAction = new SymAction ();
      okButton.addActionListener (lSymAction);
  }
  javax.swing.JPanel namePanel;
  javax.swing.JTextField nameField;
  javax.swing.JLabel nameLabel;
  javax.swing.JPanel transformPanel;
  javax.swing.JPanel parametersPanel;
  javax.swing.JLabel meanLabel;
  javax.swing.JTextField meanField;
  javax.swing.JLabel notesToGenerateLabel;
  javax.swing.JTextField notesToGenerateField;
  javax.swing.JCheckBox incrementTimeCheckbox;
  javax.swing.JLabel parametersLabel;
  javax.swing.JPanel buttonPanel;
  javax.swing.JButton okButton;
  class SymAction implements java.awt.event.ActionListener
  {
    public void actionPerformed (java.awt.event.ActionEvent event)
    {
      Object object = event.getSource ();
      if (object == okButton)
	  okButton_Action (event);
    }
  }
  void okButton_Action (java.awt.event.ActionEvent event)
  {
    updateModel ();
    updateView ();
  }
}
