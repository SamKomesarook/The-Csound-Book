package Silence.Score.Nodes;
import Silence.MatrixEditor;
import java.awt.*;
import javax.swing.*;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JLabel;
/**
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class TransformView extends javax.swing.JInternalFrame
{
  Transform transform = null;
  MatrixEditor matrixEditor = null;
  public TransformView (Transform t)
  {
    this ();
    transform = t;
    matrixEditor = new MatrixEditor ();
    String[] rowLabels =
    {
      "Status", "Instr", "Time", "Duration", "Key", "Decibels", "Phase",
	"X", "Y", "Z", "Mason", "Unity"};
    String[] columnLabels =
    {
      "Dim", "Status", "Instr", "Time", "Duration", "Key", "Decibels",
	"Phase", "X", "Y", "Z", "Mason", "Move"};
    matrixEditor.create (t.M, columnLabels, rowLabels);
    matrixEditor.setFont (new Font ("Dialog", Font.PLAIN, 12));
    transformPanel.setLayout (new BorderLayout ());
    transformPanel.add ("Center", matrixEditor);
    updateView ();
    setTitle ("Transform");
  }
  void updateView ()
  {
    nameField.setText (transform.getName ());
  }
  void updateModel ()
  {
    transform.setName (nameField.getText ());
  }
  public TransformView ()
  {
    super ("Transform");
    getContentPane ().setLayout (null);
    setVisible (false);
    setSize (640, 480);
    namePanel = new javax.swing.JPanel ();
    namePanel.setLayout (null);
    namePanel.setBounds (12, 12, 624, 60);
    namePanel.setFont (new Font ("Dialog", Font.BOLD, 12));
    namePanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (namePanel);
    nameLabel = new javax.swing.JLabel ();
    nameLabel.setText ("Name");
    nameLabel.setHorizontalAlignment (0);
    nameLabel.setHorizontalTextPosition (0);
    nameLabel.setBounds (12, 0, 600, 24);
    nameLabel.setFont (new Font ("Dialog", Font.BOLD, 12));
    namePanel.add (nameLabel);
    nameField = new javax.swing.JTextField ();
    nameField.setBounds (12, 24, 600, 24);
    nameField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    namePanel.add (nameField);
    transformPanel = new javax.swing.JPanel ();
    transformPanel.setLayout (new BorderLayout (0, 0));
    transformPanel.setBounds (12, 84, 624, 240);
    transformPanel.setFont (new Font ("Dialog", Font.BOLD, 12));
    transformPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (transformPanel);
    buttonPanel = new javax.swing.JPanel ();
    buttonPanel.setLayout (null);
    buttonPanel.setBounds (12, 336, 624, 48);
    buttonPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (buttonPanel);
    okButton = new javax.swing.JButton ();
    okButton.setText ("Update");
    okButton.setActionCommand ("button");
    okButton.setBounds (12, 12, 83, 24);
    okButton.setFont (new Font ("Dialog", Font.PLAIN, 12));
    buttonPanel.add (okButton);
    SymAction lSymAction = new SymAction ();
      okButton.addActionListener (lSymAction);
  }
  javax.swing.JPanel namePanel;
  javax.swing.JTextField nameField;
  javax.swing.JLabel nameLabel;
  javax.swing.JPanel transformPanel;
  javax.swing.JPanel buttonPanel;
  javax.swing.JButton okButton;
  class SymAction implements java.awt.event.ActionListener
  {
    public void actionPerformed (java.awt.event.ActionEvent event)
    {
      Object object = event.getSource ();
      if (object == okButton)
	  okButton_Action (event);
    }
  }
  void okButton_Action (java.awt.event.ActionEvent event)
  {
    updateModel ();
  }
}
