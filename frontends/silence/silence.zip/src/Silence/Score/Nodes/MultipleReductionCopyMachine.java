package Silence.Score.Nodes;
import Silence.Orchestra.Event;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import Silence.Mathematics.*;
import java.awt.*;
import java.io.*;
import java.util.*;
/**
Implements the Multiple Reduction Copy Machine algorithm for
deterministic iterated function systems. Any number of child transformations
are recursively applied for a specified number of iterations; at each leaf
of the generated tree of transformations, a note is generated at the resulting
point in music space.
<p>
Note: This node should have no children except the required transformations.
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class MultipleReductionCopyMachine extends Node implements
  NodeInterface, java.io.Serializable
  {
  int iterationCount = 0;
  public MultipleReductionCopyMachine ()
  {
  }
  public NodeInterface copy()
  {
    MultipleReductionCopyMachine copy = new MultipleReductionCopyMachine();
    copyFieldsInto(copy);
    return copy;
  }
  public void copyFieldsInto(NodeInterface copy_)
  {
    MultipleReductionCopyMachine copy = (MultipleReductionCopyMachine) copy_;
    super.copyFieldsInto(copy);
    copy.iterationCount = iterationCount;
  }
  public double[][] traverseMusicGraph (double[][] parentTransformation,
                                        Score score)
  {
    double[][] transformation =
      produceOrTransformNotes (parentTransformation, score,
                               score.size(), score.size());
    System.gc ();
    return transformation;
  }
  public void recurse (double[][]compositeTransformation, Score score,
                       int preTraversalCount, int postTraversalCount,
                       int iteration)
  {
    if (iteration < iterationCount)
    {
      iteration++;
      for (int i = 0, n = getChildCount (); i < n; i++)
      {
        double[][] childTransformation = getChild(i).getLocalTransformation();
        double[][] newCompositeTransformation =
          Matrix.times (compositeTransformation, childTransformation);
        recurse (newCompositeTransformation, score, preTraversalCount,
                 postTraversalCount, iteration);
      }
    }
    else
    {
      try
      {
        score.addEvent (Matrix.times (compositeTransformation,
                                      Event.createNote()));
      }
      catch (Exception e)
      {
        e.printStackTrace ();
      }
    }
  }
  public double[][]
    produceOrTransformNotes (double[][]compositeTransformation, Score score,
                             int preTraversalCount, int postTraversalCount)
  {
    int iteration = 0;
    recurse (compositeTransformation,
             score, preTraversalCount, postTraversalCount, iteration);
    return compositeTransformation;
  }
  public void openView ()
  {
    MultipleReductionCopyMachineView view =
      new MultipleReductionCopyMachineView (this);
    view.setVisible (true);
  }
  public Container getView ()
  {
    return new MultipleReductionCopyMachineView (this);
  }
}
