package Silence.Score.Nodes;
import Silence.Orchestra.Event;
import Silence.Score.MasonNumbers;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import Silence.Mathematics.*;
import java.awt.*;
import java.io.*;
import java.util.*;
/**
Generates notes by searching for a chaotic dynamical system defined by a
polynomial equation or partial differential equation using
Julien C. Sprott's Lyupanov exponent search, or by translating a known
chaotic dynamical system into music, by interpreting each iteration
of the system as a note. The time of the note can be represented either
as the order of iteration, or as a dimension of the attractor.
See Julien C. Sprott's book <I><B>Strange Attractors</I></B>.
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class StrangeAttractor extends Node implements NodeInterface,
  java.io.Serializable, StrangeAttractorRenderer
{
  public void initialize (int NMAX, double XMIN, double YMIN, double ZMIN,
			  double WMIN, double XMAX, double YMAX, double ZMAX,
			  double WMAX)
  {
  }
  public StrangeAttractorRenderer renderer;
    byte[] code = null;
  boolean useChords = false;
  String filename;
  int scoreType;
  int NMAX;
  transient double[] A = null;
  transient double AL;
  transient double COSAL;
  transient int D;
  transient int DD;
  transient double D2;
  transient double D2MAX;
  transient double decibels;
  transient double DF;
  transient double DL2;
  transient double DLW;
  transient double DLX;
  transient double DLY;
  transient double DLZ;
  transient double DUM;
  transient double DW;
  transient double DX;
  transient double DY;
  transient double DZ;
  transient double EPS;
  transient double F;
  transient int I;
  transient double instrument;
  transient int I1;
  transient int I2;
  transient int I3;
  transient int I4;
  transient int I5;
  transient int J;
  transient double L;
  transient double duration;
  transient double LSUM;
  transient int M;
  transient double MX;
  transient double MY;
  transient int N;
  transient double N1;
  transient double N2;
  transient double NL;
  transient int O;
  transient double octave;
  transient int ODE;
  transient int OMAX;
  transient int P;
  transient double x;
  transient int PREV;
  transient double PT;
  transient double RAN;
  transient double RS;
  transient double SH;
  transient double SINAL;
  transient double time;
  transient double SW;
  transient int T;
  transient double TIA;
  transient double TT;
  transient int TWOD;
  transient double TWOPI;
  transient double[] V = null;
  transient double W;
  transient double WE;
  transient double WMAX;
  transient double WMIN;
  transient double WNEW;
  transient double WP;
  transient double[] WS = null;
  transient double WSAVE;
  transient double X;
  transient double XA;
  transient double XE;
  transient double XH;
  transient double XL;
  transient double XMAX;
  transient double XMIN;
  transient double[] XN = null;
  transient double XNEW;
  transient double XP;
  transient double[] XS = null;
  transient double XSAVE;
  transient double XW;
  transient double[] XY = null;
  transient double XZ;
  transient double Y;
  transient double YA;
  transient double YE;
  transient double YH;
  transient double YL;
  transient double YMAX;
  transient double YMIN;
  transient double YNEW;
  transient double YP;
  transient double[] YS = null;
  transient double YSAVE;
  transient double YW;
  transient double YZ;
  transient double Z;
  transient double ZA;
  transient double ZE;
  transient double ZMAX;
  transient double ZMIN;
  transient double ZNEW;
  transient double ZP;
  transient double[] ZS = null;
  transient double ZSAVE;
  public StrangeAttractor ()
  {
    super ();
    initialize ();
    defaultsStrangeAttractor ();
    renderer = this;
  }
  public NodeInterface copy()
  {
    StrangeAttractor copy = new StrangeAttractor();
    copyFieldsInto(copy);
    return copy;
  }
  public void copyFieldsInto(NodeInterface copy_)
  {
    StrangeAttractor copy = (StrangeAttractor) copy_;
    super.copyFieldsInto(copy);
    copy.code = code;
    copy.useChords = useChords;
    copy.filename = filename;
    copy.scoreType = scoreType;
    copy.NMAX = NMAX;
  }
  public void initialize ()
  {
    D = 2;
    EPS = .1;
    setIterationCount (4000);
    ODE = 0;
    OMAX = 5;
    PREV = 5;
    A = new double[505];
      V = new double[100];
      WS = new double[500];
      XN = new double[5];
      XS = new double[500];
      XY = new double[5];
      YS = new double[500];
      ZS = new double[500];
  }
  public void defaultsStrangeAttractor ()
  {
    initialize ();
    setLocalScore (new Score ());
    filename = "Strnmus1.srm";
    codeRandomize ();
  }
  public void iterate ()
  {
    if (ODE > 1)
      {
	specialFunctions ();
      }
    else
      {
	M = 1;
	XY[1] = X;
	XY[2] = Y;
	XY[3] = Z;
	XY[4] = W;
	for (I = 1; I <= D; I++)
	  {
	    XN[I] = A[M];
	    M = M + 1;
	    for (I1 = 1; I1 <= D; I1++)
	      {
		XN[I] = XN[I] + A[M] * XY[I1];
		M = M + 1;
		for (I2 = I1; I2 <= D; I2++)
		  {
		    XN[I] = XN[I] + A[M] * XY[I1] * XY[I2];
		    M = M + 1;
		    for (I3 = I2; O > 2 && I3 <= D; I3++)
		      {
			XN[I] = XN[I] + A[M] * XY[I1] * XY[I2] * XY[I3];
			M = M + 1;
			for (I4 = I3; O > 3 && I4 <= D; I4++)
			  {
			    XN[I] =
			      XN[I] +
			      A[M] * XY[I1] * XY[I2] * XY[I3] * XY[I4];
			    M = M + 1;
			    for (I5 = I4; O > 4 && I5 <= D; I5++)
			      {
				XN[I] =
				  XN[I] +
				  A[M] * XY[I1] * XY[I2] * XY[I3] * XY[I4] *
				  XY[I5];
				M = M + 1;
			      }
			  }
		      }
		  }
	      }
	    if (ODE == 1)
	      {
		XN[I] = XY[I] + EPS * XN[I];
	      }
	  }
	XNEW = XN[1];
	YNEW = XN[2];
	ZNEW = XN[3];
	WNEW = XN[4];
      }
    N = N + 1;
    M = M - 1;
    if (N >= 100 && N <= 1000)
      {
	if (X < XMIN)
	  {
	    XMIN = X;
	  }
	if (X > XMAX)
	  {
	    XMAX = X;
	  }
	if (Y < YMIN)
	  {
	    YMIN = Y;
	  }
	if (Y > YMAX)
	  {
	    YMAX = Y;
	  }
	if (Z < ZMIN)
	  {
	    ZMIN = Z;
	  }
	if (Z > ZMAX)
	  {
	    ZMAX = Z;
	  }
	if (W < WMIN)
	  {
	    WMIN = W;
	  }
	if (W > WMAX)
	  {
	    WMAX = W;
	  }
      }
    if (N == 1000)
      {
	if (D == 1)
	  {
	    YMIN = XMIN;
	    YMAX = XMAX;
	  }
	renderer.initialize (NMAX, XMIN, YMIN, ZMIN, WMIN, XMAX, YMAX, ZMAX,
			     WMAX);
      }
    XS[P] = X;
    YS[P] = Y;
    ZS[P] = Z;
    WS[P] = W;
    P = (P + 1) % 500;
    I = (P + 500 - PREV) % 500;
    if (D == 1)
      {
	XP = XS[I];
	YP = XNEW;
      }
    else
      {
	XP = X;
	YP = Y;
      }
  }
  public void specialFunctions ()
  {
    /*
     * Default 3rd and 4th dimension
     */ ZNEW = X * X + Y * Y;
    WNEW = (N - 100) / 900;
    if (N > 1000)
      {
	WNEW = (N - 1000) / (NMAX - 1000);
      }
    switch (ODE)
      {
      case 2:
	M = 10;
	XNEW =
	  A[1] + A[2] * X + A[3] * Y + A[4] * Math.abs (X) +
	  A[5] * Math.abs (Y);
	YNEW =
	  A[6] + A[7] * X + A[8] * Y + A[9] * Math.abs (X) +
	  A[10] * Math.abs (Y);
	break;
      case 3:
	M = 14;
	XNEW =
	  A[1] + A[2] * X + A[3] * Y +
	  ((int) (A[4] * X + .5) & (int) (A[5] * Y + .5)) +
	  ((int) (A[6] * X + .5) | (int) (A[7] * Y + .5));
	YNEW =
	  A[8] + A[9] * X + A[10] * Y +
	  ((int) (A[11] * X + .5) & (int) (A[12] * Y + .5)) +
	  ((int) (A[13] * X + .5) | (int) (A[14] * Y + .5));
	break;
      case 4:
	M = 14;
	XNEW =
	  A[1] + A[2] * X + A[3] * Y + A[4] * Math.pow (Math.abs (X),
							A[5]) +
	  A[6] * Math.pow (Math.abs (Y), A[7]);
	YNEW =
	  A[8] + A[9] * X + A[10] * Y + A[11] * Math.pow (Math.abs (X),
							  A[12]) +
	  A[13] * Math.pow (Math.abs (Y), A[14]);
	break;
      case 5:
	M = 18;
	XNEW =
	  A[1] + A[2] * X + A[3] * Y + A[4] * Math.sin (A[5] * X + A[6]) +
	  A[7] * Math.sin (A[8] * Y + A[9]);
	YNEW =
	  A[10] + A[11] * X + A[12] * Y + A[13] * Math.sin (A[14] * X +
							    A[15]) +
	  A[16] * Math.sin (A[17] * Y + A[18]);
	break;
      case 6:
	M = 6;
	if (N < 2)
	  {
	    AL = Maths.TWO_PI / (13 + 10 * A[6]);
	    SINAL = Math.sin (AL);
	    COSAL = Math.cos (AL);
	  }
	DUM = X + A[2] * Math.sin (A[3] * Y + A[4]);
	XNEW = 10 * A[1] + DUM * COSAL + Y * SINAL;
	YNEW = 10 * A[5] - DUM * SINAL + Y * COSAL;
	break;
      case 7:
	M = 9;
	XNEW = X + EPS * A[1] * Y;
	YNEW =
	  Y + EPS * (A[2] * X + A[3] * X * X * X + A[4] * X * X * Y +
		     A[5] * X * Y * Y + A[6] * Y + A[7] * Y * Y * Y +
		     A[8] * Math.sin (Z));
	ZNEW = Z + EPS * (A[9] + 1.3);
	if (ZNEW > Maths.TWO_PI)
	  {
	    ZNEW = ZNEW - Maths.TWO_PI;
	  }
      }
  }
  public void getDimensionAndOrder ()
  {
    D = 1 + (int) (Math.floor ((code[0] - 65) / 4));
    if (D > 6)
      {
	ODE = code[0] - 87;
	D = 4;
	specialFunctions ();
      }
    else
      {
	if (D > 4)
	  {
	    D = D - 2;
	    ODE = 1;
	  }
	else
	  {
	    ODE = 0;
	  }
	O = 2 + (code[0] - 65) % 4;
	M = 1;
	for (I = 1; I <= D; I++)
	  {
	    M = M * (O + I);
	  }
	if (D > 2)
	  {
	    for (I = 3; I <= D; I++)
	      {
		M = M / (I - 1);
	      }
	  }
      }
    if (code.length != M + 1)
      {
	while (code.length < M + 1)
	  {
	    //code = code + "M";
	  }
	if (code.length > M + 1)
	  {
	    code[M + 1] = 0;
	  }
      }
  }
  public void getCoefficients ()
  {
    getDimensionAndOrder ();
    for (I = 1; I <= M; I++)
      {
	A[I] = (code[I] - 77) / 10.0;
      }
  }
  public int getIterationCount ()
  {
    return NMAX - 1000;
  }
  public void setIterationCount (int newValue)
  {
    NMAX = newValue + 1000;
  }
  public int getIteration ()
  {
    return N;
  }
  public void setIteration (int newValue)
  {
    N = newValue;
  }
  public void reinitialize ()
  {
    XMAX = XMIN = X = .05;
    YMAX = YMIN = Y = .05;
    ZMAX = ZMIN = Z = .05;
    WMAX = WMIN = W = .05;
    XE = X + .000001;
    YE = Y;
    ZE = Z;
    WE = W;
    LSUM = 0;
    N = 1;
    getCoefficients ();
    P = 0;
    LSUM = 0;
    NL = 0;
    N1 = 0;
    N2 = 0;
    TWOD = D << 1;
  }
  public void calculateLyupanovExponent ()
  {
    XSAVE = XNEW;
    YSAVE = YNEW;
    ZSAVE = ZNEW;
    WSAVE = WNEW;
    X = XE;
    Y = YE;
    Z = ZE;
    W = WE;
    N = N - 1;
    iterate ();
    DLX = XNEW - XSAVE;
    DLY = YNEW - YSAVE;
    DLZ = ZNEW - ZSAVE;
    DLW = WNEW - WSAVE;
    DL2 = DLX * DLX + DLY * DLY + DLZ * DLZ + DLW * DLW;
    if (DL2 > 0)
      {
	DF = 1E12 * DL2;
	RS = 1 / Math.sqrt (DF);
	XE = XSAVE + RS * (XNEW - XSAVE);
	YE = YSAVE + RS * (YNEW - YSAVE);
	ZE = ZSAVE + RS * (ZNEW - ZSAVE);
	WE = WSAVE + RS * (WNEW - WSAVE);
	XNEW = XSAVE;
	YNEW = YSAVE;
	ZNEW = ZSAVE;
	WNEW = WSAVE;
	LSUM = LSUM + Math.log (DF);
	NL = NL + 1;
	L = .721347 * LSUM / NL;
	if (ODE == 1 || ODE == 7)
	  {
	    L = L / EPS;
	  }
      }
  }
  public void calculateFractalDimension ()
  {
    /*
     * Wait for transient to settle
     */ if (N >= 1000)
      {
	if (N == 1000)
	  {
	    D2MAX = Math.pow (XMAX - XMIN, 2);
	    D2MAX = D2MAX + Math.pow (YMAX - YMIN, 2);
	    D2MAX = D2MAX + Math.pow (ZMAX - ZMIN, 2);
	    D2MAX = D2MAX + Math.pow (WMAX - WMIN, 2);
	  }
	J = (P + 1 + ((int) (Math.floor (480 * Math.random ())))) % 500;
	DX = XNEW - XS[J];
	DY = YNEW - YS[J];
	DZ = ZNEW - ZS[J];
	DW = WNEW - WS[J];
	D2 = DX * DX + DY * DY + DZ * DZ + DW * DW;
	if (D2 < .001 * TWOD * D2MAX)
	  {
	    N2 = N2 + 1;
	  }
	if (D2 <= .00001 * TWOD * D2MAX)
	  {
	    N1 = N1 + 1;
	    F = .434294 * Math.log (N2 / (N1 - .5));
	  }
      }
  }
  public double getX ()
  {
    return X;
  }
  public void setX (double newValue)
  {
    X = newValue;
  }
  public double getY ()
  {
    return Y;
  }
  public void setY (double newValue)
  {
    Y = newValue;
  }
  public double getZ ()
  {
    return Z;
  }
  public void setZ (double newValue)
  {
    Z = newValue;
  }
  public double getW ()
  {
    return W;
  }
  public void setW (double newValue)
  {
    W = newValue;
  }
  public double getFractalDimension ()
  {
    return F;
  }
  public void setFractalDimension (double newValue)
  {
    F = newValue;
  }
  public double getLyupanovExponent ()
  {
    return L;
  }
  public void setLyupanovExponent (double newValue)
  {
    L = newValue;
  }
  public int getScoreType ()
  {
    return scoreType;
  }
  public void setScoreType (int newValue)
  {
    scoreType = newValue;
  }
  public void render (int N, double X, double Y, double Z, double W)
  {
    switch (D)
      {
      case 1:
	instrument = 1.0;
	time = ((double) N) / 8.0;
	duration = 0.25;
	octave = X;
	decibels = 70.0;
	x = Math.random () * 2.0 - 1.0;
	break;
	case 2:switch (scoreType)
	  {
	  case 1:
	    instrument = X;
	    time = ((double) N) / 8.0;
	    duration = 0.25;
	    octave = Y;
	    decibels = 70.0;
	    x = Math.random () * 2.0 - 1.0;
	    break;
	    case 0:instrument = 1.0;
	    time = X;
	    duration = 0.25;
	    octave = Y;
	    decibels = 70.0;
	    x = Math.random () * 2.0 - 1.0;
	    break;
	  }
	break;
      case 3:
	switch (scoreType)
	  {
	  case 1:
	    instrument = X;
	    time = ((double) N) / 8.0;
	    duration = 0.25;
	    octave = Y;
	    decibels = Z;
	    x = Math.random () * 2.0 - 1.0;
	    break;
	  case 0:
	    instrument = Z;
	    time = X;
	    duration = 0.25;
	    octave = Y;
	    decibels = 70.0;
	    x = Math.random () * 2.0 - 1.0;
	    break;
	  }
	break;
      case 4:
	switch (scoreType)
	  {
	  case 1:
	    instrument = X;
	    time = ((double) N) / 8.0;
	    duration = W;
	    octave = Y;
	    decibels = ((double) Z);
	    x = Math.random () * 2.0 - 1.0;
	    break;
	  case 0:
	    instrument = Z;
	    time = X;
	    duration = 0.25;
	    octave = Y;
	    decibels = W;
	    x = Math.random () * 2.0 - 1.0;
	    break;
	  }
	break;
      }
    double[] note =
      Event.createNote (instrument, time, duration, octave, decibels, 0.0, x,
			0.0, 0.0, 4095);
      score.addEvent (note);
  }
  public void shuffleRandomNumbers ()
  {
    if (V[0] == 0)
      {
	for (J = 0; J <= 99; J++)
	  {
	    V[J] = Math.random ();
	  }
      }
    J = (int) Math.floor (100 * RAN);
    RAN = V[J];
    V[J] = Math.random ();
  }
  public int getAttractorType ()
  {
    if (ODE == 0)
      {
	return D;
      }
    if (ODE == 1)
      {
	return D + 2;
      }
    return D + 1 + ODE;
  }
  public void setAttractorType (int newValue)
  {
    D = newValue;
    if (D > 6)
      {
	ODE = D - 5;
	D = 4;
      }
    else
      {
	if (D > 4)
	  {
	    ODE = 1;
	    D = D - 2;
	  }
	else
	  ODE = 0;
      }
  }
  public boolean evaluateAttractor ()
  {
    if (N == 1)
      {
	score.clear ();
	reinitialize ();
      }
    if (N >= NMAX)
      {
	return false;
      }
    iterate ();
    if (N >= 1000)
      {
	calculateFractalDimension ();
	calculateLyupanovExponent ();
      }
    X = XNEW;
    Y = YNEW;
    Z = ZNEW;
    W = WNEW;
    if (N >= 1000 && N < NMAX)
      {
	renderer.render (N, X, Y, Z, W);
      }
    return true;
  }
  public boolean searchForAttractor ()
  {
    //      On the first iteration, generate a new code.
    if (N == 1)
      {
	codeRandomize ();
	reinitialize ();
      }
    iterate ();
    if (N >= 100)
      {
	calculateFractalDimension ();
	calculateLyupanovExponent ();
      }
    //      The attractor at infinity has been found.
    if (
	(Math.abs (XNEW) + Math.abs (YNEW) + Math.abs (ZNEW) +
	 Math.abs (WNEW)) > 1000000)
      {
	//      It can't be musical, so force an immediate new search.
	N = 1;
	return true;
      }
    //      A strange attractor has been found.
    if (N >= NMAX)
      {
	//      End the search.
	return false;
      }
    //      The attractor at zero has been found.
    if (
	(Math.abs (XNEW - X) + Math.abs (YNEW - Y) + Math.abs (ZNEW - Z) +
	 Math.abs (WNEW - W)) < .000001)
      {
	//      It can't be musical, so force an immediate new search.
	N = 1;
	return true;
      }
    //      A periodic attractor has been found.
    if ((N > 100) && (L < 0.005))
      {
	//      Force an immediate new search.
	N = 1;
	return true;
      }
    X = XNEW;
    Y = YNEW;
    Z = ZNEW;
    W = WNEW;
    //      Keep iterating.
    return true;
  }
  public void codeRandomize ()
  {
    O = 2 + (int) (Math.floor (OMAX - 1) * Math.random ());
    code = new byte[600];
    code[0] = (byte) (59 + 4 * D + O + 8 * ODE);
    if (ODE > 1)
      {
	code[0] = (byte) (87 + ODE);
      }
    //      Get value of M.
    getDimensionAndOrder ();
    for (I = 1; I <= M; I++)
      {
	shuffleRandomNumbers ();
	code[I] = (byte) (65 + ((int) Math.floor (25 * RAN)));
      }
    code[M + 1] = 0;
  }
  public String getCode ()
  {
    return new String (code);
  }
  public void setCode (String newValue)
  {
    code = newValue.getBytes ();
  }
  public String getFilename ()
  {
    return filename;
  }
  public void setFilename (String newValue)
  {
    filename = newValue.trim ();
  }
  public void openView ()
  {
    StrangeAttractorView strangeAttractorView =
      new StrangeAttractorView (this);
      strangeAttractorView.setVisible (true);
  }
  public boolean generate ()
  {
    try
    {
      for (N = 1; evaluateAttractor ();)
	{
	}
      if (score.autoRescale)
	{
	  score.setActualScaleToTarget ();
	}
    }
    catch (Exception e)
    {
      e.printStackTrace ();
      return false;
    }
    return true;
  }
  public double[][] produceOrTransformNotes (double[][]compositeTransform,
					     Score score, int beginIndex,
					     int endIndex)
  {
    try
    {
      int n = this.score.size ();
      for (int i = 0; i < n; i++)
	{
	  double[] note = this.score.getEvent (i);
	  double[] transformedNote = Matrix.times (compositeTransform, note);
	    score.addEvent (transformedNote);
	}
    }
    catch (Exception e)
    {
      e.printStackTrace ();
    }
    return compositeTransform;
  }
  public static void main (String args[])
  {
    StrangeAttractor strangeAttractor = new StrangeAttractor ();
      strangeAttractor.openView ();
  }
  public Container getView ()
  {
    return new StrangeAttractorView (this);
  }
}
