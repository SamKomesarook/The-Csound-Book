package Silence.Score.Nodes;
import cern.jet.random.Uniform;
import java.awt.Container;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.table.AbstractTableModel;
import Silence.Global;
import Silence.Mathematics.Matrix;
import Silence.MatrixTableModel;
import Silence.Orchestra.Event;
import Silence.Score.NodeInterface;
import Silence.Score.Score;
/**
 * Title:        Silence
 * Description:  A user-extensible system for making music by means of software alone.
 * Copyright:    Copyright (c) 2002
 * Company:      Irreducible Productions
 * @author
 * @version 1.0
 */
public class IFS2D extends ScoreNode implements Runnable
{
  public static void main(String[] args)
  {
    JFrame frame = new JFrame("IFS2D");
    IFS2D ifs2d = new IFS2D();
    IFS2DView ifs2dView = (IFS2DView) ifs2d.getView();
    ifs2dView.setVisible(true);
    frame.getContentPane().add(ifs2dView);
    frame.setBounds(50, 50, 800, 600);
    frame.setVisible(true);
  }
  String filename = Global.generateDateFilename(IFS2D_EXTENSION);
  ArrayList hutchinsonOperator = new ArrayList();
  double[][] markov = new double[0][];
  int noteCount = 2000;
  double xMinimum = 0;
  double xMaximum = 0;
  double xRange = 0;
  double yMinimum = 0;
  double yMaximum = 0;
  double yRange = 0;
  double iterateForSeconds = 20;
  public static final String IFS2D_EXTENSION = "i2d";
  public static int SCORE_INSTRUMENT_INDEX = 0;
  public static int SCORE_TIME_INDEX = 1;
  public static int SCORE_DURATION_INDEX = 2;
  public static int SCORE_KEY_INDEX = 3;
  public static int SCORE_PITCH_CLASS_SET_INDEX = 4;
  public static int SCORE_VELOCITY_INDEX = 5;
  public static int SCORE_PAN_INDEX = 6;
  public static int SCORE_DIMENSION_COUNT = 7;
  transient double[][][] hutchinson = null;
  transient double[][] measure = null;
  transient Uniform wheel = null;
  transient double[] oldPoint = null;
  transient double[] newPoint = null;
  transient int affineTransformationIndex = 0;
  transient int iterationCount = 0;
  public class HutchinsonTableModel extends AbstractTableModel
  {
    String[] columnNames =
      {
      "a", "b", "c", "d", "e", "f"
    };
    public int getRowCount()
    {
      return hutchinsonOperator.size();
    }
    public int getColumnCount()
    {
      return columnNames.length;
    }
    public Object getValueAt(int row, int column)
    {
      double[][] transform = (double[][]) hutchinsonOperator.get(row);
      switch(column)
      {
      case 0:
        return String.valueOf(transform[0][0]);
      case 1:
        return String.valueOf(transform[0][1]);
      case 2:
        return String.valueOf(transform[1][0]);
      case 3:
        return String.valueOf(transform[1][1]);
      case 4:
        return String.valueOf(transform[0][2]);
      case 5:
        return String.valueOf(transform[1][2]);
      }
      return null;
    }
    public void setValueAt(Object value, int row, int column)
    {
      double[][] transform = (double[][]) hutchinsonOperator.get(row);
      double v = Double.valueOf(value.toString()).doubleValue();
      switch(column)
      {
      case 0:
        transform[0][0] = v;
        break;
      case 1:
        transform[0][1] = v;
        break;
      case 2:
        transform[1][0] = v;
        break;
      case 3:
        transform[1][1] = v;
        break;
      case 4:
        transform[0][2] = v;
        break;
      case 5:
        transform[1][2] = v;
        break;
      }
    }
    public boolean isCellEditable(int row, int column)
    {
      return true;
    }
    public String getColumnName(int column)
    {
      return columnNames[column];
    }
  }
  public class MarkovTableModel extends AbstractTableModel
  {
    public int getRowCount()
    {
      return markov.length;
    }
    public int getColumnCount()
    {
      return markov.length;
    }
    public Object getValueAt(int row, int column)
    {
      return String.valueOf(markov[row][column]);
    }
    public void setValueAt(Object value, int row, int column)
    {
      double v = Double.valueOf(value.toString()).doubleValue();
      markov[row][column] = v;
    }
    public boolean isCellEditable(int row, int column)
    {
      return true;
    }
    public String getColumnName(int column)
    {
      return String.valueOf(column + 1);
    }
  }
  public IFS2D()
  {
    setLocalScore(new Score());
    defaultsIFS2D();
  }
  public NodeInterface copy()
  {
    IFS2D copy = new IFS2D();
    copyFieldsInto(copy);
    return copy;
  }
  public void copyFieldsInto(NodeInterface copy_)
  {
    IFS2D copy = (IFS2D) copy_;
    super.copyFieldsInto(copy);
    copy.hutchinsonOperator.clear();
    for(int i = 0; i < hutchinsonOperator.size(); i++)
    {
      double[][] transform = (double[][]) hutchinsonOperator.get(i);
      copy.hutchinsonOperator.add(transform.clone());
    }
    copy.markov = (double[][]) markov.clone();
    copy.noteCount = noteCount;
    copy.xMinimum = xMinimum;
    copy.xMaximum = xMaximum;
    copy.xRange = xRange;
    copy.yMinimum = yMinimum;
    copy.yMaximum = yMaximum;
    copy.yRange = yRange;
    copy.iterateForSeconds = 20;
  }
  public void defaultsIFS2D()
  {
    score.clear();
    hutchinsonOperator.clear();
    addHutchinsonOperatorMatrix();
    addHutchinsonOperatorMatrix();
    initializeForIteration();
  }
  public void measureToScore()
  {
    System.out.println("BEGAN IFS2D.measureToScore()...");
    System.out.println("xMinimum = " + xMinimum);
    System.out.println("xMaximum = " + xMaximum);
    System.out.println("xRange   = " + xRange);
    System.out.println("yMinimum = " + yMinimum);
    System.out.println("yMaximum = " + yMaximum);
    System.out.println("yRange   = " + yRange);
    score.clear();
    double instrument = 0;
    double time = 0;
    double duration = 0;
    double key = 0;
    double velocity = 0;
    double phase = 0;
    double x = 0;
    double y = 0;
    double z = 0;
    double pitchClassSet = 0;
    double[] row = null;
    System.out.println("measure.length = " + measure.length + ".");
    for(int rowIndex = 0; rowIndex < measure.length; rowIndex++)
    {
      row = measure[rowIndex];
      duration = row[SCORE_DURATION_INDEX];
      velocity = row[SCORE_VELOCITY_INDEX];
      if(duration > 0 && velocity > 0)
      {
        instrument = row[SCORE_INSTRUMENT_INDEX];
        time = row[SCORE_TIME_INDEX];
        key = row[SCORE_KEY_INDEX];
        pitchClassSet = row[SCORE_PITCH_CLASS_SET_INDEX];
        x = row[SCORE_PAN_INDEX];
        double[] note = Event.createNote(instrument,
                                         time,
                                         duration,
                                         key,
                                         velocity,
                                         phase, x, y, z, pitchClassSet);
        score.add(note);
        System.out.println("Added note [" + score.size() + "] = " + Event.toString(note) + ".");
      }
    }
    if(score.autoRescale)
    {
      score.setActualScaleToTarget();
    }
    System.out.println("ENDED IFS2D.measureToScore().");
  }
  public void accumulate(double[] point)
  {
    double x = point[0];
    double y = point[1];
    x -= xMinimum;
    x /= xRange;
    y -= yMinimum;
    y /= yRange;
    x *= SCORE_PAN_INDEX;
    y *= noteCount;
    int row = (int) y;
    if(row < 0 || row >= noteCount)
    {
      return;
    }
    int column = (int) x;
    if(column < 0 || column > SCORE_PAN_INDEX)
    {
      return;
    }
    measure[row][column] += 1;
  }
  public void bound(double[] point)
  {
    if(point[0] < xMinimum)
    {
      xMinimum = point[0];
      xRange = xMaximum - xMinimum;
    }
    else if(point[0] > xMaximum)
    {
      xMaximum = point[0];
      xRange = xMaximum - xMinimum;
    }
    if(point[1] < yMinimum)
    {
      yMinimum = point[1];
      yRange = yMaximum - yMinimum;
    }
    else if(point[1] > yMaximum)
    {
      yMaximum = point[1];
      yRange = yMaximum - yMinimum;
    }
  }
  public void initializeForIteration()
  {
    score.clear();
    wheel = new Uniform(0, 1, (int) System.currentTimeMillis());
    normalizeMarkov();
    measure = Matrix.create(noteCount, SCORE_DIMENSION_COUNT);
    hutchinson = (double[][][]) hutchinsonOperator.toArray(new double[0][][]);
    affineTransformationIndex = 0;
    xMinimum = 0;
    xMaximum = 0;
    xRange = 0;
    yMinimum = 0;
    yMaximum = 0;
    yRange = 0;
    newPoint = Matrix.createHomogeneousVector(3);
    oldPoint = Matrix.createHomogeneousVector(3);
    iterationCount = 0;
  }
  public void run()
  {
    initializeForIteration();
    while(!iterationThread.interrupted())
    {
      iterationCount++;
      if((iterationCount % 100000) == 0)
      {
        System.out.println("iterationCount = " + iterationCount);
      }
      affineTransformationIndex = monteCarlo(affineTransformationIndex);
      Matrix.times(newPoint,
                   hutchinson[affineTransformationIndex], oldPoint);
      if(iterationCount < 100000)
      {
        bound(newPoint);
      }
      else
      {
        accumulate(newPoint);
      }
      Matrix.assign(oldPoint, newPoint);
    }
    measureToScore();
  }
  /**
   * Returns the next row index.
   */
  public int monteCarlo (int rowIndex)
  {
    if (rowIndex < 0 || rowIndex >= markov.length)
    {
      return 0;
    }
    double slot = 0;
    double ball = wheel.nextDouble ();
    for (int columnIndex = 0; true; columnIndex++)
    {
      slot += markov[rowIndex][columnIndex];
      if (slot >= ball || columnIndex >= markov.length)
      {
        return columnIndex;
      }
    }
  }
  transient Thread iterationThread = null;
  public void start()
  {
    stop();
    iterationThread = new Thread(this);
    iterationThread.start();
  }
  public void stop()
  {
    try
    {
      if(iterationThread == null)
      {
        return;
      }
      iterationThread.interrupt();
      iterationThread.join(100000);
      iterationThread = null;
    }
    catch(Exception x)
    {
      x.printStackTrace();
    }
  }
  public void normalizeMarkov ()
  {
    for (int i = 0; i < markov.length; i++)
    {
      double sum = 0;
      for (int j = 0; j < markov[i].length; j++)
      {
        sum += markov[i][j];
      }
      for (int j = 0; j < markov[i].length; j++)
      {
        markov[i][j] /= sum;
      }
    }
  }
  public void addHutchinsonOperatorMatrix ()
  {
    hutchinsonOperator.add (Matrix.identity (3));
    int hutchinsonOperatorMatrixCount = hutchinsonOperator.size();
    double[][] oldMarkovOperator = (double[][]) markov.clone ();
    markov = new double[hutchinsonOperatorMatrixCount][hutchinsonOperatorMatrixCount];
    for (int i = 0; i < oldMarkovOperator.length; i++)
    {
      for (int j = 0; j < oldMarkovOperator[i].length; j++)
      {
        markov[i][j] = oldMarkovOperator[i][j];
      }
    }
  }
  public void removeHutchinsonOperatorMatrix (int index)
  {
    hutchinsonOperator.remove (index);
    int hutchinsonOperatorMatrixCount = hutchinsonOperator.size();
    double[][] oldMarkovOperator = (double[][]) markov.clone ();
    markov = new double[hutchinsonOperatorMatrixCount][hutchinsonOperatorMatrixCount];
    for (int i = 0; i < index - 1; i++)
    {
      for (int j = 0; j < index - 1; j++)
      {
        markov[i][j] = oldMarkovOperator[i][j];
      }
    }
    for (int i = index; i < oldMarkovOperator.length; i++)
    {
      for (int j = index; j < oldMarkovOperator.length; j++)
      {
        markov[i - 1][j - 1] = oldMarkovOperator[i][j];
      }
    }
  }
  public void openView ()
  {
    IFS2DView view = new IFS2DView (this);
    view.setVisible (true);
  }
  public Container getView ()
  {
    IFS2DView view = new IFS2DView (this);
    return view;
  }
  public String getFilename()
  {
    return filename;
  }
  public void setFilename(String filename)
  {
    this.filename = filename;
  }
}
