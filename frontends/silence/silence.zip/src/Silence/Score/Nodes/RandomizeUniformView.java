package Silence.Score.Nodes;
import Silence.MatrixEditor;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import Silence.Orchestra.Event;
import java.awt.*;
import javax.swing.*;
import javax.swing.table.*;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
/**
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class RandomizeUniformView extends javax.swing.JInternalFrame
{
  RandomizeUniform randomizeUniform = null;
  MatrixEditor matrixEditor = null;
  public RandomizeUniformView (RandomizeUniform t)
  {
    this ();
    randomizeUniform = t;
    matrixEditor = new MatrixEditor ();
    String[] rowLabels = Event.labels;
    String[] columnLabels =
    {
      "Dim", "Status", "Instr", "Time", "Duration", "Octave", "Decibels",
	"Phase", "X", "Y", "Z", "Mason", "Move"};
      matrixEditor.create (t.M, columnLabels, rowLabels);
      matrixEditor.setFont (new Font ("Dialog", Font.PLAIN, 12));
      transformPanel.setLayout (new BorderLayout ());
      transformPanel.add ("Center", matrixEditor);
      updateView ();
      setTitle ("RandomizeUniform");
  }

  void updateView ()
  {
    nameField.setText (randomizeUniform.getName ());
    notesToGenerateField.
      setText (String.valueOf (randomizeUniform.notesToGenerateCount));
    incrementTimeCheckbox.setSelected (randomizeUniform.getIncrementTime ());
  }
  void updateModel ()
  {
    randomizeUniform.setName (nameField.getText ());
    randomizeUniform.notesToGenerateCount =
      Integer.parseInt (notesToGenerateField.getText ());
    randomizeUniform.setIncrementTime (incrementTimeCheckbox.isSelected ());
  }
  public RandomizeUniformView ()
  {
    super ("RandomizeUniform");
    setTitle ("RandomizeUniform");
    getContentPane ().setLayout (null);
    setVisible (false);
    setSize (640, 480);
    setBackground (new Color (8421504));
    namePanel = new javax.swing.JPanel ();
    namePanel.setLayout (null);
    namePanel.setBounds (12, 12, 672, 72);
    namePanel.setFont (new Font ("Dialog", Font.BOLD, 12));
    namePanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (namePanel);
    nameField = new javax.swing.JTextField ();
    nameField.setBounds (12, 36, 648, 24);
    nameField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    namePanel.add (nameField);
    jLabel1 = new javax.swing.JLabel ();
    jLabel1.setText ("Name");
    jLabel1.setHorizontalAlignment (0);
    jLabel1.setHorizontalTextPosition (0);
    jLabel1.setBounds (12, 0, 648, 26);
    jLabel1.setFont (new Font ("Dialog", Font.BOLD, 12));
    namePanel.add (jLabel1);
    transformPanel = new javax.swing.JPanel ();
    transformPanel.setBounds (12, 96, 672, 300);
    transformPanel.setFont (new Font ("Dialog", Font.BOLD, 12));
    transformPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (transformPanel);
    parametersPanel = new javax.swing.JPanel ();
    parametersPanel.setAlignmentY (0.478261F);
    parametersPanel.setLayout (null);
    parametersPanel.setBounds (12, 408, 672, 72);
    parametersPanel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (parametersPanel);
    notesToGenerateField = new javax.swing.JTextField ();
    notesToGenerateField.setBounds (120, 36, 85, 24);
    notesToGenerateField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (notesToGenerateField);
    notesToGenerateLabel = new javax.swing.JLabel ();
    notesToGenerateLabel.setText ("Notes to generate");
    notesToGenerateLabel.setBounds (12, 36, 98, 24);
    notesToGenerateLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (notesToGenerateLabel);
    incrementTimeCheckbox = new javax.swing.JCheckBox ();
    incrementTimeCheckbox.setText ("Increment time");
    incrementTimeCheckbox.setActionCommand ("Increment time");
    incrementTimeCheckbox.setBounds (228, 36, 109, 24);
    incrementTimeCheckbox.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (incrementTimeCheckbox);
    parametersLabel = new javax.swing.JLabel ();
    parametersLabel.setText ("Parameters");
    parametersLabel.setHorizontalAlignment (0);
    parametersLabel.setHorizontalTextPosition (0);
    parametersLabel.setBounds (12, 0, 648, 26);
    parametersLabel.setFont (new Font ("Dialog", Font.BOLD, 12));
    parametersPanel.add (parametersLabel);
    buttonPanel = new javax.swing.JPanel ();
    buttonPanel.setLayout (null);
    buttonPanel.setBounds (12, 492, 672, 48);
    buttonPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (buttonPanel);
    okButton = new javax.swing.JButton ();
    okButton.setText ("Update");
    okButton.setBounds (12, 12, 104, 24);
    buttonPanel.add (okButton);
    SymAction lSymAction = new SymAction ();
      okButton.addActionListener (lSymAction);
  }
  javax.swing.JPanel namePanel;
  javax.swing.JTextField nameField;
  javax.swing.JLabel jLabel1;
  javax.swing.JPanel transformPanel;
  javax.swing.JPanel parametersPanel;
  javax.swing.JTextField notesToGenerateField;
  javax.swing.JLabel notesToGenerateLabel;
  javax.swing.JCheckBox incrementTimeCheckbox;
  javax.swing.JLabel parametersLabel;
  javax.swing.JPanel buttonPanel;
  javax.swing.JButton okButton;
  class SymAction implements java.awt.event.ActionListener
  {
    public void actionPerformed (java.awt.event.ActionEvent event)
    {
      Object object = event.getSource ();
      if (object == okButton)
	  okButton_Action (event);
    }
  }
  void okButton_Action (java.awt.event.ActionEvent event)
  {
    updateModel ();
    updateView ();
  }
}
