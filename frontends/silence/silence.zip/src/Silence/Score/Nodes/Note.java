package Silence.Score.Nodes;
import Silence.Conversions;
import Silence.Orchestra.Event;
import Silence.Orchestra.Test;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import Silence.Mathematics.*;
import javax.sound.midi.*;
import java.awt.Container;
import java.io.*;
import java.text.*;
import java.util.*;
import javax.swing.*;
import javax.swing.table.*;
/**
Produces exactly one note as a column vector in the homogeneous linear space
{status, instrument, time, duration, octave, decibels, phase, x, y, z, Mason number, 1}.
The status dimension has the same value as the high-order nybble
of a Midi status byte; for example, status 144 means a regular note.
The Note class data consists of a double array that is identical to the array
used by {@link Silence.Noise.Event Silence.Noise.Event}
to represent musical notes and/or MIDI events as arrays. However,
in addition, the Note class is an NodeInterface and has convenience methods for
translation to and from Csound score lines.
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class Note extends Node implements NodeInterface, java.io.Serializable
{
  public static void main (String[]args)
  {
    JFrame frame = new JFrame ();
    JScrollPane scrollPane = new JScrollPane ();
      frame.getContentPane ().add (scrollPane);
    JTable table = new JTable ();
      scrollPane.getViewport ().add (table);
    Note note = new Note ();
      table.setModel (note.getTableModel ());
      frame.setBounds (50, 50, 400, 400);
      frame.setVisible (true);
      Test.serializationTest (note);
  }
  public static class MidiEventComparator implements Comparator
  {
		/**
		Compares in order of increasing time, then decreasing MIDI status.
		*/ public int compare (Object A, Object B)
    {
      MidiEvent a = (MidiEvent) A;
      MidiEvent b = (MidiEvent) B;
      if (a.getTick () < b.getTick ())
	{
	  return -1;
	}
      else if (a.getTick () > b.getTick ())
	{
	  return 1;
	}
      else if (a.getMessage ().getStatus () < b.getMessage ().getStatus ())
	{
	  return -1;
	}
      else if (a.getMessage ().getStatus () > b.getMessage ().getStatus ())
	{
	  return 1;
	}
      else
	return 0;
    }
    public boolean equals (Object a, Object b)
    {
      return a == b;
    }
  }
  public static transient MidiEventComparator midiEventComparator = null;
  double[] event = null;
  static DecimalFormat decimalFormat = null;
  public Note ()
  {
    defaultsNote ();
  }
  public NodeInterface copy()
  {
    Note copy = new Note();
    copyFieldsInto(copy);
    return copy;
  }
  public void copyFieldsInto(NodeInterface copy_)
  {
    Note copy = (Note) copy_;
    super.copyFieldsInto(copy);
    copy.event = (double[]) event.clone();
  }
  public void defaultsNote ()
  {
    event = Event.createEvent (144, 0, 0, 1, 60, 60, 0, 0, 0, 0, 4095);
  }
  public Object clone ()
  {
    Note myClone = new Note ();
      myClone.event = (double[]) event.clone ();
      return myClone;
  }
  public Note (double instrument, double start, double length, double octave,
	       double decibels, double phase, double x, double y, double z,
	       double mason)
  {
    event =
      Event.createEvent (144, instrument, start, length, octave, decibels,
			 phase, x, y, z, mason);
  }
  public double[] getElements ()
  {
    return event;
  }
  public void setElements (double[]value)
  {
    event = value;
  }
  public double getPField (int index)
  {
    return event[index];
  }
  public void setPField (int index, double value)
  {
    event[index] = value;
  }
  public int getPFieldCount ()
  {
    return event.length;
  }
  public void setPFieldCount (int value)
  {
    event = new double[value];
  }
  public double[][] produceOrTransformNotes (double[][]compositeTransform,
					     Score score,
					     int preTraversalCount,
					     int postTraversalCount)
  {
    try
    {
      double[] note = Matrix.times (compositeTransform, event);
        score.addEvent (note);
    }
    catch (Exception e)
    {
      e.printStackTrace ();
    }
    return compositeTransform;
  }
	/**
	Returns a string formatted as a valid SASL line.
	Mapping is as follows:
	<pre>
	SASL	SILENCE
	p1		p2 	time
	p2		p1	"iN"
	p3		p3	duration
	p4		p4	MIDI key
	p5		p5	MIDI velocity
	p6		p6	phase
	p7		p7	X
	p8		p8	Y
	p9		p9	Z
	p10		p10 Mason number
	</pre>
	*/
  public String getSASLString ()
  {
    decimalFormat.setGroupingUsed (false);
    decimalFormat.setMaximumFractionDigits (14);
    StringBuffer saslBuffer = new StringBuffer ();
      saslBuffer.append (decimalFormat.format (getTime ()));
      saslBuffer.append (" ");
      saslBuffer.append ("i");
      saslBuffer.append (Math.round (getInstrument ()));
      saslBuffer.append (" ");
      saslBuffer.append (decimalFormat.format (getDuration ()));
      saslBuffer.append (" ");



























       saslBuffer.append (decimalFormat.format (Conversions.octaveToMidi (getOctave ())));
      saslBuffer.append (" ");
      saslBuffer.append (decimalFormat.format (getDecibels ()));
      saslBuffer.append (" ");
      saslBuffer.append (decimalFormat.format (getPhase ()));
      saslBuffer.append (" ");
      saslBuffer.append (decimalFormat.format (getX ()));
      saslBuffer.append (" ");
      saslBuffer.append (decimalFormat.format (getY ()));
      saslBuffer.append (" ");
      saslBuffer.append (decimalFormat.format (getZ ()));
      saslBuffer.append (" ");
      saslBuffer.append (decimalFormat.format (getMason ()));
      return saslBuffer.toString ();
  }
	/**
	Returns a string formatted in such a way that it can be read
	without error by the Csound score parser, that is, without exponential notation.
	*/
  public String getCsoundString ()
  {
    String lineBuffer = new String ("i");
    String numberBuffer = null;
    double pfield;
      decimalFormat.setGroupingUsed (false);
      decimalFormat.setMaximumFractionDigits (14);
    for (int i = Event.INSTRUMENT; i < Event.ELEMENT_COUNT; ++i)
      {
	pfield = getPField (i);
	numberBuffer = decimalFormat.format (pfield);
	lineBuffer = lineBuffer + " " + numberBuffer;
      }
    return lineBuffer;
  }
	/**
	Returns a string formatted in such a way that it can be read
	without error by the Csound score parser, that is, without exponential notation;
	pitch is rounded off to the nearest equally tempered pitch.
	*/
  public String getCsoundString (double temperament)
  {
    decimalFormat.setGroupingUsed (false);
    decimalFormat.setMaximumFractionDigits (14);
    StringBuffer lineBuffer = new StringBuffer ("i");
    String numberBuffer = null;
    double pfield;
    double temperamentRound = (1.0 / temperament) / 2.0;
    for (int i = Event.INSTRUMENT; i < Event.ELEMENT_COUNT; ++i)
      {
	pfield = getPField (i);
	if (temperament != 0 && i == Event.KEY)
	  {
	    pfield =
	      ((int) ((pfield + temperamentRound) * temperament)) /
	      temperament;
	  }
	lineBuffer.append (" ");
	numberBuffer = decimalFormat.format (pfield);
	lineBuffer.append (numberBuffer);
      }
    return lineBuffer.toString ();
  }
  public void setCsoundString (String Buffer)
  {
    int Index = Buffer.indexOf ("i");
    if (Index == -1)
      {
	Index = 0;
      }
    ArrayList tokens = new ArrayList ();
    StringTokenizer stringTokenizer =
      new StringTokenizer (Buffer.substring (Index, Buffer.length () - 1));
    while (stringTokenizer.hasMoreTokens ())
      {
	tokens.add (stringTokenizer.nextToken ());
      }
    int n = tokens.size ();
    if (n <= Event.ELEMENT_COUNT)
      {
	setPFieldCount (Event.ELEMENT_COUNT);
	setPField (Event.HOMOGENEITY, 1);
      }
    else
      {
	setPFieldCount (n);
      }
    for (int i = 0; i < n; i++)
      {
	setPField (Event.INSTRUMENT + i,
		   ((Double) tokens.get (i)).doubleValue ());
      }
  }
  public boolean isNote ()
  {
    return Event.isNote (event);
  }
  public double getStatus ()
  {
    return event[Event.STATUS];
  }
  public void setStatus (double value)
  {
    event[Event.STATUS] = value;
  }
  public double getInstrument ()
  {
    return Event.getInstrument (event);
  }
  public void setInstrument (double value)
  {
    Event.setInstrument (event, value);
  }
  public double getTime ()
  {
    return Event.getTime (event);
  }
  public void setTime (double value)
  {
    Event.setTime (event, value);
  }
  public double getDuration ()
  {
    return Event.getDuration (event);
  }
  public void setDuration (double value)
  {
    Event.setDuration (event, value);
  }
  public double getOctave ()
  {
    return Event.getOctave (event);
  }
  public void setOctave (double value)
  {
    Event.setOctave (event, value);;
  }
  public double getMidiKey ()
  {
    return getOctave () * 12.0 - 36.0;
  }
  public void setMidiKey (double value)
  {
    setOctave ((value / 12.0) + 3.0);
  }
  public double getDecibels ()
  {
    return Event.getMidiVelocity (event);
  }
  public void setDecibels (double value)
  {
    Event.setMidiVelocity (event, (byte) Math.round (value));
  }
  public double getX ()
  {
    return Event.getX (event);
  }
  public void setX (double value)
  {
    Event.setX (event, value);
  }
  public double getY ()
  {
    return Event.getY (event);
  }
  public void setY (double value)
  {
    Event.setY (event, value);
  }
  public double getZ ()
  {
    return Event.getZ (event);
  }
  public void setZ (double value)
  {
    Event.setZ (event, value);
  }
  public double getPhase ()
  {
    return Event.getPhase (event);
  }
  public void setPhase (double value)
  {
    Event.setPhase (event, value);
  }
  public double getMason ()
  {
    return Event.getMason (event);
  }
  public void setMason (double value)
  {
    Event.setMason (event, value);
  }
  public void openView ()
  {
    NoteView noteView = new NoteView (this);
      noteView.setVisible (true);
  }
  public Container getView ()
  {
    return new NoteView (this);
  }
  public class TableModel extends AbstractTableModel
  {
    public int getRowCount ()
    {
      return Event.ELEMENT_COUNT;
    }
    public int getColumnCount ()
    {
      return 2;
    }
    public Object getValueAt (int row, int column)
    {
      if (column == 0)
	{
	  return Event.labels[row];
	}
      else
	{
	  if (row == Event.KEY)
	    {
	      return new Double (getMidiKey ());
	    }
	  else
	    {
	      return new Double (getPField (row));
	    }
	}
    }
    public void setValueAt (Object value, int row, int column)
    {
      if (column == 1)
	{
	  double d = Double.parseDouble (value.toString ());
	  if (row == Event.KEY)
	    {
	      setMidiKey (d);
	    }
	  else
	    {
	      setPField (row, d);
	    }
	}
    }
    public Class getColumnClass (int column)
    {
      return getValueAt (column, 0).getClass ();
    }
    public boolean isCellEditable (int row, int column)
    {
      if (column == 1 && row >= 0 && row < Event.HOMOGENEITY)
	{
	  return true;
	}
      return false;
    }
    public String getColumnName (int column)
    {
      if (column == 0)
	{
	  return "Dimension";
	}
      else if (column == 1)
	{
	  return "Value";
	}
      return null;
    }
  }
  public Note.TableModel getTableModel ()
  {
    return new Note.TableModel ();
  }
  public String toString ()
  {
    return Event.toString (event);
  }
  public String getCommandDescription (int command)
  {
    return Event.getCommandDescription (command);
  }
  public double[] fromShortMessage (ShortMessage shortMessage,
				    double timestamp)
  {
    return Event.fromShortMessage (shortMessage, timestamp);
  }
  public MidiEvent toNoteOff (double[]note,
			      int ticksPerSecond) throws
    InvalidMidiDataException
  {
    return Event.toNoteOff (note, ticksPerSecond);
  }
  public MidiEvent toNoteOn (double[]note,
			     int ticksPerSecond) throws
    InvalidMidiDataException
  {
    return Event.toNoteOn (note, ticksPerSecond);
  }
  public MidiEvent toShortEvent (double[]note,
				 int ticksPerSecond) throws
    InvalidMidiDataException
  {
    return Event.toShortEvent (note, ticksPerSecond);
  }
}
