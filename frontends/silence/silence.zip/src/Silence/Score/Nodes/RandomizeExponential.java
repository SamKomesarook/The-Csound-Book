package Silence.Score.Nodes;
import cern.jet.random.Exponential;
import cern.jet.random.engine.RandomEngine;
import Silence.Global;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import Silence.Mathematics.*;
import java.awt.*;
import java.io.*;
import java.util.*;
/**
Like RandomizeUniform, except that the random variable has an expontential distribution.
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class RandomizeExponential extends RandomizeUniform implements
  NodeInterface, java.io.Serializable
{
  double mean = 1.0;
  transient Exponential exponential = null;
  public RandomizeExponential ()
  {
    exponential = new Exponential (mean, Global.randomEngine);
    defaultsRandomizeExponential ();
  }
  public NodeInterface copy()
  {
    RandomizeExponential copy = new RandomizeExponential();
    copyFieldsInto(copy);
    return copy;
  }
  public void copyFieldsInto(NodeInterface copy_)
  {
    RandomizeExponential copy = (RandomizeExponential) copy_;
    super.copyFieldsInto(copy);
    copy.mean = mean;
  }
  public void defaultsRandomizeExponential ()
  {
    mean = 1.0;
    exponential.setState (mean);
  }
  public double getSample ()
  {
    return exponential.nextDouble (mean);
  }
  public void openView ()
  {
    RandomizeExponentialView view = new RandomizeExponentialView (this);
      view.setVisible (true);
  }
  public Container getView ()
  {
    return new RandomizeExponentialView (this);
  }
}
