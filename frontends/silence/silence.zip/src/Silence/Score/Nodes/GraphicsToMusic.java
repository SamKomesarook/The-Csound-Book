package Silence.Score.Nodes;
import Silence.Conversions;
import Silence.Mathematics.Matrix;
import Silence.Orchestra.Event;
import Silence.Orchestra.PhaseVocoderAnalysis;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import java.applet.*;
import java.awt.*;
import java.awt.image.*;
import java.io.*;
import java.util.*;
/**
Translates a Java Image object either into notes,
or a phase vocoder analysis file of a sound,
or a heterodyne analysis file of a sound (this last option is not currently
working correctly). The vertical dimension of the image represents
the pitch or octave dimension of the score, the horizontal dimension
of the image represents the time dimension of the score, and the hue dimension
of the image represents the instrument dimension of the score.
For notes, a maximum number of voices N is specified, and for each column
of pixels in the image, the N brightest pixels are chosen to begin notes,
which continue sounding as long as the succeeding pixels are not black.
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class GraphicsToMusic extends Node implements NodeInterface,
  java.io.Serializable
  {
  String filename = null;
  //  Actual parameters.
  String graphicsFilename = null;
  double brightnessThreshold;
  int instrumentCount;
  double durationSeconds;
  double tonesPerOctave;
  boolean logarithmicFrequencies = true;
  //  End actual parameters.
  public GraphicsToMusic ()
  {
    score = new Score ();
    defaultsGraphicsToMusic ();
  }
  public NodeInterface copy()
  {
    GraphicsToMusic copy = new GraphicsToMusic();
    copyFieldsInto(copy);
    return copy;
  }
  public void copyFieldsInto(NodeInterface copy_)
  {
    GraphicsToMusic copy = (GraphicsToMusic) copy_;
    super.copyFieldsInto(copy);
    copy.graphicsFilename = graphicsFilename;
    copy.brightnessThreshold = brightnessThreshold;
    copy.instrumentCount = instrumentCount;
    copy.durationSeconds = durationSeconds;
    copy.tonesPerOctave = tonesPerOctave;
    copy.logarithmicFrequencies = logarithmicFrequencies;
  }
  int instrumentIndex = 1;
  int grainCount;
  public int implementation = NOTES_IMPLEMENTATION;
  transient Frame frame = null;
  transient Image image = null;
  transient PixelGrabber pixelGrabber = null;
  transient int[] pixels = null;
  transient int pixelsWide;
  transient int pixelsHigh;
  transient int maximumY;
  transient Process process = null;
  public static final int NOTES_IMPLEMENTATION = 1;
  public static final int GRAINS_IMPLEMENTATION = 2;
  public static final int ADSYN_IMPLEMENTATION = 3;
  public static final int PVOC_IMPLEMENTATION = 4;
  public static final int HUE = 0;
  public static final int SATURATION = 1;
  public static final int BRIGHTNESS = 2;
  static final short startAmplitudeTrack = -1;
  static final short startFrequencyTrack = -2;
  static final short trackEnd = 32767;
  transient Random randomizer = new Random ();
  public class BrightnessIndex
  {
    public int position;
    public float brightness;
  }
  /**
  Sorts a brightness index using quicksort.
  */ public static void sortByBrightness (BrightnessIndex[]index)
  {
    int i;
    int j;
    int limit;
    int offset;
    int switchIndex;
    BrightnessIndex itemI = null;
    BrightnessIndex itemJ = null;
    //      Set comparison offset to half the number of events in the sequence.
    offset = index.length / 2;
    //      Loop until the offset reaches zero.
    while (offset > 0)
    {
      limit = index.length - offset;
      do
        {
        //      Assume no switches at this offset.
        switchIndex = 0;
        //      Compare events, switch events that are out of order.
        for (i = 0; i < limit; i++)
        {
          j = i + offset;
          itemI = index[i];
          itemJ = index[j];
          if (itemI.brightness > itemJ.brightness)
          {
            index[j] = itemI;
            index[i] = itemJ;
            switchIndex = i;
          }
        }
        //      Sort on the next pass only to where the last switch was made.
        limit = switchIndex;
      }
      while (switchIndex != 0);
      //      No switches at last offset - try offset half as big.
      Runtime.getRuntime ().gc ();
      System.out.println ("Offset = " + offset);
      offset = offset / 2;
    }
  }
  public void defaultsGraphicsToMusic ()
  {
    filename = null;
    graphicsFilename = null;
    implementation = NOTES_IMPLEMENTATION;
    brightnessThreshold = 0.1;
    instrumentCount = 4;
    durationSeconds = 240;
    tonesPerOctave = 12;
    image = null;
    pixelGrabber = null;
    pixels = null;
    logarithmicFrequencies = true;
    process = null;
    instrumentIndex = 1;
    grainCount = 10000;
    score.clear ();
    score.autoRescale = true;
  }
  public double[][] produceOrTransformNotes (double[][]compositeTransform,
                                             Score score, int beginIndex,
                                             int endIndex)
  {
    try
    {
      int n = this.score.size ();
      for (int i = 0; i < n; i++)
      {
        double[] note = this.score.getEvent (i);
        double[] transformedNote = Matrix.times (compositeTransform,
                                                 note);
        score.addEvent (transformedNote);
      }
    }
    catch (Exception e)
    {
      e.printStackTrace ();
    }
    return compositeTransform;
  }
  public void importImage ()
  {
    boolean temporaryFrame = false;
    boolean temporarilyVisible = false;
    if (frame == null)
    {
      temporaryFrame = true;
      frame = new Frame ();
    }
    image = frame.getToolkit ().getImage (graphicsFilename);
    MediaTracker mediaTracker = new MediaTracker (frame);
    mediaTracker.addImage (image, 0);
    frame.repaint ();
    try
    {
      mediaTracker.waitForID (0);
    }
    catch (InterruptedException e)
    {
      e.printStackTrace ();
    }
    if (temporaryFrame)
    {
      frame = null;
    }
  }
  public void pixelsGrab ()
  {
    System.out.println ("Began grabbing image...");
    int x = 0;
    int y = 0;
    pixelsWide = image.getWidth (null);
    pixelsHigh = image.getHeight (null);
    maximumY = pixelsHigh - 1;
    if (pixelsWide < 1 || pixelsHigh < 1)
    {
      System.out.println
        ("Failed to read image in GraphicsToMusic.pixelsGrag().");
    }
    pixels = new int[pixelsWide * pixelsHigh];
    int offset = 0;
    pixelGrabber =
      new PixelGrabber (image,
                        x, y, pixelsWide, pixelsHigh, pixels, offset,
                        pixelsWide);
    try
    {
      pixelGrabber.grabPixels ();
    }
    catch (InterruptedException e)
    {
      e.printStackTrace ();
      System.out.println ("Image grab interrupted.");
    }
    if ((pixelGrabber.getStatus () & ImageObserver.ABORT) != 0)
    {
      System.out.println ("Image fetch aborted or errored.");
    }
    System.out.println ("Ended grabbing image.");
    return;
  }
  public final int getPixel (int x, int y)
  {
    return pixels[y * pixelsWide + x];
  }
  void getPixel (int x, int y, float[]hueSaturationBrightness)
  {
    Color color = new Color (pixels[(maximumY - y) * pixelsWide + x]);
    color.RGBtoHSB (color.getRed (),
                    color.getGreen (),
                    color.getBlue (), hueSaturationBrightness);
  }
  public void translateToGrains ()
  {
    if (image == null)
    {
      importImage ();
      if (image == null)
      {
        System.out.println ("No image.");
        return;
      }
    }
    pixelsGrab ();
    double time = 0;
    double secondsIncrement = durationSeconds / pixelsWide;
    double duration = secondsIncrement * 2;
    double nyquistOctave = Conversions.hzToOctave (20000.0);
    double baseOctave = Conversions.hzToOctave (20.0);
    double octaveIncrement =
      (nyquistOctave - baseOctave) / ((double) pixelsHigh);
    double octave = 0;
    double decibels = 0;
    double phase;
    double pan = 0;
    System.out.println ("secondsIncrement = " + secondsIncrement);
    System.out.println ("baseOctave       = " + baseOctave);
    System.out.println ("nyquistOctave    = " + nyquistOctave);
    System.out.println ("octaveIncrement  = " + octaveIncrement);
    System.out.println ("Began filtering grains...");
    ColorModel colorModel = pixelGrabber.getColorModel ();
    int red = 0;
    int blue = 0;
    int green = 0;
    float[] hsb = new float[3];
    BrightnessIndex[]index = new BrightnessIndex[pixelsHigh * pixelsWide];
    int position = 0;
    int column = 0;
    for (int i = 0; i < pixels.length; i++)
    {
      red = colorModel.getRed (pixels[i]);
      green = colorModel.getGreen (pixels[i]);
      blue = colorModel.getBlue (pixels[i]);
      Color.RGBtoHSB (red, green, blue, hsb);
      index[i] = new BrightnessIndex ();
      index[i].position = i;
      index[i].brightness = hsb[2];
      if (i % 10000 == 0)
      {
        Runtime.getRuntime ().gc ();
        System.out.println ("Index             = " + i + " of " +
                            pixels.length);
        System.out.println ("Total Java memory = " +
                            Runtime.getRuntime ().totalMemory ());
        System.out.println ("Free Java memory  = " +
                            Runtime.getRuntime ().freeMemory ());
      }
    }
    System.out.println ("Ended filtering grains.");
    //  Sort the index by brightness.
    System.out.println ("Began sorting grains...");
    sortByBrightness (index);
    Runtime.getRuntime ().gc ();
    System.out.println ("Total Java memory = " +
                        Runtime.getRuntime ().totalMemory ());
    System.out.println ("Free Java memory  = " +
                        Runtime.getRuntime ().freeMemory ());
    System.out.println ("Ended sorting grains.");
    System.out.println ("Began producing grains...");
    //  Translate the N brightest pixels to grains.
    Note note = null;
    int x = 0;
    int y = 0;
    for (int i = 0; i < grainCount; i++)
    {
      position = index[i].position;
      red = colorModel.getRed (pixels[position]);
      green = colorModel.getGreen (pixels[position]);
      blue = colorModel.getBlue (pixels[position]);
      Color.RGBtoHSB (red, green, blue, hsb);
      if (hsb[2] > 0)
      {
        y = position / pixelsWide;
        x = position - (y * pixelsHigh);
        time = x * secondsIncrement;
        octave = baseOctave + (((double) y) * octaveIncrement);
        decibels = ((double) hsb[2]) * 78.0;
        phase = ((double) hsb[0]) - 0.5;
        pan = ((double) hsb[1]) - 0.5;
        score.addNote (instrumentIndex,
                       time, duration, octave, decibels,
                       phase, pan, 0.0, 0.0, 4095);
      }
      if (grainCount % 500 == 0)
      {
        Runtime.getRuntime ().gc ();
        System.out.println ("Total Java memory = " +
                            Runtime.getRuntime ().totalMemory ());
        System.out.println ("Free Java memory  = " +
                            Runtime.getRuntime ().freeMemory ());
        System.out.println ("Produced " + score.size () + " notes.");
      }
    }
    Runtime.getRuntime ().gc ();
    System.out.println ("Total Java memory = " +
                        Runtime.getRuntime ().totalMemory ());
    System.out.println ("Free Java memory  = " +
                        Runtime.getRuntime ().freeMemory ());
    System.out.println ("Ended producing grains.");
  }
  public void translateToNotes ()
  {
    if (image == null)
    {
      importImage ();
      if (image == null)
      {
        System.out.println ("No image.");
        return;
      }
    }
    pixelsGrab ();
    score.clear ();
    double bassOctave = 6.0;
    double rangeOctaves = 6.0;
    double octaveIncrement = 1.0 / tonesPerOctave;
    int rowIncrement = (int) (pixelsHigh / (tonesPerOctave * rangeOctaves));
    //  Translate to notes.
    //  x dimension is octave,
    //  y dimension is seconds,
    //  hue is instrument index,
    //  saturation is x dimension,
    //  brightness is decibels.
    double instrument;
    double time;
    double startTime;
    double timeIncrement = durationSeconds / pixelsWide;
    double duration;
    double octave = bassOctave;
    double decibels;
    double pan;
    float[] newHueSaturationBrightness = new float[3];
    float[] oldHueSaturationBrightness = new float[3];
    float[] buffer = new float[3];
    float[] maximumHueSaturationBrightness = new float[3];
    System.out.println ("Image is " + pixelsWide + " pixels wide x " +
                        pixelsHigh + " pixels high.");
    System.out.println ("There are " + pixelsHigh / rowIncrement +
                        " increments of pitch.");
    for (int rowIndex = 0; rowIndex < pixelsHigh;
        rowIndex += rowIncrement, octave += octaveIncrement)
    {
      time = 0;
      startTime = 0;
      for (int columnIndex = 0; columnIndex < pixelsWide;
          columnIndex++, time += timeIncrement)
      {
        System.arraycopy (newHueSaturationBrightness, 0,
                          oldHueSaturationBrightness, 0, 3);
        getPixel (columnIndex, rowIndex, newHueSaturationBrightness);
        //  Note starting.
        if (oldHueSaturationBrightness[BRIGHTNESS] <= brightnessThreshold

            && newHueSaturationBrightness[BRIGHTNESS] >
            brightnessThreshold && columnIndex > 0)
        {
          startTime = time;
          maximumHueSaturationBrightness[HUE] =
            newHueSaturationBrightness[HUE];
          maximumHueSaturationBrightness[SATURATION] =
            newHueSaturationBrightness[SATURATION];
          maximumHueSaturationBrightness[BRIGHTNESS] =
            newHueSaturationBrightness[BRIGHTNESS];
        }
        //  Note sustaining.
        else if (oldHueSaturationBrightness[BRIGHTNESS] >
            brightnessThreshold
            && newHueSaturationBrightness[BRIGHTNESS] >
            brightnessThreshold)
        {
          if (maximumHueSaturationBrightness[HUE] <
              newHueSaturationBrightness[HUE])
          {
            maximumHueSaturationBrightness[HUE] =
              newHueSaturationBrightness[HUE];
          }
          if (maximumHueSaturationBrightness[SATURATION] <
              newHueSaturationBrightness[SATURATION])
          {
            maximumHueSaturationBrightness[SATURATION] =
              newHueSaturationBrightness[SATURATION];
          }
          if (maximumHueSaturationBrightness[BRIGHTNESS] <
              newHueSaturationBrightness[BRIGHTNESS])
          {
            maximumHueSaturationBrightness[BRIGHTNESS] =
              newHueSaturationBrightness[BRIGHTNESS];
          }
        }
        //  Note ending.
        else if (oldHueSaturationBrightness[BRIGHTNESS] >
            brightnessThreshold
            && newHueSaturationBrightness[BRIGHTNESS] <=
            brightnessThreshold)
        {
          duration = time - startTime;
          if (duration > 0.0 && columnIndex > 0)
          {
            instrument =
              1.0 +
              (maximumHueSaturationBrightness[HUE] * instrumentCount);
            duration = time - startTime;
            decibels =
              maximumHueSaturationBrightness[BRIGHTNESS] * 60;
            pan = maximumHueSaturationBrightness[SATURATION] - 0.5;
            score.addNote (instrument, startTime, duration, octave,
                           decibels, 0.0, pan, 0.0, 0.0, 4095);
          }
        }
      }
      System.out.println ("Rows translated = " + rowIndex);
      System.out.println ("Notes created   = " + score.size ());
    }
  }
  public boolean translateToAdsyn ()
  {
    if (image == null)
    {
      importImage ();
      if (image == null)
      {
        System.out.println ("No image.");
        return false;
      }
    }
    pixelsGrab ();
    try
    {
      String analysisFilename = getName () + ".ads";
      FileOutputStream fileOutputStream =
        new FileOutputStream (analysisFilename);
      BufferedOutputStream bufferedOutputStream =
        new BufferedOutputStream (fileOutputStream);
      DataOutputStream dataOutputStream =
        new DataOutputStream (bufferedOutputStream);
      double time = 0;
      double millisecondsPerPixel = 10.0;
      double nyquistOctave = Conversions.hzToOctave (20000.0);
      double baseOctave = Conversions.hzToOctave (20.0);
      double octaveIncrement =
        (nyquistOctave - baseOctave) / ((double) pixelsHigh);
      System.out.println ("millisecondsPerPixel = " + millisecondsPerPixel);
      System.out.println ("baseOctave           = " + baseOctave);
      System.out.println ("nyquistOctave        = " + nyquistOctave);
      System.out.println ("octaveIncrement      = " + octaveIncrement);
      System.out.println ("Began finding amplitude scaling factor...");
      ColorModel colorModel = pixelGrabber.getColorModel ();
      int red = 0;
      int blue = 0;
      int green = 0;
      float[] hsb = new float[3];
      double columnAmplitudeSum = 0;
      double maximumColumnAmplitudSum = 0;
      double amplitudeFactor = 0;
      int pixel = 0;
      short timeMilliseconds;
      short frequencyHz;
      short amplitude;
      for (int x = 0; x < pixelsWide; x++)
      {
        columnAmplitudeSum = 0;
        for (int y = 0; y < pixelsHigh; y++)
        {
          pixel = getPixel (x, y);
          red = colorModel.getRed (pixel);
          green = colorModel.getGreen (pixel);
          blue = colorModel.getBlue (pixel);
          Color.RGBtoHSB (red, green, blue, hsb);
          columnAmplitudeSum += hsb[2];
        }
        if (columnAmplitudeSum > maximumColumnAmplitudSum)
        {
          maximumColumnAmplitudSum = columnAmplitudeSum;
        }
      }
      amplitudeFactor = 32000.0 / maximumColumnAmplitudSum;
      System.out.println ("Ended finding amplitude scaling factor: " +
                          amplitudeFactor + ".");
      System.out.println ("Began translating image to ads file...");
      //  To enable John ffitch's patch for unlimited partials.
      dataOutputStream.writeShort (Conversions.
                                   swapShort ((short) pixelsHigh));
      //  y is reversed.
      for (int y = 0; y < pixelsHigh; y++)
      {
        frequencyHz =
          (short) Conversions.octaveToHz (nyquistOctave -
                                          (y * octaveIncrement));
        //    Amplitude tracks.
        dataOutputStream.
          writeShort (Conversions.swapShort (startAmplitudeTrack));
        for (int x = 0; x < pixelsWide; x++)
        {
          timeMilliseconds = (short) (x * millisecondsPerPixel);
          pixel = getPixel (x, y);
          red = colorModel.getRed (pixel);
          green = colorModel.getRed (pixel);
          blue = colorModel.getRed (pixel);
          Color.RGBtoHSB (red, green, blue, hsb);
          amplitude = (short) (hsb[2] * amplitudeFactor);
          if (amplitude < 0.0 || amplitude > 32000.0)
          {
            System.out.println ("amplitude " + amplitude +
                                " out of range at row " + y +
                                ", column " + x + ".");
          }
          dataOutputStream.
            writeShort (Conversions.swapShort (timeMilliseconds));
          dataOutputStream.writeShort (Conversions.swapShort (amplitude));
        }
        dataOutputStream.writeShort (Conversions.swapShort (trackEnd));
        //      Frequency tracks.
        dataOutputStream.
          writeShort (Conversions.swapShort (startFrequencyTrack));
        for (int x = 0; x < pixelsWide; x++)
        {
          timeMilliseconds = (short) (x * millisecondsPerPixel);
          dataOutputStream.
            writeShort (Conversions.swapShort (timeMilliseconds));
          dataOutputStream.writeShort (Conversions.
                                       swapShort (frequencyHz));
        }
        dataOutputStream.writeShort (Conversions.swapShort (trackEnd));
      }
      dataOutputStream.close ();
      /*
       * if(getGlobalScore().getCsoundModel().getInstrument(instrumentIndex) == null)
       * {
       * String instrument = "instr " + instrumentIndex + "\n"
       * + "; adsyn phase vocoder for time stretching\n"
       * + "; of hetro files derived from screen shots.\n"
       * + "\n"
       * + "print p2, p3, p4, p5, p6, p7, p8, p9\n"
       * + "; INITIALIZATION\n"
       * + "; Assume that the picture has a root pitch of middle C.\n"
       * + "ifrequencyfactor = octcps(p4) / octcps(8)\n"
       * + "; Assume that the picture has an amplitude of 80 decibels.\n"
       * + "iamplitudefactor = ampdb(p5) / ampdb(50)\n"
       * + "iangle         =       p7 * 3.14159265359 / 2.0\n"
       * + "ileftpan       =       sqrt(2.0) / 2.0 * (cos(iangle) + sin(iangle))\n"
       * + "irightpan      =       sqrt(2.0) / 2.0 * (cos(iangle) - sin(iangle))\n"
       * + "; Derive the speed multiplier from the duration.\n"
       * + "imsperpixel = " + millisecondsPerPixel + "\n"
       * + "ipixels = " + pixelsWide + "\n"
       * + "iduration = (imsperpixel * ipixels) / 1000.0\n"
       * + "ispeedfactor = iduration / p3\n"
       * + "print iamplitudefactor\n"
       * + "print ifrequencyfactor\n"
       * + "print ispeedfactor\n"
       * + "; AUDIO\n"
       * + "asignal adsyn iamplitudefactor, ifrequencyfactor, ispeedfactor, \"" + analysisFilename + "\"\n"
       * + "outs asignal * ileftpan, asignal * irightpan\n"
       * + "endin\n";
       * getGlobalScore().getCsoundModel().setInstrument(instrumentIndex, instrument);
       * }
       */
      score.clear ();
      double[] note = Event.createNote ();
      Event.setInstrument (note, instrumentIndex);
      Event.setDuration (note, durationSeconds);
      score.addEvent (note);
      System.out.println ("Ended translating image to ads file.");
    }
    catch (Exception e)
    {
      e.printStackTrace ();
    }
    return true;
  }
  public boolean translateToPvoc ()
  {
    if (image == null)
    {
      importImage ();
      if (image == null)
      {
        System.out.println ("No image.");
        return false;
      }
    }
    pixelsGrab ();
    PhaseVocoderAnalysis pva = new PhaseVocoderAnalysis ();
    pva.setSampleCount (pixelsWide, pixelsHigh);
    int fftSampleCount = pva.getFftSampleCount ();
    if (fftSampleCount > 1024)
    {
      pva.setSampleCount (pixelsWide, 1024);
    }
    pva.setLogarithmicFrequencies (logarithmicFrequencies);
    float hsb[] = new float[3];
    int pixel = 0;
    int red = 0;
    int green = 0;
    int blue = 0;
    int columnsTranslatedCount = 0;
    double independentValueCount = pva.getIndependentValueCount ();
    double pixelIncrement = independentValueCount / ((double) pixelsHigh);
    ColorModel colorModel = pixelGrabber.getColorModel ();
    System.out.println ("Translating pixels...");
    for (int frameIndex = 0; frameIndex < pixelsWide; frameIndex++)
    {
      for (int pixelIndex = 0, sampleIndex = pixelsHigh - 1;
          pixelIndex < pixelsHigh; pixelIndex++, sampleIndex--)
      {
        int binIndex = (int) (sampleIndex * pixelIncrement);
        pixel = getPixel (frameIndex, pixelIndex);
        red = colorModel.getRed (pixel);
        green = colorModel.getGreen (pixel);
        blue = colorModel.getBlue (pixel);
        Color.RGBtoHSB (red, green, blue, hsb);
        //  Translate brightness to magnitude, hue to angle.
        pva.setMagnitude (frameIndex, binIndex, hsb[2]);
        pva.setAngle (frameIndex, binIndex, hsb[0]);
      }
      columnsTranslatedCount = frameIndex + 1;
    }
    if (filename == null)
    {
      filename = getName () + "Gtm.";
    }
    String analysisFilename =
      filename.substring (0, filename.indexOf (".")) + ".pva";
    /*
     * if(getGlobalScore().getCsoundModel().getInstrument(instrumentIndex) == null)
     * {
     * String instrumentName = filename.substring(0, filename.indexOf(".")) + "Pva";
     * String instrument = "instr " + instrumentIndex + "\n";
     * instrument += "itranspose   =   p4 / 8.\n";
     * instrument += "iamplitude   =   ampdb(p5) * 15848.926 / 15848.926\n";
     * instrument += "ileftpan     =   (0.5 - p6) / 2 * iamplitude\n";
     * instrument += "irightpan    =   (0.5 + p6) / 2 * iamplitude\n";
     * double iduration = (pva.getFrameCount() * (pva.getFftSampleCount() / (pva.getFftSampleCount() / pva.getHopCount()))) / getGlobalScore().timebase.audioSampleFramesPerSecond;
     * instrument += "iduration    =   " + iduration + "\n";
     * instrument += "             print   p1, p2, p3, p4, p5, p6\n";
     * instrument += "             print   iduration, itranspose\n";
     * instrument += "ktime        line    0, p3, iduration\n";
     * instrument += "asignal      pvoc    ktime, itranspose, \"" + analysisFilename + "\"\n";
     * instrument += "             outs    ileftpan * asignal, irightpan * asignal\n";
     * instrument += "endin\n";
     * score.clear();
     * getGlobalScore().getCsoundModel().setInstrument(instrumentIndex, instrument);
     * }
     */
    double[] note = Event.createNote ();
    Event.setInstrument (note, instrumentIndex);
    Event.setDuration (note, durationSeconds);
    score.addEvent (note);
    pva.normalize ();
    try
    {
      FileOutputStream fileOutputStream =
        new FileOutputStream (analysisFilename);
      BufferedOutputStream bufferedOutputStream =
        new BufferedOutputStream (fileOutputStream);
      DataOutputStream dataOutputStream =
        new DataOutputStream (bufferedOutputStream);
      pva.write (dataOutputStream);
      dataOutputStream.close ();
    }
    catch (Exception e)
    {
      e.printStackTrace ();
    }
    return true;
  }
  public int getImplementation ()
  {
    return implementation;
  }
  public void setImplementation (int value)
  {
    implementation = value;
  }
  public void translate ()
  {
    importImage ();
    switch (implementation)
    {
    case GRAINS_IMPLEMENTATION:
      translateToGrains ();
      break;
    case NOTES_IMPLEMENTATION:
      translateToNotes ();
      break;
    case ADSYN_IMPLEMENTATION:
      translateToAdsyn ();
      break;
    case PVOC_IMPLEMENTATION:
      translateToPvoc ();
      break;
    }
  }
  public Container getView ()
  {
    return new GraphicsToMusicView (this);
  }
}
