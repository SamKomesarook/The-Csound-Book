package Silence.Score.Nodes;
import Silence.Orchestra.Event;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import java.awt.*;
import javax.swing.*;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
/**
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class TransformRotateView extends javax.swing.JInternalFrame
{
  TransformRotate transformRotate = null;
    String[] dimensionLabels = Event.labels;
  public TransformRotateView (TransformRotate value)
  {
    this ("TransformRotate");
    transformRotate = value;
    updateView ();
  }
  void updateView ()
  {
    nameField.setText (transformRotate.getName ());
    transformRotateField.setText (String.valueOf (transformRotate.angleInPi));
    rotateFromChoice.setSelectedItem (transformRotate.dimensionFrom);
    rotateToChoice.setSelectedItem (transformRotate.dimensionTo);
  }
  public void updateModel ()
  {
    transformRotate.setName (nameField.getText ());
    transformRotate.angleInPi =
      Double.parseDouble (transformRotateField.getText ());
    transformRotate.dimensionFrom =
      rotateFromChoice.getSelectedItem ().toString ();
    transformRotate.dimensionTo =
      rotateToChoice.getSelectedItem ().toString ();
    updateView ();
  }
  public TransformRotateView ()
  {
    setTitle ("TransformRotate");
    getContentPane ().setLayout (null);
    setVisible (false);
    setSize (446, 327);
    setBackground (new Color (8421504));
    namePanel = new javax.swing.JPanel ();
    namePanel.setLayout (null);
    namePanel.setBounds (12, 12, 420, 72);
    namePanel.setFont (new Font ("Dialog", Font.BOLD, 12));
    namePanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (namePanel);
    nameField = new javax.swing.JTextField ();
    nameField.setBounds (12, 36, 396, 24);
    nameField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    namePanel.add (nameField);
    nameLabel = new javax.swing.JLabel ();
    nameLabel.setText ("Name");
    nameLabel.setHorizontalAlignment (0);
    nameLabel.setHorizontalTextPosition (0);
    nameLabel.setBounds (12, 0, 392, 26);
    nameLabel.setFont (new Font ("Dialog", Font.BOLD, 12));
    namePanel.add (nameLabel);
    parametersPanel = new javax.swing.JPanel ();
    parametersPanel.setLayout (null);
    parametersPanel.setBounds (12, 96, 420, 156);
    parametersPanel.setFont (new Font ("Dialog", Font.BOLD, 12));
    parametersPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (parametersPanel);
    transformRotateField = new javax.swing.JTextField ();
    transformRotateField.setBounds (144, 36, 240, 24);
    transformRotateField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (transformRotateField);
    angleLabel = new javax.swing.JLabel ();
    angleLabel.setText ("Angle in Pi");
    angleLabel.setBounds (12, 36, 100, 24);
    angleLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (angleLabel);
    rotateFromLabel = new javax.swing.JLabel ();
    rotateFromLabel.setText ("Rotate from");
    rotateFromLabel.setBounds (12, 72, 120, 24);
    rotateFromLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (rotateFromLabel);
    rotateToLabel = new javax.swing.JLabel ();
    rotateToLabel.setText ("Rotate to");
    rotateToLabel.setBounds (12, 108, 120, 24);
    rotateToLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (rotateToLabel);
    rotateFromChoice = new javax.swing.JComboBox ();
    rotateFromChoice.setBounds (144, 72, 242, 24);
    rotateFromChoice.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (rotateFromChoice);
    rotateToChoice = new javax.swing.JComboBox ();
    rotateToChoice.setBounds (144, 108, 242, 24);
    rotateToChoice.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (rotateToChoice);
    parametersLabel = new javax.swing.JLabel ();
    parametersLabel.setText ("Parameters");
    parametersLabel.setHorizontalAlignment (0);
    parametersLabel.setHorizontalTextPosition (0);
    parametersLabel.setBounds (12, 0, 392, 26);
    parametersLabel.setFont (new Font ("Dialog", Font.BOLD, 12));
    parametersPanel.add (parametersLabel);
    buttonPanel = new javax.swing.JPanel ();
    buttonPanel.setLayout (null);
    buttonPanel.setBounds (12, 264, 420, 48);
    buttonPanel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    buttonPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (buttonPanel);
    updateButton = new javax.swing.JButton ();
    updateButton.setText ("Update");
    updateButton.setActionCommand ("button");
    updateButton.setBounds (12, 12, 84, 24);
    updateButton.setFont (new Font ("Dialog", Font.PLAIN, 12));
    buttonPanel.add (updateButton);
    for (int i = 0; i < dimensionLabels.length; i++)
      {
	rotateToChoice.addItem (dimensionLabels[i]);
	rotateFromChoice.addItem (dimensionLabels[i]);
      }
    SymAction lSymAction = new SymAction ();
      updateButton.addActionListener (lSymAction);
  }
  public TransformRotateView (String title)
  {
    this ();
    setTitle (title);
  }
  javax.swing.JPanel namePanel;
  javax.swing.JTextField nameField;
  javax.swing.JLabel nameLabel;
  javax.swing.JPanel parametersPanel;
  javax.swing.JTextField transformRotateField;
  javax.swing.JLabel angleLabel;
  javax.swing.JLabel rotateFromLabel;
  javax.swing.JLabel rotateToLabel;
  javax.swing.JComboBox rotateFromChoice;
  javax.swing.JComboBox rotateToChoice;
  javax.swing.JLabel parametersLabel;
  javax.swing.JPanel buttonPanel;
  javax.swing.JButton updateButton;
  class SymAction implements java.awt.event.ActionListener
  {
    public void actionPerformed (java.awt.event.ActionEvent event)
    {
      Object object = event.getSource ();
      if (object == updateButton)
	  updateButton_Action (event);
    }
  }
  void updateButton_Action (java.awt.event.ActionEvent event)
  {
    updateModel ();
  }
}
