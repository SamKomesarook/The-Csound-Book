package Silence.Score.Nodes;
import cern.jet.random.Normal;
import cern.jet.random.engine.RandomEngine;
import Silence.Global;
import Silence.MatrixEditor;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import Silence.Mathematics.*;
import java.awt.*;
import java.io.*;
import java.util.*;
/**
Like RandomizeUniform, except that the random variable has the distribution of Brownian noise.
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class RandomizeBrownian extends RandomizeUniform implements
  NodeInterface, java.io.Serializable
{
  public transient Normal gaussian = null;
  public double standardDeviation = 1.0;
  public double range = 1.0;
  public RandomizeBrownian ()
  {
    gaussian = new Normal (0.0, standardDeviation, Global.randomEngine);
    defaultsRandomizeBrownian ();
  }
  public NodeInterface copy()
  {
    RandomizeBrownian copy = new RandomizeBrownian();
    copyFieldsInto(copy);
    return copy;
  }
  public void copyFieldsInto(NodeInterface copy_)
  {
    RandomizeBrownian copy = (RandomizeBrownian) copy_;
    super.copyFieldsInto(copy);
    copy.standardDeviation = standardDeviation;
    copy.range = range;
  }
  public void defaultsRandomizeBrownian ()
  {
    standardDeviation = 1.0;
    range = 1.0;
  }
  public double getSample ()
  {
    double mean = gaussian.nextDouble (0.0, standardDeviation);
    for (;;)
      {
	if (mean > range)
	  {
	    mean = 2.0 - mean;
	  }
	else if (mean < .0)
	  {
	    mean = -mean;
	  }
	else
	  {
	    break;
	  }
      }
    return mean;
  }
  public void openView ()
  {
    RandomizeBrownianView view = new RandomizeBrownianView (this);
      view.setVisible (true);
  }
  public Container getView ()
  {
    return new RandomizeBrownianView (this);
  }
}
