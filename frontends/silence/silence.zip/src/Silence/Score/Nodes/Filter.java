package Silence.Score.Nodes;
import Silence.Mathematics.Matrix;
import Silence.Orchestra.Event;
import Silence.Orchestra.Test;
import Silence.Score.MasonNumbers;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import java.applet.*;
import java.awt.*;
import java.io.*;
import java.util.*;
/**
Optionally filters all child notes of this node
through a bounding hypercube of zero or more dimensions.
If a dimension has a minimum enabled, does not produce
child notes less than that minimum;
if a dimension has a maximum enabled, does not produce
child notes greater than that maximum.
After filtering, the global matrix is applied to the result.
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class Filter extends Node implements NodeInterface,
  java.io.Serializable
{
  public static void main (String[]args)
  {
    Filter filter = new Filter ();
      Test.serializationTest (filter);
  }
  public double[] minima =
    Event.createNote (1.0, 0.0, 0.5, 6.0, 60.0, -1.0, -0.5, -0.5, -0.5,
		      MasonNumbers.modulus);
  public double[] maxima =
    Event.createNote (4.0, 240.0, 2.0, 6.0, 20.0, 2.0, 1.0, 1.0, 1.0,
		      MasonNumbers.modulus);
  public boolean[] enableMinima = new boolean[Event.ELEMENT_COUNT];
  public boolean[] enableMaxima = new boolean[Event.ELEMENT_COUNT];
  public Filter ()
  {
    defaults ();
  }
  public NodeInterface copy()
  {
    Filter copy = new Filter();
    copyFieldsInto(copy);
    return copy;
  }
  public void copyFieldsInto(NodeInterface copy_)
  {
    Filter copy = (Filter) copy_;
    super.copyFieldsInto(copy);
    copy.minima = (double[]) minima.clone();
    copy.maxima = (double[]) maxima.clone();
    copy.enableMinima = (boolean[]) enableMinima.clone();
    copy.enableMaxima = (boolean[]) enableMaxima.clone();
  }
  public void defaults ()
  {
    minima =
      Event.createNote (1.0, 0.0, 0.5, 6.0, 60.0, -1.0, -0.5, -0.5, -0.5,
			MasonNumbers.modulus);
    maxima =
      Event.createNote (4.0, 240.0, 2.0, 6.0, 20.0, 2.0, 1.0, 1.0, 1.0,
			MasonNumbers.modulus);
    for (int i = 0; i < enableMinima.length; i++)
      {
	enableMinima[i] = true;
      }
    for (int i = 0; i < enableMaxima.length; i++)
      {
	enableMaxima[i] = true;
      }
  }
  public double[][] traverseMusicGraph (double[][]parentTransformation,
					Score score)
  {
    //  Record the number of notes already in the score
    //  before traversing any child nodes of this.
    int preTraversalCount = score.size ();
    //  The local transformation of coordinate systems
    //  is identity for non-transformation nodes,
    //  or some other affine transformation for transformation nodes.
    double[][] compositeTransformation =
      Matrix.times (parentTransformation, getLocalTransformation ());
    //  Iterate over the immediate child nodes of this using a buffer score...
    Score buffer = new Score ();
    boolean pass = false;
    double[] note = null;
    for (int i = 0, n = getChildCount (); i < n; i++)
      {
	buffer.clear ();
	//  ...calling traverseMusicGraph on each one.
	//  This has the effect of performing a recursive,
	//  depth-first traversal of the music graph.
	NodeInterface childNode = (NodeInterface) getChildAt (i);
	  childNode.traverseMusicGraph (compositeTransformation, buffer);
	//      Then clone notes in the defined bounding hypercube
	//      and add them to the actual score.
	for (int j = 0, m = buffer.size (); j < m; j++)
	  {
	    note = buffer.getEvent (j);
	    pass = true;
	    for (int k = 0; k < Event.HOMOGENEITY; k++)
	      {
		if (enableMinima[k] && minima[k] > note[k])
		  {
		    pass = false;
		    break;
		  }
		if (enableMaxima[k] && maxima[k] < note[k])
		  {
		    pass = false;
		    break;
		  }
	      }
	    if (pass)
	      {
		score.addEvent ((double[]) note.clone ());
	      }
	  }
      }
    //  Record the number of notes in the score
    //  after traversing the child nodes.
    //  This number will have increased by the number of new notes
    //  produced by all child nodes of this.
    int postTraversalCount = score.size ();
    //  Finally, either produce new notes, or transform all notes
    //  that were produced by the child nodes of this.
    double[][] transformation =
      produceOrTransformNotes (compositeTransformation, score,
			       preTraversalCount, postTraversalCount);
    System.gc ();
    return transformation;
  }
  public void openView ()
  {
    FilterView filterView = new FilterView (this);
      filterView.setVisible (true);
  }
  public Container getView ()
  {
    FilterView view = new FilterView (this);
      return view;
  }
}
