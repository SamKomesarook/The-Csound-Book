package Silence.Score.Nodes;
import cern.jet.random.Distributions;
import cern.jet.random.engine.RandomEngine;
import Silence.Global;
import Silence.MatrixEditor;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import Silence.Mathematics.*;
import java.awt.*;
import java.io.*;
import java.util.*;
/**
Like RandomizeUniform, except that the random variable has a geometric distribution.
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class RandomizeGeometric extends RandomizeUniform implements
  NodeInterface, java.io.Serializable
{
  double P = 0.5;
  public RandomizeGeometric ()
  {
    defaultsRandomizeGeometric ();
  }
  public NodeInterface copy()
  {
    RandomizeGeometric copy = new RandomizeGeometric();
    copyFieldsInto(copy);
    return copy;
  }
  public void copyFieldsInto(NodeInterface copy_)
  {
    RandomizeGeometric copy = (RandomizeGeometric) copy_;
    super.copyFieldsInto(copy);
    copy.P = P;
  }
  public void defaultsRandomizeGeometric ()
  {
    P = 0.5;
  }
  public double getSample ()
  {
    return Distributions.nextGeometric (P, Global.randomEngine);
  }
  public void openView ()
  {
    RandomizeGeometricView view = new RandomizeGeometricView (this);
      view.setVisible (true);
  }
  public Container getView ()
  {
    return new RandomizeGeometricView (this);
  }
}
