package Silence.Score.Nodes;
import Silence.Orchestra.Event;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import java.applet.*;
import java.awt.Container;
import java.io.*;
import java.util.*;
/**
Defines a bounding hypercube of note space in the score,
into which will be refitted, by appropriate translating
and rescaling, all the child notes of this node. Useful for
assembling a piece of music by locating and sizing various sections.
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class Rescale extends Node implements NodeInterface,
  java.io.Serializable
{
  public double[] scaleActualMinima = null;
  public double[] scaleActualRanges = null;
  public double[] scaleTargetMinima = null;
  public double[] scaleTargetRanges = null;
  public boolean[] rescaleMinima = null;
  public boolean[] rescaleRanges = null;
  public Rescale ()
  {
    defaultsRescale ();
  }
  public NodeInterface copy()
  {
    Rescale copy = new Rescale();
    copyFieldsInto(copy);
    return copy;
  }
  public void copyFieldsInto(NodeInterface copy_)
  {
    Rescale copy = (Rescale) copy_;
    super.copyFieldsInto(copy);
    copy.scaleActualMinima = (double[]) scaleActualMinima.clone();
    copy.scaleActualRanges = (double[]) scaleActualRanges.clone();
    copy.scaleTargetMinima = (double[]) scaleTargetMinima.clone();
    copy.scaleTargetRanges = (double[]) scaleTargetRanges.clone();
    copy.rescaleMinima = (boolean[]) rescaleMinima.clone();
    copy.rescaleRanges = (boolean[]) rescaleRanges.clone();
  }
  public void defaults ()
  {
    defaultsRescale ();
    childNodes.clear ();
  }
  public void defaultsRescale ()
  {
    scaleActualMinima = Event.createNote ();
    scaleActualRanges = Event.createNote ();
    scaleTargetMinima =
      Event.createNote (1.0, 0.0, 2.0, 36.0, 60.0, -1.0, -0.5, -0.5, -0.5, 0);
    scaleTargetRanges =
      Event.createNote (4.0, 240.0, 4.0, 72.0, 20.0, 2.0, 1.0, 1.0, 1.0,
			4095);
    Event.setStatus (scaleTargetRanges, 0);
    rescaleMinima = new boolean[Event.ELEMENT_COUNT];
    for (int i = 1; i < rescaleMinima.length - 2; i++)
      {
	rescaleMinima[i] = true;
      }
    rescaleRanges = new boolean[Event.ELEMENT_COUNT];
    for (int i = 1; i < rescaleRanges.length - 2; i++)
      {
	rescaleRanges[i] = true;
      }
  }
  public boolean findActualScale (Score notes, int beginIndex, int endIndex)
  {
    boolean returnValue = false;
      try
    {
      int i;
      int j;
      double[] note = null;
      double[] scaleActualMaxima = Event.createNote ();
      double d = 0;
      double min = 0;
      double max = 0;
      for (j = Event.INSTRUMENT; j < Event.HOMOGENEITY; j++)
	{
	  scaleActualMinima[j] = Double.MAX_VALUE;
	  scaleActualMaxima[j] = -Double.MAX_VALUE;
	}
      for (i = beginIndex; i < endIndex; i++)
	{
	  note = notes.getEvent (i);
	  if (Event.isNote (note))
	    {
	      for (j = Event.INSTRUMENT; j < Event.HOMOGENEITY; j++)
		{
		  d = note[j];
		  min = scaleActualMinima[j];
		  max = scaleActualMaxima[j];
		  if (d <= min)
		    {
		      scaleActualMinima[j] = d;
		    }
		  if (d >= max)
		    {
		      scaleActualMaxima[j] = d;
		    }
		}
	    }
	}
      for (j = Event.INSTRUMENT; j < Event.HOMOGENEITY; j++)
	{
	  double range = 0;
	  double minimum = 0;
	  double maximum = 0;
	  minimum = scaleActualMinima[j];
	  maximum = scaleActualMaxima[j];
	  //      Avoid exceptions on too small a range.
	  if (minimum == Double.NaN || maximum == Double.NaN)
	    {
	      range = 0;
	    }
	  else
	    {
	      range = maximum - minimum;
	    }
	  scaleActualRanges[j] = range;
	}
      returnValue = true;
    }
    catch (Exception e)
    {
      e.printStackTrace ();
      returnValue = false;
    }
    return returnValue;
  }
  public boolean setTargetScaleToActual (Score notes, int beginIndex,
					 int endIndex)
  {
    boolean returnValue = findActualScale (notes, beginIndex, endIndex);
      scaleTargetMinima = (double[]) scaleActualMinima.clone ();
      scaleTargetRanges = (double[]) scaleActualRanges.clone ();
      return returnValue;
  }
  public boolean setActualScaleToTarget (Score notes, int beginIndex,
					 int endIndex)
  {
    boolean returnValue = true;
      try
    {
      if (!findActualScale (notes, beginIndex, endIndex))
	{
	  return false;
	}
      int i;
      int j;
      double[] note = null;
      double[] rescale = Event.createEvent ();
      double scale;
      double moveToTarget;
      double a;
      double t;
      double d;
      for (j = Event.INSTRUMENT; j < Event.HOMOGENEITY; j++)
	{
	  if (Math.abs (scaleActualRanges[j]) > Float.MIN_VALUE)
	    {
	      t = scaleTargetRanges[j];
	      a = scaleActualRanges[j];
	      d = t / a;
	      rescale[j] = d;
	    }
	  else
	    {
	      rescale[j] = 1;
	    }
	}
      for (i = beginIndex; i < endIndex; i++)
	{
	  note = notes.getEvent (i);
	  if (note != null)
	    {
	      if (Event.isNote (note))
		{
		  for (j = Event.INSTRUMENT; j < Event.HOMOGENEITY; j++)
		    {
		      double moveToOrigin = scaleActualMinima[j];
		      if (rescaleRanges[j])
			{
			  scale = rescale[j];
			}
		      else
			{
			  scale = 1.0;
			}
		      if (rescaleMinima[j])
			{
			  moveToTarget = scaleTargetMinima[j];
			}
		      else
			{
			  moveToTarget = moveToOrigin;
			}
		      d = note[j];
		      d = d - moveToOrigin;
		      d = d * scale;
		      d = d + moveToTarget;
		      note[j] = d;
		    }
		}
	    }
	}
      findActualScale (notes, beginIndex, endIndex);
    }
    catch (Exception e)
    {
      e.printStackTrace ();
    }
    return returnValue;
  }
	/**
	 *  First rescales all notes produced by children of this to fit the target scale,
	 *  then applies the global matrix to the result.
	 */
  public double[][] produceOrTransformNotes (double[][]compositeTransform,
					     Score score,
					     int preTraversalCount,
					     int postTraversalCount)
  {
    try
    {
      setActualScaleToTarget (score, preTraversalCount, postTraversalCount);
    }
    catch (Exception e)
    {
      e.printStackTrace ();
    }
    return compositeTransform;
  }
  public void openView ()
  {
    RescaleView rescaleView = new RescaleView (this);
      rescaleView.setVisible (true);
  }
  public Container getView ()
  {
    RescaleView view = new RescaleView (this);
      return view;
  }
  //public void findActualScale()
  //{
  //      findActualScale(this, 0, getChildCount());
  //}
}
