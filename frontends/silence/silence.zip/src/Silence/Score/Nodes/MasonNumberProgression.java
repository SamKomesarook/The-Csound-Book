package Silence.Score.Nodes;
import Silence.Orchestra.Event;
import Silence.Score.Score;
import Silence.Score.MasonNumbers;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import java.awt.*;
import java.io.*;
import java.util.*;
/**
Defines a temporal sequence of pitch-class sets,
or operations upon pitch-class sets,
which are represented as Mason numbers.
Each element of the sequence is a triple <time, Mason number, operation>,
where time is relative to the total time of the child notes of this node;
a Mason number of 0 means use the Mason number of the child notes of the
temporal segment, but a Mason number greater than 0 means use that Mason number;
and the pitch-classes of the child notes of the segment
finally are conformed to the Mason number
that is the product of the original Mason number and the operation
(2 transposes up a perfect fifth).
Times can be relative (sequential from 0 at the beginning of the node),
or delta times.
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class MasonNumberProgression extends Node implements NodeInterface,
  java.io.Serializable
  {
  public MasonNumberProgression ()
  {
    defaultsMasonNumberProgression ();
  }
  public ArrayList times = new ArrayList ();
  public ArrayList masonNumbers = new ArrayList ();
  public ArrayList operations = new ArrayList ();
  boolean relativeTimes = true;
  ArrayList cumulativeTimes = new ArrayList ();
  ArrayList segments = new ArrayList ();
  public void defaultsMasonNumberProgression ()
  {
    times.clear ();
    cumulativeTimes.clear ();
    masonNumbers.clear ();
    operations.clear ();
    relativeTimes = true;
  }
  public NodeInterface copy()
  {
    MasonNumberProgression copy = new MasonNumberProgression();
    copyFieldsInto(copy);
    return copy;
  }
  public void copyFieldsInto(NodeInterface copy_)
  {
    MasonNumberProgression copy = (MasonNumberProgression) copy_;
    super.copyFieldsInto(copy);
    copy.times = (ArrayList) times.clone();
    copy.masonNumbers = (ArrayList) masonNumbers.clone();
    copy.operations = (ArrayList) operations.clone();
    copy.relativeTimes = relativeTimes;
  }
  void parseString (String text)
  {
    times.clear ();
    masonNumbers.clear ();
    operations.clear ();
    String token = null;
    StringTokenizer tokenizer = new StringTokenizer (text);
    while (tokenizer.hasMoreTokens ())
    {
      token = tokenizer.nextToken ();
      times.add (Double.valueOf (token));
      token = tokenizer.nextToken ();
      masonNumbers.add (Double.valueOf (token));
      token = tokenizer.nextToken ();
      operations.add (Double.valueOf (token));
    }
  }
  void parseVector (ArrayList vector)
  {
    times.clear ();
    masonNumbers.clear ();
    operations.clear ();
    int n = vector.size ();
    for (int i = 0; i < n;)
    {
      times.add (Double.valueOf ((String) vector.get (i++)));
      masonNumbers.add (Double.valueOf ((String) vector.get (i++)));
      operations.add (Double.valueOf ((String) vector.get (i++)));
    }
  }
  String formatString ()
  {
    StringBuffer buffer = new StringBuffer ();
    int n = times.size ();
    for (int i = 0; i < n; i++)
    {
      buffer.append (String.valueOf (times.get (i)));
      buffer.append (" ");
      buffer.append (String.valueOf (masonNumbers.get (i)));
      buffer.append (" ");
      buffer.append (String.valueOf (operations.get (i)));
      buffer.append (" ");
    }
    return buffer.toString ();
  }
  public String formatStringWithNewlines ()
  {
    ByteArrayOutputStream buffer = new ByteArrayOutputStream ();
    PrintStream printStream = new PrintStream (buffer);
    int n = times.size ();
    for (int i = 0; i < n; i++)
    {
      printStream.print (times.get (i));
      printStream.print (" ");
      printStream.print (masonNumbers.get (i));
      printStream.print (" ");
      printStream.print (operations.get (i));
      printStream.println ();
    }
    return buffer.toString ();
  }
  int segmentForTime (double time)
  {
    int n = masonNumbers.size ();
    if (relativeTimes)
    {
      for (int i = 0; i < n; i++)
      {
        if (((Double) cumulativeTimes.get (i)).doubleValue () > time)
        {
          return i;
        }
      }
    }
    else
    {
      for (int i = 0; i < n; i++)
      {
        if (((Double) times.get (i)).doubleValue () > time)
        {
          return i;
        }
      }
    }
    return -1;
  }
  public double[][] produceOrTransformNotes (double[][]compositeTransform,
                                             Score score,
                                             int preTraversalCount,
                                             int postTraversalCount)
  {
    System.
      out.println ("BEGAN MasonNumberProgression.produceOrTransformNotes()...");
    //  Find the total duration of notes produced by the child nodes of this.
    double[] note = score.getEvent (preTraversalCount);
    if (note == null)
    {
      return compositeTransform;
    }
    double beginSeconds = Event.getTime (note);
    double endSeconds = beginSeconds;
    double childNotesDurationSeconds = 0;
    for (int i = preTraversalCount; i < postTraversalCount; i++)
    {
      note = score.getEvent (i);
      if (beginSeconds > Event.getTime (note))
      {
        beginSeconds = Event.getTime (note);
      }
      if (endSeconds < Event.getTime (note) + Event.getDuration (note))
      {
        endSeconds = Event.getTime (note) + Event.getDuration (note);
      }
    }
    childNotesDurationSeconds = endSeconds - beginSeconds;
    //  Find the total duration of the time.
    double cumulativeTime = 0;
    cumulativeTimes.clear ();
    for (int i = 0; i < times.size (); i++)
    {
      cumulativeTime += ((Double) times.get (i)).doubleValue ();
      cumulativeTimes.add (new Double (cumulativeTime));
    }
    double totalTimes =
      ((Double) cumulativeTimes.
       get (cumulativeTimes.size () - 1)).doubleValue ();
    //  Apply the appropriate Mason numbers.
    int masonNumberIndex;
    int segmentCount = masonNumbers.size ();
    Score[]segments = new Score[segmentCount];
    for (int i = 0; i < segmentCount; i++)
    {
      segments[i] = new Score ();
    }
    for (int i = preTraversalCount; i < postTraversalCount; i++)
    {
      note = score.getEvent (i);
      masonNumberIndex =
        segmentForTime (
                        ((Event.getTime (note) - beginSeconds) /
                         childNotesDurationSeconds) * totalTimes);
      if (masonNumberIndex == -1)
      {
        System.out.println ("Note " + i + " segment out of range.");
      }
      else
      {
        segments[masonNumberIndex].add (note);
      }
    }
    for (int segmentIndex = 0; segmentIndex < segmentCount; segmentIndex++)
    {
      Score segment = segments[segmentIndex];
      System.out.println("Segment " + segmentIndex + ": " + segment.size() + " events.");
      double operation =
        ((Double) operations.get (segmentIndex)).doubleValue ();
      double masonNumber =
        ((Double) masonNumbers.get (segmentIndex)).doubleValue ();
      if (masonNumber == 0 && operation == 0)
      {
        System.out.println("  No operation.");
      }
      else if (masonNumber == 0 && operation != 0)
      {
        System.out.println ("  operation = " + operation);
        MasonNumbers.multiply(operation, segment);
      }
      else if (masonNumber != 0 && operation == 0)
      {
        System.out.println ("  New Mason number = " + masonNumber);
        segment.conformToMasonNumber (masonNumber);
      }
      else if (masonNumber != 0 && operation != 0)
      {
        System.out.println ("  Mason number = " + masonNumber);
        System.out.println ("  operation = " + operation);
        masonNumber = masonNumber * operation;
        System.out.println ("  New Mason number = " + operation);
        segment.conformToMasonNumber (masonNumber);
      }
    }
    System.
      out.println ("ENDED MasonNumberProgression.produceOrTransformNotes().");
    return compositeTransform;
  }
  public void openView ()
  {
    MasonNumberProgressionView view = new MasonNumberProgressionView (this);
    view.setVisible (true);
  }
  public Container getView ()
  {
    return new MasonNumberProgressionView (this);
  }
}
