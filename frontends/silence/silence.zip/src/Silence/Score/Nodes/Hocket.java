package Silence.Score.Nodes;
import Silence.Mathematics.Matrix;
import Silence.Orchestra.Event;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import java.awt.*;
import java.io.*;
import java.util.*;
/**
Decimates a stream of notes.
Several Hocket nodes with different indexes
can be be used to hocket a common child node.
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class Hocket extends Node implements NodeInterface,
  java.io.Serializable
  {
  int hocketCount = 2;
  int hocketIndex = 0;
  public Hocket ()
  {
    defaultsHocket ();
  }
  public void defaultsHocket ()
  {
    score = new Score();
    hocketCount = 2;
    hocketIndex = 0;
  }
  public NodeInterface copy()
  {
    Hocket copy = new Hocket();
    copyFieldsInto(copy);
    return copy;
  }
  public void copyFieldsInto(NodeInterface copy_)
  {
    Hocket copy = (Hocket) copy_;
    super.copyFieldsInto(copy);
    copy.hocketCount = hocketCount;
    copy.hocketIndex = hocketIndex;
  }
  public double[][] traverseMusicGraph (double[][]parentTransformation,
                                        Score score)
  {
    this.score.clear();
    int preTraversalCount = this.score.size ();
    double[][] compositeTransformation =
      Matrix.times (parentTransformation, getLocalTransformation ());
    for (int i = 0, n = getChildCount (); i < n; i++)
    {
      getChild (i).traverseMusicGraph (compositeTransformation, this.score);
    }
    int postTraversalCount = this.score.size ();
    double[][] transformation =
      produceOrTransformNotes (compositeTransformation, score,
                               preTraversalCount, postTraversalCount);
    System.gc ();
    return transformation;
  }
  public double[][] produceOrTransformNotes (double[][]compositeTransform,
                                             Score score,
                                             int preTraversalCount,
                                             int postTraversalCount)
  {
    this.score.sort();
    //  Produce a decimated clone of the child notes of this.
    for (int i = hocketIndex, n = this.score.size (); i < n; i += hocketCount)
    {
      double[] note = (double[]) this.score.get (i);
      score.addEvent (note);
    }
    return compositeTransform;
  }
  public void openView ()
  {
    HocketView view = new HocketView (this);
    view.setVisible (true);
  }
  public Container getView ()
  {
    return new HocketView (this);
  }
}
