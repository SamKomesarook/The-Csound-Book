package Silence.Score.Nodes;
import Silence.Score.Score;
import Silence.Score.ScoreView;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;
/**
 * @author Copyright (C) 2000 by Michael Gogins. All rights reserved.
 * <ADDRESS>
 * gogins@pipeline.com
 * </ADDRESS>
 */
public class StrangeAttractorView extends JPanel
{
  public static void main (String[]args)
  {
    JFrame frame = new JFrame ();
    StrangeAttractorView strangeAttractorView = new StrangeAttractorView ();
    frame.getContentPane ().add (strangeAttractorView);
    frame.setBounds (50, 50, 800, 600);
    frame.setVisible (true);
  }
  boolean cancelIteration = false;
  ArrayList codes = new ArrayList();
  int codeIndex = -1;
  Score score = null;
  ScoreView scoreView = null;
  StrangeAttractor strangeAttractor = null;
  BorderLayout borderLayout1 = new BorderLayout ();
  JTabbedPane tabs = new JTabbedPane ();
  JPanel parametersPanel = new JPanel ();
  BorderLayout borderLayout2 = new BorderLayout ();
  JPanel innerParametersPanel = new JPanel ();
  JTextField nameTextField = new JTextField ();
  JPanel namePanel = new JPanel ();
  JLabel nameLabel = new JLabel ();
  JPanel codePanel = new JPanel ();
  JLabel codeLabel = new JLabel ();
  JScrollPane jScrollPane1 = new JScrollPane ();
  JTextArea codeTextArea = new JTextArea ();
  JPanel dynamicalSystemPanel = new JPanel ();
  JLabel dynamicalSystemLabel = new JLabel ();
  JComboBox dynamicalSystemComboBox = new JComboBox ();
  BorderLayout borderLayout3 = new BorderLayout ();
  BorderLayout borderLayout4 = new BorderLayout ();
  BorderLayout borderLayout5 = new BorderLayout ();
  JPanel fractalPanel = new JPanel ();
  JLabel iterationLabel = new JLabel ();
  JTextField iterationsTextField = new JTextField ();
  JTextField iterationTextField = new JTextField ();
  JLabel lyupanovLabel = new JLabel ();
  JLabel ofLabel = new JLabel ();
  JTextField lyupanovTextField = new JTextField ();
  JTextField fractalDimensionTextField = new JTextField ();
  JLabel fractalDimensionlabel = new JLabel ();
  JPanel interpretationPanel = new JPanel ();
  JLabel interpretationLabel = new JLabel ();
  JLabel iterationPanelLabel = new JLabel ();
  JRadioButton orbitScoreRadioButton = new JRadioButton ();
  JRadioButton attractorScoreRadioButton = new JRadioButton ();
  ButtonGroup Frequencies = new javax.swing.ButtonGroup ();
  JButton searchButton = new JButton ();
  JToolBar toolBar = new JToolBar ();
  JButton updateButton = new JButton ();
  JButton exitButton = new JButton ();
  JButton newButton = new JButton ();
  JButton evaluateButton = new JButton ();
  JButton storeButton = new JButton();
  JButton restoreButton = new JButton();
  JButton clearButton = new JButton();
  public StrangeAttractorView ()
  {
    this (new StrangeAttractor ());
  }
  public StrangeAttractorView (StrangeAttractor strangeAttractor)
  {
    this.strangeAttractor = strangeAttractor;
    try
    {
      jbInit ();
      Frequencies.add (orbitScoreRadioButton);
      Frequencies.add (attractorScoreRadioButton);
      dynamicalSystemComboBox.addItem ("1-dimensional polynomial map");
      dynamicalSystemComboBox.addItem ("2-dimensional polynomial map");
      dynamicalSystemComboBox.addItem ("3-dimensional polynomial map");
      dynamicalSystemComboBox.addItem ("4-dimensional polynomial map");
      dynamicalSystemComboBox.addItem
        ("3-dimensional ordinary differential equation");
      dynamicalSystemComboBox.addItem
        ("4-dimensional ordinary differential equation");
      dynamicalSystemComboBox.addItem ("4-dimensional special map Y");
      dynamicalSystemComboBox.addItem ("4-dimensional special map Z");
      dynamicalSystemComboBox.addItem ("4-dimensional special map [");
      dynamicalSystemComboBox.addItem ("4-dimensional special map \\");
      dynamicalSystemComboBox.addItem ("4-dimensional special map ]");
      score = strangeAttractor.getLocalScore ();
      score.autoRescale = true;
      scoreView = (ScoreView) score.getView ();
      tabs.add (scoreView, "Score");
      updateView ();
    }
    catch (Exception ex)
    {
      ex.printStackTrace ();
    }
  }
  private void jbInit () throws Exception
  {
    this.setLayout (borderLayout1);
    parametersPanel.setLayout (borderLayout2);
    innerParametersPanel.setLayout (null);
    namePanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    namePanel.setBounds (new Rectangle (8, 13, 195, 44));
    namePanel.setLayout (borderLayout4);
    nameLabel.setHorizontalAlignment (SwingConstants.CENTER);
    nameLabel.setText ("Name");
    codePanel.setLayout (borderLayout3);
    codePanel.setBounds (new Rectangle (8, 9, 153, 61));
    codePanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    codePanel.setBounds (new Rectangle (8, 60, 395, 92));
    codePanel.setBounds (new Rectangle (8, 9, 153, 61));
    codePanel.setBounds (new Rectangle (8, 64, 527, 141));
    codeLabel.setHorizontalAlignment (SwingConstants.CENTER);
    codeLabel.setText ("Code");
    dynamicalSystemPanel.setLayout (borderLayout5);
    dynamicalSystemPanel.setBounds (new Rectangle (8, 9, 153, 61));
    dynamicalSystemPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    dynamicalSystemPanel.setBounds (new Rectangle (208, 13, 195, 44));
    dynamicalSystemPanel.setBounds (new Rectangle (8, 9, 153, 61));
    dynamicalSystemPanel.setBounds (new Rectangle (209, 13, 326, 45));
    dynamicalSystemLabel.setHorizontalAlignment (SwingConstants.CENTER);
    dynamicalSystemLabel.setText ("Dynamical System");
    fractalPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    fractalPanel.setBounds (new Rectangle (8, 212, 527, 86));
    fractalPanel.setLayout (null);
    iterationLabel.setText ("Iteration");
    iterationLabel.setBounds (new Rectangle (14, 32, 115, 20));
    iterationsTextField.setBounds (new Rectangle (382, 32, 135, 20));
    iterationTextField.setBounds (new Rectangle (105, 8, 87, 20));
    iterationTextField.setBounds (new Rectangle (105, 9, 87, 20));
    iterationTextField.setEditable (false);
    iterationTextField.setBounds (new Rectangle (50, 2, 48, 31));
    lyupanovLabel.setBounds (new Rectangle (7, 8, 87, 20));
    lyupanovLabel.setBounds (new Rectangle (197, 40, 87, 20));
    lyupanovLabel.setHorizontalAlignment (SwingConstants.CENTER);
    lyupanovLabel.setText ("Lyupanov exponent");
    lyupanovLabel.setBounds (new Rectangle (194, 47, 48, 30));
    ofLabel.setBounds (new Rectangle (7, 8, 87, 20));
    ofLabel.setBounds (new Rectangle (7, 8, 87, 20));
    ofLabel.setBounds (new Rectangle (198, 6, 87, 20));
    ofLabel.setBounds (new Rectangle (7, 8, 87, 20));
    ofLabel.setBounds (new Rectangle (7, 8, 87, 20));
    ofLabel.setBounds (new Rectangle (7, 8, 87, 20));
    ofLabel.setText ("of");
    ofLabel.setBounds (new Rectangle (113, 0, 48, 38));
    ofLabel.setHorizontalAlignment (SwingConstants.CENTER);
    ofLabel.setBounds (new Rectangle (198, 6, 87, 20));
    ofLabel.setBounds (new Rectangle (197, 9, 87, 20));
    ofLabel.setBounds (new Rectangle (7, 8, 87, 20));
    ofLabel.setBounds (new Rectangle (7, 8, 87, 20));
    ofLabel.setBounds (new Rectangle (198, 6, 87, 20));
    ofLabel.setBounds (new Rectangle (7, 8, 87, 20));
    ofLabel.setBounds (new Rectangle (7, 8, 87, 20));
    ofLabel.setBounds (new Rectangle (7, 8, 87, 20));
    ofLabel.setBounds (new Rectangle (262, 32, 115, 20));
    lyupanovTextField.setBounds (new Rectangle (287, 6, 87, 20));
    lyupanovTextField.setBounds (new Rectangle (289, 40, 87, 20));
    lyupanovTextField.setEditable (false);
    lyupanovTextField.setBounds (new Rectangle (175, 2, 48, 32));
    fractalDimensionTextField.setBounds (new Rectangle (105, 8, 87, 20));
    fractalDimensionTextField.setBounds (new Rectangle (105, 8, 87, 20));
    fractalDimensionTextField.setBounds (new Rectangle (99, 6, 87, 20));
    fractalDimensionTextField.setBounds (new Rectangle (105, 8, 87, 20));
    fractalDimensionTextField.setBounds (new Rectangle (105, 8, 87, 20));
    fractalDimensionTextField.setBounds (new Rectangle (105, 8, 87, 20));
    fractalDimensionTextField.setEditable (false);
    fractalDimensionTextField.setBounds (new Rectangle (133, 56, 48, 25));
    fractalDimensionTextField.setBounds (new Rectangle (99, 6, 87, 20));
    fractalDimensionTextField.setBounds (new Rectangle (105, 40, 87, 20));
    fractalDimensionTextField.setBounds (new Rectangle (105, 8, 87, 20));
    fractalDimensionTextField.setBounds (new Rectangle (105, 8, 87, 20));
    fractalDimensionTextField.setBounds (new Rectangle (99, 6, 87, 20));
    fractalDimensionTextField.setBounds (new Rectangle (105, 8, 87, 20));
    fractalDimensionTextField.setBounds (new Rectangle (105, 8, 87, 20));
    fractalDimensionTextField.setBounds (new Rectangle (105, 8, 87, 20));
    fractalDimensionTextField.setBounds (new Rectangle (122, 56, 135, 20));
    fractalDimensionlabel.setBounds (new Rectangle (8, 6, 87, 20));
    fractalDimensionlabel.setBounds (new Rectangle (13, 40, 87, 20));
    fractalDimensionlabel.setText ("Fractal dimension");
    fractalDimensionlabel.setBounds (new Rectangle (33, 59, 48, 24));
    interpretationPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    interpretationPanel.setBounds (new Rectangle (8, 304, 528, 86));
    interpretationPanel.setLayout (null);
    interpretationLabel.setHorizontalAlignment (SwingConstants.CENTER);
    interpretationLabel.setText ("Interpretation");
    interpretationLabel.setBounds (new Rectangle (6, 4, 516, 23));
    iterationPanelLabel.setBounds (new Rectangle (5, 6, 447, 23));
    iterationPanelLabel.setBounds (new Rectangle (7, 4, 447, 23));
    iterationPanelLabel.setText ("Iteration");
    iterationPanelLabel.setHorizontalAlignment (SwingConstants.CENTER);
    orbitScoreRadioButton.setSelected (true);
    orbitScoreRadioButton.setText
      ("Orbit (Instr = z, Start = iteration, Dur = x, Key = y, dB = w, " +
       "Pan = random)");
    orbitScoreRadioButton.setBounds (new Rectangle (16, 53, 431, 23));
    attractorScoreRadioButton.setBounds (new Rectangle (15, 56, 431, 23));
    attractorScoreRadioButton.setText
      ("Attractor (Instr = z, Start = x, Dur = .25, Key = y, dB = w, Pan "
       + "= random)");
    codeTextArea.setLineWrap (true);
    searchButton.setText(" Search ");
    searchButton.addActionListener(new
                                   StrangeAttractorView_searchButton_actionAdapter
                                   (this));
    toolBar.setFloatable(false);
    updateButton.setText(" Update ");
    updateButton.addActionListener(new
                                   StrangeAttractorView_updateButton_actionAdapter
                                   (this));
    exitButton.setText(" Exit ");
    exitButton.addActionListener(new
                                 StrangeAttractorView_exitButton_actionAdapter
                                 (this));
    newButton.setText(" New ");
    newButton.addActionListener(new
                                StrangeAttractorView_newButton_actionAdapter
                                (this));
    evaluateButton.setText(" Evaluate ");
    evaluateButton.addActionListener(new
                                     StrangeAttractorView_evaluateButton_actionAdapter
                                     (this));
    storeButton.setToolTipText("");
    storeButton.setText(" Store ");
    storeButton.addActionListener(new java.awt.event.ActionListener()
                                  {
        public void actionPerformed(ActionEvent e)
        {
          storeButton_actionPerformed(e);
        }
      }
    );
    restoreButton.setText(" Restore ");
    restoreButton.addActionListener(new java.awt.event.ActionListener()
                                    {
        public void actionPerformed(ActionEvent e)
        {
          restoreButton_actionPerformed(e);
        }
      }
    );
    clearButton.setText(" Clear ");
    clearButton.addActionListener(new java.awt.event.ActionListener()
                                  {
        public void actionPerformed(ActionEvent e)
        {
          clearButton_actionPerformed(e);
        }
      }
    );
    this.add (tabs, BorderLayout.CENTER);
    this.add(toolBar, BorderLayout.NORTH);
    toolBar.add(newButton, null);
    toolBar.add(searchButton, null);
    toolBar.add(evaluateButton, null);
    toolBar.add(updateButton, null);
    toolBar.add(storeButton, null);
    toolBar.add(restoreButton, null);
    toolBar.add(clearButton, null);
    toolBar.add(exitButton, null);
    tabs.add (parametersPanel, "Parameters");
    parametersPanel.add (innerParametersPanel, BorderLayout.CENTER);
    innerParametersPanel.add (namePanel, null);
    namePanel.add (nameLabel, BorderLayout.NORTH);
    namePanel.add (nameTextField, BorderLayout.CENTER);
    innerParametersPanel.add (dynamicalSystemPanel, null);
    dynamicalSystemPanel.add (dynamicalSystemLabel, BorderLayout.NORTH);
    dynamicalSystemPanel.add (dynamicalSystemComboBox, BorderLayout.CENTER);
    innerParametersPanel.add (codePanel, null);
    codePanel.add (codeLabel, BorderLayout.NORTH);
    codePanel.add (jScrollPane1, BorderLayout.CENTER);
    innerParametersPanel.add (fractalPanel, null);
    fractalPanel.add (iterationLabel, null);
    fractalPanel.add (fractalDimensionlabel, null);
    fractalPanel.add (iterationPanelLabel, null);
    fractalPanel.add (iterationTextField, null);
    fractalPanel.add (fractalDimensionTextField, null);
    fractalPanel.add (lyupanovLabel, null);
    fractalPanel.add (ofLabel, null);
    fractalPanel.add (lyupanovTextField, null);
    fractalPanel.add (iterationsTextField, null);
    innerParametersPanel.add (interpretationPanel, null);
    interpretationPanel.add (interpretationLabel, null);
    interpretationPanel.add (attractorScoreRadioButton, null);
    interpretationPanel.add (orbitScoreRadioButton, null);
    jScrollPane1.getViewport ().add (codeTextArea, null);
    iterationTextField.setBounds (new Rectangle (122, 32, 135, 20));
    lyupanovLabel.setBounds (new Rectangle (262, 56, 115, 20));
    lyupanovTextField.setBounds (new Rectangle (382, 56, 135, 20));
    fractalDimensionlabel.setBounds (new Rectangle (14, 56, 115, 20));
    iterationPanelLabel.setBounds (new Rectangle (5, 6, 517, 23));
    attractorScoreRadioButton.setBounds (new Rectangle (16, 30, 431, 23));
  }
  void exitButton_actionPerformed (ActionEvent e)
  {
    System.exit (0);
  }
  void newButton_actionPerformed (ActionEvent e)
  {
    strangeAttractor.defaultsStrangeAttractor ();
  }
  void searchButton_actionPerformed (ActionEvent e)
  {
    try
    {
      updateModel ();
      for (cancelIteration = false, strangeAttractor.N = 1;
          !cancelIteration && strangeAttractor.searchForAttractor ();)
      {
        if (strangeAttractor.N % 100 == 0)
        {
          updateView ();
        }
      }
      if (cancelIteration)
      {
        return;
      }
      updateView ();
      evaluateButton_actionPerformed (e);
    }
    catch (Exception x)
    {
      x.printStackTrace ();
    }
  }
  void evaluateButton_actionPerformed (ActionEvent e)
  {
    try
    {
      updateModel ();
      for (cancelIteration = false, strangeAttractor.N = 1;
          !cancelIteration && strangeAttractor.evaluateAttractor ();)
      {
        if (strangeAttractor.N % 100 == 0)
        {
          updateView ();
          repaint ();
        }
      }
      updateView ();
      if (cancelIteration)
      {
        return;
      }
      if (strangeAttractor.score.autoRescale)
      {
        strangeAttractor.score.setActualScaleToTarget ();
      }
      tabs.setSelectedIndex (1);
    }
    catch (Exception x)
    {
      x.printStackTrace ();
    }
  }

  void updateButton_actionPerformed (ActionEvent e)
  {
    updateModel ();
  }
  public void updateModel ()
  {
    strangeAttractor.setName (nameTextField.getText ().trim ());
    strangeAttractor.setScoreType (orbitScoreRadioButton.
                                   isSelected ()? 1 : 0);
    //      1-dimensional polynomial map
    //      2-dimensional polynomial map
    //      3-dimensional polynomial map
    //      4-dimensional polynomial map
    //      3-dimensional ordinary differential equation
    //      4-dimensional ordinary differential equation
    //      4-dimensional special map Y
    //      4-dimensional special map Z
    //      4-dimensional special map [
    //      4-dimensional special map \
    //      4-dimensional special map ]
    //      4-dimensional special map ^
    if (dynamicalSystemComboBox.getSelectedItem ().
        toString ().compareTo ("1-dimensional polynomial map") == 0)
    {
      strangeAttractor.setAttractorType (1);
    }
    else if (dynamicalSystemComboBox.getSelectedItem ().
        toString ().compareTo ("2-dimensional polynomial map") == 0)
    {
      strangeAttractor.setAttractorType (2);
    }
    else if (dynamicalSystemComboBox.getSelectedItem ().
        toString ().compareTo ("3-dimensional polynomial map") == 0)
    {
      strangeAttractor.setAttractorType (3);
    }
    else if (dynamicalSystemComboBox.getSelectedItem ().
        toString ().compareTo ("4-dimensional polynomial map") == 0)
    {
      strangeAttractor.setAttractorType (4);
    }
    else if (dynamicalSystemComboBox.getSelectedItem ().toString ().compareTo
        ("3-dimensional ordinary differential equation") == 0)
    {
      strangeAttractor.setAttractorType (5);
    }
    else if (dynamicalSystemComboBox.getSelectedItem ().toString ().compareTo
        ("4-dimensional ordinary differential equation") == 0)
    {
      strangeAttractor.setAttractorType (6);
    }
    else if (dynamicalSystemComboBox.getSelectedItem ().
        toString ().compareTo ("4-dimensional special map Y") == 0)
    {
      strangeAttractor.setAttractorType (7);
    }
    else if (dynamicalSystemComboBox.getSelectedItem ().
        toString ().compareTo ("4-dimensional special map Z") == 0)
    {
      strangeAttractor.setAttractorType (8);
    }
    else if (dynamicalSystemComboBox.getSelectedItem ().
        toString ().compareTo ("4-dimensional special map [") == 0)
    {
      strangeAttractor.setAttractorType (9);
    }
    else if (dynamicalSystemComboBox.getSelectedItem ().
        toString ().compareTo ("4-dimensional special map \\") == 0)
    {
      strangeAttractor.setAttractorType (10);
    }
    else if (dynamicalSystemComboBox.getSelectedItem ().
        toString ().compareTo ("4-dimensional special map ]") == 0)
    {
      strangeAttractor.setAttractorType (11);
    }
    else if (dynamicalSystemComboBox.getSelectedItem ().
        toString ().compareTo ("4-dimensional special map ^") == 0)
    {
      strangeAttractor.setAttractorType (12);
    }
    strangeAttractor.setCode (codeTextArea.getText ());
    strangeAttractor.setIterationCount (Integer.parseInt
                                        (iterationsTextField.
                                         getText ()));
  }
  public void updateView ()
  {
    nameTextField.setText (strangeAttractor.getName ());
    switch (strangeAttractor.getAttractorType ())
    {
    case 1:
      dynamicalSystemComboBox.setSelectedItem
        ("1-dimensional polynomial map");
      break;
    case
        2:dynamicalSystemComboBox.setSelectedItem
        ("2-dimensional polynomial map");
      break;
    case
        3:dynamicalSystemComboBox.setSelectedItem
        ("3-dimensional polynomial map");
      break;
    case
        4:dynamicalSystemComboBox.setSelectedItem
        ("4-dimensional polynomial map");
      break;
    case
        5:dynamicalSystemComboBox.setSelectedItem
        ("3-dimensional ordinary differential equation");
      break;
    case
        6:dynamicalSystemComboBox.setSelectedItem
        ("4-dimensional ordinary differential equation");
      break;
    case
        7:dynamicalSystemComboBox.setSelectedItem
        ("4-dimensional special map Y");
      break;
    case
        8:dynamicalSystemComboBox.setSelectedItem
        ("4-dimensional special map Z");
      break;
    case
        9:dynamicalSystemComboBox.setSelectedItem
        ("4-dimensional special map [");
      break;
    case
        10:dynamicalSystemComboBox.setSelectedItem
        ("4-dimensional special map /");
      break;
    case
        11:dynamicalSystemComboBox.setSelectedItem
        ("4-dimensional special map ]");
      break;
    case
        12:dynamicalSystemComboBox.setSelectedItem
        ("4-dimensional special map ^");
      break;
    case
        13:dynamicalSystemComboBox.setSelectedItem
        ("4-dimensional special map [");
      break;
    }
    codeTextArea.setText (strangeAttractor.getCode ());
    fractalDimensionTextField.
      setText (String.valueOf (strangeAttractor.getFractalDimension ()));
    iterationsTextField.
      setText (String.valueOf (strangeAttractor.getIterationCount ()));
    iterationTextField.
      setText (String.valueOf (strangeAttractor.getIteration ()));
    lyupanovTextField.
      setText (String.valueOf (strangeAttractor.getLyupanovExponent ()));
    orbitScoreRadioButton.setSelected (strangeAttractor.getScoreType () ==
                                       0 ? false : true);
    scoreView.updateView ();
  }

  void storeButton_actionPerformed(ActionEvent e)
  {
    codes.add(codeTextArea.getText());
    codeIndex = codes.size();
    System.out.println("Storing code " + (codeIndex - 1) + " = " + strangeAttractor.code);
  }

  void restoreButton_actionPerformed(ActionEvent e)
  {
    if(codes.isEmpty())
    {
      return;
    }
    codeIndex--;
    if(codeIndex >= codes.size() || codeIndex < 0)
    {
      codeIndex = codes.size() - 1;
    }
    String code = (String) codes.get(codeIndex);
    codeTextArea.setText(code);
    System.out.println("Restoring code " + codeIndex + " = " + code);
    evaluateButton_actionPerformed(null);
  }

  void clearButton_actionPerformed(ActionEvent e)
  {
    codes.clear();
    codeIndex = 0;
  }
}

class StrangeAttractorView_exitButton_actionAdapter implements java.awt.
  event.ActionListener
  {
  StrangeAttractorView adaptee;

  StrangeAttractorView_exitButton_actionAdapter (StrangeAttractorView adaptee)
  {
    this.adaptee = adaptee;
  }

  public void actionPerformed (ActionEvent e)
  {
    adaptee.exitButton_actionPerformed (e);
  }
}
class StrangeAttractorView_newButton_actionAdapter implements java.awt.
  event.ActionListener
  {
  StrangeAttractorView adaptee;

  StrangeAttractorView_newButton_actionAdapter (StrangeAttractorView adaptee)
  {
    this.adaptee = adaptee;
  }
  public void actionPerformed (ActionEvent e)
  {
    adaptee.newButton_actionPerformed (e);
  }
}
class StrangeAttractorView_searchButton_actionAdapter implements java.
  awt.event.ActionListener
  {
  StrangeAttractorView adaptee;

  StrangeAttractorView_searchButton_actionAdapter (StrangeAttractorView adaptee)
  {
    this.adaptee = adaptee;
  }
  public void actionPerformed (ActionEvent e)
  {
    adaptee.searchButton_actionPerformed (e);
  }
}
class StrangeAttractorView_evaluateButton_actionAdapter implements java.
  awt.event.ActionListener
  {
  StrangeAttractorView adaptee;

  StrangeAttractorView_evaluateButton_actionAdapter (StrangeAttractorView adaptee)
  {
    this.adaptee = adaptee;
  }
  public void actionPerformed (ActionEvent e)
  {
    adaptee.evaluateButton_actionPerformed (e);
  }
}
class StrangeAttractorView_updateButton_actionAdapter implements java.
  awt.event.ActionListener
  {
  StrangeAttractorView adaptee;

  StrangeAttractorView_updateButton_actionAdapter (StrangeAttractorView adaptee)
  {
    this.adaptee = adaptee;
  }
  public void actionPerformed (ActionEvent e)
  {
    adaptee.updateButton_actionPerformed (e);
  }
}
