package Silence.Score.Nodes;
import Silence.Orchestra.Event;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import Silence.Mathematics.*;
import java.awt.*;
import java.applet.*;
import java.io.*;
import java.util.*;
/**
Moves all child nodes and all notes produced by them to the origin
of the global coordinate system, rescales them, and returns them
to their original position. Corresponds to the diagonal of the Transform node.
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class TransformScale extends Transform implements NodeInterface,
  java.io.Serializable
{
  public TransformScale ()
  {
    defaultsTransform ();
  }
  public NodeInterface copy()
  {
    TransformScale copy = new TransformScale();
    copyFieldsInto(copy);
    return copy;
  }
  public void copyFieldsInto(NodeInterface copy_)
  {
    TransformScale copy = (TransformScale) copy_;
    super.copyFieldsInto(copy);
  }
  public void defaultsTransform ()
  {
    setSize (Event.ELEMENT_COUNT, Event.ELEMENT_COUNT);
  }
  public TransformScale (int rowCount, int columnCount)
  {
    setSize (rowCount, columnCount);
  }
  public double[][] getElements ()
  {
    return M;
  }
  public void setElements (double[][]V)
  {
    M = V;
  }
  /**
  Translate to the origin, rescale, and translate back to the original position.
  */
  public double[][] produceOrTransformNotes (double[][]compositeTransform,
					     Score score,
					     int preTraversalCount,
					     int postTraversalCount)
  {
    //  Second, find their origin.
    Rescale scale = new Rescale ();
      scale.findActualScale (score, preTraversalCount, postTraversalCount);
    //  Third, create matrices to translate the produced notes
    //  to the origin, rescale them, and translate them back to their original position.
    double[][] translateToOrigin = Matrix.identity (Event.ELEMENT_COUNT);
    double[][] rescale = getLocalTransformation ();
    double[][] translateToOriginalPosition =
      Matrix.identity (Event.ELEMENT_COUNT);
    for (int i = 0; i < Event.HOMOGENEITY; i++)
      {
	translateToOrigin[i][Event.HOMOGENEITY] = -scale.scaleActualMinima[i];
	translateToOriginalPosition[i][Event.HOMOGENEITY] =
	  scale.scaleActualMinima[i];
      }
    try
    {
      for (int i = preTraversalCount; i < postTraversalCount; i++)
	{
	  double[] note = score.getEvent (i);
	  double[] newNote = Matrix.times (translateToOrigin, note);
	    newNote = Matrix.times (rescale, newNote);
	    Matrix.times (note, translateToOriginalPosition, newNote);
	}
    }
    catch (Exception e)
    {
      e.printStackTrace ();
    }
    return compositeTransform;
  }
  public double[][] getLocalTransformation ()
  {
    return Matrix.copy (M);
  }
  public void openView ()
  {
    TransformScaleView view = new TransformScaleView (this);
      view.setVisible (true);
  }
  public Container getView ()
  {
    return new TransformScaleView (this);
  }
}
