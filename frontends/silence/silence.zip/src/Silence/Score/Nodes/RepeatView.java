package Silence.Score.Nodes;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import java.awt.*;
import javax.swing.*;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
/**
 *  @author Copyright (C) 1998 by Michael Gogins. All rights reserved.
 *  <ADDRESS>
 *  gogins@pipeline.com
 *  </ADDRESS>
 */
public class RepeatView extends javax.swing.JInternalFrame
{
  Repeat repeat = null;
  public RepeatView (Repeat value)
  {
    this ("Repeat");
    repeat = value;
    updateView ();
  }
  void updateView ()
  {
    nameField.setText (repeat.getName ());
    repeatCountField.setText (String.valueOf (repeat.repeatCount));
    relativeDurationCheckbox.setSelected (repeat.relativeDuration);
    durationSecondsField.setText (String.valueOf (repeat.durationSeconds));
  }
  public void updateModel ()
  {
    repeat.setName (nameField.getText ());
    repeat.repeatCount =
      Integer.parseInt (repeatCountField.getText ());
    repeat.relativeDuration = relativeDurationCheckbox.isSelected ();
    repeat.durationSeconds =
      Double.parseDouble (durationSecondsField.getText ());
    updateView ();
  }
  public RepeatView ()
  {
    setTitle ("Repeat");
    getContentPane ().setLayout (null);
    setVisible (false);
    setSize (444, 314);
    setBackground (new Color (8421504));
    namePanel = new javax.swing.JPanel ();
    namePanel.setLayout (null);
    namePanel.setBounds (12, 12, 420, 72);
    namePanel.setFont (new Font ("Dialog", Font.BOLD, 12));
    namePanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (namePanel);
    nameField = new javax.swing.JTextField ();
    nameField.setBounds (12, 36, 396, 24);
    nameField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    namePanel.add (nameField);
    nameLabel = new javax.swing.JLabel ();
    nameLabel.setText ("Name");
    nameLabel.setHorizontalAlignment (0);
    nameLabel.setHorizontalTextPosition (0);
    nameLabel.setBounds (12, 0, 392, 26);
    nameLabel.setFont (new Font ("Dialog", Font.BOLD, 12));
    namePanel.add (nameLabel);
    parametersPanel = new javax.swing.JPanel ();
    parametersPanel.setLayout (null);
    parametersPanel.setBounds (12, 96, 420, 144);
    parametersPanel.setFont (new Font ("Dialog", Font.BOLD, 12));
    parametersPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (parametersPanel);
    repeatCountField = new javax.swing.JTextField ();
    repeatCountField.setBounds (192, 36, 216, 24);
    repeatCountField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (repeatCountField);
    repeatCountLabel = new javax.swing.JLabel ();
    repeatCountLabel.setText ("Repetition count");
    repeatCountLabel.setBounds (12, 36, 120, 24);
    repeatCountLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (repeatCountLabel);
    relativeDurationCheckbox = new javax.swing.JCheckBox ();
    relativeDurationCheckbox.setText
      ("Duration relative to total duration of notes produced by child nodes");
    relativeDurationCheckbox.setActionCommand
      ("Duration relative to total duration of notes produced by child nodes");
    relativeDurationCheckbox.setBounds (12, 108, 384, 28);
    relativeDurationCheckbox.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (relativeDurationCheckbox);
    durationSecondsField = new javax.swing.JTextField ();
    durationSecondsField.setBounds (192, 72, 216, 24);
    durationSecondsField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (durationSecondsField);
    repeatDuration = new javax.swing.JLabel ();
    repeatDuration.setText ("Repeat at interval (seconds)");
    repeatDuration.setBounds (12, 72, 168, 24);
    repeatDuration.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (repeatDuration);
    parametersLabel = new javax.swing.JLabel ();
    parametersLabel.setText ("Parameters");
    parametersLabel.setHorizontalAlignment (0);
    parametersLabel.setHorizontalTextPosition (0);
    parametersLabel.setBounds (12, 0, 392, 26);
    parametersLabel.setFont (new Font ("Dialog", Font.BOLD, 12));
    parametersPanel.add (parametersLabel);
    buttonPanel = new javax.swing.JPanel ();
    buttonPanel.setLayout (null);
    buttonPanel.setBounds (12, 252, 420, 48);
    buttonPanel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    buttonPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (buttonPanel);
    updateButton = new javax.swing.JButton ();
    updateButton.setText ("Update");
    updateButton.setActionCommand ("button");
    updateButton.setBounds (12, 12, 84, 24);
    updateButton.setFont (new Font ("Dialog", Font.PLAIN, 12));
    buttonPanel.add (updateButton);
    SymAction lSymAction = new SymAction ();
      updateButton.addActionListener (lSymAction);
  }
  public RepeatView (String title)
  {
    this ();
    setTitle (title);
  }
  javax.swing.JPanel namePanel;
    javax.swing.JTextField nameField;
    javax.swing.JLabel nameLabel;
    javax.swing.JPanel parametersPanel;
    javax.swing.JTextField repeatCountField;
    javax.swing.JLabel repeatCountLabel;
    javax.swing.JCheckBox relativeDurationCheckbox;
    javax.swing.JTextField durationSecondsField;
    javax.swing.JLabel repeatDuration;
    javax.swing.JLabel parametersLabel;
    javax.swing.JPanel buttonPanel;
    javax.swing.JButton updateButton;
  class SymAction implements java.awt.event.ActionListener
  {
    public void actionPerformed (java.awt.event.ActionEvent event)
    {
      Object object = event.getSource ();
      if (object == updateButton)
	  updateButton_Action (event);
    }
  }
  void updateButton_Action (java.awt.event.ActionEvent event)
  {
    updateModel ();
  }
}
