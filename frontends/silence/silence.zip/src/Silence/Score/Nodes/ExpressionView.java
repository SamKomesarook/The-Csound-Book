package Silence.Score.Nodes;
import Silence.Orchestra.Event;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import Silence.calc.expression.*;
import Silence.calc.ui.*;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JComboBox;
import javax.swing.JScrollPane;
import javax.swing.JCheckBox;
/**
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
 */
public class ExpressionView extends javax.swing.JInternalFrame
{
  Expression expression = null;
    Silence.calc.ui.Graph graph = null;
  public ExpressionView (Expression value)
  {
    this ("Expression");
    expression = value;
    updateView ();
  }
  void updateView ()
  {
    nameField.setText (expression.getName ());
    expressionTextArea.setText (expression.getText ());
    XComboBox.setSelectedIndex (expression.domainDimension);
    YComboBox.setSelectedIndex (expression.rangeDimension);
    minimumXTextField.setText (String.valueOf (expression.minimumX));
    maximumXTextField.setText (String.valueOf (expression.maximumX));
    normalizeOverXCheckBox.setSelected (expression.normalizeOverX);
    graph.setExpression (expression.getExpression ());
    graph.setXRange (expression.minimumX, expression.maximumX);
    graph.setMode (graph.DRAW_EXPRESSION);
    multiplyCheckBox.setSelected (expression.multiply);
    graph.repaint ();
  }
  public void updateModel ()
  {
    expression.setName (nameField.getText ());
    expression.setText (expressionTextArea.getText ());
    expression.domainDimension = XComboBox.getSelectedIndex ();
    expression.rangeDimension = YComboBox.getSelectedIndex ();
    expression.minimumX =
      Double.parseDouble (minimumXTextField.getText ());
    expression.maximumX =
      Double.parseDouble (maximumXTextField.getText ());
    expression.normalizeOverX = normalizeOverXCheckBox.isSelected ();
    expression.multiply = multiplyCheckBox.isSelected ();
    updateView ();
  }
  public ExpressionView ()
  {
    setTitle ("Expression");
    getContentPane ().setLayout (null);
    setVisible (false);
    setSize (454, 564);
    setBackground (new Color (8421504));
    parametersPanel = new javax.swing.JPanel ();
    parametersPanel.setLayout (null);
    parametersPanel.setBounds (12, 84, 432, 408);
    parametersPanel.setFont (new Font ("Dialog", Font.BOLD, 12));
    parametersPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (parametersPanel);
    parametersLabel = new javax.swing.JLabel ();
    parametersLabel.setText ("Parameters");
    parametersLabel.setHorizontalAlignment (0);
    parametersLabel.setHorizontalTextPosition (0);
    parametersLabel.setBounds (12, 0, 408, 24);
    parametersLabel.setFont (new Font ("Dialog", Font.BOLD, 12));
    parametersPanel.add (parametersLabel);
    graphPanel = new javax.swing.JPanel ();
    graphPanel.setLayout (new BorderLayout (0, 0));
    graphPanel.setBounds (12, 24, 408, 108);
    graphPanel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (graphPanel);
    XComboBox = new javax.swing.JComboBox ();
    XComboBox.setBounds (216, 264, 204, 24);
    XComboBox.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (XComboBox);
    YComboBox = new javax.swing.JComboBox ();
    YComboBox.setBounds (216, 300, 204, 24);
    YComboBox.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (YComboBox);
    expressionScrollPane = new javax.swing.JScrollPane ();
    expressionScrollPane.setBounds (12, 168, 408, 84);
    expressionScrollPane.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (expressionScrollPane);
    expressionTextArea = new javax.swing.JTextArea ();
    expressionTextArea.setBounds (12, 12, 384, 60);
    expressionTextArea.setFont (new Font ("Dialog", Font.PLAIN, 12));
    expressionScrollPane.getViewport ().add (expressionTextArea);
    minimumXTextField = new javax.swing.JTextField ();
    minimumXTextField.setText ("0");
    minimumXTextField.setBounds (216, 336, 204, 24);
    minimumXTextField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (minimumXTextField);
    maximumXTextField = new javax.swing.JTextField ();
    maximumXTextField.setText ("1");
    maximumXTextField.setBounds (216, 372, 204, 24);
    maximumXTextField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (maximumXTextField);
    domainLabel = new javax.swing.JLabel ();
    domainLabel.setText ("Dimenson of X or domain");
    domainLabel.setBounds (12, 264, 192, 24);
    domainLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (domainLabel);
    rangeLabel = new javax.swing.JLabel ();
    rangeLabel.setText ("Dimenson of Y or range");
    rangeLabel.setBounds (12, 300, 192, 24);
    rangeLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (rangeLabel);
    minimumXLabel = new javax.swing.JLabel ();
    minimumXLabel.setText ("Minimum value of X");
    minimumXLabel.setBounds (12, 336, 192, 24);
    minimumXLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (minimumXLabel);
    maximumXLabel = new javax.swing.JLabel ();
    maximumXLabel.setText ("Maximum value of X");
    maximumXLabel.setBounds (12, 372, 192, 24);
    maximumXLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (maximumXLabel);
    expressionLabel = new javax.swing.JLabel ();
    expressionLabel.setText
      ("Mathematical expression for f: Y <= f(X [, Y])");
    expressionLabel.setHorizontalAlignment (0);
    expressionLabel.setHorizontalTextPosition (0);
    expressionLabel.setBounds (12, 132, 408, 24);
    expressionLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (expressionLabel);
    buttonPanel = new javax.swing.JPanel ();
    buttonPanel.setLayout (null);
    buttonPanel.setBounds (12, 504, 432, 48);
    buttonPanel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    buttonPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (buttonPanel);
    updateButton = new javax.swing.JButton ();
    updateButton.setText ("Update");
    updateButton.setActionCommand ("button");
    updateButton.setBounds (12, 12, 84, 24);
    updateButton.setFont (new Font ("Dialog", Font.PLAIN, 12));
    buttonPanel.add (updateButton);
    normalizeOverXCheckBox = new javax.swing.JCheckBox ();
    normalizeOverXCheckBox.setText ("Normalize over [min(X), max(X)]");
    normalizeOverXCheckBox.setBounds (216, 12, 204, 24);
    normalizeOverXCheckBox.setFont (new Font ("Dialog", Font.PLAIN, 12));
    buttonPanel.add (normalizeOverXCheckBox);
    multiplyCheckBox = new javax.swing.JCheckBox ();
    multiplyCheckBox.setText ("Multiply");
    multiplyCheckBox.setBounds (216 - 96, 12, 84, 24);
    multiplyCheckBox.setFont (new Font ("Dialog", Font.PLAIN, 12));
    buttonPanel.add (multiplyCheckBox);
    namePanel = new javax.swing.JPanel ();
    namePanel.setLayout (null);
    namePanel.setBounds (12, 12, 432, 60);
    namePanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (namePanel);
    nameField = new javax.swing.JTextField ();
    nameField.setBounds (12, 24, 408, 24);
    nameField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    namePanel.add (nameField);
    nameLabel = new javax.swing.JLabel ();
    nameLabel.setText ("Name");
    nameLabel.setHorizontalAlignment (0);
    nameLabel.setHorizontalTextPosition (0);
    nameLabel.setBounds (12, 0, 408, 26);
    nameLabel.setFont (new Font ("Dialog", Font.BOLD, 12));
    namePanel.add (nameLabel);
    for (int i = 0; i < Event.labels.length - 1; i++)
      {
	YComboBox.addItem (Event.labels[i]);
	XComboBox.addItem (Event.labels[i]);
      }
    YComboBox.setSelectedIndex (4);
      XComboBox.setSelectedIndex (2);
      graph = new Silence.calc.ui.Graph ();
      graphPanel.add ("Center", graph);
    SymAction lSymAction = new SymAction ();
      updateButton.addActionListener (lSymAction);
  }
  public ExpressionView (String title)
  {
    this ();
    setTitle (title);
  }
  javax.swing.JPanel parametersPanel;
  javax.swing.JLabel parametersLabel;
  javax.swing.JPanel graphPanel;
  javax.swing.JComboBox XComboBox;
  javax.swing.JComboBox YComboBox;
  javax.swing.JScrollPane expressionScrollPane;
  javax.swing.JTextArea expressionTextArea;
  javax.swing.JTextField minimumXTextField;
  javax.swing.JTextField maximumXTextField;
  javax.swing.JLabel domainLabel;
  javax.swing.JLabel rangeLabel;
  javax.swing.JLabel minimumXLabel;
  javax.swing.JLabel maximumXLabel;
  javax.swing.JLabel expressionLabel;
  javax.swing.JPanel buttonPanel;
  javax.swing.JButton updateButton;
  javax.swing.JCheckBox normalizeOverXCheckBox;
  javax.swing.JCheckBox multiplyCheckBox;
  javax.swing.JPanel namePanel;
  javax.swing.JTextField nameField;
  javax.swing.JLabel nameLabel;
  class SymAction implements java.awt.event.ActionListener
  {
    public void actionPerformed (java.awt.event.ActionEvent event)
    {
      Object object = event.getSource ();
      if (object == updateButton)
	  updateButton_Action (event);
    }
  }
  void updateButton_Action (java.awt.event.ActionEvent event)
  {
    updateModel ();
  }
}
