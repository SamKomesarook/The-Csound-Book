package Silence.Score.Nodes;
import cern.jet.random.engine.RandomEngine;
import cern.jet.random.Binomial;
import Silence.Global;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import Silence.Mathematics.*;
import java.awt.*;
import java.io.*;
import java.util.*;
/**
Like RandomizeUniform, except that the random variable has a binomial distribution.
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class RandomizeBinomial extends RandomizeUniform implements
  NodeInterface, java.io.Serializable
{
  transient Binomial binomial = null;
  double P = 0.5;
  int N = 16;
  public RandomizeBinomial ()
  {
    binomial = new Binomial (N, P, Global.randomEngine);
  }
  public NodeInterface copy()
  {
    RandomizeBinomial copy = new RandomizeBinomial();
    copyFieldsInto(copy);
    return copy;
  }
  public void copyFieldsInto(NodeInterface copy_)
  {
    RandomizeBinomial copy = (RandomizeBinomial) copy_;
    super.copyFieldsInto(copy);
    copy.P = P;
    copy.N = N;
  }
  public void defaultsRandomizeBinomial ()
  {
    P = 0.5;
    N = 16;
    binomial.setNandP (N, P);
  }
  public double getSample ()
  {
    return binomial.nextInt (N, P);
  }
  public Container getView ()
  {
    return new RandomizeBinomialView (this);
  }
}
