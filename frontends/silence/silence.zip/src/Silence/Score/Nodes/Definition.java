package Silence.Score.Nodes;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import java.awt.*;
import java.io.*;
import java.util.*;
/**
Contains the definition of a node (and possibly its children, grandchildren, etc.)
that does not directly produce notes. It can, however, be instantiated
by a Use node. The Definition node is similar to the DEF node in
Virtual Reality Modeling Language. It corresponds to the definition
of a function in a procedural language, and the Use node corresponds
to an invocation of that function.
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class Definition extends Node implements NodeInterface,
  java.io.Serializable
{
  public Definition ()
  {
  }
  public NodeInterface copy()
  {
    Definition copy = new Definition();
    copyFieldsInto(copy);
    return copy;
  }
  public double[][] traverseMusicGraph (double[][]parentTransformation,
					Score score)
  {
    return parentTransformation;
  }
  public double[][] produceOrTransformNotes (double[][]compositeTransform,
					     Score score,
					     int preTraversalCount,
					     int postTraversalCount)
  {
    return compositeTransform;
  }
  public void openView ()
  {
    DefinitionView view = new DefinitionView (this);
      view.setVisible (true);
  }
  public Container getView ()
  {
    return new DefinitionView (this);
  }
}
