package Silence.Score.Nodes;
import cern.jet.random.Uniform;
import cern.jet.random.engine.RandomEngine;
import Silence.Global;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import Silence.Mathematics.*;
import Silence.Orchestra.Event;
import java.awt.*;
import java.io.*;
import java.util.*;
/**
This node produces a Translate node whose translations are sampled from a
uniformly distributed random variable. The node can also be used to produce
a specified number of notes whose values are thus randomized,
and these can be randomly distributed over time, or follow in sequence.
Randomization can be applied to one, any, or all dimensions of note space
by setting the appropriate weights to zero or to more than zero.
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class RandomizeUniform extends Transform implements NodeInterface,
  java.io.Serializable
{
  public transient Uniform uniform = null;
  int notesToGenerateCount = 0;
  boolean incrementTime = false;
  double currentTime = 0;
  public RandomizeUniform ()
  {
    uniform = new Uniform (Global.randomEngine);
    defaultsRandomizeUniform ();
  }
  public NodeInterface copy()
  {
    RandomizeUniform copy = new RandomizeUniform();
    copyFieldsInto(copy);
    return copy;
  }
  public void copyFieldsInto(NodeInterface copy_)
  {
    RandomizeUniform copy = (RandomizeUniform) copy_;
    super.copyFieldsInto(copy);
    copy.notesToGenerateCount = notesToGenerateCount;
    copy.incrementTime = incrementTime;
    copy.currentTime = currentTime;
  }
  public void defaultsRandomizeUniform ()
  {
    notesToGenerateCount = 0;
    incrementTime = false;
    currentTime = 0;
  }
  public double[][] getLocalTransformation ()
  {
    double[][] N = Matrix.copy (M);
    for (int i = Event.INSTRUMENT; i < Event.HOMOGENEITY; i++)
      {
	N[i][Event.HOMOGENEITY] *= getSample ();
      }
    return N;
  }
  public double[][] produceOrTransformNotes (double[][]compositeTransform,
					     Score score,
					     int preTraversalCount,
					     int postTraversalCount)
  {
    double[][] compositeMatrix = null;
    if (notesToGenerateCount > 0)
      {
	try
	{
	  for (int i = 0; i < notesToGenerateCount; i++)
	    {
	      //  Resample for every generated note.
	      compositeMatrix =
		Matrix.times (compositeTransform, getLocalTransformation ());
	      double[] note =
		Event.createNote (1., 1., 1., 1., 1., 1., 1., 1., 1., 1.);
	        note = Matrix.times (compositeMatrix, note);
	      if (incrementTime)
		{
		  double buffer = Math.abs (Event.getTime (note));
		    Event.setTime (note, buffer + currentTime);
		    currentTime += buffer;
		}
	      score.addEvent (note);
	    }
	}
	catch (Exception e)
	{
	  e.printStackTrace ();
	}
      }
    else
      {
	try
	{
	  for (int i = preTraversalCount; i < postTraversalCount; i++)
	    {
	      compositeMatrix =
		Matrix.times (compositeTransform, getLocalTransformation ());
	      double[] note = score.getEvent (i);
	      Matrix.times (note, compositeMatrix, (double[]) note.clone ());
	    }
	}
	catch (Exception e)
	{
	  e.printStackTrace ();
	}
      }
    return compositeTransform;
  }
  public double getSample ()
  {
    return uniform.nextDouble ();
  }
  public int getNotesToGenerateCount ()
  {
    return notesToGenerateCount;
  }
  public boolean getIncrementTime ()
  {
    return incrementTime;
  }
  public void setIncrementTime (boolean value)
  {
    incrementTime = value;
  }
  public void setNotesToGenerate (int value)
  {
    notesToGenerateCount = value;
  }
  public void openView ()
  {
    RandomizeUniformView view = new RandomizeUniformView (this);
      view.setVisible (true);
  }
  public Container getView ()
  {
    return new RandomizeUniformView (this);
  }
}
