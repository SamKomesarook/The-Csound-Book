package Silence.Score.Nodes;
import Silence.Global;
import Silence.Score.ScoreView;
import java.lang.reflect.InvocationTargetException;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.table.*;
/**
 * Title:        Silence
 * Description:  A user-extensible system for making music by means of software alone.
 * Copyright:    Copyright (c) 2002
 * Company:      Irreducible Productions
 * @author
 * @version 1.0
 */
public class IFS2DView extends JPanel
{
  IFS2D ifs2d = null;
  ScoreView scoreView = null;
  JToolBar toolbar = new JToolBar();
  JButton saveButton = new JButton();
  JButton openButton = new JButton();
  BorderLayout borderLayout1 = new BorderLayout();
  JTabbedPane tabs = new JTabbedPane();
  JPanel hutchinsonPanel = new JPanel();
  JScrollPane markovScrollPane = new JScrollPane();
  JToolBar hutchinsonToolbar = new JToolBar();
  BorderLayout borderLayout2 = new BorderLayout();
  JButton addButton = new JButton();
  JPanel evolverPanel = new JPanel();
  JButton saveAsButton = new JButton();
  JButton generateButton = new JButton();
  JButton evolveButton = new JButton();
  JButton newButton = new JButton();
  JButton removeButton = new JButton();
  JScrollPane hutchinsonScrollPane = new JScrollPane();
  JTable hutchinsonTable = new JTable();
  JTable markovTable = new JTable();
  JButton translateButton = new JButton();
  JButton exitButton = new JButton();
  JButton stopButton = new JButton();
  public IFS2DView()
  {
    this(new IFS2D());
  }
  public IFS2DView(IFS2D ifs2d)
  {
    this.ifs2d = ifs2d;
    try
    {
      jbInit();
      hutchinsonTable.setModel(ifs2d.new HutchinsonTableModel());
      markovTable.setModel(ifs2d.new MarkovTableModel());
      scoreView = (ScoreView) ifs2d.getLocalScore().getView();
      tabs.addTab(" Score ", scoreView);
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception
  {
    saveButton.setText(" Save ");
    saveButton.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        saveButton_actionPerformed(e);
      }
    });
    toolbar.setFloatable(false);
    openButton.setText(" Open... ");
    openButton.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        openButton_actionPerformed(e);
      }
    });
    this.setLayout(borderLayout1);
    hutchinsonPanel.setLayout(borderLayout2);
    addButton.setText(" Add ");
    addButton.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        addButton_actionPerformed(e);
      }
    });
    saveAsButton.setText(" Save as... ");
    saveAsButton.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        saveAsButton_actionPerformed(e);
      }
    });
    generateButton.setText(" Generate ");
    generateButton.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        generateButton_actionPerformed(e);
      }
    });
    evolveButton.setText(" Evolve ");
    evolveButton.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        evolveButton_actionPerformed(e);
      }
    });
    newButton.setText(" New ");
    newButton.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        newButton_actionPerformed(e);
      }
    });
    removeButton.setText(" Remove ");
    removeButton.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        removeButton_actionPerformed(e);
      }
    });
    translateButton.setText(" Translate... ");
    translateButton.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        translateButton_actionPerformed(e);
      }
    });
    exitButton.setText(" Exit ");
    exitButton.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        exitButton_actionPerformed(e);
      }
    });
    hutchinsonToolbar.setFloatable(false);
    stopButton.setText(" Stop ");
    stopButton.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        stopButton_actionPerformed(e);
      }
    });
    this.add(toolbar, BorderLayout.NORTH);
    toolbar.add(newButton, null);
    toolbar.add(openButton, null);
    toolbar.add(saveButton, null);
    toolbar.add(saveAsButton, null);
    toolbar.add(generateButton, null);
    toolbar.add(stopButton, null);
    toolbar.add(translateButton, null);
    toolbar.add(evolveButton, null);
    toolbar.add(exitButton, null);
    this.add(tabs, BorderLayout.CENTER);
    tabs.add(hutchinsonPanel, "Hutchinson");
    hutchinsonPanel.add(hutchinsonToolbar, BorderLayout.NORTH);
    hutchinsonToolbar.add(addButton, null);
    hutchinsonToolbar.add(removeButton, null);
    hutchinsonPanel.add(hutchinsonScrollPane, BorderLayout.CENTER);
    hutchinsonScrollPane.getViewport().add(hutchinsonTable, null);
    tabs.add(markovScrollPane, "Markov");
    markovScrollPane.getViewport().add(markovTable, null);
    tabs.add(evolverPanel, "Evolver");
  }

  void newButton_actionPerformed(ActionEvent e)
  {
    ifs2d.defaultsIFS2D();
  }

  void openButton_actionPerformed(ActionEvent e)
  {
    Cursor cursor = getCursor ();
      setCursor (Cursor.getPredefinedCursor (Cursor.WAIT_CURSOR));
    JFileChooser fileDialog = Global.createFileDialog ("Open");
       fileDialog.addChoosableFileFilter (Global.createFileFilter ("IFS2d files", IFS2D.IFS2D_EXTENSION));
    File currentDirectory = new File(ifs2d.filename);
    fileDialog.setCurrentDirectory(currentDirectory);
    if (fileDialog.showOpenDialog (this) == fileDialog.APPROVE_OPTION)
      {
	File file = fileDialog.getSelectedFile ();
	if (file.getAbsolutePath ().endsWith (IFS2D.IFS2D_EXTENSION))
	  {
	    try
	    {
	      System.out.println ("Opening " + file.getAbsolutePath ());
	      ifs2d =
		(IFS2D) ifs2d.deserialize (file.getAbsolutePath ());
	      Container container = getParent ();
	        container.remove (this);
	      IFS2DView ifs2dView =
		(IFS2DView) ifs2d.getView ();
	        container.add (ifs2dView);
	        ifs2d.setFilename (file.getAbsolutePath ());
	        ifs2dView.updateView ();
	        ifs2dView.invalidate();
                container.invalidate();
                container.validate();
                container.repaint();
	    }
	    catch (IOException x)
	    {
	      x.printStackTrace ();
	    }
	    catch (InvocationTargetException x)
	    {
	      x.printStackTrace ();
	    }
	    catch (ClassNotFoundException x)
	    {
	      x.printStackTrace ();
	    }
	    catch (InstantiationException x)
	    {
	      x.printStackTrace ();
	    }
	    catch (IllegalAccessException x)
	    {
	      x.printStackTrace ();
	    }
	    catch (NoSuchFieldException x)
	    {
	      x.printStackTrace ();
	    }
	  }
      }
    setCursor (cursor);
  }

  void saveButton_actionPerformed(ActionEvent e)
  {
    Cursor cursor = getCursor ();
      setCursor (Cursor.getPredefinedCursor (Cursor.WAIT_CURSOR));
    String filename = ifs2d.getFilename ();
    if (filename.indexOf (".") == -1)
      {
	filename = filename + ".mml";
      }
    try
    {
      System.out.println ("Began IFS2D.serialize(" +
			  ifs2d.getFilename () + ").");
      ifs2d.serialize (ifs2d.getFilename ());
      System.out.println ("Ended IFS2D.serialize().");
    }
    catch (IOException x)
    {
      x.printStackTrace ();
    }
    catch (IllegalAccessException x)
    {
      x.printStackTrace ();
    }
    setCursor (cursor);
  }

  void saveAsButton_actionPerformed(ActionEvent e)
  {
    Cursor cursor = getCursor ();
      setCursor (Cursor.getPredefinedCursor (Cursor.WAIT_CURSOR));
    JFileChooser fileDialog = Global.createFileDialog ("Save as");
      fileDialog.setFileFilter (Global.createFileFilter ("IFS2D files", IFS2D.IFS2D_EXTENSION));
     File currentDirectory = new File(ifs2d.filename);
      fileDialog.setSelectedFile(new File(ifs2d.getFilename()));
   fileDialog.setCurrentDirectory(currentDirectory);
    if (fileDialog.showSaveDialog (this) == fileDialog.APPROVE_OPTION)
      {
	File file = fileDialog.getSelectedFile ();
	  ifs2d.setFilename (file.getAbsolutePath ());
	  saveButton_actionPerformed (e);
	  updateView ();
      }
    setCursor (cursor);
  }

  void generateButton_actionPerformed(ActionEvent e)
  {
    ifs2d.start();
  }

  void evolveButton_actionPerformed(ActionEvent e)
  {

  }

  void addButton_actionPerformed(ActionEvent e)
  {
    ifs2d.addHutchinsonOperatorMatrix();
    AbstractTableModel model = (AbstractTableModel) hutchinsonTable.getModel();
    int rows = model.getRowCount();
    model.fireTableRowsDeleted(rows - 1, rows - 1);
    model = (AbstractTableModel) markovTable.getModel();
    model.fireTableStructureChanged();
  }

  void removeButton_actionPerformed(ActionEvent e)
  {
    AbstractTableModel model = (AbstractTableModel) hutchinsonTable.getModel();
    int[] selection = hutchinsonTable.getSelectedRows();
    for(int i = selection.length - 1; i >= 0; i--)
    {
      ifs2d.hutchinsonOperator.remove(selection[i]);
      model.fireTableRowsDeleted(selection[i], selection[i]);
    }
    model = (AbstractTableModel) markovTable.getModel();
    model.fireTableStructureChanged();
  }

  void translateButton_actionPerformed(ActionEvent e)
  {
    ifs2d.measureToScore();
    scoreView.updateView();
  }

  void exitButton_actionPerformed(ActionEvent e)
  {
    System.exit(0);
  }

  void stopButton_actionPerformed(ActionEvent e)
  {
    ifs2d.stop();
  }
  public void updateModel()
  {
  }
  public void updateView()
  {
  }
}