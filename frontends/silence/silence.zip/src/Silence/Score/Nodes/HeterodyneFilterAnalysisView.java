package Silence.Score.Nodes;
import Silence.Global;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import java.awt.*;
import java.io.File;
import javax.swing.*;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
/**
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class HeterodyneFilterAnalysisView extends javax.swing.JInternalFrame
{
  HeterodyneFilterAnalysis heterodyneFilterAnalysis = null;
  public HeterodyneFilterAnalysisView (HeterodyneFilterAnalysis file)
  {
    this ("HeterodyneFilterAnalysis");
    heterodyneFilterAnalysis = file;
    updateView ();
  }
  void updateView ()
  {
    nameField.setText (heterodyneFilterAnalysis.getName ());
    soundfileField.setText (heterodyneFilterAnalysis.soundFilename);
    channelField.setText (String.valueOf (heterodyneFilterAnalysis.channel));
    startField.setText (String.
			valueOf (heterodyneFilterAnalysis.startSeconds));
    durationField.
      setText (String.valueOf (heterodyneFilterAnalysis.durationSeconds));
    fundamentalField.
      setText (String.valueOf (heterodyneFilterAnalysis.fundamentalHz));
    partialCountField.
      setText (String.valueOf (heterodyneFilterAnalysis.partialCount));
    maximumTotalAmplitudeField.

      setText (String.valueOf
	       (heterodyneFilterAnalysis.maximumTotalAmplitude));
    amplitudeThresholdField.
      setText (String.valueOf (heterodyneFilterAnalysis.amplitudeThreshold));
    initialBreakpointCountField.

      setText (String.valueOf
	       (heterodyneFilterAnalysis.initialBreakpointCount));
    lowpassHzField.
      setText (String.valueOf (heterodyneFilterAnalysis.lowpassHz));
    instrumentIndexField.
      setText (String.valueOf (heterodyneFilterAnalysis.instrumentIndex));
    useExistingAnalysisCheckbox.
      setSelected (heterodyneFilterAnalysis.useExistingAnalysis);
  }
  public void updateModel ()
  {
    heterodyneFilterAnalysis.setName (nameField.getText ());
    heterodyneFilterAnalysis.soundFilename = soundfileField.getText ();
    heterodyneFilterAnalysis.channel =
      Integer.parseInt (channelField.getText ());
    heterodyneFilterAnalysis.startSeconds =
      Double.parseDouble (startField.getText ());
    heterodyneFilterAnalysis.durationSeconds =
      Double.parseDouble (durationField.getText ());
    heterodyneFilterAnalysis.fundamentalHz =
      Double.parseDouble (fundamentalField.getText ());
    heterodyneFilterAnalysis.partialCount =
      Integer.parseInt (partialCountField.getText ());
    heterodyneFilterAnalysis.maximumTotalAmplitude =
      Integer.parseInt (maximumTotalAmplitudeField.getText ());
    heterodyneFilterAnalysis.amplitudeThreshold =
      Integer.parseInt (amplitudeThresholdField.getText ());
    heterodyneFilterAnalysis.initialBreakpointCount =
      Integer.parseInt (initialBreakpointCountField.getText ());
    heterodyneFilterAnalysis.lowpassHz =
      Double.parseDouble (lowpassHzField.getText ());
    heterodyneFilterAnalysis.instrumentIndex =
      Integer.parseInt (instrumentIndexField.getText ());
    heterodyneFilterAnalysis.useExistingAnalysis =
      useExistingAnalysisCheckbox.isSelected ();
    updateView ();
  }
  public HeterodyneFilterAnalysisView ()
  {
    setTitle ("HeterodyneFilterAnalysis");
    getContentPane ().setLayout (null);
    setVisible (false);
    setSize (640, 480);
    setBackground (new Color (8421504));
    namePanel = new javax.swing.JPanel ();
    namePanel.setLayout (null);
    namePanel.setBounds (12, 12, 552, 72);
    namePanel.setFont (new Font ("Dialog", Font.BOLD, 12));
    namePanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (namePanel);
    nameField = new javax.swing.JTextField ();
    nameField.setBounds (12, 36, 528, 24);
    nameField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    namePanel.add (nameField);
    nameLabel = new javax.swing.JLabel ();
    nameLabel.setText ("Name");
    nameLabel.setHorizontalAlignment (0);
    nameLabel.setHorizontalTextPosition (0);
    nameLabel.setBounds (12, 0, 528, 26);
    nameLabel.setFont (new Font ("Dialog", Font.BOLD, 12));
    namePanel.add (nameLabel);
    parametersPanel = new javax.swing.JPanel ();
    parametersPanel.setLayout (null);
    parametersPanel.setBounds (12, 96, 552, 252);
    parametersPanel.setFont (new Font ("Dialog", Font.BOLD, 12));
    parametersPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (parametersPanel);
    soundfileField = new javax.swing.JTextField ();
    soundfileField.setBounds (144, 36, 240, 24);
    soundfileField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (soundfileField);
    soundfileButton = new javax.swing.JButton ();
    soundfileButton.setText ("Soundfile");
    soundfileButton.setActionCommand ("Soundfile");
    soundfileButton.setBounds (12, 36, 92, 24);
    soundfileButton.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (soundfileButton);
    channelField = new javax.swing.JTextField ();
    channelField.setBounds (144, 72, 84, 24);
    channelField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (channelField);
    startLabel = new javax.swing.JLabel ();
    startLabel.setText ("Start (seconds)");
    startLabel.setBounds (12, 108, 94, 24);
    startLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (startLabel);
    startField = new javax.swing.JTextField ();
    startField.setBounds (144, 108, 84, 24);
    startField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (startField);
    channelLabel = new javax.swing.JLabel ();
    channelLabel.setText ("Channel");
    channelLabel.setBounds (12, 72, 94, 24);
    channelLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (channelLabel);
    durationLabel = new javax.swing.JLabel ();
    durationLabel.setText ("Duration (seconds)");
    durationLabel.setBounds (12, 144, 108, 24);
    durationLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (durationLabel);
    durationField = new javax.swing.JTextField ();
    durationField.setBounds (144, 144, 84, 24);
    durationField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (durationField);
    fundamentalLabel = new javax.swing.JLabel ();
    fundamentalLabel.setText ("Fundamental (Hz)");
    fundamentalLabel.setBounds (12, 180, 108, 24);
    fundamentalLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (fundamentalLabel);
    fundamentalField = new javax.swing.JTextField ();
    fundamentalField.setBounds (144, 180, 84, 24);
    fundamentalField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (fundamentalField);
    partialCountLabel = new javax.swing.JLabel ();
    partialCountLabel.setText ("Partial count");
    partialCountLabel.setBounds (12, 216, 108, 24);
    partialCountLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (partialCountLabel);
    partialCountField = new javax.swing.JTextField ();
    partialCountField.setBounds (144, 216, 84, 24);
    partialCountField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (partialCountField);
    maximumTotalAmplitudeLabel = new javax.swing.JLabel ();
    maximumTotalAmplitudeLabel.setText ("Maximum amplitude");
    maximumTotalAmplitudeLabel.setBounds (276, 72, 120, 24);
    maximumTotalAmplitudeLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (maximumTotalAmplitudeLabel);
    maximumTotalAmplitudeField = new javax.swing.JTextField ();
    maximumTotalAmplitudeField.setBounds (408, 72, 84, 24);
    parametersPanel.add (maximumTotalAmplitudeField);
    amplitudeThresholdLabel = new javax.swing.JLabel ();
    amplitudeThresholdLabel.setText ("Amplitude threshold");
    amplitudeThresholdLabel.setBounds (276, 108, 120, 24);
    amplitudeThresholdLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (amplitudeThresholdLabel);
    amplitudeThresholdField = new javax.swing.JTextField ();
    amplitudeThresholdField.setBounds (408, 108, 84, 24);
    amplitudeThresholdField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (amplitudeThresholdField);
    initialBreakpointCountLabel = new javax.swing.JLabel ();
    initialBreakpointCountLabel.setText ("Breakpoint count");
    initialBreakpointCountLabel.setBounds (276, 144, 120, 24);
    initialBreakpointCountLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (initialBreakpointCountLabel);
    initialBreakpointCountField = new javax.swing.JTextField ();
    initialBreakpointCountField.setBounds (408, 144, 84, 24);
    initialBreakpointCountField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (initialBreakpointCountField);
    lowpassHzLabel = new javax.swing.JLabel ();
    lowpassHzLabel.setText ("Lowpass filter (Hz)");
    lowpassHzLabel.setBounds (276, 180, 120, 24);
    lowpassHzLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (lowpassHzLabel);
    lowpassHzField = new javax.swing.JTextField ();
    lowpassHzField.setBounds (408, 180, 84, 24);
    lowpassHzField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (lowpassHzField);
    useExistingAnalysisCheckbox = new javax.swing.JCheckBox ();
    useExistingAnalysisCheckbox.setText ("Use existing analysis");
    useExistingAnalysisCheckbox.setActionCommand ("Use existing analysis");
    useExistingAnalysisCheckbox.setBounds (408, 36, 144, 22);
    useExistingAnalysisCheckbox.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (useExistingAnalysisCheckbox);
    instrumentIndexLabel = new javax.swing.JLabel ();
    instrumentIndexLabel.setText ("Instrument index");
    instrumentIndexLabel.setBounds (276, 216, 120, 24);
    instrumentIndexLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (instrumentIndexLabel);
    instrumentIndexField = new javax.swing.JTextField ();
    instrumentIndexField.setBounds (408, 216, 84, 24);
    instrumentIndexField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (instrumentIndexField);
    parametersLabel = new javax.swing.JLabel ();
    parametersLabel.setText ("Parameters");
    parametersLabel.setHorizontalAlignment (0);
    parametersLabel.setHorizontalTextPosition (0);
    parametersLabel.setBounds (12, 0, 528, 26);
    parametersLabel.setFont (new Font ("Dialog", Font.BOLD, 12));
    parametersPanel.add (parametersLabel);
    buttonPanel = new javax.swing.JPanel ();
    buttonPanel.setLayout (null);
    buttonPanel.setBounds (12, 360, 552, 48);
    buttonPanel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    buttonPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (buttonPanel);
    updateButton = new javax.swing.JButton ();
    updateButton.setText ("Update");
    updateButton.setActionCommand ("button");
    updateButton.setBounds (12, 12, 84, 24);
    updateButton.setFont (new Font ("Dialog", Font.PLAIN, 12));
    buttonPanel.add (updateButton);
    SymAction lSymAction = new SymAction ();
      updateButton.addActionListener (lSymAction);
      soundfileButton.addActionListener (lSymAction);
  }
  public HeterodyneFilterAnalysisView (String title)
  {
    this ();
    setTitle (title);
  }
  javax.swing.JPanel namePanel;
    javax.swing.JTextField nameField;
    javax.swing.JLabel nameLabel;
    javax.swing.JPanel parametersPanel;
    javax.swing.JTextField soundfileField;
    javax.swing.JButton soundfileButton;
    javax.swing.JTextField channelField;
    javax.swing.JLabel startLabel;
    javax.swing.JTextField startField;
    javax.swing.JLabel channelLabel;
    javax.swing.JLabel durationLabel;
    javax.swing.JTextField durationField;
    javax.swing.JLabel fundamentalLabel;
    javax.swing.JTextField fundamentalField;
    javax.swing.JLabel partialCountLabel;
    javax.swing.JTextField partialCountField;
    javax.swing.JLabel maximumTotalAmplitudeLabel;
    javax.swing.JTextField maximumTotalAmplitudeField;
    javax.swing.JLabel amplitudeThresholdLabel;
    javax.swing.JTextField amplitudeThresholdField;
    javax.swing.JLabel initialBreakpointCountLabel;
    javax.swing.JTextField initialBreakpointCountField;
    javax.swing.JLabel lowpassHzLabel;
    javax.swing.JTextField lowpassHzField;
    javax.swing.JCheckBox useExistingAnalysisCheckbox;
    javax.swing.JLabel instrumentIndexLabel;
    javax.swing.JTextField instrumentIndexField;
    javax.swing.JLabel parametersLabel;
    javax.swing.JPanel buttonPanel;
    javax.swing.JButton updateButton;
  class SymAction implements java.awt.event.ActionListener
  {
    public void actionPerformed (java.awt.event.ActionEvent event)
    {
      Object object = event.getSource ();
      if (object == updateButton)
	  updateButton_Action (event);
      else if (object == soundfileButton)
	  soundfileButton_ActionPerformed (event);
    }
  }
  void updateButton_Action (java.awt.event.ActionEvent event)
  {
    updateModel ();
  }
  void soundfileButton_ActionPerformed (java.awt.event.ActionEvent event)
  {
    JFileChooser fileDialog = Global.createFileDialog ("Select file");




      fileDialog.addChoosableFileFilter (Global.createFileFilter
					 ("Soundfiles", ".wav"));
      fileDialog.setFileFilter (Global.createFileFilter ("Soundfiles",
							 ".aif"));
    if (fileDialog.showOpenDialog (this) == fileDialog.APPROVE_OPTION)
      {
	File file = fileDialog.getSelectedFile ();
	  heterodyneFilterAnalysis.soundFilename = file.getAbsolutePath ();
      }
    updateView ();
  }
}
