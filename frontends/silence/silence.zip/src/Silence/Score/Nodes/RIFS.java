package Silence.Score.Nodes;
import Silence.Conversions;
import Silence.Orchestra.Event;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import Silence.Mathematics.*;
import java.awt.*;
import java.io.*;
import java.util.*;
/**
Produces notes using a recurrent iterated function system (RIFS).
The RIFS consists of a Hutchinson operator, which is a set of
contractive affine transformation matrices, and a Markov operator,
which specifies the probability of one matrix succeeding another.
A sequence of matrices is chosen from the Hutchinson operator by means of the
Markov operator and used to transform a point, which moves around in the space
{instrument, octave, time}. If the Hutchinson operator as a whole is contractive,
that is if its determinant is less than 1, then the point will settle into a
chaotic attractor. Thereafter, each iteration of the point is accumulated
in a large array which approximates the measure on the attractor.
After sufficient iterations, the measure array is a very good approximation of the
actual attractor, and it is translated into music, either as notes or as sound.
<P>
The translation algorithm is the same as for the GraphicsToMusic node,
except that the instrument dimension of the attractor is used in place of
the hue dimension of an image to represent the instrument dimension of the score.
By specifying different weights in the Markov operator, the relative loudnesses
of different parts of the music can be changed. By specifying zeros in the
Markov operator, holes can be opened up in the music.
<P>
It is known that any set in the attractor's space can be approximated
to any desired degree of precision by choosing the appropriate
Hutchinson and Markov operators, although at this time it is
<I>not</I> known how to derive the operators from a target set.
Given two RIFS, it is possible to derive a series of attractors intermediate
in form between the two by linearly interpolating between the
operator coefficients of the two RIFS. This can be used to create
a series of variations on a form. The RIFS node is, mathematically speaking,
the most powerful generative algorithm in Silence.
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class RIFS extends Node implements NodeInterface, java.io.Serializable
  {
  public static int TIME_DIMENSION = 0;
  public static int OCTAVE_DIMENSION = 1;
  public static int INSTRUMENT_DIMENSION = 2;
  public static int DIMENSION_COUNT = 3;
  public static int ELEMENT_COUNT = 4;
  int findSizeCount;
  boolean renderAsSound;
  int hutchinsonOperatorMatrixCount;
  transient Random wheel = null;
  double[][] markovOperator = null;
  ArrayList hutchinsonOperator = null;
  double totalDurationSeconds;
  int voiceCount;
  int timeBinCount;
  int octaveBinCount;
  int tonesPerOctave;
  int instrumentBinCount;
  transient int[][][] measure = null;
  double secondsToIterate;
  double secondsToDate;
  int iterationCount;
  int currentMatrixIndex;
  double[] oldPoint;
  double[] currentPoint;
  double[] bufferPoint;
  double[] minima;
  double[] maxima;
  double[] ranges;
  int maximumAmplitude;
  boolean keepIterating;
  long beginAt;
  long currentTime;
  long endAt;
  public RIFS ()
  {
    //super.defaults();
    defaultsRIFS ();
  }
  public NodeInterface copy()
  {
    RIFS copy = new RIFS();
    copyFieldsInto(copy);
    return copy;
  }
  public void copyFieldsInto(NodeInterface copy_)
  {
    RIFS copy = (RIFS) copy_;
    super.copyFieldsInto(copy);
    copy.renderAsSound = renderAsSound;
    copy.hutchinsonOperatorMatrixCount = hutchinsonOperatorMatrixCount;
    copy.hutchinsonOperator = (ArrayList) hutchinsonOperator.clone();
    copy.timeBinCount = timeBinCount;
    copy.octaveBinCount = octaveBinCount;
    copy.tonesPerOctave = tonesPerOctave;
    copy.instrumentBinCount = instrumentBinCount;
    copy.totalDurationSeconds = totalDurationSeconds;
    copy.voiceCount = voiceCount;
    copy.markovOperator = (double[][]) markovOperator.clone();
    copy.findSizeCount = 2000000;
    copy.secondsToIterate = 300;
  }
  public void defaultsRIFS ()
  {
    setLocalScore (new Score ());
    renderAsSound = false;
    hutchinsonOperatorMatrixCount = 3;
    hutchinsonOperator = new ArrayList ();
    for (int i = 0; i < hutchinsonOperatorMatrixCount; i++)
    {
      hutchinsonOperator.add (Matrix.identity (ELEMENT_COUNT));
    }
    timeBinCount = 2048;
    octaveBinCount = 60;
    tonesPerOctave = 12;
    instrumentBinCount = 4;
    totalDurationSeconds = 240.0;
    voiceCount = 24;
    wheel = new Random ();
    markovOperator = new double[hutchinsonOperatorMatrixCount][hutchinsonOperatorMatrixCount];
    for (int i = 0; i < markovOperator.length; i++)
    {
      for (int j = 0; j < markovOperator.length; j++)
      {
        markovOperator[i][j] = 1.0;
      }
    }
    findSizeCount = 2000000;
    secondsToIterate = 300;
    reinitialize ();
  }
  public void reinitialize ()
  {
    measure = new int[timeBinCount][octaveBinCount][instrumentBinCount];
    oldPoint = new double[ELEMENT_COUNT];
    currentPoint = new double[ELEMENT_COUNT];
    minima = new double[DIMENSION_COUNT];
    maxima = new double[DIMENSION_COUNT];
    ranges = new double[DIMENSION_COUNT];
    currentMatrixIndex = 0;
    keepIterating = false;
    secondsToDate = 0;
    iterationCount = 0;
    beginAt = 0;
    endAt = 0;
    maximumAmplitude = 0;
    iterationCount = 0;
    normalizeMarkovOperator ();
    for (int i = 0; i < ELEMENT_COUNT; i++)
    {
      oldPoint[i] = 1.0;
      currentPoint[i] = 1.0;
    }
  }
  public void translateToNotes ()
  {
    System.out.println ("Began translating RIFS to notes...");
    keepIterating = true;
    int notesCreatedCount;
    double currentTimeSeconds;
    int columnIndex;
    int columnCount;
    double secondsPerBin = totalDurationSeconds / ((double) timeBinCount);
    int newVoicesIndex;
    int oldVoicesIndex;
    int rowIndex;
    int rowCount;
    double temperamentRound = 0.5;
    double[] swapNote = null;
    boolean starting;
    boolean ending;
    double instrument;
    double octave;
    double decibels;
    int columnsTranslatedCount = 0;
    //      Translate rasters of consecutively nonsilent measure into notes.
    score.clear ();
    //  Proceed instrument by instrument.
    for (int instrumentIndex = 0; instrumentIndex < instrumentBinCount;
        instrumentIndex++)
    {
      //      Proceed column by column.
      double[][] oldVoices = new double[voiceCount + 1][];
      double[][] newVoices = new double[voiceCount + 1][];
      for (notesCreatedCount = 0; notesCreatedCount < voiceCount + 1;
          notesCreatedCount++)
      {
        oldVoices[notesCreatedCount] =
          Event.createNote (instrumentIndex,
                            0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                            0.0, 0.0, 0);
        newVoices[notesCreatedCount] =
          Event.createNote (instrumentIndex,
                            0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                            0.0, 0.0, 0);
      }
      for (notesCreatedCount = 0, currentTimeSeconds = 0, columnIndex =
          0, columnCount = timeBinCount; columnIndex < columnCount;
          ++columnIndex)
      {
        currentTimeSeconds = ((double) columnIndex) * secondsPerBin;
        //      Copy newly sounding voices into the previously sounding voices array.
        for (newVoicesIndex = 0; newVoicesIndex <= voiceCount;
            ++newVoicesIndex)
        {
          oldVoices[newVoicesIndex] = newVoices[newVoicesIndex];
          newVoices[newVoicesIndex] =
            Event.createNote (instrumentIndex,
                              0, 0, 0, 0, 0, 0, 0, 0,
                              0);
        }
        //      Examine the current column
        //      and create a potential note at every row.
        for (rowIndex = 0,
            rowCount = octaveBinCount; rowIndex < rowCount;
            ++rowIndex)
        {
          if (!keepIterating)
          {
            return;
          }
          Event.setInstrument (newVoices[0], instrumentIndex);
          Event.setTime (newVoices[0], currentTimeSeconds);
          Event.setOctave (newVoices[0],
                           6.0 +
                           (((double) rowIndex) / tonesPerOctave));
          Event.setDecibels (newVoices[0],
                             measure[columnIndex][rowIndex]
                             [instrumentIndex]);
          //      If the potential note is louder than any newly sounding voice,
          //      bubble it up into the newly sounding voice array.
          for (newVoicesIndex = 1; newVoicesIndex <= voiceCount;
              newVoicesIndex++)
          {
            if (Event.getDecibels (newVoices[newVoicesIndex - 1]) >
                Event.getDecibels (newVoices[newVoicesIndex]))
            {
              swapNote = newVoices[newVoicesIndex - 1];
              newVoices[newVoicesIndex - 1] =
                newVoices[newVoicesIndex];
              newVoices[newVoicesIndex] = swapNote;
            }
            else
            {
              break;
            }
          }
        }
        //      Compare the newly sounding voices with the previously sounding voices.
        //    If a note is newly sounding but not previously sounding, it is starting.
        for (newVoicesIndex = 1; newVoicesIndex <= voiceCount;
            ++newVoicesIndex)
        {
          //      If a newly sounding note is not starting,
          //      it is continuing a previously sounding note.
          for (starting = true, oldVoicesIndex = 1;
              oldVoicesIndex <= voiceCount; oldVoicesIndex++)
          {
            if (Event.getOctave (newVoices[newVoicesIndex]) ==
                Event.getOctave (oldVoices[oldVoicesIndex])
                && Event.getInstrument (newVoices[newVoicesIndex]) ==
                Event.getInstrument (oldVoices[oldVoicesIndex]))
            {
              starting = false;
              break;
            }
          }
          if (starting)
          {
            Event.setTime (newVoices[newVoicesIndex],
                           currentTimeSeconds);
          }
          else
          {
            newVoices[newVoicesIndex] = oldVoices[oldVoicesIndex];
          }
        }
        //      If a note is previously sounding but not newly sounding, it is ending.
        for (oldVoicesIndex = 1; oldVoicesIndex <= voiceCount;
            ++oldVoicesIndex)
        {
          for (ending = true, newVoicesIndex = 1;
              newVoicesIndex <= voiceCount; ++newVoicesIndex)
          {
            if (Event.getOctave (oldVoices[oldVoicesIndex]) ==
                Event.getOctave (newVoices[newVoicesIndex])
                && Event.getInstrument (oldVoices[oldVoicesIndex]) ==
                Event.getInstrument (newVoices[newVoicesIndex]))
            {
              ending = false;
            }
          }
          //      If a note is ending, add it to the score.
          if (ending)
          {
            if (Event.getDecibels (oldVoices[oldVoicesIndex]) > 0.0)
            {
              Event.setDuration (oldVoices[oldVoicesIndex],
                                 currentTimeSeconds -
                                 Event.getTime (oldVoices
                                                [oldVoicesIndex]));
              score.addEvent ((double[])
                              oldVoices[oldVoicesIndex].clone ());
              ++notesCreatedCount;
            }
          }
        }
        columnsTranslatedCount = columnIndex + 1;
      }
      System.out.println ("RIFS translate to notes for instrument " +
                          instrumentIndex);
      System.out.println ("RIFS notes created " + score.size ());
    }
    System.out.println ("Ended RIFS translate to notes.");
  }
  public void translateToAdsyn ()
  {
    //  Proceed instrument by instrument.//  There is no phase dimension in adsyn, so the "phase dimension" is rendered as instruments.//  These could be panned. A separate instrument and note is created for each instrument bin.
    for (int instrumentIndex = 0; instrumentIndex < instrumentBinCount;
        instrumentIndex++)
    {
      try
      {
        String analysisFilename = name + instrumentIndex + ".ads";
        FileOutputStream fileOutputStream =
          new FileOutputStream (analysisFilename);
        BufferedOutputStream bufferedOutputStream =
          new BufferedOutputStream (fileOutputStream);
        DataOutputStream dataOutputStream =
          new DataOutputStream (bufferedOutputStream);
        //      Write hetro data frame by frame.
        short StartAmplitudeTrack = -1;
        short StartFrequencyTrack = -2;
        short TrackEnd = 32767;
        int rowIndex;
        int columnIndex;
        int timeIndex;
        //      Milliseconds per pixel.
        int TimeIncrement = 10;
        double FrequencyIncrement = 20000.0 / octaveBinCount;
        double FrequencyLogBase = Math.log (FrequencyIncrement);
        double FrequencyLogTop = Math.log (20000);
        double FrequencyLog;
        double FrequencyLogIncrement =
          (FrequencyLogTop - FrequencyLogBase) / (double) octaveBinCount;
        double FrequencyAmplitudeFactor = 0;
        double AmplitudeFactor = 0;
        double RowMaximum = 0;
        double ColumnSum;
        double ColumnMaximum;
        //      Find maximum amplitude value.
        for (ColumnMaximum = 0,
            columnIndex = 0; columnIndex < timeBinCount;
            ++columnIndex)
        {
          for (ColumnSum = 0, rowIndex = 0; rowIndex < octaveBinCount;
              ++rowIndex)
          {
            ColumnSum +=
              measure[columnIndex][rowIndex][instrumentIndex];
          }
          if (ColumnSum > ColumnMaximum)
          {
            ColumnMaximum = ColumnSum;
          }
        }
        //      Solve for the maximum row amplitude that will not clip given frequency amplitude adjustment.
        RowMaximum =
          (32767.0 * Math.exp (-FrequencyLogIncrement + FrequencyLogTop) *
           (-1.0 + Math.exp (FrequencyLogIncrement))) / (20000.0 * (-1.0 +
                                                                    Math.exp
                                                                    (FrequencyLogIncrement
                                                                     *
                                                                     octaveBinCount)));
        //      Correct for maximum color value.
        AmplitudeFactor =
          RowMaximum / ((double) ColumnMaximum / (double) octaveBinCount);
        //  To enable John ffitch's patch for unlimited partials.
        dataOutputStream.
          writeShort (Conversions.swapShort ((short) octaveBinCount));
        //      Frequency bins, logarithmically spaced.
        for (rowIndex = 0, FrequencyLog =
            FrequencyLogTop + FrequencyLogIncrement;
            rowIndex < octaveBinCount;
            ++rowIndex, FrequencyLog -= FrequencyLogIncrement)
        {
          //      Halve the amplitude for every octave more in frequency.
          FrequencyAmplitudeFactor = 20000.0 / Math.exp (FrequencyLog);
          //      Amplitude tracks.
          dataOutputStream.
            writeShort (Conversions.swapShort (StartAmplitudeTrack));
          for (columnIndex = 0,
              timeIndex = 0; columnIndex < timeBinCount;
              ++columnIndex, timeIndex += TimeIncrement)
          {
            dataOutputStream.
              writeShort (Conversions.swapShort ((short) timeIndex));
            dataOutputStream.
              writeShort (Conversions.swapShort
                          ((short)
                           (measure[columnIndex][rowIndex]
                            [instrumentIndex] *
                            FrequencyAmplitudeFactor *
                            AmplitudeFactor)));
          }
          dataOutputStream.writeShort (Conversions.swapShort (TrackEnd));
          //      Frequency tracks.
          dataOutputStream.
            writeShort (Conversions.swapShort (StartFrequencyTrack));
          for (columnIndex = 0,
              timeIndex = 0; columnIndex < timeBinCount;
              ++columnIndex, timeIndex += TimeIncrement)
          {
            dataOutputStream.
              writeShort (Conversions.swapShort ((short) timeIndex));
            dataOutputStream.
              writeShort (Conversions.swapShort
                          ((short) Math.exp (FrequencyLog)));
          }
          dataOutputStream.writeShort (Conversions.swapShort (TrackEnd));
        }
        dataOutputStream.close ();
        String instrument =
          "; adsyn phase vocoder for time stretching\n" +
          "; of hetro files derived from screen shots.\n" +
          "; p1 = Instrument.\n" + "; p2 = Starting time in seconds.\n" +
          "; p3 = Duration in seconds.\n" +
          "; p4 = Pitch in linear octaves.\n" +
          "; p5 = Loudness in decibels.\n" + "; p6 = Phase.\n" +
          "; p7 = Pan from left to right.\n" + "\n" +
          "print p2, p3, p4, p5\n" + "; INITIALIZATION\n" +
          "; Assume that the picture has a root pitch of middle C.\n" +
          "ifrequencyfactor = octcps(p4) / octcps(8)\n" +
          "; Assume that the picture has an amplitude of 80 decibels.\n" +
          "iamplitudefactor = ampdb(p5) / ampdb(80)\n" +
          "ileftpan     =   (0.5 - p7) / 2 * iamplitudefactor\n" +
          "irightpan    =   (0.5 + p7) / 2 * iamplitudefactor\n" +
          "; Derive the speed multiplier from the duration.\n" +
          "icolumns = " + timeBinCount + "\n" + "imspercolumn = " +
          TimeIncrement + "\n" +
          "ispeedfactor = ((icolumns * imspercolumn) / 1000) / p3\n" +
          "print iamplitudefactor\n" + "print ifrequencyfactor\n" +
          "print ispeedfactor\n" + "; AUDIO\n" +
          "asignal adsyn iamplitudefactor, ifrequencyfactor, ispeedfactor, \""
          + analysisFilename + "\"\n" +
          "outs asignal * ileftpan, asignal * irightpan\n";
        String instrumentName = name + instrumentIndex + "Ads";
        score.clear ();
        double[] note = Event.createNote ();
        Event.setInstrument (note, instrumentIndex);
        Event.setDuration (note, totalDurationSeconds);
        score.addEvent (note);
      }
      catch (Exception e)
      {
        e.printStackTrace ();
      }
    }
  }
  public void addHutchinsonOperatorMatrix ()
  {
    hutchinsonOperatorMatrixCount++;
    hutchinsonOperator.add (Matrix.identity (ELEMENT_COUNT));
    double[][] oldMarkovOperator = (double[][]) markovOperator.clone ();
    markovOperator = new double[hutchinsonOperatorMatrixCount][hutchinsonOperatorMatrixCount];
    for (int i = 0; i < oldMarkovOperator.length; i++)
    {
      for (int j = 0; j < oldMarkovOperator[i].length; j++)
      {
        markovOperator[i][j] = oldMarkovOperator[i][j];
      }
    }
  }
  public void removeHutchinsonOperatorMatrix (int index)
  {
    hutchinsonOperatorMatrixCount--;
    hutchinsonOperator.remove (index);
    double[][] oldMarkovOperator = (double[][]) markovOperator.clone ();
    markovOperator = new double[hutchinsonOperatorMatrixCount][hutchinsonOperatorMatrixCount];
    for (int i = 0; i < index - 1; i++)
    {
      for (int j = 0; j < index - 1; j++)
      {
        markovOperator[i][j] = oldMarkovOperator[i][j];
      }
    }
    for (int i = index; i < oldMarkovOperator.length; i++)
    {
      for (int j = index; j < oldMarkovOperator.length; j++)
      {
        markovOperator[i - 1][j - 1] = oldMarkovOperator[i][j];
      }
    }
  }

  public void normalizeMarkovOperator ()
  {
    for (int i = 0; i < markovOperator.length; i++)
    {
      double sum = 0;
      for (int j = 0; j < markovOperator[i].length; j++)
      {
        sum += markovOperator[i][j];
      }
      for (int j = 0; j < markovOperator[i].length; j++)
      {
        markovOperator[i][j] /= sum;
      }
    }
  }
  //  Returns the next row index.
  public int monteCarlo (int rowIndex)
  {
    if (rowIndex < 0 || rowIndex >= markovOperator.length)
    {
      return 0;
    }
    double slot = 0;
    double ball = wheel.nextDouble ();
    for (int columnIndex = 0; true; columnIndex++)
    {
      slot += markovOperator[rowIndex][columnIndex];
      if (slot >= ball || columnIndex >= markovOperator.length)
      {
        return columnIndex;
      }
    }
  }
  public void prepareForIteration ()
  {
    try
    {
      reinitialize ();
      //Settle into the attractor.
      for (int i = 0; i < 100; i++)
      {
        currentMatrixIndex = monteCarlo (currentMatrixIndex);
        double[][] matrix =
          (double[][]) hutchinsonOperator.get (currentMatrixIndex);
        Matrix.times (currentPoint, matrix, oldPoint);
        bufferPoint = currentPoint;
        currentPoint = oldPoint;
        oldPoint = bufferPoint;
      }
      //Make the size of the attractor start at a point known to be in the attractor.
      for (int i = 0; i < DIMENSION_COUNT; i++)
      {
        minima[i] = oldPoint[i];
        maxima[i] = oldPoint[i];
        ranges[i] = 0.0;
      }
      // Find size of attractor.
      for (int i = 0; i < findSizeCount; i++)
      {
        currentMatrixIndex = monteCarlo (currentMatrixIndex);
        double[][] matrix =
          (double[][]) hutchinsonOperator.get (currentMatrixIndex);
        Matrix.times (currentPoint, matrix, oldPoint);
        for (int j = 0; j < minima.length; j++)
        {
          if (minima[j] > currentPoint[j])
          {
            minima[j] = currentPoint[j];
            ranges[j] = maxima[j] - minima[j];
          }
          if (maxima[j] < currentPoint[j])
          {
            maxima[j] = currentPoint[j];
            ranges[j] = maxima[j] - minima[j];
          }
        }
        bufferPoint = currentPoint;
        currentPoint = oldPoint;
        oldPoint = bufferPoint;
      }
      beginAt = System.currentTimeMillis ();
      endAt =
        System.currentTimeMillis () + ((long) (secondsToIterate * 1000.0));
      System.out.println ("RIFS prepared to iterate:");
      System.out.println ("Begin at " + beginAt + " milliseconds.");
      System.out.println ("End at   " + endAt + " milliseconds.");
      System.out.println ("Attractor minima:");
      System.out.println ("Seconds     " + minima[TIME_DIMENSION]);
      System.out.println ("Octaves     " + minima[OCTAVE_DIMENSION]);
      System.out.println ("Instruments " + minima[INSTRUMENT_DIMENSION]);
      System.out.println ("Attractor ranges:");
      System.out.println ("Seconds     " + ranges[TIME_DIMENSION]);
      System.out.println ("Octaves     " + ranges[OCTAVE_DIMENSION]);
      System.out.println ("Instruments " + ranges[INSTRUMENT_DIMENSION]);
    }
    catch (Exception e)
    {
      e.printStackTrace ();
    }
  }
  public void generate ()
  {
    prepareForIteration ();
    {
      if (!iterate ())
      {
        translate ();
        return;
      }
    }
  }
  public boolean iterate ()
  {
    try
    {
      currentMatrixIndex = monteCarlo (currentMatrixIndex);
      double[][] matrix =
        (double[][]) hutchinsonOperator.get (currentMatrixIndex);
      Matrix.times (currentPoint, matrix, oldPoint);
      bufferPoint = currentPoint;
      currentPoint = oldPoint;
      oldPoint = bufferPoint;
      currentTime = System.currentTimeMillis ();
      iterationCount++;
      if (iterationCount % 1000 == 0)
      {
        secondsToDate = (currentTime - beginAt) / 1000.0;
        System.out.println ("RIFS iteration    " + iterationCount + " at " +
                            secondsToDate + " seconds.");
        System.out.println ("Maximum amplitude " + maximumAmplitude);
        System.out.println ("Current matrix    " + currentMatrixIndex);
        if (currentTime >= endAt)
        {
          return false;
        }
      }
      return accumulate (oldPoint);
    }
    catch (Exception e)
    {
      e.printStackTrace ();
      return true;
    }
  }
  public boolean accumulate (double[]point)
  {
    try
    {
      int timeBinIndex =
        (int) (
               ((point[TIME_DIMENSION] - minima[TIME_DIMENSION]) /
                ranges[TIME_DIMENSION]) * (timeBinCount - 1));
      int octaveBinIndex =
        (int) (
               ((point[OCTAVE_DIMENSION] - minima[OCTAVE_DIMENSION]) /
                ranges[OCTAVE_DIMENSION]) * (octaveBinCount - 1));
      int instrumentBinIndex =
        (int) (
               ((point[INSTRUMENT_DIMENSION] - minima[INSTRUMENT_DIMENSION]) /
                ranges[INSTRUMENT_DIMENSION]) * (instrumentBinCount - 1));
      if (measure[timeBinIndex][octaveBinIndex][instrumentBinIndex] <
          Integer.MAX_VALUE)
      {
        measure[timeBinIndex][octaveBinIndex][instrumentBinIndex] += 1;
        if (measure[timeBinIndex][octaveBinIndex][instrumentBinIndex] >
            maximumAmplitude)
        {
          maximumAmplitude =
            measure[timeBinIndex][octaveBinIndex][instrumentBinIndex];
        }
      }
      else
      {
        return false;
      }
    }
    catch (Exception e)
    {
      e.printStackTrace ();
    }
    return true;
  }
  public void importIFS (String filename)
  {
    try
    {
      FileReader fileReader = new FileReader (filename.trim ());
      BufferedReader bufferedReader = new BufferedReader (fileReader);
      hutchinsonOperator = new ArrayList ();
      ArrayList probabilities = new ArrayList ();
      double buffer = 0;
      for (;;)
      {
        String line = bufferedReader.readLine ();
        if (line == null)
        {
          return;
        }
        if (line.indexOf ("{") != -1)
        {
          break;
        }
      }
      int matrixCount;
      for (matrixCount = 0;; matrixCount++)
      {
        String line = bufferedReader.readLine ();
        if (line == null)
        {
          break;
        }
        if (line.indexOf ("}") != -1)
        {
          break;
        }
        double[][] matrix = Matrix.create (ELEMENT_COUNT,
                                           ELEMENT_COUNT);
        StringTokenizer stringTokenizer =
          new StringTokenizer (line, "{} \t\n\r,");
        int columnCount = 0;
        while (stringTokenizer.hasMoreTokens ())
        {
          String token = stringTokenizer.nextToken ();
          if (token.indexOf (";") == -1)
          {
            buffer = Double.parseDouble (token);
            switch (columnCount)
            {
            case 0:
              matrix[TIME_DIMENSION][TIME_DIMENSION] = buffer;
              break;
            case 1:
              matrix[TIME_DIMENSION][OCTAVE_DIMENSION] = buffer;
              break;
            case 2:
              matrix[OCTAVE_DIMENSION][TIME_DIMENSION] = buffer;
              break;
            case 3:
              matrix[OCTAVE_DIMENSION][OCTAVE_DIMENSION] = buffer;
              break;
            case 4:
              matrix[TIME_DIMENSION][DIMENSION_COUNT] = buffer;
              break;
            case 5:
              matrix[OCTAVE_DIMENSION][DIMENSION_COUNT] = buffer;
              break;
            case 6:
              probabilities.add (new Double (buffer));
              break;
            }
          }
          columnCount++;
        }
        matrix[DIMENSION_COUNT][DIMENSION_COUNT] = 1.0;
        hutchinsonOperator.add (matrix);
      }
      //reinitialize();
      fileReader.close ();
      markovOperator = new double[matrixCount][matrixCount];
      for (int i = 0; i < markovOperator.length; i++)
      {
        for (int j = 0; j < markovOperator[i].length; j++)
        {
          markovOperator[i][j] =
            ((Double) probabilities.get (j)).doubleValue ();
        }
      }
    }
    catch (Exception e)
    {
      e.printStackTrace ();
    }
  }
  public void translate ()
  {
    if (renderAsSound)
    {
      translateToAdsyn ();
    }
    else
    {
      translateToNotes ();
    }
    if (score.autoRescale)
    {
      score.setActualScaleToTarget ();
    }
  }
  public double[][] produceOrTransformNotes (double[][]compositeTransform,
                                             Score score,
                                             int preTraversalCount,
                                             int postTraversalCount)
  {
    try
    {
      int n = this.score.size ();
      for (int i = 0; i < n; i++)
      {
        double[] note = this.score.getEvent (i);
        double[] transformedNote = Matrix.times (compositeTransform,
                                                 note);
        score.addEvent (transformedNote);
      }
    }
    catch (Exception e)
    {
      e.printStackTrace ();
    }
    return compositeTransform;
  }
  public void openView ()
  {
    RIFSView view = new RIFSView (this);
    view.setVisible (true);
  }
  public Container getView ()
  {
    RIFSView view = new RIFSView (this);
    return view;
  }
}
