package Silence.Score.Nodes;
import Silence.Orchestra.Event;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import java.awt.*;
import javax.swing.*;
import javax.swing.table.*;
/**
 *  @author Copyright (C) 1998 by Michael Gogins. All rights reserved.
 *  <ADDRESS>
 *  gogins@pipeline.com
 *  </ADDRESS>
 */
public class RescaleView extends javax.swing.JInternalFrame
{
  public static void main (String args[])
  {
    JFrame frame = new JFrame ();
    RescaleView rescaleView = new RescaleView (new Rescale ());
      rescaleView.setVisible (true);
      frame.getContentPane ().add (rescaleView);
      frame.setBounds (50, 50, 400, 400);
      frame.setVisible (true);
  }
  Rescale rescale = null;
  public class TableModel extends AbstractTableModel
  {
    public int getRowCount ()
    {
      return Event.ELEMENT_COUNT;
    }
    public int getColumnCount ()
    {
      return 5;
    }
    public Object getValueAt (int row, int column)
    {
      if (column < 0 || column > 4 || rescale == null)
	{
	  return null;
	}
      try
      {
	switch (column)
	  {
	  case 0:
	    return Event.labels[row];
	    case 1:return new Boolean (rescale.rescaleMinima[row]);
	    case 2:return new Double (rescale.scaleTargetMinima[row]);
	    case 3:return new Boolean (rescale.rescaleRanges[row]);
	    case 4:return new Double (rescale.scaleTargetRanges[row]);
	  }
      }
      catch (Exception x)
      {
	x.printStackTrace ();
      }
      return null;
    }
    public void setValueAt (Object value, int row, int column)
    {
      if (column < 0 || column > 4 || rescale == null
	  || row >= Event.HOMOGENEITY)
	{
	  return;
	}
      boolean b = false;
      double d = 0;
      switch (column)
	{
	case 1:
	  b = ((Boolean) value).booleanValue ();
	  rescale.rescaleMinima[row] = b;
	  return;
	case 2:
	  d = Double.parseDouble (value.toString ());
	  rescale.scaleTargetMinima[row] = d;
	  return;
	case 3:
	  b = ((Boolean) value).booleanValue ();
	  rescale.rescaleRanges[row] = b;
	  return;
	case 4:
	  d = Double.parseDouble (value.toString ());
	  rescale.scaleTargetRanges[row] = d;
	  return;
	}
    }
    public Class getColumnClass (int column)
    {
      switch (column)
	{
	case 0:
	  return String.class;
	  case 1:return Boolean.class;
	  case 2:return Double.class;
	  case 3:return Boolean.class;
	  case 4:return Double.class;
	}
      return String.class;
    }
    public boolean isCellEditable (int row, int column)
    {
      if (column == 0)
	{
	  return false;
	}
      if (row >= Event.HOMOGENEITY)
	{
	  return false;
	}
      return true;
    }
    public String getColumnName (int column)
    {
      switch (column)
	{
	case 0:
	  return "Dimension";
	  case 1:return "Rescale?";
	  case 2:return "Minima";
	  case 3:return "Rescale?";
	  case 4:return "Ranges";
	}
      return "Error";
    }
  }
  TableModel tableModel = new TableModel ();
  void updateView ()
  {
    nameField.setText (rescale.getName ());
    tableModel.fireTableDataChanged ();
  }
  void updateModel ()
  {
    String buffer = nameField.getText ();
    if (buffer != null)
      {
	rescale.setName (buffer);
      }
  }
  public RescaleView (Rescale r)
  {
    this ();
    rescale = r;
    updateView ();
  }
  public RescaleView ()
  {
    super ();
    getContentPane ().setLayout (null);
    setVisible (false);
    setSize (457, 549);
    setFont (new Font ("Dialog", Font.PLAIN, 12));
    setForeground (new Color (0));
    setBackground (new Color (8421504));
    namePanel = new javax.swing.JPanel ();
    namePanel.setLayout (null);
    namePanel.setBounds (12, 12, 432, 72);
    namePanel.setFont (new Font ("Dialog", Font.BOLD, 12));
    namePanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (namePanel);
    nameField = new javax.swing.JTextField ();
    nameField.setBounds (12, 36, 408, 24);
    nameField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    namePanel.add (nameField);
    nameLabel = new javax.swing.JLabel ();
    nameLabel.setText ("Name");
    nameLabel.setHorizontalAlignment (0);
    nameLabel.setHorizontalTextPosition (0);
    nameLabel.setBounds (12, 0, 408, 24);
    nameLabel.setFont (new Font ("Dialog", Font.BOLD, 12));
    namePanel.add (nameLabel);
    scalePanel = new javax.swing.JPanel ();
    scalePanel.setLayout (new BorderLayout ());
    scalePanel.setBounds (12, 96, 432, 384);
    scalePanel.setFont (new Font ("Dialog", Font.BOLD, 12));
    scalePanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (scalePanel);
    parametersLabel = new javax.swing.JLabel ();
    parametersLabel.setText ("Parameters");
    parametersLabel.setFont (new Font ("Dialog", Font.BOLD, 12));
    scalePanel.add (parametersLabel, BorderLayout.NORTH);
    table = new JTable ();
    scrollPane = new JScrollPane ();
    scrollPane.getViewport ().add (table);
    scalePanel.add (scrollPane, BorderLayout.CENTER);
    buttonPanel = new javax.swing.JPanel ();
    buttonPanel.setLayout (null);
    buttonPanel.setBounds (12, 492, 432, 48);
    buttonPanel.setFont (new Font ("Dialog", Font.BOLD, 12));
    buttonPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (buttonPanel);
    okButton = new javax.swing.JButton ();
    okButton.setText ("Update");
    okButton.setActionCommand ("button");
    okButton.setBounds (12, 12, 96, 24);
    okButton.setFont (new Font ("Dialog", Font.PLAIN, 12));
    buttonPanel.add (okButton);
    setTitle ("Rescale");
    SymAction lSymAction = new SymAction ();
      okButton.addActionListener (lSymAction);
      table.setModel (tableModel);
  }
  javax.swing.JPanel namePanel;
  javax.swing.JTextField nameField;
  javax.swing.JLabel nameLabel;
  javax.swing.JPanel scalePanel;
  javax.swing.JLabel parametersLabel;
  javax.swing.JScrollPane scrollPane;
  javax.swing.JTable table;
  javax.swing.JPanel buttonPanel;
  javax.swing.JButton okButton;
  class SymAction implements java.awt.event.ActionListener
  {
    public void actionPerformed (java.awt.event.ActionEvent event)
    {
      Object object = event.getSource ();
      if (object == okButton)
	  okButton_Action (event);
    }
  }
  void okButton_Action (java.awt.event.ActionEvent event)
  {
    updateModel ();
  }
}
