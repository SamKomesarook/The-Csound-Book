package Silence.Score.Nodes;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import java.awt.Container;
import java.util.Iterator;
/**
Simply produces the notes that are in its score.
@author Copyright (C) 2000 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class ScoreNode extends Node implements NodeInterface
{
  public ScoreNode ()
  {
    score = new Score ();
  }
  public NodeInterface copy()
  {
    ScoreNode copy = new ScoreNode();
    copyFieldsInto(copy);
    return copy;
  }
  public void copyFieldsInto(NodeInterface copy_)
  {
    ScoreNode copy = (ScoreNode) copy_;
    super.copyFieldsInto(copy);
  }
  public double[][]
    produceOrTransformNotes (double[][]compositeTransformation, Score score,
			     int preTraversalCount, int postTraversalCount)
  {
    if (this.score.autoRescale)
      {
	this.score.setActualScaleToTarget ();
      }
    for (Iterator i = this.score.iterator (); i.hasNext ();)
      {
	score.add (((double[]) i.next ()).clone());
      }
    return compositeTransformation;
  }
  public Container getView ()
  {
    return score.getView ();
  }
}
