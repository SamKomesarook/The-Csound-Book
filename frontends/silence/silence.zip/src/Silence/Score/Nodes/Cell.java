package Silence.Score.Nodes;
import Silence.Score.NodeInterface;

public class Cell extends ScoreNode
{
  public Cell ()
  {
  }
  public NodeInterface copy()
  {
    Cell copy = new Cell();
    copyFieldsInto(copy);
    return copy;
  }
}
