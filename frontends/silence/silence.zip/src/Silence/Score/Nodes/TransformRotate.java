package Silence.Score.Nodes;
import Silence.Orchestra.Event;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import Silence.Mathematics.*;
import java.awt.*;
import java.applet.*;
import java.io.*;
import java.util.*;
/**
Moves all child nodes and all notes produced by them
to the origin of the global coordinate system,
rotates them from one dimension to another
by an angle specified in units of pi, and returns them to their original position.
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class TransformRotate extends Transform implements NodeInterface,
  java.io.Serializable
{
  String dimensionFrom;
  String dimensionTo;
  double angleInPi;
  public TransformRotate ()
  {
    super ();
    defaultsTransformRotate ();
  }
  public NodeInterface copy()
  {
    TransformRotate copy = new TransformRotate();
    copyFieldsInto(copy);
    return copy;
  }
  public void copyFieldsInto(NodeInterface copy_)
  {
    TransformRotate copy = (TransformRotate) copy_;
    super.copyFieldsInto(copy);
    copy.dimensionFrom = dimensionFrom;
    copy.dimensionTo = dimensionTo;
    copy.angleInPi = angleInPi;
  }
  public void defaultsTransformRotate ()
  {
    dimensionFrom = "time";
    dimensionTo = "octave";
    angleInPi = 0.5;
  }
  public TransformRotate (int rowCount, int columnCount)
  {
    setSize (rowCount, columnCount);
  }
	/**
	Translate to the origin, rescale, and translate back to the original position.
	*/
  public double[][] produceOrTransformNotes (double[][]compositeTransform,
					     Score score,
					     int preTraversalCount,
					     int postTraversalCount)
  {
    Rescale scale = new Rescale ();
      scale.findActualScale (score, preTraversalCount, postTraversalCount);
    //  Third, create matrices to translate the produced notes
    //  to the origin, rescale them, and translate them back to their original position.
    double[][] translateToOrigin = Matrix.identity (Event.ELEMENT_COUNT);
    double[][] rescale = createRotation (getDimension (dimensionFrom),
					 getDimension (dimensionTo),
					 angleInPi);
    double[][] translateToOriginalPosition =
      Matrix.identity (Event.ELEMENT_COUNT);
    for (int i = 0; i < Event.HOMOGENEITY; i++)
      {
	translateToOrigin[i][Event.HOMOGENEITY] = -scale.scaleActualMinima[i];
	translateToOriginalPosition[i][Event.HOMOGENEITY] =
	  scale.scaleActualMinima[i];
      }
    try
    {
      for (int i = preTraversalCount; i < postTraversalCount; i++)
	{
	  double[] note = score.getEvent (i);
	  double[] newNote = Matrix.times (translateToOrigin, note);
	    newNote = Matrix.times (rescale, newNote);
	    Matrix.times (note, translateToOriginalPosition, newNote);
	}
    }
    catch (Exception e)
    {
      e.printStackTrace ();
    }
    return compositeTransform;
  }
  public static int getDimension (String dimension)
  {
    if (dimension.startsWith ("Status"))
      {
	return Event.STATUS;
      }
    else if (dimension.startsWith ("Instrument"))
      {
	return Event.INSTRUMENT;
      }
    else if (dimension.startsWith ("Time"))
      {
	return Event.TIME;
      }
    else if (dimension.startsWith ("Duration"))
      {
	return Event.DURATION;
      }
    else if (dimension.startsWith ("Octave"))
      {
	return Event.KEY;
      }
    else if (dimension.startsWith ("Decibels"))
      {
	return Event.DECIBELS;
      }
    else if (dimension.startsWith ("Phase"))
      {
	return Event.PHASE;
      }
    else if (dimension.startsWith ("X"))
      {
	return Event.X;
      }
    else if (dimension.startsWith ("Y"))
      {
	return Event.Y;
      }
    else if (dimension.startsWith ("Z"))
      {
	return Event.Z;
      }
    return -1;
  }
  public static double[][] createRotation (int dimension1, int dimension2,
					   double angle)
  {
    double[][] rotation = Matrix.identity (Event.ELEMENT_COUNT);
    if (dimension1 == -1 || dimension2 == -1)
      {
	System.out.println
	  ("Dimension out of range in TransformRotate.createRotation().");
	return rotation;
      }
    try
    {
      rotation[dimension1][dimension1] = Math.cos (angle);
      rotation[dimension1][dimension2] = -Math.sin (angle);
      rotation[dimension2][dimension1] = Math.sin (angle);
      rotation[dimension2][dimension2] = Math.cos (angle);
    }
    catch (Exception e)
    {
      e.printStackTrace ();
    }
    return rotation;
  }
  public void openView ()
  {
    TransformRotateView view = new TransformRotateView (this);
      view.setVisible (true);
  }
  public Container getView ()
  {
    return new TransformRotateView (this);
  }
}
