package Silence.Score.Nodes;
import Silence.Global;
import Silence.Score.Score;
import Silence.Score.ScoreView;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import java.awt.*;
import java.io.*;
import javax.swing.*;
import java.awt.event.*;
/**
 * @author Copyright (C) 2000 by Michael Gogins. All rights reserved.
 * <ADDRESS>
 * gogins@pipeline.com
 * </ADDRESS>
 */
public class GraphicsToMusicView extends JPanel
{
  public static void main (String[]args)
  {
    JFrame frame = new JFrame ();
    GraphicsToMusicView graphicsToMusicView = new GraphicsToMusicView ();
    frame.getContentPane ().add (graphicsToMusicView);
    frame.setBounds (50, 50, 800, 600);
    frame.setVisible (true);
  }
  public class ImagePanel extends JPanel
  {
    public void paint (Graphics g)
    {
      if (graphicsToMusic.image == null)
      {
        return;
      }
      int width = getSize ().width;
      int height = getSize ().height;
      boolean returnValue =
        g.drawImage (graphicsToMusic.image,
                     0, 0, width, height, Color.black,
                     this);
    }
  }
  BorderLayout borderLayout1 = new BorderLayout ();
  JTabbedPane tabs = new JTabbedPane ();
  Image image = null;
  ImagePanel imagePanel = new ImagePanel ();
  JPanel parametersPanel = new JPanel ();
  ScoreView scoreView = null;
  GraphicsToMusic graphicsToMusic = null;
  JToolBar toolBar = new JToolBar ();
  JButton importButton = new JButton ();
  JTextField graphicsFilenameField = new JTextField ();
  JButton translateButton = new JButton ();
  JPanel innerParametersPanel = new JPanel ();
  JLabel brightnessThresholdLabel = new JLabel ();
  JLabel tonesPerOctaveLabel = new JLabel ();
  JTextField instrumentCountTextField = new JTextField ();
  JTextField tonesPerOctaveTextField = new JTextField ();
  JLabel instrumentCountLabel = new JLabel ();
  JLabel durationSecondsLabel = new JLabel ();
  JTextField durationSecondsTextField = new JTextField ();
  JTextField brightnessThresholdTextField = new JTextField ();
  BorderLayout borderLayout2 = new BorderLayout ();
  JButton exitButton = new JButton ();

  public GraphicsToMusicView (GraphicsToMusic graphicsToMusic)
  {
    this.graphicsToMusic = graphicsToMusic;
    scoreView = (ScoreView) graphicsToMusic.getLocalScore ().getView ();
    scoreView.setVisible (true);
    try
    {
      jbInit ();
    }
    catch (Exception ex)
    {
      ex.printStackTrace ();
    }
    updateView ();
  }

  public GraphicsToMusicView ()
  {
    this (new GraphicsToMusic ());
  }
  private void jbInit () throws Exception
  {
    this.setLayout (borderLayout1);
    parametersPanel.setLayout (borderLayout2);
    toolBar.setFloatable (false);
    importButton.setText ("Import");
    importButton.addActionListener (new
                                    GraphicsToMusicView_importButton_actionAdapter
                                    (this));
    graphicsFilenameField.setEditable (false);
    translateButton.setText ("Translate");
    translateButton.addActionListener (new
                                       GraphicsToMusicView_translateButton_actionAdapter
                                       (this));
    innerParametersPanel.setLayout (null);
    brightnessThresholdLabel.setText ("Brightness threshold");
    brightnessThresholdLabel.setBounds (new Rectangle (21, 16, 144, 25));
    brightnessThresholdLabel.setBounds (new Rectangle (6, 49, 144, 25));
    brightnessThresholdLabel.setBounds (new Rectangle (8, 45, 144, 25));
    tonesPerOctaveLabel.setBounds (new Rectangle (9, 79, 144, 25));
    tonesPerOctaveLabel.setBounds (new Rectangle (7, 123, 144, 25));
    tonesPerOctaveLabel.setText ("Tones per octave");
    tonesPerOctaveLabel.setBounds (new Rectangle (9, 79, 144, 25));
    tonesPerOctaveLabel.setBounds (new Rectangle (21, 87, 144, 25));
    tonesPerOctaveLabel.setBounds (new Rectangle (6, 120, 144, 25));
    tonesPerOctaveLabel.setBounds (new Rectangle (9, 79, 144, 25));
    tonesPerOctaveLabel.setBounds (new Rectangle (7, 123, 144, 25));
    tonesPerOctaveLabel.setBounds (new Rectangle (9, 79, 144, 25));
    tonesPerOctaveLabel.setBounds (new Rectangle (6, 120, 144, 25));
    tonesPerOctaveLabel.setBounds (new Rectangle (9, 79, 144, 25));
    tonesPerOctaveLabel.setBounds (new Rectangle (7, 123, 144, 25));
    tonesPerOctaveLabel.setBounds (new Rectangle (8, 76, 144, 25));
    instrumentCountTextField.setBounds (new Rectangle (156, 12, 112, 25));
    instrumentCountTextField.setBounds (new Rectangle (156, 44, 112, 25));
    instrumentCountTextField.setBounds (new Rectangle (156, 12, 112, 25));
    instrumentCountTextField.setBounds (new Rectangle (169, 53, 112, 25));
    instrumentCountTextField.setBounds (new Rectangle (154, 86, 112, 25));
    instrumentCountTextField.setBounds (new Rectangle (156, 12, 112, 25));
    instrumentCountTextField.setBounds (new Rectangle (156, 44, 112, 25));
    instrumentCountTextField.setBounds (new Rectangle (156, 12, 112, 25));
    instrumentCountTextField.setBounds (new Rectangle (154, 86, 112, 25));
    instrumentCountTextField.setBounds (new Rectangle (156, 12, 112, 25));
    instrumentCountTextField.setBounds (new Rectangle (156, 44, 112, 25));
    instrumentCountTextField.setBounds (new Rectangle (157, 12, 112, 25));
    tonesPerOctaveTextField.setBounds (new Rectangle (157, 81, 112, 25));
    tonesPerOctaveTextField.setBounds (new Rectangle (156, 125, 112, 25));
    tonesPerOctaveTextField.setBounds (new Rectangle (157, 81, 112, 25));
    tonesPerOctaveTextField.setBounds (new Rectangle (169, 87, 112, 25));
    tonesPerOctaveTextField.setBounds (new Rectangle (154, 120, 112, 25));
    tonesPerOctaveTextField.setBounds (new Rectangle (157, 81, 112, 25));
    tonesPerOctaveTextField.setBounds (new Rectangle (156, 125, 112, 25));
    tonesPerOctaveTextField.setBounds (new Rectangle (157, 81, 112, 25));
    tonesPerOctaveTextField.setBounds (new Rectangle (154, 120, 112, 25));
    tonesPerOctaveTextField.setBounds (new Rectangle (157, 81, 112, 25));
    tonesPerOctaveTextField.setBounds (new Rectangle (156, 125, 112, 25));
    tonesPerOctaveTextField.setBounds (new Rectangle (157, 80, 112, 25));
    instrumentCountLabel.setBounds (new Rectangle (8, 13, 144, 25));
    instrumentCountLabel.setBounds (new Rectangle (11, 42, 144, 25));
    instrumentCountLabel.setText ("Instrument count");
    instrumentCountLabel.setBounds (new Rectangle (8, 13, 144, 25));
    instrumentCountLabel.setBounds (new Rectangle (21, 52, 144, 25));
    instrumentCountLabel.setBounds (new Rectangle (6, 85, 144, 25));
    instrumentCountLabel.setBounds (new Rectangle (8, 13, 144, 25));
    instrumentCountLabel.setBounds (new Rectangle (11, 42, 144, 25));
    instrumentCountLabel.setBounds (new Rectangle (8, 13, 144, 25));
    instrumentCountLabel.setBounds (new Rectangle (6, 85, 144, 25));
    instrumentCountLabel.setBounds (new Rectangle (8, 13, 144, 25));
    instrumentCountLabel.setBounds (new Rectangle (11, 42, 144, 25));
    instrumentCountLabel.setBounds (new Rectangle (8, 13, 144, 25));
    durationSecondsLabel.setText ("Duration (seconds)");
    durationSecondsLabel.setBounds (new Rectangle (21, 123, 144, 25));
    durationSecondsLabel.setBounds (new Rectangle (6, 156, 144, 25));
    durationSecondsLabel.setBounds (new Rectangle (8, 108, 144, 25));
    durationSecondsTextField.setBounds (new Rectangle (156, 41, 112, 25));
    durationSecondsTextField.setBounds (new Rectangle (157, 70, 112, 25));
    durationSecondsTextField.setBounds (new Rectangle (156, 41, 112, 25));
    durationSecondsTextField.setBounds (new Rectangle (169, 121, 112, 25));
    durationSecondsTextField.setBounds (new Rectangle (154, 154, 112, 25));
    durationSecondsTextField.setBounds (new Rectangle (156, 41, 112, 25));
    durationSecondsTextField.setBounds (new Rectangle (157, 70, 112, 25));
    durationSecondsTextField.setBounds (new Rectangle (156, 41, 112, 25));
    durationSecondsTextField.setBounds (new Rectangle (154, 154, 112, 25));
    durationSecondsTextField.setBounds (new Rectangle (156, 41, 112, 25));
    durationSecondsTextField.setBounds (new Rectangle (157, 70, 112, 25));
    durationSecondsTextField.setBounds (new Rectangle (157, 114, 112, 25));
    brightnessThresholdTextField.setBounds (new Rectangle (169,
                                                           19, 112, 25));
    brightnessThresholdTextField.setBounds (new Rectangle (154,
                                                           52, 112, 25));
    brightnessThresholdTextField.setBounds (new Rectangle (157,
                                                           46, 112, 25));
    exitButton.setText ("Exit");
    exitButton.addActionListener (new
                                  GraphicsToMusicView_exitButton_actionAdapter
                                  (this));
    innerParametersPanel.setBorder (BorderFactory.createEtchedBorder ());
    this.add (tabs, BorderLayout.CENTER);
    tabs.add (parametersPanel, "Parameters");
    tabs.add (scoreView, "Score");
    tabs.add (imagePanel, "Display");
    this.add(toolBar, BorderLayout.NORTH);
    toolBar.add (importButton, null);
    toolBar.add (translateButton, null);
    toolBar.add (exitButton, null);
    toolBar.add (graphicsFilenameField, null);
    parametersPanel.add (innerParametersPanel, BorderLayout.CENTER);
    innerParametersPanel.add (brightnessThresholdLabel, null);
    innerParametersPanel.add (tonesPerOctaveLabel, null);
    innerParametersPanel.add (instrumentCountTextField, null);
    innerParametersPanel.add (instrumentCountLabel, null);
    innerParametersPanel.add (durationSecondsLabel, null);
    innerParametersPanel.add (durationSecondsTextField, null);
    innerParametersPanel.add (tonesPerOctaveTextField, null);
    innerParametersPanel.add (brightnessThresholdTextField, null);
  }
  void translateButton_actionPerformed (ActionEvent e)
  {
    updateModel ();
    graphicsToMusic.importImage ();
    graphicsToMusic.translate ();
    tabs.setSelectedComponent (scoreView);
    scoreView.updateView ();
  }
  void importButton_actionPerformed (ActionEvent e)
  {
    JFileChooser fileDialog = Global.createFileDialog ("Import from");
    fileDialog.addChoosableFileFilter (Global.createFileFilter
                                       ("JPEG files", ".jpeg"));
    fileDialog.addChoosableFileFilter (Global.createFileFilter ("GIF files",
                                                                ".gif"));
    if (graphicsToMusic.graphicsFilename != null)
    {
      fileDialog.setSelectedFile (new File(graphicsToMusic.graphicsFilename));
    }
    if (fileDialog.showOpenDialog (this) == fileDialog.APPROVE_OPTION)
    {
      File file = fileDialog.getSelectedFile ();
      graphicsToMusic.graphicsFilename = file.getAbsolutePath ();
      graphicsToMusic.importImage ();
      tabs.setSelectedComponent (imagePanel);
      updateView ();
      translateButton_actionPerformed(e);
    }
  }
  public void updateView ()
  {
    if (scoreView != null)
    {
      scoreView.updateView ();
    }
    graphicsFilenameField.setText (graphicsToMusic.graphicsFilename);
    brightnessThresholdTextField.
      setText (String.valueOf (graphicsToMusic.brightnessThreshold));
    instrumentCountTextField.
      setText (String.valueOf (graphicsToMusic.instrumentCount));
    tonesPerOctaveTextField.
      setText (String.valueOf (graphicsToMusic.tonesPerOctave));
    durationSecondsTextField.
      setText (String.valueOf (graphicsToMusic.durationSeconds));
  }
  public void updateModel ()
  {
    graphicsToMusic.brightnessThreshold =
      Double.parseDouble (brightnessThresholdTextField.getText ());
    graphicsToMusic.instrumentCount =
      (int) Double.parseDouble (instrumentCountTextField.getText ());
    graphicsToMusic.tonesPerOctave =
      Double.parseDouble (tonesPerOctaveTextField.getText ());
    graphicsToMusic.durationSeconds =
      Double.parseDouble (durationSecondsTextField.getText ());
  }
  void exitButton_actionPerformed (ActionEvent e)
  {
    System.exit (0);
  }
}
class GraphicsToMusicView_importButton_actionAdapter implements java.
  awt.event.ActionListener
  {
  GraphicsToMusicView adaptee;

  GraphicsToMusicView_importButton_actionAdapter (GraphicsToMusicView adaptee)
  {
    this.adaptee = adaptee;
  }
  public void actionPerformed (ActionEvent e)
  {
    adaptee.importButton_actionPerformed (e);
  }
}
class GraphicsToMusicView_translateButton_actionAdapter implements java.
  awt.event.ActionListener
  {
  GraphicsToMusicView adaptee;

  GraphicsToMusicView_translateButton_actionAdapter (GraphicsToMusicView adaptee)
  {
    this.adaptee = adaptee;
  }
  public void actionPerformed (ActionEvent e)
  {
    adaptee.translateButton_actionPerformed (e);
  }
}
class GraphicsToMusicView_exitButton_actionAdapter implements java.awt.
  event.ActionListener
  {
  GraphicsToMusicView adaptee;

  GraphicsToMusicView_exitButton_actionAdapter (GraphicsToMusicView adaptee)
  {
    this.adaptee = adaptee;
  }
  public void actionPerformed (ActionEvent e)
  {
    adaptee.exitButton_actionPerformed (e);
  }
}
