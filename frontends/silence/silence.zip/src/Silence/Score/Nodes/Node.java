package Silence.Score.Nodes;
import Silence.Global;
import Silence.Plugin;
import Silence.Conversions;
import Silence.Mathematics.Matrix;
import Silence.Orchestra.Event;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import java.awt.Container;
import java.io.*;
import java.util.*;
import javax.swing.AbstractListModel;
/**
Serves simply as a container for child nodes,
without transforming the coordinate system or producing notes.
Can be used as a base class for other nodes.
@author Copyright (C) 1998, 2000 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class Node extends Plugin implements NodeInterface,
  javax.swing.tree.TreeNode
{
  protected NodeInterface parentNode = null;
  public ArrayList childNodes = new ArrayList ();
  protected double[][] localTransformation =
    Matrix.identity (Event.ELEMENT_COUNT);
  public Score score = null;
  public static Score globalScore = null;
  public static class InstancesListModel extends AbstractListModel
  {
    public int getSize()
    {
      return instances.size();
    }
    public Object getElementAt(int index)
    {
      return instances.keySet().toArray()[index];
    }
  }
  public static final InstancesListModel instancesListModel = new InstancesListModel();
  public static class ClassesListModel extends AbstractListModel
  {
    public int getSize()
    {
      return classes.size();
    }
    public Object getElementAt(int index)
    {
      return classes.keySet().toArray()[index];
    }
  }
  public static final ClassesListModel classesListModel = new ClassesListModel();
  public Node ()
  {
  }
  public void clear ()
  {
    childNodes.clear ();
  }
  public double[][] getLocalTransformation ()
  {
    return localTransformation;
  }
  public void setLocalTransformation (double[][]localTransformation)
  {
    this.localTransformation = localTransformation;
  }
  public double[][] traverseMusicGraph (double[][]parentTransformation,
					Score score)
  {
    //  Record the number of notes already in the score
    //  before traversing any child nodes of this.
    int preTraversalCount = score.size ();
    //  The local transformation of coordinate systems
    //  is identity for non-transformation nodes,
    //  or some other affine transformation for transformation nodes.
    double[][] compositeTransformation =
      Matrix.times (parentTransformation, getLocalTransformation ());
    //  Iterate over the immediate child nodes of this...
    for (int i = 0, n = getChildCount (); i < n; i++)
      {
	//  ...calling traverseMusicGraph on each one.
	//  This has the effect of performing a recursive,
	//  depth-first traversal of the music graph.
	getChild (i).traverseMusicGraph (compositeTransformation, score);
      }
    //  Record the number of notes in the score
    //  after traversing the child nodes.
    //  This number will have increased by the number of new notes
    //  produced by all child nodes of this.
    int postTraversalCount = score.size ();
    //  Finally, either produce new notes, or transform all notes
    //  that were produced by the child nodes of this.
    double[][] transformation =
      produceOrTransformNotes (compositeTransformation, score,
			       preTraversalCount, postTraversalCount);
      System.gc ();
      return transformation;
  }
  public double[][] traverseMusicGraph (Score score)
  {
    return traverseMusicGraph (Event.identity (), score);
  }
  public double[][]
    produceOrTransformNotes (double[][]compositeTransformation, Score score,
			     int preTraversalCount, int postTraversalCount)
  {
    return compositeTransformation;
  }
  public boolean setChildAt (int index, NodeInterface node)
  {
    try
    {
      childNodes.set (index, node);
      node.setParent (this);
    }
    catch (Exception e)
    {
      return false;
    }
    return true;
  }
  public void addChild (NodeInterface node)
  {
    childNodes.add (node);
    node.setParent (this);
  }
  public void insertChildAt (int index, NodeInterface node)
  {
    childNodes.add (index, node);
    node.setParent (this);
  }
  public boolean removeChildAt (int Index)
  {
    try
    {
      childNodes.remove (Index);
      return true;
    }
    catch (Exception e)
    {
      e.printStackTrace ();
    }
    return false;
  }
  public boolean removeChild (NodeInterface node)
  {
    return childNodes.remove (node);
  }
  public Score getGlobalScore ()
  {
    return globalScore;
  }
  public void setGlobalScore (Score score)
  {
    globalScore = score;
  }
  public Score getLocalScore ()
  {
    return score;
  }
  public void setLocalScore (Score score)
  {
    this.score = score;
  }
  //  Implementation of JFC TreeNode. nodes of this.m all notesses.served.
  public javax.swing.tree.TreeNode getChildAt (int index)
  {
    try
    {
      return (javax.swing.tree.TreeNode) childNodes.get (index);
    }
    catch (Exception e)
    {
      e.printStackTrace ();
    }
    return null;
  }
  public int getChildCount ()
  {
    return childNodes.size ();
  }
  public javax.swing.tree.TreeNode getParent ()
  {
    return parentNode;
  }
  public void setParent (NodeInterface node)
  {
    parentNode = node;
  }
  public java.util.Enumeration children ()
  {
    return Collections.enumeration (childNodes);
  }
  public int getIndex (javax.swing.tree.TreeNode node)
  {
    return childNodes.indexOf (node);
  }
  public boolean getAllowsChildren ()
  {
    return true;
  }
  public boolean isLeaf ()
  {
    if (getChildCount () > 0)
      {
	return false;
      }
    return true;
  }
  public String toString ()
  {
    return getClass ().getName () + " : " + getName ();
  }
  public Node getChild (int index)
  {
    return (Node) childNodes.get (index);
  }
  public Container getView ()
  {
    return new NodeView (this);
  }
  public NodeInterface copy()
  {
    Node copy = new Node();
    copyFieldsInto(copy);
    return copy;
  }
  public void copyFieldsInto(NodeInterface copy)
  {
    copy.setName(null);
    copy.setClassname(getClassname());
    copy.setLocalTransformation((double[][]) getLocalTransformation().clone());
    if(score != null)
    {
      copy.setLocalScore(getLocalScore().copy());
    }
    for(int i = 0, n = getChildCount(); i < n; i++)
    {
      copy.addChild(getChild(i).copy());
    }
  }
}
