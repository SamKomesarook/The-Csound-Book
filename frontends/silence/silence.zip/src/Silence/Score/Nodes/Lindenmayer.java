package Silence.Score.Nodes;
import Silence.Orchestra.Event;
import Silence.Score.MasonNumbers;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import Silence.Mathematics.*;
import java.applet.*;
import java.awt.*;
import java.io.*;
import java.util.*;
import javax.swing.*;
/**
 * Defines a simple context-free Lindenmayer system, or O-L string rewriting grammar,
 * that produces a string of commands for generating a score.
 * The system begins as an axiom of uninterpreted symbols.
 * A table of rewriting rules specifies strings of symbols that
 * are to replace at least one of the symbols in the axiom.
 * The system also divides the circle into N equally sized angles.
 * The system is iterated a specified number of times, producing a possibly
 * lengthy string of symbols. The symbols are then interpreted as a set of commands
 * for controlling a &quot;turtle&quot; that writes a Silence score.
 * The turtle is simply a Silence Note node, representing
 * a position in the score, or note space, together with a vector of step sizes,
 * a vector representing the orientation of the turtle, and a Mason number representing
 * a pitch-class set. *
 * <p>
 * The dimensions of note space are represented by letters:
 * <ul>
 * <li>i     = instrument, starting with 1.</li>
 * <li>t     = time, in seconds.</li>
 * <li>d     = duration, in seconds.</li>
 * <li>k     = pitch, in MIDI keys where middle C = 60.0.</li>
 * <li>v     = loudness, in MIDI velocity where 0 = silence.</li>
 * <li>p     = phase, in radians.</li>
 * <li>x     = distance along x dimension.</li>
 * <li>y     = distance along y dimension.</li>
 * <li>z     = distance along z dimension.</li>
 * <li>m     = Mason number from 0 to 4095.</li>
 * </ul>
 * The turtle commands also are represented by letters (all n default to 1):
 * <ul>
 * <li>N     = Write the current state of the turtle into the score as a note.</li>
 * <li>Mn    = Translate the turtle by adding to its state its step times its orientation times n.</li>
 * <li>Rabn  = Rotate the turtle from dimension a to dimension b by angle 2 pi / (angleCount * n)</li>
 * <li>Uan   = Vary the turtle state on dimension a by a normalized (-1 through +1) uniformly distributed random variable times n.</li>
 * <li>Gan   = Vary the turtle state on dimension a by a normalized (-1 through +1) Gaussian random variable times n.</li>
 * <li>T=an  = Assign to dimension a of the turtle state the value n.</li>
 * <li>T*an  = Multiply dimension a of the turtle state by n.</li>
 * <li>T/an  = Divide dimension a of the turtle state by n.</li>
 * <li>T+an  = Add to dimension a of the turtle state the value n.</li>
 * <li>T-an  = Subtract from dimension a of the turtle state the value n.</li>
 * <li>S=an  = Assign to dimension a of the turtle step the value n.</li>
 * <li>S*an  = Multiply dimension a of the turtle step by n.</li>
 * <li>S/an  = Divide dimension a of the turtle step by n.</li>
 * <li>S+an  = Add to dimension a of the turtle step the value n.</li>
 * <li>S-an  = Subtract from dimension a of the turtle step the value n.</li>
 * <li>[     = Push the current state of the turtle state onto a stack.</li>
 * <li>]     = Pop the current state of the turtle from the stack.</li>
 * </ul>
 * When entering rules, the turtle commands are separated by spaces.
 * @author Copyright (C) 1998 by Michael Gogins. All rights reserved.
 * <ADDRESS>
 * gogins@pipeline.com
 * </ADDRESS>
 */
public class Lindenmayer extends Node implements NodeInterface,
  java.io.Serializable
  {
  public void openView ()
  {
    JFrame frame = new JFrame ("Simple Lindenmayer");
    LindenmayerView lindenmayerView = new LindenmayerView (this);
    frame.getContentPane ().add (lindenmayerView);
    frame.setBounds (50, 50, 800, 600);
    lindenmayerView.setVisible (true);
  }
  String filename = null;
  String axiom = null;
  Hashtable rules = new Hashtable ();
  int angleCount = 4;
  int iterationCount;
  transient double angle;
  transient double[] turtle = null;
  transient double[] turtleStep = null;
  transient double[] turtleOrientation = null;
  transient ArrayList turtleStack = new ArrayList ();
  transient ArrayList turtleStepStack = new ArrayList ();
  transient ArrayList turtleOrientationStack = new ArrayList ();
  transient StringBuffer production = null;
  transient StringBuffer priorProduction = null;
  transient int ruleIndex;
  public Lindenmayer ()
  {
    defaultsLindenmayer ();
  }
  public NodeInterface copy()
  {
    Lindenmayer copy = new Lindenmayer();
    copyFieldsInto(copy);
    return copy;
  }
  public void copyFieldsInto(NodeInterface copy_)
  {
    Lindenmayer copy = (Lindenmayer) copy_;
    super.copyFieldsInto(copy);
    copy.filename = filename;
    copy.axiom = axiom;
    copy.rules = (Hashtable) rules.clone();
    copy.iterationCount = iterationCount;
  }
  public void defaultsLindenmayer ()
  {
    setLocalScore (new Score ());
    reinit();
    filename = "Lindenmayer.lnm";
    axiom = null;
    angleCount = 4;
    rules.clear ();
    ruleIndex = 0;
    iterationCount = 3;
    turtleStep = null;
    turtleOrientation = null;
    turtleStack.clear ();
    turtleStepStack.clear ();
    turtleOrientationStack.clear ();
    production = null;
    priorProduction = null;
    score.clear ();
    reinit ();
  }
  public void reinit ()
  {
    turtle = Event.createNote ();
    turtleStep = Event.createEvent ();
    for(int dimension = Event.INSTRUMENT; dimension < Event.ELEMENT_COUNT; dimension++)
    {
      turtleStep[dimension] = 1.0;
    }
    turtleOrientation = Event.createEvent ();
    turtleOrientation[Event.TIME] = 1.0;
    turtleStack.clear ();
    turtleStepStack.clear ();
    turtleOrientationStack.clear ();
    production = new StringBuffer ();
    priorProduction = new StringBuffer ();
    angle = Maths.TWO_PI / angleCount;
    score.clear ();
  }
  String getSymbol (int index)
  {
    String symbol = null;
    if (rules.size () > 0)
    {
      Enumeration e = rules.keys ();
      for (int i = 0; i <= index && e.hasMoreElements (); i++)
      {
        symbol = (String) e.nextElement ();
      }
    }
    return symbol;
  }
  public double[][] produceOrTransformNotes (double[][]compositeTransform,
                                             Score score, int beginIndex,
                                             int endIndex)
  {
    double[] note = null;
    double[] newNote = null;
    try
    {
      for (int i = 0, n = this.score.size(); i < n; i++)
      {
        score.addEvent(Matrix.times(compositeTransform,
                                    this.score.getEvent(i)));
      }
    }
    catch (Exception e)
    {
      e.printStackTrace ();
    }
    return compositeTransform;
  }
  public void generate ()
  {
    rewrite ();
    translate ();
    if (score.autoRescale)
    {
      score.setActualScaleToTarget ();
    }
  }
  public void rewrite ()
  {
    System.out.println ("Began rewriting " + getClass ().getName () + ":" +
                        getName () + "...");
    StringTokenizer tokenizer = null;
    String symbol = null;
    String replacement = null;
    reinit ();
    production.append (axiom);
    for (int i = 0; i < iterationCount; i++)
    {
      priorProduction = production;
      production = new StringBuffer ();
      tokenizer = new StringTokenizer (priorProduction.toString ());
      while (tokenizer.hasMoreTokens ())
      {
        symbol = tokenizer.nextToken ();
        replacement = (String) rules.get (symbol);
        if(replacement == null)
        {
          production.append(symbol);
        }
        else
        {
          production.append (replacement);
        }
        production.append (" ");
      }
    }
    System.out.println ("Ended rewriting " + getClass ().getName () + ":" +
                        getName () + ".");
  }
  public void translate ()
  {
    System.out.println ("Began interpreting " + getClass ().getName () +
                        ":" + getName () + "....");
    StringTokenizer tokenizer = new StringTokenizer (production.toString ());
    while (tokenizer.hasMoreTokens ())
    {
      interpret (tokenizer.nextToken ());
    }
    System.out.println ("Ended interpreting " + getClass ().getName () + ":" +
                        getName () + ".");
  }
  /*
   * <li>N     = Write the current state of the turtle into the score as a note.</li>
   * <li>Mn    = Translate the turtle by adding to its state its step times its orientation times n.</li>
   * <li>Rabn  = Rotate the turtle from dimension a to dimension b by angle 2 pi / (angleCount * n)</li>
   * <li>Uan   = Vary the turtle state on dimension a by a normalized (-1 through +1) uniformly distributed random variable times n.</li>
   * <li>Gan   = Vary the turtle state on dimension a by a normalized (-1 through +1) Gaussian random variable times n.</li>
   * <li>Ta=n  = Assign to dimension a of the turtle state the value n.</li>
   * <li>Ta*n  = Multiply dimension a of the turtle state by n.</li>
   * <li>Ta/n  = Divide dimension a of the turtle state by n.</li>
   * <li>Ta+n  = Add to dimension a of the turtle state the value n.</li>
   * <li>Ta-n  = Subtract from dimension a of the turtle state the value n.</li>
   * <li>Sa=n  = Assign to dimension a of the turtle step the value n.</li>
   * <li>Sa*n  = Multiply dimension a of the turtle step by n.</li>
   * <li>Sa/n  = Divide dimension a of the turtle step by n.</li>
   * <li>Sa+n  = Add to dimension a of the turtle step the value n.</li>
   * <li>Sa-n  = Subtract from dimension a of the turtle step the value n.</li>
   * <li>[     = Push the current state of the turtle state onto a stack.</li>
   * <li>]     = Pop the current state of the turtle from the stack.</li>
   */
  public void interpret (String action)
  {
    try
    {
      //System.err.println ("action = " + action);
      action = action.trim ();
      char command = action.charAt(0);
      switch(command)
      {
      case 'N':
        {
          score.add(turtle.clone());
        }
        break;
      case 'M':
        {
          double a = 1.0;
          if(action.length () > 1)
          {
            a = Double.parseDouble(action.substring(1));
          }
          double step;
          for (int i = 1; i < Event.HOMOGENEITY; i++)
          {
            step = turtle[i] + (turtleStep[i] * a * turtleOrientation[i]);
            turtle[i] = step;
          }
        }
        break;
      case 'R':
        {
          int d1 = getDimension(action.charAt(1));
          int d2 = getDimension(action.charAt(2));
          double n = 1.0;
          if(action.length() > 3)
          {
            n = Double.parseDouble(action.substring(3));
          }
          double a = angle * n;
          double[][] rotation = createRotation (d1, d2, a);
          turtleOrientation = Matrix.times (rotation,
                                            turtleOrientation);
        }
        break;
      case 'T':
        {
          int dimension = getDimension(action.charAt(1));
          char operation = action.charAt(2);
          double n = 1.0;
          if(action.length() > 3)
          {
            n = Double.parseDouble(action.substring(3));
          }
          switch(operation)
          {
          case '=':
            turtle[dimension] =  (turtleStep[dimension] * n);
            break;
          case '*':
            turtle[dimension] *= (turtleStep[dimension] * n);
            break;
          case '/':
            turtle[dimension] /= (turtleStep[dimension] * n);
            break;
          case '+':
            turtle[dimension] += (turtleStep[dimension] * n);
            break;
          case '-':
            turtle[dimension] -= (turtleStep[dimension] * n);
            break;
          }
          if(dimension == Event.MASON)
          {
             turtle[dimension] = Maths.generalModulus(turtle[dimension], MasonNumbers.modulus);
          }
        }
        break;
      case 'S':
        {
          int dimension = getDimension(action.charAt(1));
          char operation = action.charAt(2);
          double n = 1.0;
          if(action.length() > 3)
          {
            n = Double.parseDouble(action.substring(3));
          }
          switch(operation)
          {
          case '=':
            turtleStep[dimension] = n;
            break;
          case '*':
            turtleStep[dimension] *= n;
            break;
          case '/':
            turtleStep[dimension] /= n;
            break;
          case '+':
            turtleStep[dimension] += n;
            break;
          case '-':
            turtleStep[dimension] -= n;
            break;
          }
          if(dimension == Event.MASON)
          {
            turtleStep[dimension] = Maths.generalModulus(turtleStep[dimension], MasonNumbers.modulus);
          }
        }
        break;
      case '[':
        {
          turtleStack.add(turtle.clone ());
          turtleStepStack.add(turtleStep.clone ());
          turtleOrientationStack.add(turtleOrientation.clone ());
        }
        break;
      case ']':
        {
          int lastIndex = turtleStack.size() - 1;
          turtle = (double[]) turtleStack.remove(lastIndex);
          turtleStep = (double[]) turtleStepStack.remove(lastIndex);
          turtleOrientation = (double[]) turtleOrientationStack.remove(lastIndex);
        }
        break;
      }
    }
    catch(Exception x)
    {
      x.printStackTrace();
    }
  }
  public int getDimension (char dimension)
  {
    switch(dimension)
    {
    case 'i': return 1;
    case 't': return 2;
    case 'd': return 3;
    case 'k': return 4;
    case 'v': return 5;
    case 'p': return 6;
    case 'x': return 7;
    case 'y': return 8;
    case 'z': return 9;
    case 'm': return 10;
    }
    return -1;
  }
  double[][] createRotation (int dimension1, int dimension2, double angle)
  {
    double[][] rotation = Matrix.identity (Event.ELEMENT_COUNT);
    rotation[dimension1][dimension1] =  Math.cos(angle);
    rotation[dimension1][dimension2] = -Math.sin(angle);
    rotation[dimension2][dimension1] =  Math.sin(angle);
    rotation[dimension2][dimension2] =  Math.cos(angle);
    return rotation;
  }
  public Container getView ()
  {
    LindenmayerView lindenmayerView = new LindenmayerView (this);
    return lindenmayerView;
  }
}
