package Silence.Score.Nodes;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import Silence.Mathematics.*;
import java.awt.*;
import java.applet.*;
import java.io.*;
import java.util.*;
/**
Moves all child nodes and all notes produced by them by the specified amount
on each dimension. Corresponds to the rightmost column of the Transform node.
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class TransformTranslate extends Transform implements NodeInterface,
  java.io.Serializable
{
  public TransformTranslate ()
  {
  }
  public NodeInterface copy()
  {
    TransformTranslate copy = new TransformTranslate();
    copyFieldsInto(copy);
    return copy;
  }
  public void copyFieldsInto(NodeInterface copy_)
  {
    TransformTranslate copy = (TransformTranslate) copy_;
    super.copyFieldsInto(copy);
  }
  public void defaultsTransformTranslate ()
  {
    defaultsTransform ();
  }
  public TransformTranslate (int rowCount, int columnCount)
  {
    setSize (rowCount, columnCount);
  }
  public void openView ()
  {
    TransformTranslateView view = new TransformTranslateView (this);
      view.setVisible (true);
  }
  public Container getView ()
  {
    return new TransformTranslateView (this);
  }
}
