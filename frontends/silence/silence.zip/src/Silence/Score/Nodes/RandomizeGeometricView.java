package Silence.Score.Nodes;
import Silence.MatrixEditor;
import Silence.Orchestra.Event;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import java.awt.*;
import javax.swing.*;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
/**
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class RandomizeGeometricView extends javax.swing.JInternalFrame
{
  RandomizeGeometric randomizeGeometric = null;
  MatrixEditor matrixEditor = null;
  public RandomizeGeometricView (RandomizeGeometric t)
  {
    this ();
    randomizeGeometric = t;
    matrixEditor = new MatrixEditor ();
    String[] rowLabels = Event.labels;
    String[] columnLabels =
    {
      "Dim", "Status", "Instr", "Time", "Duration", "Octave", "Decibels",
	"Phase", "X", "Y", "Z", "Mason", "Move"};
      matrixEditor.create (t.M, columnLabels, rowLabels);
      matrixEditor.setFont (new Font ("Dialog", Font.PLAIN, 12));
      transformPanel.setLayout (new BorderLayout ());
      transformPanel.add ("Center", matrixEditor);
      updateView ();
      setTitle ("RandomizeGeometric");
  }

  void updateView ()
  {
    nameField.setText (randomizeGeometric.getName ());
    PField.setText (String.valueOf (randomizeGeometric.P));
    notesToGenerateField.
      setText (String.valueOf (randomizeGeometric.notesToGenerateCount));
    incrementTimeCheckbox.setSelected (randomizeGeometric.
				       getIncrementTime ());
  }
  void updateModel ()
  {
    randomizeGeometric.setName (nameField.getText ());
    randomizeGeometric.P = Double.parseDouble (PField.getText ());
    randomizeGeometric.notesToGenerateCount =
      Integer.parseInt (notesToGenerateField.getText ());
    randomizeGeometric.setIncrementTime (incrementTimeCheckbox.isSelected ());
  }
  public RandomizeGeometricView ()
  {
    super ("RandomizeGeometric");
    setTitle ("RandomizeGeometric");
    getContentPane ().setLayout (null);
    setVisible (false);
    setSize (640, 480);
    setBackground (new Color (8421504));
    namePanel = new javax.swing.JPanel ();
    namePanel.setLayout (null);
    namePanel.setBounds (12, 12, 672, 72);
    namePanel.setFont (new Font ("Dialog", Font.BOLD, 12));
    namePanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (namePanel);
    nameField = new javax.swing.JTextField ();
    nameField.setBounds (12, 34, 648, 26);
    nameField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    namePanel.add (nameField);
    nameLabel = new javax.swing.JLabel ();
    nameLabel.setText ("Name");
    nameLabel.setHorizontalAlignment (0);
    nameLabel.setHorizontalTextPosition (0);
    nameLabel.setBounds (12, 0, 648, 24);
    nameLabel.setFont (new Font ("Dialog", Font.BOLD, 12));
    namePanel.add (nameLabel);
    transformPanel = new javax.swing.JPanel ();
    transformPanel.setBounds (12, 96, 672, 300);
    transformPanel.setFont (new Font ("Dialog", Font.BOLD, 12));
    transformPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (transformPanel);
    parametersPanel = new javax.swing.JPanel ();
    parametersPanel.setLayout (null);
    parametersPanel.setBounds (12, 408, 672, 71);
    parametersPanel.setFont (new Font ("Dialog", Font.BOLD, 12));
    parametersPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (parametersPanel);
    parametersLabel = new javax.swing.JLabel ();
    parametersLabel.setText ("Parameters");
    parametersLabel.setHorizontalAlignment (0);
    parametersLabel.setHorizontalTextPosition (0);
    parametersLabel.setBounds (3, 0, 667, 35);
    parametersLabel.setFont (new Font ("Dialog", Font.BOLD, 12));
    parametersPanel.add (parametersLabel);
    PField = new javax.swing.JTextField ();
    PField.setBounds (48, 35, 76, 24);
    PField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (PField);
    PLabel = new javax.swing.JLabel ();
    PLabel.setText ("P");
    PLabel.setBounds (12, 35, 32, 24);
    PLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (PLabel);
    notesToGenerateField = new javax.swing.JTextField ();
    notesToGenerateField.setBounds (252, 35, 76, 24);
    notesToGenerateField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (notesToGenerateField);
    notesToGenerateLabel = new javax.swing.JLabel ();
    notesToGenerateLabel.setText ("Notes to generate");
    notesToGenerateLabel.setBounds (144, 35, 120, 24);
    notesToGenerateLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (notesToGenerateLabel);
    incrementTimeCheckbox = new javax.swing.JCheckBox ();
    incrementTimeCheckbox.setText ("Increment time");
    incrementTimeCheckbox.setActionCommand ("Increment time");
    incrementTimeCheckbox.setText ("Increment time");
    incrementTimeCheckbox.setBounds (348, 35, 229, 24);
    incrementTimeCheckbox.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (incrementTimeCheckbox);
    buttonPanel = new javax.swing.JPanel ();
    buttonPanel.setLayout (null);
    buttonPanel.setBounds (12, 492, 672, 48);
    buttonPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (buttonPanel);
    okButton = new javax.swing.JButton ();
    okButton.setText ("Update");
    okButton.setBounds (12, 12, 104, 24);
    buttonPanel.add (okButton);
    SymAction lSymAction = new SymAction ();
      okButton.addActionListener (lSymAction);
  }
  javax.swing.JPanel namePanel;
  javax.swing.JTextField nameField;
  javax.swing.JLabel nameLabel;
  javax.swing.JPanel transformPanel;
  javax.swing.JPanel parametersPanel;
  javax.swing.JLabel parametersLabel;
  javax.swing.JTextField PField;
  javax.swing.JLabel PLabel;
  javax.swing.JTextField notesToGenerateField;
  javax.swing.JLabel notesToGenerateLabel;
  javax.swing.JCheckBox incrementTimeCheckbox;
  javax.swing.JPanel buttonPanel;
  javax.swing.JButton okButton;
  class SymAction implements java.awt.event.ActionListener
  {
    public void actionPerformed (java.awt.event.ActionEvent event)
    {
      Object object = event.getSource ();
      if (object == okButton)
	  okButton_Action (event);
    }
  }
  void okButton_Action (java.awt.event.ActionEvent event)
  {
    updateModel ();
    updateView ();
  }
}
