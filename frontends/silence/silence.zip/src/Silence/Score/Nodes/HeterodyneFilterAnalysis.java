package Silence.Score.Nodes;
import Silence.Conversions;
import Silence.Mathematics.Matrix;
import Silence.Orchestra.Event;
import Silence.Score.MasonNumbers;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import java.awt.*;
import java.io.*;
import java.util.*;
/**
Translates a soundfile, using Csound's hetro opcode, into
a series of Note nodes representing a filterbank time/frequency analysis.
There is one Note per breakpoint of each analysis envelope.
The frequency and amplitude breakpoints are combined.
<P>
The node can be transformed like any other producer of INotes.
The time, pitch, loudness, and harmonic content of sounds
can be reshaped independently or in combination.
<p>
The Notes are designed to be synthesized
by a Csound instrument that simulates the
adsyn opcode. This is done by assigning each envelope
to a different fractional instrument, which "holds"
the notes and interpolates between the frequencies
and amplitudes of successive breakpoints.
<p>
With a dense analysis (one breakpoint per 50 Hz and 0.01 seconds),
resynthesis is quite accurate with harmonic sounds, and not too terrible
even with noisy sounds.
<p>
Overlapping tones must be assigned to different instrument numbers.
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class HeterodyneFilterAnalysis extends Transform implements
  NodeInterface, java.io.Serializable
{
  public HeterodyneFilterAnalysis ()
  {
    defaults ();
  }
  boolean debug = false;
  public static final int amplitudeTrackStart = -1;
  public static final int frequencyTrackStart = -2;
  public static final int trackEnd = 32767;
  String soundFilename;
  int channel;
  double startSeconds;
  double durationSeconds;
  double fundamentalHz;
  int partialCount;
  int maximumTotalAmplitude;
  int amplitudeThreshold;
  int initialBreakpointCount;
  double lowpassHz;
  int instrumentIndex;
  boolean useExistingAnalysis;
  public NodeInterface copy()
  {
    HeterodyneFilterAnalysis copy = new HeterodyneFilterAnalysis();
    copyFieldsInto(copy);
    return copy;
  }
  public void copyFieldsInto(NodeInterface copy_)
  {
    HeterodyneFilterAnalysis copy = (HeterodyneFilterAnalysis) copy_;
    super.copyFieldsInto(copy);
    copy.soundFilename = soundFilename;
    copy.channel = channel;
    copy.startSeconds = startSeconds;
    copy.durationSeconds = durationSeconds;
    copy.fundamentalHz = fundamentalHz;
    copy.partialCount = partialCount;
    copy.maximumTotalAmplitude = maximumTotalAmplitude;
    copy.amplitudeThreshold = amplitudeThreshold;
    copy.initialBreakpointCount = initialBreakpointCount;
    copy.lowpassHz = lowpassHz;
    copy.instrumentIndex = instrumentIndex;
    copy.useExistingAnalysis = useExistingAnalysis;
  }
  public void defaults ()
  {
    soundFilename = "";
    channel = 1;
    startSeconds = 0;
    durationSeconds = 0;
    fundamentalHz = 100;
    partialCount = 10;
    maximumTotalAmplitude = 32767;
    amplitudeThreshold = 64;
    initialBreakpointCount = 256;
    lowpassHz = 0;
    instrumentIndex = 1;
    useExistingAnalysis = false;
  }
  public String getCommandLine ()
  {
    String commandLine = "winsound -Uhetro";
      commandLine += " -c " + channel;
      commandLine += " -b " + startSeconds;
      commandLine += " -d " + durationSeconds;
      commandLine += " -f " + fundamentalHz;
      commandLine += " -h " + partialCount;
      commandLine += " -M " + maximumTotalAmplitude;
      commandLine += " -m " + amplitudeThreshold;
      commandLine += " -n " + initialBreakpointCount;
      commandLine += " -l " + lowpassHz;
      commandLine += " " + soundFilename;
      commandLine += " " + soundFilename + "ads";
      return commandLine;
  }
  public double[][]
    produceOrTransformNotes (double[][]compositeTransformation, Score score,
			     int beginIndex, int endIndex)
  {
    if (useExistingAnalysis == false)
      {
	System.out.println ("Began analyzing soundfile...");
	try
	{
	  String commandLine = getCommandLine ();
	  Runtime runtime = Runtime.getRuntime ();
	  Process process = runtime.exec (commandLine);
	    System.out.println ("Executed Csound command: " + commandLine);
	    try
	  {
	    process.waitFor ();
	  }
	  catch (InterruptedException e)
	  {
	    e.printStackTrace ();
	  }
	}
	catch (Exception e)
	{
	  e.printStackTrace ();
	}
	System.out.println ("Ended analyzing soundfile.");
      }
    //  Assumes that each amplitude envelope is always followed by its corresponding frequency envelope.
    System.out.println ("Began translating breakpoints to Notes...");
    try
    {
      int initialNoteCount = score.size ();
      File file = new File (soundFilename + "ads");
      RandomAccessFile randomAccessFile = new RandomAccessFile (file, "r");
      short buffer;
      double instrument = 0;
      double time = 0;
      double duration;
      double octave;
      double decibels;
      double phase;
      double x;
      double y;
      double z;
      int trackIndex = 0;
      int breakpoints;
      ArrayList envelope = new ArrayList ();
      try
      {
	for (;;)
	  {
	    buffer = Conversions.swapShort (randomAccessFile.readShort ());
	    if (buffer == amplitudeTrackStart)
	      {
		trackIndex = trackIndex + 1;
		instrument =
		  ((double) instrumentIndex) + ((double) trackIndex) / 1000.0;
		for (breakpoints = 0;; breakpoints++)
		  {
		    buffer =
		      Conversions.swapShort (randomAccessFile.readShort ());
		    if (buffer == trackEnd)
		      {
			if (debug)
			  {
			    System.out.println ();
			  }
			System.out.println ("Amplitude track " + trackIndex +
					    ", " + breakpoints +
					    " breakpoints.");
			break;
		      }
		    else
		      {
			time = buffer;
			duration = 0.0;
			//  Mark as amplitude breakpoint.
			octave = -1.0;
			decibels =
			  (double) Conversions.
			  swapShort (randomAccessFile.readShort ());
			if (debug)
			  {
			    System.out.print ("[" + time + " " + decibels +
					      "]");
			  }
			phase = 0.0;
			x = 0.0;
			y = 0.0;
			z = 0.0;
			double[] note =
			  Event.createNote (instrument, time, duration,
					    octave, decibels, phase, x,
					    y, z,
					    MasonNumbers.modulus);
			envelope.add (note);
		      }
		  }
	      }
	    if (buffer == frequencyTrackStart)
	      {
		for (breakpoints = 0;; breakpoints++)
		  {
		    buffer =
		      Conversions.swapShort (randomAccessFile.readShort ());
		    if (buffer == trackEnd)
		      {
			if (debug)
			  {
			    System.out.println ();
			  }
			System.out.println ("Frequency track " + trackIndex +
					    ", " + breakpoints +
					    " breakpoints.");
			consolidateBreakpoints (envelope, score);
			break;
		      }
		    else
		      {
			time = buffer;
			duration = 0.0;
			octave =
			  (double) Conversions.
			  swapShort (randomAccessFile.readShort ());
			if (debug)
			  {
			    System.out.print ("[" + time + " " + octave +
					      "]");
			  }
			//  Mark as frequency breakpoint.
			decibels = -1.0;
			phase = 0.0;
			x = 0.0;
			y = 0.0;
			z = 0.0;
			Note note =
			  new Note (instrument, time, duration, octave,
				    decibels, phase, x, y, z,
				    MasonNumbers.modulus);
			envelope.add (note);
		      }
		  }
	      }
	  }
      }
      catch (EOFException e)
      {
	randomAccessFile.close ();
      }
      double[] note = null;
      for (int i = initialNoteCount, n = score.size (); i < n; i++)
	{
	  note = score.getEvent (i);
	  Matrix.times (note, compositeTransformation,
			(double[]) note.clone ());
	}
      System.out.println ("HeterodyneFilterAnalysis produced " +
			  (score.size () - initialNoteCount) + " notes.");
    }
    catch (Exception e)
    {
      e.printStackTrace ();
    }
    System.out.println ("Ended translating breakpoints to Notes.");
    return compositeTransformation;
  }
  void consolidateBreakpoints (ArrayList envelope, Score score)
  {
    if (envelope.size () == 0)
      {
	return;
      }
    int i = 0;
    int j = 0;
    int k = 0;
    int n = 0;
    double[] previousNote = null;
    double[] note = null;
    double time;
    double[] nextNote = null;
    double nextTime;
    double x;
    double xRange;
    double xPart;
    double xFraction;
    double yFloor;
    double yRange;
    double y;
    //  Interpolate.
    Collections.sort (envelope, Event.eventComparator);
    if (debug)
      {
	System.out.println ("Raw envelope:");
      }
    for (i = 1, n = envelope.size (); i < n; i++)
      {
	note = (double[]) envelope.get (i);
	if (debug)
	  {
	    System.out.println (Event.getCsoundString (note));
	  }
	if (Event.getOctave (note) == -1.0)
	  {
	    for (j = i; j >= 0; j--)
	      {
		previousNote = (double[]) envelope.get (j);
		if (Event.getOctave (previousNote) != -1.0)
		  {
		    break;
		  }
	      }
	    for (k = i; k < n; k++)
	      {
		nextNote = (double[]) envelope.get (k);
		if (Event.getOctave (nextNote) != -1.0)
		  {
		    break;
		  }
	      }
	    xRange = Event.getTime (nextNote) - Event.getTime (previousNote);
	    if (xRange == 0.0)
	      {
		xRange = 1.0;
	      }
	    xPart = Event.getTime (note) - Event.getTime (previousNote);
	    xFraction = xPart / xRange;
	    yRange = Event.getOctave (note) - Event.getOctave (previousNote);
	    y = Event.getOctave (previousNote) + (xFraction * yRange);
	    Event.setOctave (note, y);
	  }
	else if (Event.getDecibels (note) == -1.0)
	  {
	    for (j = i; j >= 0; j--)
	      {
		previousNote = (double[]) envelope.get (j);
		if (Event.getDecibels (previousNote) != -1.0)
		  {
		    break;
		  }
	      }
	    for (k = i; k < n; k++)
	      {
		nextNote = (double[]) envelope.get (k);
		if (Event.getDecibels (nextNote) != -1.0)
		  {
		    break;
		  }
	      }
	    xRange = Event.getTime (nextNote) - Event.getTime (previousNote);
	    if (xRange == 0.0)
	      {
		xRange = 1.0;
	      }
	    xPart = Event.getTime (note) - Event.getTime (previousNote);
	    xFraction = xPart / xRange;
	    yRange =
	      Event.getDecibels (nextNote) - Event.getDecibels (previousNote);
	    y = Event.getDecibels (previousNote) + (xFraction * yRange);
	    Event.setDecibels (note, y);
	  }
      }
    //  Consolidate.
    Collections.sort (envelope, Event.eventComparator);
    for (i = envelope.size () - 2; i >= 0; i--)
      {
	note = (double[]) envelope.get (i);
	nextNote = (double[]) envelope.get (i + 1);
	if (Event.getTime (note) == Event.getTime (nextNote))
	  {
	    if (Event.getOctave (note) == -1.0)
	      {
		Event.setOctave (note, Event.getOctave (nextNote));
	      }
	    if (Event.getDecibels (note) == -1.0)
	      {
		Event.setDecibels (note, Event.getDecibels (nextNote));
	      }
	    envelope.remove (i + 1);
	  }
      }
    Collections.sort (envelope, Event.eventComparator);
    for (i = 0, n = envelope.size (); i < n; i++)
      {
	if (i < n - 1)
	  {
	    note = (double[]) envelope.get (i);
	    nextNote = (double[]) envelope.get (i + 1);
	    x = Event.getTime (nextNote) - Event.getTime (note);
	    Event.setDuration (note, x);
	  }
      }
    if (debug)
      {
	System.out.println ("Consolidated envelope:");
      }
    for (i = 0, n = envelope.size (); i < n; i++)
      {
	note = (double[]) envelope.get (i);
	Event.setTime (note, Event.getTime (note) * 0.001);
	Event.setDuration (note, Event.getDuration (note) * 0.001);
	y = Event.getOctave (note);
	if (y > 0.0)
	  {
	    Event.setOctave (note,
			     Conversions.hzToOctave (Event.getOctave (note)));
	  }
	else
	  {
	    Event.setOctave (note, 0);
	  }
	Event.setDecibels (note,
			   Conversions.amplitudeToDecibels (Event.getDecibels
							    (note)));
	if (n == 1 && Event.getDecibels (note) > 0.0)
	  {
	    if (debug)
	      {
		System.out.println (Event.getCsoundString (note));
	      }
	    score.addEvent (note);
	  }
	else if (n > 1)
	  {
	    if (debug)
	      {
		System.out.println (Event.getCsoundString (note));
	      }
	    score.addEvent (note);
	  }
      }
    envelope.clear ();
  }
  public void openView ()
  {
    HeterodyneFilterAnalysisView view =
      new HeterodyneFilterAnalysisView (this);
      view.setVisible (true);
  }
  public Container getView ()
  {
    return new HeterodyneFilterAnalysisView (this);
  }
}
