package Silence.Score.Nodes;
import Silence.Global;
import Silence.Orchestra.Event;
import Silence.Score.Score;
import Silence.Score.ScoreView;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
/**
 * @author Copyright (C) 2000 by Michael Gogins. All rights reserved.
 * <ADDRESS>
 * gogins@pipeline.com
 * </ADDRESS>
 */
public class LindenmayerView extends JPanel
{
  public static void main (String[]args)
  {
    JFrame frame = new JFrame ();
    LindenmayerView simpleLindenmayerView = new LindenmayerView ();
    frame.getContentPane ().add (simpleLindenmayerView);
    frame.setBounds (50, 50, 800, 600);
    frame.setVisible (true);
  }
  Lindenmayer lindenmayer = null;
  Score score = null;
  ScoreView scoreView = null;
  BorderLayout borderLayout1 = new BorderLayout ();
  JTabbedPane tabs = new JTabbedPane ();
  JPanel parametersPanel = new JPanel ();
  BorderLayout borderLayout2 = new BorderLayout ();
  JToolBar toolBar = new JToolBar ();
  JButton newButton = new JButton ();
  JButton updateButton = new JButton ();
  JButton generateButton = new JButton ();
  JButton exitButton = new JButton ();
  JPanel innerPrametersPanel = new JPanel ();
  JPanel namePanel = new JPanel ();
  BorderLayout borderLayout3 = new BorderLayout ();
  JLabel nameLabel = new JLabel ();
  JTextField nameTextField = new JTextField ();
  JPanel iterationsPanel = new JPanel ();
  JTextField iterationsTextField = new JTextField ();
  JLabel iterationsLabel = new JLabel ();
  BorderLayout borderLayout4 = new BorderLayout ();
  JLabel axiomLabel = new JLabel ();
  BorderLayout borderLayout5 = new BorderLayout ();
  JPanel axiomPanel = new JPanel ();
  BorderLayout borderLayout6 = new BorderLayout ();
  JPanel rulePanel = new JPanel ();
  JLabel ruleLabel = new JLabel ();
  JScrollPane axiomScrollPane = new JScrollPane ();
  JTextArea axiomTextArea = new JTextArea ();
  JToolBar rulesToolBar = new JToolBar ();
  JButton ruleNewButton = new JButton ();
  JButton ruleRemoveButton = new JButton ();
  JButton ruleFirstButton = new JButton ();
  JButton ruleNextButton = new JButton ();
  JButton rulePreviousButton = new JButton ();
  JButton ruleLastButton = new JButton ();
  JSplitPane ruleSplitPane = new JSplitPane ();
  JScrollPane replaceScrollPane = new JScrollPane ();
  JScrollPane replaceWithScrollPane = new JScrollPane ();
  JTextArea replaceTextArea = new JTextArea ();
  JTextArea replaceWithTextArea = new JTextArea ();
  public LindenmayerView ()
  {
    this (new Lindenmayer ());
  }
  public LindenmayerView (Lindenmayer lindenmayer)
  {
    System.out.println ("BEGAN LindemayerView()...");
    try
    {
      this.lindenmayer = lindenmayer;
      jbInit ();
      score = lindenmayer.getLocalScore ();
      score.autoRescale = true;
      scoreView = (ScoreView) score.getView ();
      tabs.add (scoreView, "Score");
      updateView ();
    }
    catch (Exception ex)
    {
      ex.printStackTrace ();
    }
    System.out.println ("ENDED LindemayerView().");
  }
  private void jbInit () throws Exception
  {
    this.setLayout (borderLayout1);
    parametersPanel.setLayout (borderLayout2);
    newButton.setText (" New ");
    newButton.addActionListener (new
                                 LindenmayerView_newButton_actionAdapter
                                 (this));
    updateButton.setText (" Update ");
    updateButton.addActionListener (new
                                    LindenmayerView_updateButton_actionAdapter
                                    (this));
    generateButton.setText (" Generate ");
    generateButton.addActionListener (new
                                      LindenmayerView_generateButton_actionAdapter
                                      (this));
    exitButton.setText (" Exit ");
    exitButton.addActionListener (new
                                  LindenmayerView_exitButton_actionAdapter
                                  (this));
    toolBar.setFloatable (false);
    innerPrametersPanel.setLayout (null);
    namePanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    //namePanel.setMaximumSize(new Dimension(800, 600));
    namePanel.setBounds (new Rectangle (8, 6, 370, 45));
    namePanel.setLayout (borderLayout3);
    nameLabel.setHorizontalAlignment (SwingConstants.CENTER);
    nameLabel.setText ("Name");
    iterationsPanel.setLayout (borderLayout4);
    iterationsPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    iterationsPanel.setBounds (new Rectangle (386, 6, 139, 45));
    iterationsLabel.setHorizontalAlignment (SwingConstants.CENTER);
    iterationsLabel.setText ("Iterations");
    axiomLabel.setText ("Axiom");
    axiomLabel.setHorizontalAlignment (SwingConstants.CENTER);
    axiomPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    axiomPanel.setBounds (new Rectangle (8, 56, 516, 70));
    axiomPanel.setLayout (borderLayout5);
    rulePanel.setLayout (borderLayout6);
    rulePanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    rulePanel.setBounds (new Rectangle (122, 50, 281, 47));
    ruleLabel.setText ("Replace");
    ruleLabel.setHorizontalAlignment (SwingConstants.CENTER);
    rulePanel.setBounds (new Rectangle (8, 133, 515, 199));
    rulesToolBar.setFloatable (false);
    ruleNewButton.setText (" New ");
    ruleNewButton.addActionListener (new
                                     LindenmayerView_ruleNewButton_actionAdapter
                                     (this));
    ruleRemoveButton.setText (" Remove ");
    ruleRemoveButton.addActionListener (new
                                        LindenmayerView_ruleRemoveButton_actionAdapter
                                        (this));
    ruleFirstButton.setText (" First ");
    ruleFirstButton.addActionListener (new
                                       LindenmayerView_ruleFirstButton_actionAdapter
                                       (this));
    ruleNextButton.setText (" Next ");
    ruleNextButton.addActionListener (new
                                      LindenmayerView_ruleNextButton_actionAdapter
                                      (this));
    rulePreviousButton.setText ("Previous");
    rulePreviousButton.addActionListener (new
                                          LindenmayerView_rulePreviousButton_actionAdapter
                                          (this));
    ruleLastButton.setText (" Last ");
    ruleLastButton.addActionListener (new
                                      LindenmayerView_ruleLastButton_actionAdapter
                                      (this));
    //innerPrametersPanel.setMaximumSize(new Dimension(800, 600));
    innerPrametersPanel.setPreferredSize (new Dimension (500, 500));
    ruleSplitPane.setOrientation (JSplitPane.VERTICAL_SPLIT);
    this.setPreferredSize (new Dimension (20, 20));
    //parametersPanel.setMaximumSize(new Dimension(800, 600));
    //parametersPanel.setPreferredSize(new Dimension(32767, 32767));
    //tabs.setMaximumSize(new Dimension(1078, 768));
    tabs.setPreferredSize (new Dimension (800, 600));
    helpTextArea.setWrapStyleWord(true);
    helpTextArea.setLineWrap(true);
    helpTextArea.setText("Defines a simple context-free Lindenmayer system, or O-L string rewriting " +
                         "grammar, that produces a string of commands for generating a score.\n" +
                         "\nThe system begins as an axiom of uninterpreted symbols.\n\nA table " +
                         "of rewriting rules specifies strings of symbols that are to replace " +
                         "at least one of the symbols in the axiom.\n\nThe system also divides " +
                         "the circle into N equally sized angles.\n\nThe system is iterated a " +
                         "specified number of times, producing a possibly lengthy string of " +
                         "symbols. The symbols are then interpreted as a set of commands for " +
                         "controlling a ?turtle? that writes a Silence score.\n\nThe turtle is " +
                         "simply a Silence Note node, representing a position in the score, " +
                         "or note space, together with a vector of step sizes, a vector representing " +
                         "the orientation of the turtle, and a Mason number representing a " +
                         "pitch-class set.\n\nThe dimensions of note space are represented by " +
                         "letters:\n\ni     = instrument, starting with 1.\nt     = time, in seconds.\n" +
                         "d     = duration, in seconds.\nk     = pitch, in MIDI keys where middle " +
                         "C = 60.0.\nv     = loudness, in MIDI velocity where 0 = silence.\np " +
                         "    = phase, in radians.\nx     = distance along x dimension.\ny   " +
                         "  = distance along y dimension.\nz     = distance along z dimension.\n" +
                         "m     = Mason number from 0 to 4095.\n\nThe turtle commands also are " +
                         "represented by letters (all n default to 1):\n\nN     = Write the current " +
                         "state of the turtle into the score as a note.\nMn    = Translate the " +
                         "turtle by adding to its state its step times its orientation times " +
                         "n.\nRabn  = Rotate the turtle from dimension a to dimension b by angle " +
                         "2 pi / (angleCount * n)\nUan   = Vary the turtle state on dimension " +
                         "a by a normalized (-1 through +1) uniformly distributed random variable " +
                         "times n.\nGan   = Vary the turtle state on dimension a by a normalized " +
                         "(-1 through +1) Gaussian random variable times n.\nT=an  = Assign " +
                         "to dimension a of the turtle state the value n.\nT*an  = Multiply " +
                         "dimension a of the turtle state by n.\nT/an  = Divide dimension a " +
                         "of the turtle state by n.\nT+an  = Add to dimension a of the turtle " +
                         "state the value n.\nT-an  = Subtract from dimension a of the turtle " +
                         "state the value n.\nS=an  = Assign to dimension a of the turtle step " +
                         "the value n.\nS*an  = Multiply dimension a of the turtle step by n.\n" +
                         "S/an  = Divide dimension a of the turtle step by n.\nS+an  = Add to " +
                         "dimension a of the turtle step the value n.\nS-an  = Subtract from " +
                         "dimension a of the turtle step the value n.\n[     = Push the current " +
                         "state of the turtle state onto a stack.\n]     = Pop the current state " +
                         "of the turtle from the stack.\n\n");
    helpTextArea.setAutoscrolls(false);
    helpTextArea.setFont(new java.awt.Font("Monospaced", 0, 12));
    helpScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
    this.add (tabs, BorderLayout.NORTH);
    tabs.add (parametersPanel, " Parameters ");
    parametersPanel.add (toolBar, BorderLayout.NORTH);
    toolBar.add (newButton, null);
    toolBar.add (generateButton, null);
    toolBar.add (updateButton, null);
    toolBar.add (exitButton, null);
    parametersPanel.add (innerPrametersPanel, BorderLayout.CENTER);
    innerPrametersPanel.add (namePanel, null);
    namePanel.add (nameLabel, BorderLayout.NORTH);
    namePanel.add (nameTextField, BorderLayout.CENTER);
    innerPrametersPanel.add (axiomPanel, null);
    axiomPanel.add (axiomLabel, BorderLayout.NORTH);
    axiomPanel.add (axiomScrollPane, BorderLayout.CENTER);
    innerPrametersPanel.add (iterationsPanel, null);
    iterationsPanel.add (iterationsTextField, BorderLayout.CENTER);
    iterationsPanel.add (iterationsLabel, BorderLayout.NORTH);
    innerPrametersPanel.add (rulePanel, null);
    rulePanel.add (ruleLabel, BorderLayout.NORTH);
    rulePanel.add (rulesToolBar, BorderLayout.SOUTH);
    rulesToolBar.add (ruleNewButton, null);
    rulesToolBar.add (ruleRemoveButton, null);
    rulesToolBar.add (ruleFirstButton, null);
    rulesToolBar.add (ruleNextButton, null);
    rulesToolBar.add (rulePreviousButton, null);
    rulesToolBar.add (ruleLastButton, null);
    rulePanel.add (ruleSplitPane, BorderLayout.CENTER);
    ruleSplitPane.add (replaceScrollPane, JSplitPane.TOP);
    replaceScrollPane.getViewport ().add (replaceTextArea, null);
    ruleSplitPane.add (replaceWithScrollPane, JSplitPane.BOTTOM);
    tabs.add(helpScrollPane, " Help ");
    helpScrollPane.getViewport().add(helpTextArea, null);
    replaceWithScrollPane.getViewport ().add (replaceWithTextArea, null);
    axiomScrollPane.getViewport ().add (axiomTextArea, null);
    ruleSplitPane.setDividerLocation (40);
  }
  int ruleIndex = 0;
  JScrollPane helpScrollPane = new JScrollPane();
  JTextArea helpTextArea = new JTextArea();
  void updateView ()
  {
    nameTextField.setText (lindenmayer.getName ());
    axiomTextArea.setText (lindenmayer.axiom);
    iterationsTextField.setText (String.valueOf (lindenmayer.iterationCount));
    if (ruleIndex >= lindenmayer.rules.size ())
    {
      ruleIndex = lindenmayer.rules.size () - 1;
    }
    if (ruleIndex < 0)
    {
      ruleIndex = 0;
    }
    String symbol = (String) lindenmayer.getSymbol (ruleIndex);
    String replacement = null;
    if (symbol != null)
    {
      replacement = (String) lindenmayer.rules.get (symbol);
      replaceTextArea.setText (symbol);
      replaceWithTextArea.setText (replacement);
    }
    scoreView.updateView ();
  }
  void updateModel ()
  {
    if (nameTextField.getText () != null)
    {
      lindenmayer.setName (nameTextField.getText ());
    }
    lindenmayer.axiom = axiomTextArea.getText ();
    String symbol = replaceTextArea.getText ().trim ();
    String replacement = replaceWithTextArea.getText ();
    lindenmayer.rules.put (symbol, replacement);
    lindenmayer.iterationCount =
      (int) Math.round(Double.parseDouble (iterationsTextField.getText ()));
  }
  void newButton_actionPerformed (ActionEvent e)
  {
    lindenmayer.defaultsLindenmayer ();
    updateView ();
  }
  void generateButton_actionPerformed (ActionEvent e)
  {
    lindenmayer.generate ();
    updateView ();
    tabs.setSelectedComponent(scoreView);
  }
  void updateButton_actionPerformed (ActionEvent e)
  {
    updateModel ();
  }
  void exitButton_actionPerformed (ActionEvent e)
  {
    System.exit (0);
  }
  void ruleNewButton_actionPerformed (ActionEvent e)
  {
    replaceTextArea.setText ("");
    replaceWithTextArea.setText ("");
  }
  void ruleRemoveButton_actionPerformed (ActionEvent e)
  {
    lindenmayer.rules.remove (replaceTextArea.getText ());
    updateView ();
  }
  void ruleFirstButton_actionPerformed (ActionEvent e)
  {
    ruleIndex = 0;
    updateView ();
  }
  void ruleNextButton_actionPerformed (ActionEvent e)
  {
    ruleIndex = ruleIndex + 1;
    updateView ();
  }
  void rulePreviousButton_actionPerformed (ActionEvent e)
  {
    ruleIndex = ruleIndex - 1;
    updateView ();
  }
  void ruleLastButton_actionPerformed (ActionEvent e)
  {
    ruleIndex = lindenmayer.rules.size () - 1;
    updateView ();
  }
}
class LindenmayerView_newButton_actionAdapter implements java.awt.
  event.ActionListener
  {
  LindenmayerView adaptee;

  LindenmayerView_newButton_actionAdapter (LindenmayerView adaptee)
  {
    this.adaptee = adaptee;
  }
  public void actionPerformed (ActionEvent e)
  {
    adaptee.newButton_actionPerformed (e);
  }
}
class LindenmayerView_generateButton_actionAdapter implements java.awt.
  event.ActionListener
  {
  LindenmayerView adaptee;

  LindenmayerView_generateButton_actionAdapter (LindenmayerView adaptee)
  {
    this.adaptee = adaptee;
  }
  public void actionPerformed (ActionEvent e)
  {
    adaptee.generateButton_actionPerformed (e);
  }
}
class LindenmayerView_updateButton_actionAdapter implements java.awt.
  event.ActionListener
  {
  LindenmayerView adaptee;

  LindenmayerView_updateButton_actionAdapter (LindenmayerView adaptee)
  {
    this.adaptee = adaptee;
  }
  public void actionPerformed (ActionEvent e)
  {
    adaptee.updateButton_actionPerformed (e);
  }
}
class LindenmayerView_exitButton_actionAdapter implements java.awt.
  event.ActionListener
  {
  LindenmayerView adaptee;

  LindenmayerView_exitButton_actionAdapter (LindenmayerView adaptee)
  {
    this.adaptee = adaptee;
  }
  public void actionPerformed (ActionEvent e)
  {
    adaptee.exitButton_actionPerformed (e);
  }
}
class LindenmayerView_ruleNewButton_actionAdapter implements java.awt.
  event.ActionListener
  {
  LindenmayerView adaptee;

  LindenmayerView_ruleNewButton_actionAdapter (LindenmayerView adaptee)
  {
    this.adaptee = adaptee;
  }
  public void actionPerformed (ActionEvent e)
  {
    adaptee.ruleNewButton_actionPerformed (e);
  }
}
class LindenmayerView_ruleRemoveButton_actionAdapter implements java.
  awt.event.ActionListener
  {
  LindenmayerView adaptee;

  LindenmayerView_ruleRemoveButton_actionAdapter (LindenmayerView adaptee)
  {
    this.adaptee = adaptee;
  }
  public void actionPerformed (ActionEvent e)
  {
    adaptee.ruleRemoveButton_actionPerformed (e);
  }
}
class LindenmayerView_ruleFirstButton_actionAdapter implements java.awt.
  event.ActionListener
  {
  LindenmayerView adaptee;

  LindenmayerView_ruleFirstButton_actionAdapter (LindenmayerView adaptee)
  {
    this.adaptee = adaptee;
  }
  public void actionPerformed (ActionEvent e)
  {
    adaptee.ruleFirstButton_actionPerformed (e);
  }
}
class LindenmayerView_ruleNextButton_actionAdapter implements java.awt.
  event.ActionListener
  {
  LindenmayerView adaptee;

  LindenmayerView_ruleNextButton_actionAdapter (LindenmayerView adaptee)
  {
    this.adaptee = adaptee;
  }
  public void actionPerformed (ActionEvent e)
  {
    adaptee.ruleNextButton_actionPerformed (e);
  }
}
class LindenmayerView_rulePreviousButton_actionAdapter implements java.
  awt.event.ActionListener
  {
  LindenmayerView adaptee;

  LindenmayerView_rulePreviousButton_actionAdapter (LindenmayerView adaptee)
  {
    this.adaptee = adaptee;
  }
  public void actionPerformed (ActionEvent e)
  {
    adaptee.rulePreviousButton_actionPerformed (e);
  }
}
class LindenmayerView_ruleLastButton_actionAdapter implements java.awt.
  event.ActionListener
  {
  LindenmayerView adaptee;

  LindenmayerView_ruleLastButton_actionAdapter (LindenmayerView adaptee)
  {
    this.adaptee = adaptee;
  }
  public void actionPerformed (ActionEvent e)
  {
    adaptee.ruleLastButton_actionPerformed (e);
  }
}
