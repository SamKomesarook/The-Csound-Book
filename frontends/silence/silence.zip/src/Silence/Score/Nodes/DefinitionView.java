package Silence.Score.Nodes;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import java.awt.*;
import javax.swing.*;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
/**
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class DefinitionView extends javax.swing.JInternalFrame
{
  Definition definition = null;

  public DefinitionView (Definition d)
  {
    this ("Definition");
    definition = d;
    updateView ();
    //{{INIT_MENUS
    //}}
  }

  void updateView ()
  {
    nameField.setText (definition.getName ());
  }
  public void updateModel ()
  {
    definition.setName (nameField.getText ());
    updateView ();
  }
  public DefinitionView ()
  {
    setTitle ("Definition");
    getContentPane ().setLayout (null);
    setVisible (false);
    setSize (443, 155);
    setBackground (new Color (8421504));
    namePanel = new javax.swing.JPanel ();
    namePanel.setLayout (null);
    namePanel.setBounds (12, 12, 420, 72);
    namePanel.setFont (new Font ("Dialog", Font.BOLD, 12));
    namePanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (namePanel);
    nameField = new javax.swing.JTextField ();
    nameField.setBounds (12, 36, 396, 24);
    nameField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    namePanel.add (nameField);
    nameLabel = new javax.swing.JLabel ();
    nameLabel.setText ("Name");
    nameLabel.setHorizontalAlignment (0);
    nameLabel.setHorizontalTextPosition (0);
    nameLabel.setBounds (12, 0, 392, 26);
    nameLabel.setFont (new Font ("Dialog", Font.BOLD, 12));
    namePanel.add (nameLabel);
    buttonPanel = new javax.swing.JPanel ();
    buttonPanel.setLayout (null);
    buttonPanel.setBounds (12, 96, 420, 48);
    buttonPanel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    buttonPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (buttonPanel);
    updateButton = new javax.swing.JButton ();
    updateButton.setText ("Update");
    updateButton.setActionCommand ("button");
    updateButton.setBounds (12, 12, 84, 24);
    updateButton.setFont (new Font ("Dialog", Font.PLAIN, 12));
    buttonPanel.add (updateButton);
    SymAction lSymAction = new SymAction ();
      updateButton.addActionListener (lSymAction);
  }
  public DefinitionView (String title)
  {
    this ();
    setTitle (title);
  }
  javax.swing.JPanel namePanel;
    javax.swing.JTextField nameField;
    javax.swing.JLabel nameLabel;
    javax.swing.JPanel buttonPanel;
    javax.swing.JButton updateButton;
  class SymAction implements java.awt.event.ActionListener
  {
    public void actionPerformed (java.awt.event.ActionEvent event)
    {
      Object object = event.getSource ();
      if (object == updateButton)
	  updateButton_Action (event);
    }
  }
  void updateButton_Action (java.awt.event.ActionEvent event)
  {
    updateModel ();
  }
}
