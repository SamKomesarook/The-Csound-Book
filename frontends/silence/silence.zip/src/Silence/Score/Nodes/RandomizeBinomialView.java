package Silence.Score.Nodes;
import Silence.Global;
import Silence.MatrixEditor;
import Silence.Orchestra.Event;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import java.awt.*;
import javax.swing.*;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
/**
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class RandomizeBinomialView extends javax.swing.JInternalFrame
{
  RandomizeBinomial randomizeBinomial = null;
  MatrixEditor matrixEditor = null;
  public RandomizeBinomialView (RandomizeBinomial t)
  {
    this ();
    randomizeBinomial = t;
    matrixEditor = new MatrixEditor ();
    String[] rowLabels = Event.labels;
    String[] columnLabels =
    {
      "Dim", "Status", "Instr", "Time", "Duration", "Octave", "Decibels",
	"Phase", "X", "Y", "Z", "Mason", "Move"};
      matrixEditor.create (randomizeBinomial.M, columnLabels, rowLabels);
      transformPanel.setLayout (new BorderLayout ());
      transformPanel.add ("Center", matrixEditor);
      updateView ();
      setTitle ("RandomizeBinomial");
  }
  void updateView ()
  {
    nameField.setText (randomizeBinomial.getName ());
    PField.setText (String.valueOf (randomizeBinomial.P));
    NField.setText (String.valueOf (randomizeBinomial.N));
    notesToGenerateField.
      setText (String.valueOf (randomizeBinomial.notesToGenerateCount));
    incrementTimeCheckbox.setSelected (randomizeBinomial.getIncrementTime ());
  }
  void updateModel ()
  {
    randomizeBinomial.setName (nameField.getText ());
    randomizeBinomial.P = Double.parseDouble (PField.getText ());
    randomizeBinomial.N = Integer.parseInt (NField.getText ());
    randomizeBinomial.notesToGenerateCount =
      Integer.parseInt (notesToGenerateField.getText ());
    randomizeBinomial.setIncrementTime (incrementTimeCheckbox.isSelected ());
  }
  public RandomizeBinomialView ()
  {
    super ("RandomizeBinomial");
    setTitle ("RandomizeBinomial");
    getContentPane ().setLayout (null);
    setVisible (false);
    setSize (640, 480);
    namePanel = new javax.swing.JPanel ();
    namePanel.setLayout (null);
    namePanel.setBounds (12, 12, 672, 72);
    namePanel.setFont (new Font ("Dialog", Font.BOLD, 12));
    namePanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (namePanel);
    nameField = new javax.swing.JTextField ();
    nameField.setBounds (12, 34, 648, 26);
    nameField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    namePanel.add (nameField);
    jLabel1 = new javax.swing.JLabel ();
    jLabel1.setText ("Name");
    jLabel1.setHorizontalAlignment (0);
    jLabel1.setHorizontalTextPosition (0);
    jLabel1.setBounds (12, 0, 648, 24);
    jLabel1.setFont (new Font ("Dialog", Font.BOLD, 12));
    namePanel.add (jLabel1);
    transformPanel = new javax.swing.JPanel ();
    GridBagLayout gridBagLayout;
      gridBagLayout = new GridBagLayout ();
      transformPanel.setLayout (gridBagLayout);
      transformPanel.setBounds (12, 96, 672, 300);
      transformPanel.setFont (new Font ("Dialog", Font.BOLD, 12));
      transformPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
      getContentPane ().add (transformPanel);
      parametersPanel = new javax.swing.JPanel ();
      parametersPanel.setLayout (null);
      parametersPanel.setBounds (12, 408, 672, 72);
      parametersPanel.setFont (new Font ("Dialog", Font.BOLD, 12));
      parametersPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
      getContentPane ().add (parametersPanel);
      PLabel = new javax.swing.JLabel ();
      PLabel.setText ("P");
      PLabel.setBounds (12, 36, 24, 24);
      PLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
      parametersPanel.add (PLabel);
      PField = new javax.swing.JTextField ();
      PField.setBounds (48, 36, 60, 24);
      PField.setFont (new Font ("Dialog", Font.PLAIN, 12));
      parametersPanel.add (PField);
      NLabel = new javax.swing.JLabel ();
      NLabel.setText ("N");
      NLabel.setBounds (132, 36, 24, 24);
      NLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
      parametersPanel.add (NLabel);
      NField = new javax.swing.JTextField ();
      NField.setBounds (156, 36, 60, 24);
      NField.setFont (new Font ("Dialog", Font.PLAIN, 12));
      parametersPanel.add (NField);
      notesToGenerateLabel = new javax.swing.JLabel ();
      notesToGenerateLabel.setText ("Notes to generate");
      notesToGenerateLabel.setBounds (240, 36, 108, 24);
      notesToGenerateLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
      parametersPanel.add (notesToGenerateLabel);
      notesToGenerateField = new javax.swing.JTextField ();
      notesToGenerateField.setBounds (360, 36, 60, 24);
      notesToGenerateField.setFont (new Font ("Dialog", Font.PLAIN, 12));
      parametersPanel.add (notesToGenerateField);
      incrementTimeCheckbox = new javax.swing.JCheckBox ();
      incrementTimeCheckbox.setText ("Increment time");
      incrementTimeCheckbox.setActionCommand ("Increment time");
      incrementTimeCheckbox.setBounds (444, 36, 120, 21);
      incrementTimeCheckbox.setFont (new Font ("Dialog", Font.PLAIN, 12));
      parametersPanel.add (incrementTimeCheckbox);
      parametersLabel = new javax.swing.JLabel ();
      parametersLabel.setText ("Parameters");
      parametersLabel.setHorizontalAlignment (0);
      parametersLabel.setHorizontalTextPosition (0);
      parametersLabel.setBounds (12, 0, 648, 24);
      parametersLabel.setFont (new Font ("Dialog", Font.BOLD, 12));
      parametersPanel.add (parametersLabel);
      buttonPanel = new javax.swing.JPanel ();
      buttonPanel.setLayout (null);
      buttonPanel.setBounds (12, 492, 672, 48);
      buttonPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
      getContentPane ().add (buttonPanel);
      okButton = new javax.swing.JButton ();
      okButton.setText ("Update");
      okButton.setBounds (12, 12, 104, 24);
      buttonPanel.add (okButton);
    SymAction lSymAction = new SymAction ();
      okButton.addActionListener (lSymAction);
  }
  javax.swing.JPanel namePanel;
  javax.swing.JTextField nameField;
  javax.swing.JLabel jLabel1;
  javax.swing.JPanel transformPanel;
  javax.swing.JPanel parametersPanel;
  javax.swing.JLabel PLabel;
  javax.swing.JTextField PField;
  javax.swing.JLabel NLabel;
  javax.swing.JTextField NField;
  javax.swing.JLabel notesToGenerateLabel;
  javax.swing.JTextField notesToGenerateField;
  javax.swing.JCheckBox incrementTimeCheckbox;
  javax.swing.JLabel parametersLabel;
  javax.swing.JPanel buttonPanel;
  javax.swing.JButton okButton;
  class SymAction implements java.awt.event.ActionListener
  {
    public void actionPerformed (java.awt.event.ActionEvent event)
    {
      Object object = event.getSource ();
      if (object == okButton)
	  okButton_Action (event);
    }
  }
  void okButton_Action (java.awt.event.ActionEvent event)
  {
    updateModel ();
    updateView ();
  }
}
