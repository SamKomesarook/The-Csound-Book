package Silence.Score.Nodes;
import Silence.Score.Score;
import Silence.Score.MasonNumbers;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import java.awt.*;
import javax.swing.*;
import javax.swing.table.*;
import javax.swing.JPanel;
/**
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class MasonNumberProgressionView extends javax.swing.JInternalFrame
{
  MasonNumberProgression progression = null;
  JComboBox pcsNamesComboBox = new JComboBox();
  DefaultCellEditor pcsCellEditor = null;
  public class MasonNumberProgressionTableModel extends AbstractTableModel
  {
    public int getColumnCount ()
    {
      return 3;
    }
    public int getRowCount ()
    {
      return progression.times.size ();
    }
    public void setValueAt (Object object, int row, int column)
    {
      if (column == 0)
	{
	  progression.times.set (row, Double.valueOf(object.toString()));
	}
      else if (column == 1)
	{
          Object m = (Double) MasonNumbers.pcsNames.get(object);
          if(m == null)
          {
            m = object;
          }
          progression.masonNumbers.set (row, Double.valueOf(m.toString()));
	}
      else if (column == 2)
	{
          Object m = (Double) MasonNumbers.pcsNames.get(object);
          if(m == null)
          {
            m = object;
          }
          progression.operations.set (row, Double.valueOf(m.toString()));
	}
    }
    public Object getValueAt (int row, int column)
    {
      if (row >= progression.times.size ())
	{
	  return null;
	}
      if (column == 0)
	{
	  return progression.times.get (row).toString();
	}
      else if (column == 1)
	{
	  return progression.masonNumbers.get (row).toString();
	}
      else if (column == 2)
	{
	  return progression.operations.get (row).toString();
	}
      return null;
    }
    public String getColumnName (int column)
    {
      if (column == 0)
	{
	  return "Time";
	}
      else if (column == 1)
	{
	  return "Mason number";
	}
      else if (column == 2)
	{
	  return "Operation";
	}
      return null;
    }
    public boolean isCellEditable (int row, int column)
    {
      return true;
    }
    public Class getColumnClass(int column)
    {
      return String.class;
    }
  }
  MasonNumberProgressionTableModel progressionTableModel = null;
  public MasonNumberProgressionView (MasonNumberProgression progression)
  {
    this ("MasonNumberProgression");
    this.progression = progression;
    updateView ();
  }
  void updateView ()
  {
    nameField.setText (progression.getName ());
    relativeTimesCheckbox.setSelected (progression.relativeTimes);
  }
  public void updateModel ()
  {
    progression.setName (nameField.getText ());
    progression.relativeTimes = relativeTimesCheckbox.isSelected ();
    updateView ();
  }
  public MasonNumberProgressionView ()
  {
    progressionTable = new JTable ();
    progressionTableModel = new MasonNumberProgressionTableModel ();
    progressionTable.setModel (progressionTableModel);
    pcsNamesComboBox.setModel(MasonNumbers.pcsNamesComboBoxModel);
    pcsNamesComboBox.setEditable(true);
    pcsCellEditor = new DefaultCellEditor(pcsNamesComboBox);
    TableColumnModel tableColumnModel = progressionTable.getColumnModel();
    TableColumn column1 = tableColumnModel.getColumn(1);
    column1.setCellEditor(pcsCellEditor);
    TableColumn column2 = tableColumnModel.getColumn(2);
    column2.setCellEditor(pcsCellEditor);
    getContentPane ().setLayout (null);
    setVisible (false);
    setSize (441, 383);
    setBackground (new Color (8421504));
    namePanel = new javax.swing.JPanel ();
    namePanel.setLayout (null);
    namePanel.setBounds (12, 12, 420, 72);
    namePanel.setFont (new Font ("Dialog", Font.BOLD, 12));
    namePanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (namePanel);
    nameField = new javax.swing.JTextField ();
    nameField.setBounds (12, 36, 396, 24);
    nameField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    namePanel.add (nameField);
    nameLabel = new javax.swing.JLabel ();
    nameLabel.setText ("Name");
    nameLabel.setHorizontalAlignment (0);
    nameLabel.setHorizontalTextPosition (0);
    nameLabel.setBounds (12, 0, 392, 26);
    nameLabel.setFont (new Font ("Dialog", Font.BOLD, 12));
    namePanel.add (nameLabel);
    parametersPanel = new javax.swing.JPanel ();
    parametersPanel.setLayout (null);
    parametersPanel.setBounds (12, 96, 420, 216);
    parametersPanel.setFont (new Font ("Dialog", Font.BOLD, 12));
    parametersPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (parametersPanel);
    relativeTimesCheckbox = new javax.swing.JCheckBox ();
    relativeTimesCheckbox.setText ("Use delta times");
    relativeTimesCheckbox.setActionCommand ("Use delta times");
    relativeTimesCheckbox.setBounds (12, 36, 144, 24);
    relativeTimesCheckbox.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (relativeTimesCheckbox);
    parametersLabel = new javax.swing.JLabel ();
    parametersLabel.setText ("Parameters");
    parametersLabel.setHorizontalAlignment (0);
    parametersLabel.setHorizontalTextPosition (0);
    parametersLabel.setBounds (12, 0, 392, 26);
    parametersLabel.setFont (new Font ("Dialog", Font.BOLD, 12));
    parametersPanel.add (parametersLabel);
    progressionScrollPane = new javax.swing.JScrollPane ();
    progressionScrollPane.setOpaque (true);
    progressionScrollPane.setBounds (12, 72, 396, 133);
    progressionScrollPane.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (progressionScrollPane);
    progressionScrollPane.getViewport ().add (progressionTable);
    buttonPanel = new javax.swing.JPanel ();
    buttonPanel.setLayout (null);
    buttonPanel.setBounds (12, 324, 420, 48);
    buttonPanel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    buttonPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (buttonPanel);
    updateButton = new javax.swing.JButton ();
    updateButton.setText ("Update");
    updateButton.setActionCommand ("button");
    updateButton.setBounds (12, 12, 84, 24);
    updateButton.setFont (new Font ("Dialog", Font.PLAIN, 12));
    buttonPanel.add (updateButton);
    insertButton = new javax.swing.JButton ();
    insertButton.setText ("Insert");
    insertButton.setActionCommand ("Insert");
    insertButton.setBounds (216, 12, 84, 24);
    insertButton.setFont (new Font ("Dialog", Font.PLAIN, 12));
    buttonPanel.add (insertButton);
    deleteButton = new javax.swing.JButton ();
    deleteButton.setText ("Delete");
    deleteButton.setActionCommand ("Delete");
    deleteButton.setBounds (324, 12, 84, 24);
    deleteButton.setFont (new Font ("Dialog", Font.PLAIN, 12));
    buttonPanel.add (deleteButton);
    SymAction lSymAction = new SymAction ();
      updateButton.addActionListener (lSymAction);
      insertButton.addActionListener (lSymAction);
      deleteButton.addActionListener (lSymAction);
  }
  public MasonNumberProgressionView (String title)
  {
    this ();
    setTitle (title);
  }
  javax.swing.JPanel namePanel;
  javax.swing.JTextField nameField;
  javax.swing.JLabel nameLabel;
  javax.swing.JPanel parametersPanel;
  javax.swing.JCheckBox relativeTimesCheckbox;
  javax.swing.JLabel parametersLabel;
  javax.swing.JScrollPane progressionScrollPane;
  javax.swing.JTable progressionTable;
  javax.swing.JPanel buttonPanel;
  javax.swing.JButton updateButton;
  javax.swing.JButton insertButton;
  javax.swing.JButton deleteButton;
  javax.swing.JCheckBox relativeTimeCheckbox;
  class SymAction implements java.awt.event.ActionListener
  {
    public void actionPerformed (java.awt.event.ActionEvent event)
    {
      Object object = event.getSource ();
      if (object == updateButton)
	  updateButton_Action (event);
      else if (object == insertButton)
	  insertButton_ActionPerformed (event);
      else if (object == deleteButton)
	  deleteButton_ActionPerformed (event);
    }
  }
  void updateButton_Action (java.awt.event.ActionEvent event)
  {
    updateModel ();
  }
  void insertButton_ActionPerformed (java.awt.event.ActionEvent event)
  {
    int[] selectedRows = progressionTable.getSelectedRows ();
    if (selectedRows.length == 0)
      {
	progression.times.add (new Double (0));
	progression.masonNumbers.add (new Double (0));
	progression.operations.add (new Double (0));
	progressionTableModel.
	  fireTableRowsInserted (progressionTableModel.getRowCount (), 0);
      }
    else
      {
	for (int i = 0; i < selectedRows.length; i++)
	  {
	    progression.times.add (selectedRows[i], new Double (0));
	    progression.masonNumbers.add (selectedRows[i], new Double (0));
	    progression.operations.add (selectedRows[i], new Double (0));
	  }
	progressionTableModel.fireTableRowsInserted (selectedRows[0],
						     selectedRows
						     [selectedRows.length -
						      1]);
      }
  }
  void deleteButton_ActionPerformed (java.awt.event.ActionEvent event)
  {
    int[] selectedRows = progressionTable.getSelectedRows ();
    if (selectedRows.length == 0)
      {
	return;
      }
    for (int i = 0, j = selectedRows.length - 1; i < selectedRows.length;
	 i++, j--)
      {
	progression.times.remove (selectedRows[j]);
	progression.masonNumbers.remove (selectedRows[j]);
	progression.operations.remove (selectedRows[j]);
      }
    //progressionTableModel.fireTableStructureChanged();
    progressionTableModel.fireTableRowsDeleted (selectedRows[0],
						selectedRows
						[selectedRows.length - 1]);
  }
}
