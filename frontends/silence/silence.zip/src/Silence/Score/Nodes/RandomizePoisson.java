package Silence.Score.Nodes;
import cern.jet.random.Poisson;
import cern.jet.random.engine.RandomEngine;
import Silence.Global;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import Silence.Orchestra.Event;
import Silence.Mathematics.*;
import java.awt.*;
import java.io.*;
import java.util.*;
/**
Like RandomizeUniform, except that the random variable has a Poisson distribution.
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class RandomizePoisson extends RandomizeUniform implements
  NodeInterface, java.io.Serializable
{
  public transient Poisson poisson = null;
  public double mean = 1.0;
  public RandomizePoisson ()
  {
    poisson = new Poisson (mean, Global.randomEngine);
  }
  public NodeInterface copy()
  {
    RandomizePoisson copy = new RandomizePoisson();
    copyFieldsInto(copy);
    return copy;
  }
  public void copyFieldsInto(NodeInterface copy_)
  {
    RandomizePoisson copy = (RandomizePoisson) copy_;
    super.copyFieldsInto(copy);
    copy.mean = mean;
  }
  public void defaults ()
  {
    mean = 1.0;
  }
  public double getSample ()
  {
    return poisson.nextInt (mean);
  }
  public void openView ()
  {
    RandomizePoissonView view = new RandomizePoissonView (this);
      view.setVisible (true);
  }
  public Container getView ()
  {
    return new RandomizePoissonView (this);
  }
}
