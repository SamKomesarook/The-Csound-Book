package Silence.Score.Nodes;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import java.awt.*;
import javax.swing.*;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
/**
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class HocketView extends javax.swing.JInternalFrame
{
  Silence.Score.Nodes.Hocket hocket = null;
  public HocketView (Hocket value)
  {
    this ("Hocket");
    hocket = value;
    updateView ();
  }
  void updateView ()
  {
    nameField.setText (hocket.getName ());
    hocketCountField.setText (String.valueOf (hocket.hocketCount));
    hocketIndexField.setText (String.valueOf (hocket.hocketIndex));
  }
  public void updateModel ()
  {
    hocket.setName (nameField.getText ());
    hocket.hocketCount =
      Integer.parseInt (hocketCountField.getText ());
    hocket.hocketIndex =
      Integer.parseInt (hocketIndexField.getText ());
    updateView ();
  }
  public HocketView ()
  {
    setTitle ("Hocket");
    getContentPane ().setLayout (null);
    setVisible (false);
    setSize (444, 314);
    setBackground (new Color (8421504));
    namePanel = new javax.swing.JPanel ();
    namePanel.setLayout (null);
    namePanel.setBounds (12, 12, 420, 72);
    namePanel.setFont (new Font ("Dialog", Font.BOLD, 12));
    namePanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (namePanel);
    nameField = new javax.swing.JTextField ();
    nameField.setBounds (12, 36, 396, 24);
    nameField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    namePanel.add (nameField);
    nameLabel = new javax.swing.JLabel ();
    nameLabel.setText ("Name");
    nameLabel.setHorizontalAlignment (0);
    nameLabel.setHorizontalTextPosition (0);
    nameLabel.setBounds (12, 0, 392, 26);
    nameLabel.setFont (new Font ("Dialog", Font.BOLD, 12));
    namePanel.add (nameLabel);
    parametersPanel = new javax.swing.JPanel ();
    parametersPanel.setLayout (null);
    parametersPanel.setBounds (12, 96, 420, 144);
    parametersPanel.setFont (new Font ("Dialog", Font.BOLD, 12));
    parametersPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (parametersPanel);
    hocketCountField = new javax.swing.JTextField ();
    hocketCountField.setBounds (192, 36, 216, 24);
    hocketCountField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (hocketCountField);
    hocketCountLabel = new javax.swing.JLabel ();
    hocketCountLabel.setText ("Hocket count");
    hocketCountLabel.setBounds (12, 36, 120, 24);
    hocketCountLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (hocketCountLabel);
    hocketIndexField = new javax.swing.JTextField ();
    hocketIndexField.setBounds (192, 72, 216, 24);
    hocketIndexField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (hocketIndexField);
    hocketIndexLabel = new javax.swing.JLabel ();
    hocketIndexLabel.setText ("Start at note");
    hocketIndexLabel.setBounds (12, 72, 168, 24);
    hocketIndexLabel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    parametersPanel.add (hocketIndexLabel);
    parametersLabel = new javax.swing.JLabel ();
    parametersLabel.setText ("Parameters");
    parametersLabel.setHorizontalAlignment (0);
    parametersLabel.setHorizontalTextPosition (0);
    parametersLabel.setBounds (12, 0, 392, 26);
    parametersLabel.setFont (new Font ("Dialog", Font.BOLD, 12));
    parametersPanel.add (parametersLabel);
    buttonPanel = new javax.swing.JPanel ();
    buttonPanel.setLayout (null);
    buttonPanel.setBounds (12, 252, 420, 48);
    buttonPanel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    buttonPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (buttonPanel);
    updateButton = new javax.swing.JButton ();
    updateButton.setText ("Update");
    updateButton.setActionCommand ("button");
    updateButton.setBounds (12, 12, 84, 24);
    updateButton.setFont (new Font ("Dialog", Font.PLAIN, 12));
    buttonPanel.add (updateButton);
    SymAction lSymAction = new SymAction ();
      updateButton.addActionListener (lSymAction);
  }
  public HocketView (String title)
  {
    this ();
    setTitle (title);
  }
  javax.swing.JPanel namePanel;
    javax.swing.JTextField nameField;
    javax.swing.JLabel nameLabel;
    javax.swing.JPanel parametersPanel;
    javax.swing.JTextField hocketCountField;
    javax.swing.JLabel hocketCountLabel;
    javax.swing.JTextField hocketIndexField;
    javax.swing.JLabel hocketIndexLabel;
    javax.swing.JLabel parametersLabel;
    javax.swing.JPanel buttonPanel;
    javax.swing.JButton updateButton;
  class SymAction implements java.awt.event.ActionListener
  {
    public void actionPerformed (java.awt.event.ActionEvent event)
    {
      Object object = event.getSource ();
      if (object == updateButton)
	  updateButton_Action (event);
    }
  }
  void updateButton_Action (java.awt.event.ActionEvent event)
  {
    updateModel ();
  }
}
