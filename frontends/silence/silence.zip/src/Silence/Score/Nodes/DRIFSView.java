package Silence.Score.Nodes;
import Silence.MatrixEditor;
import Silence.Orchestra.Event;
import Silence.Score.ScoreView;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
/**
 * Title:        Silence
 * Description:  A user-extensible system for making music by means of software alone.
 * Copyright:    Copyright (c) 2002
 * Company:      Irreducible Productions
 * @author
 * @version 1.0
 */

public class DRIFSView extends JPanel
{
  DRIFS drifs = null;
  ScoreView scoreView = null;
  JToolBar toolbar = new JToolBar();
  JButton newButton = new JButton();
  BorderLayout borderLayout1 = new BorderLayout();
  JTabbedPane tabs = new JTabbedPane();
  JTabbedPane hutchinsonTabs = new JTabbedPane();
  JScrollPane markovScrollPane = new JScrollPane();
  JTable markovTable = new JTable();
  JButton addTransformButton = new JButton();
  JButton removeTransformButton = new JButton();
  JButton generateButton = new JButton();
  JLabel iterationCountLabel = new JLabel();
  JTextField iterationCountTextField = new JTextField();
  static final String[] rowLabels =
    {
    "Status", "Instr", "Time", "Duration", "Key", "Decibels", "Phase",
      "X", "Y", "Z", "Mason", "Unity"
  };
  static final String[] columnLabels =
    {
    "Dim", "Status", "Instr", "Time", "Duration", "Key", "Decibels",
      "Phase", "X", "Y", "Z", "Mason", "Move"
  };
  public DRIFSView()
  {
    this(new DRIFS());
  }
  public DRIFSView(DRIFS drifs)
  {
    this.drifs = drifs;
    try
    {
      jbInit();
      scoreView = (ScoreView) drifs.getLocalScore().getView();
      tabs.add(scoreView, " Score ");
      markovTable.setModel(drifs.markovTableModel);
      for(int i = 0, n = drifs.hutchinsonOperator.size(); i < n; i++)
      {
        hutchinsonTabs.addTab(String.valueOf(i),
                              MatrixEditor.createEditor((double[][]) drifs.hutchinsonOperator.get(i), columnLabels, rowLabels));
      }
      updateView();
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception
  {
    newButton.setText(" New ");
    newButton.addActionListener(new java.awt.event.ActionListener()
                                {
        public void actionPerformed(ActionEvent e)
        {
          newButton_actionPerformed(e);
        }
      }
    );
    this.setLayout(borderLayout1);
    addTransformButton.setText(" Add transform ");
    addTransformButton.addActionListener(new java.awt.event.ActionListener()
                                         {
        public void actionPerformed(ActionEvent e)
        {
          addTransformButton_actionPerformed(e);
        }
      }
    );
    removeTransformButton.setText(" Remove transform ");
    removeTransformButton.addActionListener(new java.awt.event.ActionListener()
                                            {
        public void actionPerformed(ActionEvent e)
        {
          removeTransformButton_actionPerformed(e);
        }
      }
    );
    generateButton.setText(" Generate ");
    generateButton.addActionListener(new java.awt.event.ActionListener()
                                     {
        public void actionPerformed(ActionEvent e)
        {
          generateButton_actionPerformed(e);
        }
      }
    );
    iterationCountLabel.setText("   Iterations ");
    iterationCountTextField.setText("4");
    toolbar.setFloatable(false);
    this.add(toolbar, BorderLayout.NORTH);
    this.add(tabs, BorderLayout.CENTER);
    tabs.add(hutchinsonTabs, " Hutchinson operator ");
    tabs.add(markovScrollPane, " Markov operator ");
    markovScrollPane.getViewport().add(markovTable, null);
    toolbar.add(newButton, null);
    toolbar.add(addTransformButton, null);
    toolbar.add(removeTransformButton, null);
    toolbar.add(generateButton, null);
    toolbar.add(iterationCountLabel, null);
    toolbar.add(iterationCountTextField, null);
  }

  void newButton_actionPerformed(ActionEvent e)
  {
    drifs.defaultsDrifs();
    hutchinsonTabs.removeAll();
    for(int i = 0, n = drifs.hutchinsonOperator.size(); i < n; i++)
    {
      hutchinsonTabs.add(MatrixEditor.createEditor((double[][]) drifs.hutchinsonOperator.get(i), columnLabels, rowLabels)," Transform " + String.valueOf(i));
    }
    updateView();
  }

  void addTransformButton_actionPerformed(ActionEvent e)
  {
    int index = hutchinsonTabs.getTabCount();
    hutchinsonTabs.addTab(String.valueOf(index),
                          MatrixEditor.createEditor(drifs.addHutchinsonOperatorMatrix(), columnLabels, rowLabels));
    drifs.markovTableModel.fireTableStructureChanged();
  }

  void removeTransformButton_actionPerformed(ActionEvent e)
  {
    int index = hutchinsonTabs.getSelectedIndex();
    drifs.removeHutchinsonOperatorMatrix(index);
    hutchinsonTabs.remove(index);
    drifs.markovTableModel.fireTableStructureChanged();
  }

  void generateButton_actionPerformed(ActionEvent e)
  {
    updateModel();
    drifs.generate();
    tabs.setSelectedComponent(scoreView);
    updateView();
  }
  void updateModel()
  {
    drifs.iterationCount = Integer.valueOf(iterationCountTextField.getText()).intValue();
  }
  void updateView()
  {
    this.iterationCountTextField.setText(String.valueOf(drifs.iterationCount));
    scoreView.updateView();
  }
}
