package Silence.Score.Nodes;
import cern.jet.random.Uniform;
import java.awt.Container;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.TreeMap;
import javax.swing.JFrame;
import javax.swing.table.AbstractTableModel;
import Silence.Global;
import Silence.Mathematics.Matrix;
import Silence.MatrixTableModel;
import Silence.Orchestra.Event;
import Silence.Score.NodeInterface;
import Silence.Score.Score;
/**
 * Title:        Silence
 * Description:  A user-extensible system for making music by means of software alone.
 * Copyright:    Copyright (c) 2002
 * Company:      Irreducible Productions
 * Implements a recurrent iterated function system (DRIFS) in music space,
 * using the deterministic algorithm. Transition probabilities are interpreted as a factor by which
 * to multiply loudness. Notes that land within an error bound are assumed to have the same address,
 * and are replaced by their cumulative arithmetic mean except for loudness, which is summed.
 * This class is designed to support an evolver.
 * @author
 * @version 1.0
 */

public class DRIFS extends ScoreNode implements NodeInterface, Serializable
{
  String filename = Global.generateDateFilename(IFS2D_EXTENSION);
  ArrayList hutchinsonOperator = new ArrayList();
  double[][] markov = new double[0][];
  int noteCount = 2000;
  public static final double[] quanta = Event.createNote(1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 4095.0);
  public static final String IFS2D_EXTENSION = "drifs";
  transient double[][][] hutchinson = null;
  transient int iterationCount = 0;
  transient TreeMap attractor = new TreeMap();
  public DRIFS()
  {
    defaultsDrifs();
  }
  public void defaultsDrifs()
  {
    clear();
    this.addHutchinsonOperatorMatrix();
    this.addHutchinsonOperatorMatrix();
    this.addHutchinsonOperatorMatrix();
    iterationCount = 3;
  }
  public void initializeForIteration()
  {
    int iteration = 0;
    attractor.clear();
    score.clear();
    normalizeMarkov();
    hutchinson = (double[][][]) hutchinsonOperator.toArray(new double[0][][]);
  }
  public void normalizeMarkov ()
  {
    for (int i = 0; i < markov.length; i++)
    {
      double sum = 0;
      for (int j = 0; j < markov[i].length; j++)
      {
        sum += markov[i][j];
      }
      for (int j = 0; j < markov[i].length; j++)
      {
        markov[i][j] /= sum;
      }
    }
  }
  public double[][] addHutchinsonOperatorMatrix ()
  {
    double[][] identity = Event.identity();
    hutchinsonOperator.add (identity);
    int hutchinsonOperatorMatrixCount = hutchinsonOperator.size();
    double[][] oldMarkovOperator = (double[][]) markov.clone ();
    markov = new double[hutchinsonOperatorMatrixCount][hutchinsonOperatorMatrixCount];
    for (int i = 0; i < oldMarkovOperator.length; i++)
    {
      for (int j = 0; j < oldMarkovOperator[i].length; j++)
      {
        markov[i][j] = oldMarkovOperator[i][j];
      }
    }
    return identity;
  }
  public void removeHutchinsonOperatorMatrix (int index)
  {
    hutchinsonOperator.remove (index);
    int hutchinsonOperatorMatrixCount = hutchinsonOperator.size();
    double[][] oldMarkovOperator = (double[][]) markov.clone ();
    markov = new double[hutchinsonOperatorMatrixCount][hutchinsonOperatorMatrixCount];
    for (int i = 0; i < index - 1; i++)
    {
      for (int j = 0; j < index - 1; j++)
      {
        markov[i][j] = oldMarkovOperator[i][j];
      }
    }
    for (int i = index; i < oldMarkovOperator.length; i++)
    {
      for (int j = index; j < oldMarkovOperator.length; j++)
      {
        markov[i - 1][j - 1] = oldMarkovOperator[i][j];
      }
    }
  }
  public void openView ()
  {
    DRIFSView view = new DRIFSView (this);
    view.setVisible (true);
  }
  public Container getView ()
  {
    DRIFSView view = new DRIFSView (this);
    return view;
  }
  public String getFilename()
  {
    return filename;
  }
  public void setFilename(String filename)
  {
    this.filename = filename;
  }
  public void quantize(double[] event)
  {
    for(int i = 0; i < Event.HOMOGENEITY; i++)
    {
      event[i] /= quanta[i];
      event[i] = Math.round(event[i]);
      event[i] *= quanta[i];
    }
  }
  public NodeInterface copy()
  {
    DRIFS copy = new DRIFS();
    copyFieldsInto(copy);
    return copy;
  }
  public void copyFieldsInto(NodeInterface copy_)
  {
    DRIFS copy = (DRIFS) copy_;
    super.copyFieldsInto(copy);
    copy.iterationCount = iterationCount;
    copy.markov = (double[][]) markov.clone();
    for(int i = 0, n = hutchinsonOperator.size(); i < n; i++)
    {
      double[][] transformation = (double[][]) hutchinsonOperator.get(i);
      copy.hutchinsonOperator.add(transformation.clone());
    }
  }
  public double[][] traverseMusicGraph (double[][] parentTransformation,
                                        Score score)
  {
    double[][] transformation =
      produceOrTransformNotes (parentTransformation, score,
                               score.size(), score.size());
    System.gc ();
    return transformation;
  }
  public void generate()
  {
    initializeForIteration();
    for(int i = 0; i < hutchinson.length; i++)
    {
      recurse (hutchinson[i],
               i, 1.0, 1);
    }
    for(Iterator it = attractor.values().iterator(); it.hasNext(); )
    {
      score.add(it.next());
    }
    attractor.clear();
    if(score.autoRescale)
    {
      score.setActualScaleToTarget();
    }
  }
  public void recurse (double[][] priorTransformation,
                       int priorIndex,
                       double weight,
                       int iteration)
  {
    if (iteration < iterationCount)
    {
      iteration++;
      for (int successorIndex = 0; successorIndex < hutchinson.length; successorIndex++)
      {
        weight *= markov[priorIndex][successorIndex];
        double[][] successorTransformation = hutchinson[successorIndex];
        double[][] compositeTransformation = Matrix.times (priorTransformation,
                                                           successorTransformation);
        recurse (compositeTransformation, successorIndex, weight, iteration);
      }
    }
    else
    {
      try
      {
        double[] point = (Matrix.times (priorTransformation,
                                        Event.createNote(1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 4095.0)));
        point[Event.DECIBELS] *= weight;
        if(Math.abs(Event.getDuration(point)) == 0.0)
        {
          return;
        }
        if(Math.abs(Event.getDecibels(point)) == 0.0)
        {
          return;
        }
        String key = Event.toString(point);
        //  System.err.println(key);
        //  Will (one hopes) replace an existing point at that address.
        attractor.put(key, point);
      }
      catch (Exception e)
      {
        e.printStackTrace ();
      }
    }
  }
  public double[][] produceOrTransformNotes (double[][]compositeTransform,
                                             Score score,
                                             int preTraversalCount,
                                             int postTraversalCount)
  {
    try
    {
      int n = this.score.size ();
      for (int i = 0; i < n; i++)
      {
        double[] note = this.score.getEvent (i);
        double[] transformedNote = Matrix.times (compositeTransform,
                                                 note);
        score.addEvent (transformedNote);
      }
    }
    catch (Exception e)
    {
      e.printStackTrace ();
    }
    return compositeTransform;
  }
  public class MarkovTableModel extends AbstractTableModel
  {
    public int getRowCount()
    {
      return markov.length;
    }
    public int getColumnCount()
    {
      return markov.length;
    }
    public Object getValueAt(int row, int column)
    {
      return String.valueOf(markov[row][column]);
    }
    public void setValueAt(Object value, int row, int column)
    {
      double v = Double.valueOf(value.toString()).doubleValue();
      markov[row][column] = v;
    }
    public boolean isCellEditable(int row, int column)
    {
      return true;
    }
    public String getColumnName(int column)
    {
      return String.valueOf(column + 1);
    }
  }
  public MarkovTableModel markovTableModel = new MarkovTableModel();
  public void clear()
  {
    while(hutchinsonOperator.size() > 0)
    {
      this.removeHutchinsonOperatorMatrix(0);
    }
    iterationCount = 3;
  }
}
