package Silence.Score.Nodes;
import Silence.Orchestra.Event;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import java.applet.*;
import java.awt.*;
import java.io.*;
import java.util.*;
/**
Quantizes any combination of dimensions, each by its own
modulus, which can be any real number. If the dimension
is rounded to zero, it is corrected to one unit of the modulus.
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class Quantize extends Node implements NodeInterface,
  java.io.Serializable
{
  double[] moduli = new double[Event.ELEMENT_COUNT];
    boolean[] quantize = new boolean[Event.ELEMENT_COUNT];
  public Quantize ()
  {
    defaultsQuantize ();
  }
  public NodeInterface copy()
  {
    Quantize copy = new Quantize();
    copyFieldsInto(copy);
    return copy;
  }
  public void copyFieldsInto(NodeInterface copy_)
  {
    Quantize copy = (Quantize) copy_;
    super.copyFieldsInto(copy);
    copy.moduli = (double[]) moduli.clone();
    copy.quantize = (boolean[]) quantize.clone();
  }
  public void defaultsQuantize ()
  {
    moduli = new double[Event.ELEMENT_COUNT];
      quantize = new boolean[Event.ELEMENT_COUNT];
  }
  public double[][] produceOrTransformNotes (double[][]compositeTransform,
					     Score score,
					     int preTraversalCount,
					     int postTraversalCount)
  {
    try
    {
      double[] note = null;
      double pfield = 0;
      for (int j = Event.INSTRUMENT; j < Event.HOMOGENEITY; j++)
	{
	  if (quantize[j] == true)
	    {
	      for (int i = preTraversalCount; i < postTraversalCount; i++)
		{
		  note = score.getEvent (i);
		  pfield = note[j];
		  pfield = pfield / moduli[j];
		  pfield = Math.rint (pfield);
		  pfield = pfield * moduli[j];
		  if (pfield == 0.0)
		    {
		      pfield = moduli[j];
		    }
		  note[j] = pfield;
		}
	    }
	}
    }
    catch (Exception e)
    {
      e.printStackTrace ();
    }
    return compositeTransform;
  }
  public void openView ()
  {
    QuantizeView view = new QuantizeView (this);
      view.setVisible (true);
  }
  public Container getView ()
  {
    return new QuantizeView (this);
  }
}
