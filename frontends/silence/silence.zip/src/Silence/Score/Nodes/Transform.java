package Silence.Score.Nodes;
import Silence.Mathematics.Matrix;
import Silence.Orchestra.Event;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import java.awt.Container;
/**
Generic affine transformation of a score.
@author Copyright (C) 2000 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class Transform extends Node implements NodeInterface
{
  public double[][] M = Matrix.identity (Event.ELEMENT_COUNT);
  public Transform ()
  {
  }
  public NodeInterface copy()
  {
    Transform copy = new Transform();
    copyFieldsInto(copy);
    return copy;
  }
  public void copyFieldsInto(NodeInterface copy_)
  {
    Transform copy = (Transform) copy_;
    super.copyFieldsInto(copy);
    copy.M = Matrix.copy(M);
  }
  public void defaultsTransform ()
  {
    M = Matrix.identity (Event.ELEMENT_COUNT);
  }
  public Transform (int rowCount, int columnCount)
  {
    setSize (rowCount, columnCount);
  }
  public void setSize (int rowCount, int columnCount)
  {
    M = Matrix.create (rowCount, columnCount);
  }
  public int getRowCount ()
  {
    return Matrix.getRowDimension (M);
  }
  public int getColumnCount ()
  {
    return Matrix.getColumnDimension (M);
  }
  public double[][] getLocalTransformation ()
  {
    return Matrix.copy (M);
  }
  public void setTransformation (double[][]T)
  {
    M = Matrix.copy (T);
  }
  public double[][] produceOrTransformNotes (double[][]compositeTransform,
					     Score score,
					     int preTraversalCount,
					     int postTraversalCount)
  {
    try
    {
      for (int i = preTraversalCount; i < postTraversalCount; i++)
	{
	  double[] event = score.getEvent (i);
	  double[] clone = (double[]) event.clone ();
	    Matrix.times (event, compositeTransform, clone);
	}
    }
    catch (Exception e)
    {
      e.printStackTrace ();
    }
    return compositeTransform;
  }
  public Container getView ()
  {
    return new TransformView (this);
  }
}
