package Silence.Score.Nodes;
import Silence.Score.Score;
import Silence.Score.NodeInterface;
import Silence.Score.Nodes.Node;
import java.awt.*;
import javax.swing.*;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
/**
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class NoteView extends javax.swing.JInternalFrame
{
  JFrame frame = null;
  Note note = null;
    Note.TableModel tableModel = null;
  public static void main (String[]args)
  {
    JFrame frame = new JFrame ();
    Note note = new Note ();
    NoteView noteView = new NoteView (note);
      noteView.setVisible (true);
      frame.getContentPane ().add (noteView);
      frame.setBounds (50, 50, 400, 400);
      frame.setVisible (true);
  }
  public NoteView (Note note)
  {
    this ("Note");
    this.note = note;
    tableModel = note.getTableModel ();
    noteTable.setModel (tableModel);
  }
  public NoteView ()
  {
    setTitle ("Note");
    getContentPane ().setLayout (null);
    setVisible (false);
    setSize (422, 564);
    namePanel = new javax.swing.JPanel ();
    namePanel.setLayout (null);
    namePanel.setBounds (12, 12, 396, 72);
    namePanel.setFont (new Font ("Dialog", Font.BOLD, 12));
    namePanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    getContentPane ().add (namePanel);
    nameField = new javax.swing.JTextField ();
    nameField.setBounds (12, 36, 372, 24);
    nameField.setFont (new Font ("Dialog", Font.PLAIN, 12));
    namePanel.add (nameField);
    nameLabel = new javax.swing.JLabel ();
    nameLabel.setText ("Name");
    nameLabel.setHorizontalAlignment (0);
    nameLabel.setHorizontalTextPosition (0);
    nameLabel.setBounds (12, 0, 369, 24);
    nameLabel.setFont (new Font ("Dialog", Font.BOLD, 12));
    namePanel.add (nameLabel);
    parametersPanel = new javax.swing.JPanel ();
    parametersPanel.setLayout (new BorderLayout ());
    parametersPanel.setBounds (12, 96, 396, 396);
    parametersPanel.setFont (new Font ("Dialog", Font.BOLD, 12));
    parametersPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    scrollPane = new JScrollPane ();
    parametersPanel.add (scrollPane);
    noteTable = new JTable ();
    scrollPane.getViewport ().add (noteTable);
    getContentPane ().add (parametersPanel);
    buttonPanel = new javax.swing.JPanel ();
    buttonPanel.setLayout (null);
    buttonPanel.setBounds (12, 504, 396, 48);
    buttonPanel.setFont (new Font ("Dialog", Font.PLAIN, 12));
    getContentPane ().add (buttonPanel);
    updateNote = new javax.swing.JButton ();
    updateNote.setText ("Update");
    updateNote.setActionCommand ("button");
    updateNote.setBounds (12, 12, 75, 25);
    updateNote.setFont (new Font ("Dialog", Font.PLAIN, 12));
    buttonPanel.setBorder (BorderFactory.createRaisedBevelBorder ());
    buttonPanel.add (updateNote);
    defaultsButton = new javax.swing.JButton ();
    defaultsButton.setText ("Defaults");
    defaultsButton.setActionCommand ("button");
    defaultsButton.setBounds (180, 12, 81, 25);
    defaultsButton.setFont (new Font ("Dialog", Font.PLAIN, 12));
    buttonPanel.add (defaultsButton);
    SymAction lSymAction = new SymAction ();
      defaultsButton.addActionListener (lSymAction);
      updateNote.addActionListener (lSymAction);
  }
  public NoteView (String title)
  {
    this ();
    setTitle (title);
  }
  javax.swing.JPanel namePanel;
    javax.swing.JTextField nameField;
    javax.swing.JLabel nameLabel;
    javax.swing.JPanel parametersPanel;
    javax.swing.JLabel parametersLabel;
    javax.swing.JPanel buttonPanel;
    javax.swing.JButton updateNote;
    javax.swing.JButton defaultsButton;
    javax.swing.JScrollPane scrollPane;
    javax.swing.JTable noteTable;
  class SymAction implements java.awt.event.ActionListener
  {
    public void actionPerformed (java.awt.event.ActionEvent event)
    {
      Object object = event.getSource ();
      if (object == updateNote)
	  updateNote_Action (event);
      else if (object == defaultsButton)
	  defaultsButton_Action (event);
    }
  }
  void updateNote_Action (java.awt.event.ActionEvent event)
  {
    updateModel ();
  }
  void defaultsButton_Action (java.awt.event.ActionEvent event)
  {
    note.defaultsNote ();
    updateView ();
  }
  public void updateModel ()
  {
    note.setName (nameField.getText ());
  }
  public void updateView ()
  {
    nameField.setText (note.getName ());
    tableModel.fireTableDataChanged ();
  }
}
