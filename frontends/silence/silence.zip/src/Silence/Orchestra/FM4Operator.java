package Silence.Orchestra;
/**
 * Base class for Yamaha DX-7 style frequency modulation synthesis.
 * Adapted from Perry Cook's STK.
 * @author Copyright (C) 2000 by Michael Gogins. All rights reserved.
 * <ADDRESS>
 * gogins@pipeline.com
 * </ADDRESS>
 */
public abstract class FM4Operator extends StereoInstrument
{
  protected Envelope[] envelope = null;
  protected InterpolatingPhaseOscillator[] waves = null;
  protected InterpolatingOscillator vibrato =
    new InterpolatingOscillator ();
  protected TwoZero twoZero = new TwoZero ();
  protected double baseFrequency;
  protected double[] ratios = new double[4];
  protected double[] gains = new double[4];
  protected double modDepth;
  protected double control1;
  protected double control2;
  protected double[] operatorGains = new double[100];
  protected double[] sustainLevels = new double[16];
  protected double[] attenuationTimes = new double[32];
  public FM4Operator ()
  {
  }
  public void initialize (Timebase timebase)
  {
    this.timebase = timebase;
    int i;
    double[] tempCoeffs = { 0.0, -1.0 };
      twoZero.initialize (timebase);
      twoZero.setZeroCoefficients (tempCoeffs);
      twoZero.setGain (0.0);
    FunctionTable functionTable = FunctionTable.getFunctionTable ("Sine");
    if (functionTable == null)
      {
	functionTable = new FunctionTable ();
	functionTable.setHarmonic (1, 1, 0);
	functionTable.rescale (1.0);
	FunctionTable.setFunctionTable ("Sine", functionTable);
      }
    vibrato.setFunctionTable (functionTable);
      waves = new InterpolatingPhaseOscillator[4];
      envelope = new Envelope[4];
    for (i = 0; i < waves.length; i++)
      {
	waves[i] = new InterpolatingPhaseOscillator ();
	waves[i].initialize (timebase);
	waves[i].setFunctionTable (functionTable);
	envelope[i] = new Envelope ();
	envelope[i].initialize (timebase);
	envelope[i].reset ();
      }
    vibrato.initialize (timebase);
    vibrato.setFrequency (6.0);
    modDepth = 0.0;
    //      We don't make the waves here yet,
    //      because we don't know what they will be.
    baseFrequency = 440.0;
    ratios[0] = 1.0;
    ratios[1] = 1.0;
    ratios[2] = 1.0;
    ratios[3] = 1.0;
    gains[0] = 1.0;
    gains[1] = 1.0;
    gains[2] = 1.0;
    gains[3] = 1.0;
    control1 = 1.0;
    control2 = 1.0;
    double temp = 1.0;
    for (i = 99; i >= 0; i--)
      {
	operatorGains[i] = temp;
	temp *= 0.933033;
      }
    temp = 1.0;
    for (i = 15; i >= 0; i--)
      {
	sustainLevels[i] = temp;
	temp *= 0.707101;
      }
    temp = 8.498186;
    for (i = 0; i < 32; i++)
      {
	attenuationTimes[i] = temp;
	temp *= 0.707101;
      }
  }
  public void setRatio (int index, double ratio)
  {
    ratios[index] = ratio;
    if (ratio > 0.0)
      {
	waves[index].setFrequency (baseFrequency * ratio);
      }
    else
      {
	waves[index].setFrequency (ratio);
      }
  }
}
