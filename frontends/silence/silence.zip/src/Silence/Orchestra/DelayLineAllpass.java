package Silence.Orchestra;
/**
 * @author Copyright (C) 2000 by Michael Gogins. All rights reserved.
 * <ADDRESS>
 * gogins@pipeline.com
 * </ADDRESS>
 */
public class DelayLineAllpass extends Filter
{
  public int writeIndex;
  public int readIndex;
  public double alpha;
  public double coefficient;
  public double feedbackSignal;
  public DelayLineAllpass ()
  {
    this (2048);
  }
  public DelayLineAllpass (int length)
  {
    int i;
      inputs = new double[length];
      reset ();
      writeIndex = 0;
      readIndex = inputs.length >> 1;
  }
  public void reset ()
  {
    for (int i = 0; i < inputs.length; i++)
      {
	inputs[i] = 0;
      }
    feedbackSignal = 0;
      signal = 0;
  }
  public void setDelaySeconds (double delay)
  {
    double lag = timebase.audioSampleFramesPerSecond * delay;
      setDelay (lag);
  }
  public void setDelay (double lag)
  {
    double readPosition;
    //      If delay is too big, force delay to max_length.
    if (lag > inputs.length - 1)
      {
	System.out.println ("DelayLineAllpass: Delay length too big.");
	System.out.println ("Setting to maximum length of " +
			    (inputs.length - 1) + ".");
	readPosition = writeIndex + 1.0;
      }
    else if (lag < 0.1)
      {
	System.out.println
	  ("DelayLineAllpass: Delays < 0.1 not possible with current structure.");
	System.out.println ("Setting delay length to 0.1.");
	readPosition = writeIndex + 0.8999999999;
      }
    else
      {
	// readIndex chases writeIndex
	readPosition = writeIndex - lag + 1.0;
      }
    if (readPosition < 0)
      {
	// modulo table length
	readPosition += inputs.length;
      }
    // Integer part of delay
    readIndex = (int) readPosition;
    // fractional part of delay
    alpha = 1.0 + readIndex - readPosition;
    if (alpha == 0.0)
      {
	// exact integer delay
	readIndex -= 1;
	if (readIndex < 0)
	  {
	    readIndex += inputs.length;
	  }
      }
    // Hack to avoid pole/zero cancellation.  Keeps allpass.
    if (alpha < 0.1)
      {
	readIndex += 1;
	if (readIndex >= inputs.length)
	  {
	    readIndex -= inputs.length;
	  }
	// delay in range of .1 to 1.1
	alpha += 1.0;
      }
    coefficient = (1.0 - alpha) / (1.0 + alpha);
  }
  public double tick (double inputSignal)
  {
    inputs[writeIndex++] = inputSignal;
    if (writeIndex == inputs.length)
      {
	writeIndex -= inputs.length;
      }
    double delaySignal = inputs[readIndex++];
    if (readIndex == inputs.length)
      {
	readIndex -= inputs.length;
      }
    signal = (-coefficient) * signal;
    signal += feedbackSignal + (coefficient * delaySignal);
    feedbackSignal = delaySignal;
    return signal;
  }
  public void removeDC ()
  {
    double sum = 0;
    for (int i = 0; i < inputs.length; i++)
      {
	sum += inputs[i];
      }
    double mean = sum / inputs.length;
    if (Math.abs (mean) <= Float.MIN_VALUE)
      {
	return;
      }
    for (int i = 0; i < inputs.length; i++)
      {
	inputs[i] -= mean;
      }
  }
}
