package Silence.Orchestra;
/**
 * @author Copyright (C) 2000 by Michael Gogins. All rights reserved.
 * <ADDRESS>
 * gogins@pipeline.com
 * </ADDRESS>
 */
public abstract class Filter extends InputOutputUnit
{
  public Filter ()
  {
  }
  protected double gain;
  protected double[] inputs;
  protected double[] outputs;
}
