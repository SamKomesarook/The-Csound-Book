package Silence.Orchestra;
/**
 * Abstract base class for instruments in software synthesizers.
 * Note that Instrument is auto-extensible.
 * @author Copyright (C) 2000 by Michael Gogins. All rights reserved.
 * <ADDRESS>
 * gogins@pipeline.com
 * </ADDRESS>
 */
public abstract class Instrument extends SignalFlowUnit
{
 /**
   * The local signal value, not to be confused with the output sample frame.
   */
  public double signal = 0;
    /**
     * Stores the current NOTE ON event.
     */
  public double[] noteOnEvent = null;
  public double offTime = -1.0;
  public Instrument ()
  {
  }
    /**
     * Called by the synthesizer to set the time base
     * and the input and output sample frames.
     * Note that all instruments in a pool share the same input and output frames.
     * The default implementation merely sets the timebase and input/output frames,
     * and calls the base class initialize function. Do not override this function.
     */
  public void initialize (Timebase timebase, SampleFrame input, SampleFrame output)
  {
    if(timebase == null)
    {
      throw new NullPointerException("Null timebase in SignalFlowUnit.initialize().");
    }
    this.input = input;
    this.output = output;
    initialize (timebase);
  }
    /**
     * Called by the synthesizer to indicate that synthesis should begin.
     * The instrument begins producing sound.
     * The default implementation merely saves the NOTE ON event.
     * Most instruments should extend the off time,
     * which is set by the synthesizer, to allow for an envelope tail.
     */
  public void attack (double[]noteOnEvent)
  {
    this.noteOnEvent = noteOnEvent;
  }
    /**
     * Called by the synthesizer with real-time control notifications.
     * The default implementation does nothing.
     */
  public void control (double[]controlEvent)
  {
  }
    /**
     * Called by the synthesizer to indicate that synthesis should end.
     * The instrument sets its state to RELEASED and then,
     * some finite time later, to FINISHED.
     * The default implementation does nothing.
     */
  public void release (double[]noteOffEvent)
  {
  }
  /**
   * Computes one tick and returns the resulting signal value.
   * Simplifies using SignalFlowInstruments as OutputUnits,
   * for example in other instruments.
   */
  public double tickOutput () throws SampleFrame.ShapeException
  {
    tick ();
    return signal;
  }
  /**
   * Adds the input signal to the input sample frame,
   * computes one tick, and returns the resulting signal value.
   * Simplifies using SignalFlowInstruments as OutputUnits,
   * for example in other instruments.
   */
  public double tickOutput (double inputSignal) throws SampleFrame.ShapeException
  {
    input.add (inputSignal);
    tick ();
    return signal;
  }
  public void turnOff()
  {
    offTime = timebase.currentTime;
    signal = 0;
  }
}
