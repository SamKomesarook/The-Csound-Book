package Silence.Orchestra;
import java.util.*;
/**
Data shared by signal processing units in a software synthesizer.
Each unit must contain a reference to the same Buss object.
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class Conductor
{
  public int audioSampleFramesPerControlSample = 100;
  public int audioSampleFramesPerSecond = 44100;
  public double secondsPerAudioSampleFrame;
  public double secondsPerControlSample;
	/**
  	For JavaSound and soundfile output.
  	*/
  public int bytesPerAudioSample = 2;
  public int outputChannelCount = 2;
  public int currentControlSample;
  public double currentTime;
  public Sample[] inputs = null;
  public Sample[] outputs = null;
    byte[] dataLineBuffer = null;
  public void initialize ()
  {
    initialize (audioSampleFramesPerSecond, audioSampleFramesPerControlSample,
		outputChannelCount);
  }
  public Conductor ()
  {
    initialize ();
  }
  public void initialize (int audioSampleFramesPerControlSample,
			  int audioSampleFramesPerSecond,
			  int bytesPerAudioSample, int outputChannelCount)
  {
    this.bytesPerAudioSample = bytesPerAudioSample;
    initialize (audioSampleFramesPerSecond, audioSampleFramesPerControlSample,
		outputChannelCount);
  }
  public void initialize (int audioSampleFramesPerSecond,
			  int audioSampleFramesPerControlSample,
			  int outputChannelCount)
  {
    this.audioSampleFramesPerSecond = audioSampleFramesPerSecond;
    secondsPerAudioSampleFrame = 1.0 / this.audioSampleFramesPerSecond;
    this.audioSampleFramesPerControlSample =
      audioSampleFramesPerControlSample;
    secondsPerControlSample =
      secondsPerAudioSampleFrame * this.audioSampleFramesPerControlSample;
    this.outputChannelCount = outputChannelCount;
    inputs = new Sample[outputChannelCount];
    outputs = new Sample[outputChannelCount];
    for (int i = 0; i < outputChannelCount; i++)
      {
	inputs[i] = new Sample ();
	outputs[i] = new Sample ();
      }
    start ();
  }
  public void start ()
  {
    currentTime = 0;
    currentControlSample = 0;
    for (int i = 0; i < outputChannelCount; i++)
      {
	inputs[i].reset ();
	outputs[i].reset ();
      }
  }
  public void nextControlSample ()
  {
    currentControlSample++;
    currentTime = currentControlSample * secondsPerControlSample;
  }
  public class FunctionTables extends TreeMap
  {
    FunctionTable getFunctionTable (String name)
    {
      return (FunctionTable) get (name);
    }
  }
  public FunctionTables functionTables = new FunctionTables ();
  public void resetAudioSampleFrame ()
  {
    for (int i = 0; i < outputChannelCount; i++)
      {
	inputs[i].signal = 0;
	outputs[i].signal = 0;
      }
  }
  public int getAudioSampleFrameSize ()
  {
    return bytesPerAudioSample * outputChannelCount;
  }
  public boolean areSimultaneous (double[]a, double[]b)
  {
    double deltaTime = Math.abs (Event.getTime (a) - Event.getTime (b));
    if (deltaTime <= secondsPerAudioSampleFrame)
      {
	return true;
      }
    else
      {
	return false;
      }
  }
  public boolean areOverlapping (double[]a, double[]b)
  {
    double overlap = 0;
      overlap = Event.getTime (b) - (Event.getTime (a) + Event.getDuration (a));
    if (overlap > secondsPerAudioSampleFrame)
      {
	return true;
      }
    overlap = Event.getTime (a) - (Event.getTime (b) + Event.getDuration (b));
    if (overlap > secondsPerAudioSampleFrame)
      {
	return true;
      }
    return false;
  }
}
