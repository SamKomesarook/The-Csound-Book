package Silence.Orchestra;
import Silence.Conversions;
import java.util.ArrayList;
import java.util.Iterator;
/**
General-purpose non-interpolating function lookup table
or phase-modulation digital oscillator. Can easily be used
to make accurate frequency modulation instruments.
@author Copyright (C) 1998, 2000 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class PhaseOscillator extends Oscillator implements java.
  io.Serializable
{
  public double lookupIndex = 0;
  public double phaseIndex = 0;
  public PhaseOscillator ()
  {
  }
  /**
   * Advances the sample index by the indicated sampling increment,
   * which can be positive or negative,
   * or even phase modulated (for implementing phase or FM oscillators).
   * The sample index is wrapped back (or forward)
   * after it passes the end (or beginning) of the table.
   */
  public double tick ()
  {
    lookupIndex = frequencyAccumulator + phaseIndex;
    while (lookupIndex >= functionTable.sampleCount)
      {
	lookupIndex -= functionTable.sampleCount;
      }
    while (lookupIndex < 0)
      {
	lookupIndex += functionTable.sampleCount;
      }
    frequencyAccumulator = frequencyAccumulator + frequencyIncrement;
    while (frequencyAccumulator >= functionTable.sampleCount)
      {
	frequencyAccumulator -= functionTable.sampleCount;
      }
    while (frequencyAccumulator < 0)
      {
	frequencyAccumulator += functionTable.sampleCount;
      }
    int index = (int) Math.round (lookupIndex);
    signal = functionTable.table[index];
    return signal;
  }
  public double getPhase ()
  {
    return Conversions.TWO_PI * (phaseIndex /
				 (double) functionTable.sampleCount);
  }
  public double setPhase (double phase)
  {
    phaseIndex = phase / Conversions.TWO_PI * functionTable.sampleCount;
    return phaseIndex;
  }
  public void reset ()
  {
    super.reset ();
    lookupIndex = 0;
    phaseIndex = 0;
  }
}
