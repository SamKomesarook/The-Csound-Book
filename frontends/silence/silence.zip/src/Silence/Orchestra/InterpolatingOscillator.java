package Silence.Orchestra;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.Iterator;
/**
General-purpose interpolating digital oscillator.
@author Copyright (C) 1998, 2000 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class InterpolatingOscillator extends Oscillator
{
  public InterpolatingOscillator ()
  {
  }
  /**
   * Advances the sample index by the indicated sampling increment,
   * which must be positive. The sample index is wrapped back
   * after it passes the end of the table.
   */
  public double tick ()
  {
    frequencyAccumulator += frequencyIncrement;
    while (frequencyAccumulator >= functionTable.sampleCount)
      {
	frequencyAccumulator -= functionTable.sampleCount;
      }
    int indexFloor = (int) Math.floor (frequencyAccumulator);
    int indexCeiling = (int) Math.ceil (frequencyAccumulator);
    double indexAboveFloor = frequencyAccumulator - ((double) indexFloor);
      signal =
      functionTable.table[indexFloor] + (functionTable.table[indexCeiling] -
					 functionTable.table[indexFloor]) *
      indexAboveFloor;
      return signal;
  }
}
