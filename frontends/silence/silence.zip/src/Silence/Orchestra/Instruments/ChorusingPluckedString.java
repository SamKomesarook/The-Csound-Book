package Silence.Orchestra.Instruments;
import Silence.Conversions;
import Silence.Orchestra.Orchestra;
import Silence.Orchestra.CombFilter;
import Silence.Orchestra.LinearEnvelope;
import Silence.Orchestra.InterpolatingOscillator;
import Silence.Orchestra.StereoInstrument;
import Silence.Orchestra.Timebase;
import Silence.Orchestra.Event;
/**
 * Adaptation of Thomas Kung's plucked string, chorused, pitch-shifted, delayed
 * instrument from Csound.
 * @author Copyright (C) 2000 by Michael Gogins. All rights reserved.
 * <ADDRESS>
 * gogins@pipeline.com
 * </ADDRESS>
 */
public class ChorusingPluckedString extends StereoInstrument
{
  public static void main (String[]args)
  {
    StereoInstrument.test (ChorusingPluckedString.class.getName ());
  }
  public ChorusingPluckedString ()
  {
  }
  double duration;
  public double detune = 0.5;
  public double amplitude = 0;
  public double frequency = 0;
  public double delay1 = 0.1;
  public double sustain1 = 0.52;
  public double delay2 = 0.21;
  public double sustain2 = 0.51;
  public double attack = 0.2;
  public double release = 0.05;
  double leftSignal = 0;
  double rightSignal = 0;
  public LinearEnvelope damping = new LinearEnvelope ();
  public PluckedString pluck = new PluckedString ();
  public PluckedString pluck1 = new PluckedString ();
  public PluckedString pluck2 = new PluckedString ();
  public CombFilter delayLine1 = new CombFilter ();
  public CombFilter delayLine2 = new CombFilter ();
  public void initialize (Timebase timebase)
  {
    super.initialize (timebase);
    damping.initialize (timebase);
    pluck.initialize (timebase);
    pluck1.initialize (timebase);
    pluck2.initialize (timebase);
    delayLine1.initialize (timebase);
    delayLine2.initialize (timebase);
  }
  public void attack (double[]noteOnEvent)
  {
    super.attack (noteOnEvent);
    duration = Event.getDuration (noteOnEvent);
    frequency = Event.getFrequency (noteOnEvent);
    amplitude = Event.getGain (noteOnEvent);
    damping.setThreeSegments (attack, 1.0, Event.getDuration (noteOnEvent),
			      1.0, release);
    pluck.setLowestFrequency (frequency * 0.9);
    pluck.attack (duration, leftGain, rightGain, frequency, amplitude);
    pluck1.setLowestFrequency (frequency * 0.9);
    pluck1.attack (duration, leftGain, rightGain, frequency + detune,
		   amplitude);
    pluck2.setLowestFrequency (frequency * 0.9);
    pluck2.attack (duration, leftGain, rightGain, frequency - detune,
		   amplitude);
    delayLine1.setDelayPrime (delay1);
    delayLine1.setSustain (sustain1);
    delayLine1.reset ();
    delayLine2.setDelayPrime (delay2);
    delayLine2.setSustain (sustain2);
    delayLine2.reset ();
  }
  public void release (double[]noteOnEvent)
  {
    damping.release ();
    pluck.release (noteOnEvent);
    pluck1.release (noteOnEvent);
    pluck2.release (noteOnEvent);
  }
  public void tick ()
  {
    if (damping.finished)
      {
        turnOff();
        return;
      }
    double dampingSignal = damping.tick ();
    pluck.tick();
    signal = pluck.signal;
    pluck1.tick();
    leftSignal = pluck1.signal;
    pluck2.tick();
    rightSignal = pluck2.signal;
    double leftSignalDelayed = delayLine1.tick (signal * dampingSignal);
    double rightSignalDelayed = delayLine2.tick (signal * dampingSignal);
      leftSignal = (rightSignal + leftSignalDelayed);
      rightSignal = (leftSignal + rightSignalDelayed);
      signal = (leftSignal + rightSignal) * 0.1;
  }
}
