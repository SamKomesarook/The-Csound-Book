package Silence.Orchestra.Instruments;
import Silence.Conversions;
import Silence.Orchestra.Envelope;
import Silence.Orchestra.Event;
import Silence.Orchestra.StereoInstrument;
import Silence.Orchestra.DelayLineAllpass;
import Silence.Orchestra.OnePole;
import Silence.Orchestra.OneZero;
import Silence.Orchestra.Noise;
import Silence.Orchestra.Orchestra;
import Silence.Orchestra.Timebase;
/**
 * Java version of Plucked from Perry Cook's STK.
 * @author Copyright (C) 2000 by Michael Gogins. All rights reserved.
 * <ADDRESS>
 * gogins@pipeline.com
 * </ADDRESS>
 */
public class PluckedString extends StereoInstrument
{
  public static void main (String[]args)
  {
    StereoInstrument.test (PluckedString.class.getName ());
  }
  DelayLineAllpass delayLine = null;
  OneZero loopFilter = new OneZero ();
  OnePole pickFilter = new OnePole ();
  Noise noise = new Noise ();
  int length;
  double loopGain = .9995;
  double amplitude = 0;
  public Envelope envelope = new Envelope ();
  public PluckedString ()
  {
  }
  public void initialize (Timebase timebase)
  {
    this.timebase = timebase;
    envelope.initialize (timebase);
    envelope.setThreeSegments (0.001, -3, 1.0, 2.5, -3, 0.25, 0.05, -3);
    loopFilter.initialize (timebase);
    pickFilter.initialize (timebase);
    noise.initialize (timebase);
    setLowestFrequency (32);
  }
  public void setLowestFrequency (double lowestFrequency)
  {
    length =
      (int) Math.ceil (timebase.audioSampleFramesPerSecond / lowestFrequency);
    delayLine = new DelayLineAllpass (length);
    delayLine.initialize (timebase);
    reset ();
  }
  void setFrequency (double frequency)
  {
    double delay = Math.round (timebase.audioSampleFramesPerSecond / frequency);
      delayLine.setDelay (delay);
      loopGain = 0.995 + (frequency * 0.000005);
    if (loopGain > 1.0)
      {
	loopGain = 0.99999;
      }
  }
    /**
     * Fills delay line with noise, additively with current contents.
     */
  void pluck (double amplitude)
  {
    this.amplitude = amplitude;
    pickFilter.setPole (0.999 - (amplitude * 0.15));
    pickFilter.setGain (amplitude * 0.5);
    for (int i = 0; i < length; i++)
      {
	delayLine.tick (delayLine.signal * 0.6 +
			pickFilter.tick (noise.tick ()));
      }
    delayLine.removeDC ();
  }
  public void attack (double[]noteOnEvent)
  {
    this.noteOnEvent = noteOnEvent;
    attack (Event.getDuration (noteOnEvent), Event.getLeftPan (noteOnEvent),
	    Event.getRightPan (noteOnEvent), Event.getFrequency (noteOnEvent),
	    Event.getGain (noteOnEvent));
  }
  public void attack (double duration, double leftPan, double rightPan,
		      double frequency, double amplitude)
  {
    delayLine.reset ();
    loopFilter.reset ();
    pickFilter.reset ();
    envelope.reset ();
    envelope.setReleasePoint (duration);
    leftGain = leftPan * amplitude;
    rightGain = rightPan * amplitude;
    setFrequency (frequency);
    pluck (amplitude);
  }
  public void release (double[]noteOffEvent)
  {
    envelope.release ();
    loopGain = 1.0 - amplitude;
  }
  public void tick ()
  {
    if (envelope.finished)
      {
        turnOff();
        return;
      }
    signal =
      delayLine.tick (loopFilter.tick (delayLine.signal * loopGain)) * 600 *
      envelope.tick ();
  }
}
