package Silence.Orchestra.Instruments;
import Silence.Conversions;
import Silence.Orchestra.StereoInstrument;
import Silence.Orchestra.Orchestra;
import Silence.Orchestra.Envelope;
import Silence.Orchestra.FunctionTable;
import Silence.Orchestra.Timebase;
import Silence.Orchestra.LinearEnvelope;
import Silence.Orchestra.Event;
import Silence.Orchestra.InterpolatingOscillator;
import Silence.Orchestra.SchroederReverb;
import Silence.Orchestra.ButterworthBandPassFilter;
import Silence.Orchestra.InterpolatingOscillator;
/**
 * Michael Bergmann's filtered harmonics instrument from "Face on Mars",
 * ported from Csound.
 * @author Copyright (C) 2000 by Michael Gogins. All rights reserved.
 * <ADDRESS>
 * gogins@pipeline.com
 * </ADDRESS>
 */
public class FilteredHarmonics extends StereoInstrument
{
  public static void main (String[]args)
  {
    StereoInstrument.test (FilteredHarmonics.class.getName ());
  }
  static FunctionTable functionTable = null;
  InterpolatingOscillator oscillator1 = new InterpolatingOscillator ();
  InterpolatingOscillator oscillator2 = new InterpolatingOscillator ();
  InterpolatingOscillator oscillator3 = new InterpolatingOscillator ();
  InterpolatingOscillator oscillator4 = new InterpolatingOscillator ();
  InterpolatingOscillator oscillator5 = new InterpolatingOscillator ();
  InterpolatingOscillator oscillator6 = new InterpolatingOscillator ();
  ButterworthBandPassFilter butterworthBandPassFilter1 =
    new ButterworthBandPassFilter ();
  ButterworthBandPassFilter butterworthBandPassFilter2 =
    new ButterworthBandPassFilter ();
  ButterworthBandPassFilter butterworthBandPassFilter3 =
    new ButterworthBandPassFilter ();
  ButterworthBandPassFilter butterworthBandPassFilter4 =
    new ButterworthBandPassFilter ();
  Envelope damping = new Envelope ();
  LinearEnvelope envelope1 = new LinearEnvelope ();
  LinearEnvelope envelope2 = new LinearEnvelope ();
  LinearEnvelope envelope3 = new LinearEnvelope ();
  LinearEnvelope envelope4 = new LinearEnvelope ();
  LinearEnvelope envelope5 = new LinearEnvelope ();
  LinearEnvelope envelope6 = new LinearEnvelope ();
  SchroederReverb schroederReverb1 = new SchroederReverb ();
  SchroederReverb schroederReverb2 = new SchroederReverb ();
  double rightSignal = 0;
  double gain = 0;
  public FilteredHarmonics ()
  {
  }
  public void initialize (Timebase timebase)
  {
    this.timebase = timebase;
    functionTable = FunctionTable.getFunctionTable ("FilteredNoise");
    if (functionTable == null)
      {
	functionTable = new FunctionTable ();
	functionTable.initialize (timebase);
	functionTable.setHarmonic (1, 0.28, 0);
	functionTable.setHarmonic (2, 1.00, 0);
	functionTable.setHarmonic (3, 0.74, 0);
	functionTable.setHarmonic (4, 0.66, 0);
	functionTable.setHarmonic (5, 0.78, 0);
	functionTable.setHarmonic (6, 0.48, 0);
	functionTable.setHarmonic (7, 0.05, 0);
	functionTable.setHarmonic (8, 0.33, 0);
	functionTable.setHarmonic (9, 0.12, 0);
	functionTable.setHarmonic (10, 0.08, 0);
	functionTable.setHarmonic (11, 0.01, 0);
	functionTable.setHarmonic (12, 0.54, 0);
	functionTable.setHarmonic (13, 0.19, 0);
	functionTable.setHarmonic (14, 0.08, 0);
	functionTable.setHarmonic (15, 0.05, 0);
	functionTable.setHarmonic (16, 0.16, 0);
	functionTable.setHarmonic (17, 0.01, 0);
	functionTable.setHarmonic (18, 0.03, 0);
	functionTable.setHarmonic (19, 0.30, 0);
	functionTable.setHarmonic (20, 0.02, 0);
	functionTable.setHarmonic (21, 0.20, 0);
	functionTable.rescale (1.0);
	functionTable.setFunctionTable ("FilteredNoise", functionTable);
      }
    damping.initialize (timebase);
      oscillator1.initialize (timebase);
      oscillator2.initialize (timebase);
      oscillator3.initialize (timebase);
      oscillator4.initialize (timebase);
      oscillator5.initialize (timebase);
      oscillator6.initialize (timebase);
      oscillator1.setFunctionTable (functionTable);
      oscillator2.setFunctionTable (functionTable);
      oscillator3.setFunctionTable (functionTable);
      oscillator4.setFunctionTable (functionTable);
      oscillator5.setFunctionTable (functionTable);
      oscillator6.setFunctionTable (functionTable);
      butterworthBandPassFilter1.initialize (timebase);
      butterworthBandPassFilter2.initialize (timebase);
      butterworthBandPassFilter3.initialize (timebase);
      butterworthBandPassFilter4.initialize (timebase);
      envelope1.initialize (timebase);
      envelope2.initialize (timebase);
      envelope3.initialize (timebase);
      envelope4.initialize (timebase);
      envelope5.initialize (timebase);
      envelope6.initialize (timebase);
      schroederReverb1.initialize (timebase);
      schroederReverb1.setWet (1.0);
      schroederReverb1.setSustain (0.5);
      schroederReverb2.initialize (timebase);
      schroederReverb2.setWet (1.0);
      schroederReverb2.setSustain (0.4);
  }
  public void attack (double[]noteOnEvent)
  {
    this.noteOnEvent = noteOnEvent;
    gain = Event.getGain (noteOnEvent);
    leftGain = Event.getLeftPan (noteOnEvent);
    rightGain = Event.getRightPan (noteOnEvent);
    double octave = Event.getOctave (noteOnEvent);
    double octave1 = octave - .01;
    double frequency1 = Conversions.octaveToHz (octave1);
      oscillator1.setFrequency (frequency1);
    double frequency2 = Conversions.octaveToHz (octave1) * 0.999;
      oscillator2.setFrequency (frequency2);
    double frequency3 = Conversions.octaveToHz (octave1) * 1.001;
      oscillator3.setFrequency (frequency3);
    double octave2 = octave + .01;
    double frequency4 = Conversions.octaveToHz (octave2);
      oscillator4.setFrequency (frequency4);
    double frequency5 = Conversions.octaveToHz (octave2) * 0.999;
      oscillator5.setFrequency (frequency5);
    double frequency6 = Conversions.octaveToHz (octave2) * 1.001;
      oscillator6.setFrequency (frequency6);
    double dampingAttack = 0.001;
    double dampingRelease = 0.05;
    double duration =
      Event.getDuration (noteOnEvent) + dampingAttack + dampingRelease;
      damping.setThreeSegments (dampingAttack, -3, 1.0,
				Event.getDuration (noteOnEvent), -3, 1.0,
				dampingRelease, -3);
    double attack = duration * 0.25;
    double sustain = duration * 0.5;
    double release = duration * 0.25;
      envelope1.setOneSegment (40, duration, 800);
      envelope2.setOneSegment (440, duration, 220);
      envelope3.setThreeSegments (0, attack, 1, sustain, 1, release, 0);
      envelope4.setOneSegment (800, duration, 40);
      envelope5.setOneSegment (440, duration, 220);
      envelope6.setThreeSegments (0, attack, 1, sustain, 1, release, 0);
  }
  public void release (double[]noteOffEvent)
  {
    damping.release ();
  }
  public void tick ()
  {
    if (damping.finished)
      {
        turnOff();
	return;
      }
    double k1 = envelope1.tick ();
    double k2 = envelope2.tick ();
    double k3 = envelope3.tick ();
    double k4 = envelope4.tick ();
    double k5 = envelope5.tick ();
    double k6 = envelope6.tick ();
    double a1 = oscillator1.tick () * k3;
    double a2 = oscillator2.tick () * k3;
    double a3 = oscillator3.tick () * k3;
    double a4 = a1 + a2 + a3;
    double a5 = oscillator4.tick () * k6;
    double a6 = oscillator5.tick () * k6;
    double a7 = oscillator6.tick () * k6;
    double a8 = a5 + a6 + a7;
    butterworthBandPassFilter1.setFrequencyAndBandwidth (k1, 40);
    double a9 = butterworthBandPassFilter1.tick (a4);
    butterworthBandPassFilter1.setFrequencyAndBandwidth (k5, k2 * 0.8);
    double a10 = butterworthBandPassFilter1.tick (a9) * 6000.0;
    butterworthBandPassFilter1.setFrequencyAndBandwidth (k4, 40);
    double a11 = butterworthBandPassFilter1.tick (a8);
    butterworthBandPassFilter1.setFrequencyAndBandwidth (k2, k5 * 0.8);
    double a12 = butterworthBandPassFilter1.tick (a11) * 6000.0;
    double a13 = schroederReverb1.tick (a10);
    double a14 = schroederReverb1.tick (a12);
    double damp = damping.tick () * 5.0 * gain;
    signal = (a13 + a10) * damp;
    rightSignal = (a14 + a12) * damp;
  }
  public void send()
  {
    output.add(signal, rightSignal);
  }
}
