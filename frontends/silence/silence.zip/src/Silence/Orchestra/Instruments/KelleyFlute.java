package Silence.Orchestra.Instruments;
import Silence.Conversions;
import Silence.Orchestra.Event;
import Silence.Orchestra.ButterworthLowPassFilter;
import Silence.Orchestra.InterpolatingOscillator;
import Silence.Orchestra.Orchestra;
import Silence.Orchestra.Envelope;
import Silence.Orchestra.FunctionTable;
import Silence.Orchestra.Noise;
import Silence.Orchestra.StereoInstrument;
import Silence.Orchestra.Timebase;
/**
 * Port of James Kelley's flute instrument from Csound.
 * @author Copyright (C) 2000 by Michael Gogins. All rights reserved.
 * <ADDRESS>
 * gogins@pipeline.com
 * </ADDRESS>
 */
public class KelleyFlute extends StereoInstrument
{
  public static void main (String[]args)
  {
    StereoInstrument.test (KelleyFlute.class.getName ());
  }
  public KelleyFlute ()
  {
  }
  double attack = 0.07;
  double decay = 0.15;
  double sustain = 1.0;
  double release = 0.1;
  public double frequency = 0;
  public double vibratoFrequency = 5.0;
  public double vibratoDepth = 0.2;
  public double envelopeExponent = -1.0;
  public double noiseCutoff = 200.0;
  public double amplitude = 0.0;
  public Envelope envelope = new Envelope ();
  public InterpolatingOscillator oscillator = new InterpolatingOscillator ();
  public InterpolatingOscillator vibrato = new InterpolatingOscillator ();
  public Noise noise = new Noise ();
  public Envelope noiseEnvelope = new Envelope ();
  public ButterworthLowPassFilter filter = new ButterworthLowPassFilter ();
  public void initialize (Timebase timebase)
  {
    super.initialize (timebase);
    FunctionTable fluteWave = FunctionTable.getFunctionTable ("KelleyFlute");
    if (fluteWave == null)
      {
	fluteWave = new FunctionTable ();
	fluteWave.setHarmonic (1, 1.00, 0);
	fluteWave.setHarmonic (2, 0.25, 0);
	fluteWave.setHarmonic (3, 1.00, 0);
	fluteWave.rescale (1.0);
      }
    oscillator.initialize (timebase);
      oscillator.setFunctionTable (fluteWave);
    FunctionTable sineWave = FunctionTable.getFunctionTable ("Sine");
    if (sineWave == null)
      {
	sineWave = new FunctionTable ();
	sineWave.setHarmonic (1, 1.00, 0);
	sineWave.rescale (1.0);
      }
    vibrato.initialize (timebase);
    vibrato.setFunctionTable (sineWave);
    envelope.initialize (timebase);
    noiseEnvelope.initialize (timebase);
    noise.initialize (timebase);
    filter.initialize (timebase);
  }
  public void attack (double[]noteOnEvent)
  {
    super.attack (noteOnEvent);
    amplitude = Event.getGain (noteOnEvent);
    sustain = Event.getDuration (noteOnEvent);
    envelope.setFourSegments (attack, envelopeExponent, amplitude * 1.5,
			      decay, envelopeExponent, amplitude, sustain,
			      envelopeExponent, amplitude, release,
			      envelopeExponent);
    noiseEnvelope.setOneSegment (amplitude / 4.0, 0.14, envelopeExponent,
				 0.0);
    frequency = Event.getFrequency (noteOnEvent);
    filter.setFrequencyAndDamping (noiseCutoff, 3.0);
    filter.reset ();
  }
  public void release (double[]noteOffEvent)
  {
    envelope.release ();
  }
  public void tick ()
  {
    if (envelope.finished)
      {
        turnOff();
        return;
      }
    double envelopeSignal = envelope.tick ();
    double randomAmplitude = noise.tick () * amplitude * 0.1;
    double vibratoAmplitude =
      (8.0 + Event.getOctave (noteOnEvent)) * vibratoDepth + randomAmplitude;
    double randomFrequency = noise.tick () * 1.0;
    vibrato.setFrequency (vibratoFrequency + randomFrequency);
    double vibratoSignal = vibrato.tick () * vibratoAmplitude;
    oscillator.setFrequency (frequency + vibratoSignal);
    signal = oscillator.tick ();
    signal += filter.tick (noise.tick ()) * noiseEnvelope.tick () * 70.0;
    signal *= (envelopeSignal * 4.0);
  }
}
