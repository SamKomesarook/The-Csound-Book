package Silence.Orchestra.Instruments;
import Silence.Orchestra.FM4Operator;
import Silence.Orchestra.FM4Algorithm5;
import Silence.Orchestra.Event;
import Silence.Orchestra.Envelope;
import Silence.Orchestra.Instrument;
import Silence.Orchestra.Orchestra;
import Silence.Orchestra.StereoInstrument;
import Silence.Orchestra.SampleFrame;
import Silence.Orchestra.Timebase;
/**
 * Port of Perry Cook's TubeBell instrument from his STK.
 * @author Copyright (C) 2000 by Michael Gogins. All rights reserved.
 * <ADDRESS>
 * gogins@pipeline.com
 * </ADDRESS>
 */
public class TubularBell extends FM4Algorithm5
{
  public static void main (String[]args)
  {
    StereoInstrument.test (TubularBell.class.getName ());
  }
  public double vibratoFrequency = 2.0;
  public TubularBell ()
  {
  }
  public void initialize (Timebase timebase)
  {
    super.initialize (timebase);
    setRatio (1, 1.0 * 0.995);
    setRatio (1, 1.414 * 0.995);
    setRatio (2, 1.0 * 1.005);
    setRatio (3, 1.414 * 1.000);
    gains[0] = operatorGains[94];
    gains[1] = operatorGains[76];
    gains[2] = operatorGains[99];
    gains[3] = operatorGains[71];
    //envelope[0].setSustainLevel(0);
    double exponent = -9;
       envelope[0].setThreeSegments (0.005, exponent, 1.0, 4.0, exponent, 0, 0.06, exponent);
       envelope[1].setThreeSegments (0.005, exponent, 1.0, 4.0, exponent, 0, 0.06, exponent);
       envelope[2].setThreeSegments (0.005, exponent, 1.0, 2.0, exponent, 0, 0.06, exponent);
       envelope[3].setThreeSegments (0.005, exponent, 1.0, 4.0, exponent, 0, 0.06, exponent);
      twoZero.setGain (0.5);
  }
  public void attack (double[]noteOnEvent)
  {
    this.noteOnEvent = noteOnEvent;
    double amplitude = Event.getGain (noteOnEvent);
    double duration = Event.getDuration (noteOnEvent);
      leftGain = Event.getLeftPan (noteOnEvent);
      rightGain = Event.getRightPan (noteOnEvent);
      gains[0] = amplitude * operatorGains[94];
      gains[1] = amplitude * operatorGains[76];
      gains[2] = amplitude * operatorGains[99];
      gains[3] = amplitude * operatorGains[71];
      envelope[0].reset ();
      envelope[1].reset ();
      envelope[2].reset ();
      envelope[3].reset ();
      envelope[0].setReleasePoint (duration);
      envelope[1].setReleasePoint (duration);
      envelope[2].setReleasePoint (duration);
      envelope[3].setReleasePoint (duration);
      baseFrequency = Event.getFrequency (noteOnEvent);
      waves[0].setFrequency (baseFrequency * ratios[0]);
      waves[1].setFrequency (baseFrequency * ratios[1]);
      waves[2].setFrequency (baseFrequency * ratios[2]);
      waves[3].setFrequency (baseFrequency * ratios[3]);
      vibrato.setFrequency (vibratoFrequency);
      modDepth = 0.01;
  }
  public void release (double[]noteOffEvent)
  {
    envelope[0].release ();
    envelope[1].release ();
    envelope[2].release ();
    envelope[3].release ();
  }
  public void tick () throws SampleFrame.ShapeException
  {
    signal = super.tickOutput () * 6.0;
  }
}
