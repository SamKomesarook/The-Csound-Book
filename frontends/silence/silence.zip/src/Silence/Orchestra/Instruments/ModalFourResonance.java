package Silence.Orchestra.Instruments;
import Silence.Conversions;
import Silence.Orchestra.BiQuad;
import Silence.Orchestra.Envelope;
import Silence.Orchestra.Event;
import Silence.Orchestra.StereoInstrument;
import Silence.Orchestra.FunctionTable;
import Silence.Orchestra.InterpolatingOscillator;
import Silence.Orchestra.OneCycleInterpolatingOscillator;
import Silence.Orchestra.OnePole;
import Silence.Orchestra.Orchestra;
import Silence.Orchestra.Timebase;
/**
 * Base instrument for modal synthesis,
 * following Perry Cook's STK Modal4.
 */
public abstract class ModalFourResonance extends StereoInstrument
{
  Envelope envelope = null;
  OneCycleInterpolatingOscillator wave = null;
    BiQuad[] filters = new BiQuad[4];
  OnePole onePole = null;
  InterpolatingOscillator vibrato = null;
  double vibratoGain;
  double masterGain;
  double directGain;
  double stickHardness;
  double strikePosition;
  double baseFrequency;
  double[] ratios = new double[4];
  double[] resonances = new double[4];
  public ModalFourResonance ()
  {
  }
  public void initialize (Timebase timebase)
  {
    this.timebase = timebase;
    envelope = new Envelope ();
    envelope.initialize (timebase);
    // We don't make the excitation wave here yet,
    // because we don't know what it's going to be.
    filters[0] = new BiQuad ();
    filters[0].initialize (timebase);
    filters[1] = new BiQuad ();
    filters[1].initialize (timebase);
    filters[2] = new BiQuad ();
    filters[2].initialize (timebase);
    filters[3] = new BiQuad ();
    filters[3].initialize (timebase);
    onePole = new OnePole ();
    onePole.initialize (timebase);
    vibrato = new InterpolatingOscillator ();
    FunctionTable functionTable = FunctionTable.getFunctionTable ("Sine");
    if (functionTable == null)
      {
	functionTable = new FunctionTable ();
	functionTable.setHarmonic (1, 1, 0);
	functionTable.rescale (1.0);
	FunctionTable.setFunctionTable ("Sine", functionTable);
      }
    vibrato.setFunctionTable (functionTable);
      vibrato.initialize (timebase);
      vibrato.setFrequency(6.0);
      vibratoGain = 0.05;
      directGain = 0.0;
      masterGain = 1.0;
      baseFrequency = 440.0;
      setRatioAndResonance (0, 1.00, 0.9997);
      setRatioAndResonance (1, 1.30, 0.9997);
      setRatioAndResonance (2, 1.77, 0.9997);
      setRatioAndResonance (3, 2.37, 0.9997);
      setFilterGain (0, 0.01);
      setFilterGain (1, 0.01);
      setFilterGain (2, 0.01);
      setFilterGain (3, 0.01);
      reset ();
      filters[0].setEqualGainZeroes ();
      filters[1].setEqualGainZeroes ();
      filters[2].setEqualGainZeroes ();
      filters[3].setEqualGainZeroes ();
      stickHardness = 0.5;
      strikePosition = 0.561;
  }
  public void reset ()
  {
    onePole.reset ();
    filters[0].reset ();
    filters[1].reset ();
    filters[2].reset ();
    filters[3].reset ();
    signal = 0;
  }
  public void setFrequency (double frequency)
  {
    baseFrequency = frequency;
    setRatioAndResonance (0, ratios[0], resonances[0]);
    setRatioAndResonance (1, ratios[1], resonances[1]);
    setRatioAndResonance (2, ratios[2], resonances[2]);
    setRatioAndResonance (3, ratios[3], resonances[3]);
  }
  public void setRatioAndResonance (int index, double ratio, double resonance)
  {
    double temp;
    if (ratio * baseFrequency < (timebase.audioSampleFramesPerSecond / 2.0))
      {
	ratios[index] = ratio;
      }
    else
      {
	temp = ratio;
	while (temp * baseFrequency > (timebase.audioSampleFramesPerSecond / 2.0))
	  {
	    temp *= 0.5;
	  }
	ratios[index] = temp;
	System.out.println
	  ("ModalFourResonance: Aliasing would occur here, correcting.");
      }
    resonances[index] = resonance;
    if (ratio < 0)
      {
	temp = -ratio;
      }
    else
      {
	temp = ratio * baseFrequency;
      }
    filters[index].setFrequencyAndResonance (temp, resonance);
  }
  public void setMasterGain (double gain)
  {
    masterGain = gain;
  }
  public void setDirectGain (double gain)
  {
    directGain = gain;
  }
  public void setFilterGain (int index, double gain)
  {
    filters[index].setGain (gain);
  }
  public void strike (double amplitude)
  {
    double temp;
      onePole.setPole (1.0 - amplitude);
      onePole.tick (amplitude);
      wave.reset ();
    for (int i = 0; i < 4; i++)
      {
	if (ratios[i] < 0)
	  {
	    temp = -ratios[i];
	  }
	else
	  {
	    temp = ratios[i] * baseFrequency;
	  }
	filters[i].setFrequencyAndResonance (temp, resonances[i]);
      }
  }
  public void attack (double[]noteOnEvent)
  {
    this.noteOnEvent = noteOnEvent;
    strike (Event.getGain (noteOnEvent));
    setFrequency (Event.getFrequency (noteOnEvent));
    leftGain = Conversions.leftPan (Event.getX (noteOnEvent));
    rightGain = Conversions.rightPan (Event.getX (noteOnEvent));
    envelope.setThreeSegments (0.01, -3, 1, Event.getDuration (noteOnEvent),
			       1, -3, 0.05, -5);
  }
  public void release (double[]noteOffEvent)
  {
    double releaseAmplitude = Event.getGain (noteOffEvent);
      damp (1.0 - (releaseAmplitude * 0.03));
      envelope.release ();
  }
  public void damp (double amplitude)
  {
    double temp;
    for (int i = 0; i < 4; i++)
      {
	if (ratios[i] < 0)
	  {
	    temp = -ratios[i];
	  }
	else
	  {
	    temp = ratios[i] * baseFrequency;
	  }
	filters[i].setFrequencyAndResonance (temp, resonances[i] * amplitude);
      }
  }
  public void controlChange (int number, double value)
  {
  }
  public double tickOutput ()
  {
    if (envelope.finished)
      {
        signal = 0;
        return signal;
      }
    double temp = masterGain * onePole.tick (wave.tick () * envelope.tick ());
    double temp2 = filters[0].tick (temp);
    temp2 += filters[1].tick (temp);
    temp2 += filters[2].tick (temp);
    temp2 += filters[3].tick (temp);
    temp2 = temp2 - (temp2 * directGain);
    temp2 += directGain * temp;
    if (vibratoGain != 0.0)
      {
	temp = 1.0 + (vibrato.tick () * vibratoGain);
	temp2 = temp * temp2;
      }
    signal = temp2 * 0.4;
    return signal;
  }
}
