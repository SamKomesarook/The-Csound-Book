package Silence.Orchestra.Instruments;
import Silence.Conversions;
import Silence.Orchestra.Envelope;
import Silence.Orchestra.Event;
import Silence.Orchestra.StereoInstrument;
import Silence.Orchestra.FunctionTable;
import Silence.Orchestra.InterpolatingOscillator;
import Silence.Orchestra.QuadratureOscillator;
import Silence.Orchestra.SignalFlowOrchestra;
import Silence.Orchestra.Timebase;
import Silence.Orchestra.WaveSoundfile;
/**
Simple test Instrument.
@author Copyright (C) 2000 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class TestInstrument extends StereoInstrument
{
  public static void main (String[]args)
  {
    try
    {
      SignalFlowOrchestra orchestra = new SignalFlowOrchestra ();
     ((WaveSoundfile) orchestra.signalFlowGraph).setChannelCount(2);
     ((WaveSoundfile) orchestra.signalFlowGraph).setSamplingRate(44100);
     ((WaveSoundfile) orchestra.signalFlowGraph).setSampleSize(2);
     ((WaveSoundfile) orchestra.signalFlowGraph).setName("Test.wav");
      orchestra.signalFlowGraph.addSource(new TestInstrument());
        orchestra.score.addNote (0, 0, 5, 60, 80, 0, 0, 0, 0, 4095);
        orchestra.score.addNote (0, 6, 3, 72, 80, 0, 0, 0, 0, 4095);
        orchestra.compile();
        orchestra.start();
        orchestra.thread.join ();
    }
    catch (Exception x)
    {
      x.printStackTrace ();
    }
  }
  public InterpolatingOscillator oscillator = new InterpolatingOscillator ();
  public QuadratureOscillator quadratureOscillator =
    new QuadratureOscillator ();
  public Envelope envelope = new Envelope ();
  double amplitude = 0;
  public void initialize (Timebase timebase)
  {
    this.timebase = timebase;
    oscillator.initialize (timebase);
    quadratureOscillator.initialize (timebase);
    FunctionTable functionTable =
      FunctionTable.getFunctionTable ("FunctionTable");
    if (functionTable == null)
      {
	functionTable = new FunctionTable ();
	functionTable.initialize (timebase);
	functionTable.setHarmonic (1, 1, 0);
	functionTable.setHarmonic (2, 1, .3);
	functionTable.rescale (1.0);
	FunctionTable.setFunctionTable ("FunctionTable", functionTable);
      }
    oscillator.setFunctionTable (functionTable);
    envelope.initialize (timebase);
    envelope.setThreeSegments (0.03, -5, 1.0, 10.0, -7, 0.23, 0.15, -7);
  }
  public void attack (double[]event)
  {
    noteOnEvent = event;
    offTime += 0.5;
    amplitude = Event.getGain (event);
    oscillator.reset ();
    quadratureOscillator.reset ();
    oscillator.setMidiKey (event[Event.KEY]);
    quadratureOscillator.setFrequency (Event.getFrequency (event));
    envelope.reset ();
    envelope.setReleasePoint (Event.getDuration (noteOnEvent));
  }
  public void release (double[]event)
  {
    envelope.release ();
  }
  public void tick ()
  {
    if (envelope.finished)
      {
        signal = 0;
        return;
      }
    signal = amplitude * quadratureOscillator.safeTick () * envelope.tick ();
  }
}
