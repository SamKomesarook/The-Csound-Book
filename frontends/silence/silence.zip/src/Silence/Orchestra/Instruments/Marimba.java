package Silence.Orchestra.Instruments;
import Silence.Orchestra.Event;
import Silence.Orchestra.FunctionTable;
import Silence.Orchestra.ModalFourResonance;
import Silence.Orchestra.Oscillator;
import Silence.Orchestra.OneCycleInterpolatingOscillator;
import Silence.Orchestra.Orchestra;
import Silence.Orchestra.OrchestraView;
import Silence.Orchestra.StereoInstrument;
import Silence.Orchestra.Timebase;
import java.util.Random;
import javax.swing.JFrame;
/**
 * Port of Perry Cook's Marimba instrument.
 * Omits the multi-strike feature,
 * and uses a computed wavetable for the mallet strike
 * instead of an impulse file.
 * @author Copyright (C) 2000 by Michael Gogins. All rights reserved.
 * <ADDRESS>
 * gogins@pipeline.com
 * </ADDRESS>
 */
public class Marimba extends ModalFourResonance implements java.
  io.Serializable
{
  public static void main (String[]args)
  {
    StereoInstrument.test (Marimba.class.getName ());
  }
  public static int STICK_HARDNESS = 2;
  public static int STRIKE_POSITION = 4;
  static FunctionTable malletWavetable = null;
  static
  {
    malletWavetable = new FunctionTable ();
    malletWavetable.setHarmonic (1, 3, 0);
    malletWavetable.setHarmonic (2, 4, 0);
    malletWavetable.setHarmonic (3, 7, 0);
    malletWavetable.setHarmonic (4, 2, 0);
    malletWavetable.setHarmonic (5, 3, 0);
    malletWavetable.setHarmonic (6, 5, 0);
    malletWavetable.setHarmonic (7, 3, 0);
    malletWavetable.setHarmonic (8, 3, 0);
    malletWavetable.setHarmonic (9, 2, 0);
    Random random = new Random ();
    double signal;
    for (int i = 0, n = malletWavetable.getSampleCount (); i < n; i++)
      {
	signal = (random.nextDouble () * 2.0) - 1.0;
	malletWavetable.setSignal (i,
				   malletWavetable.getSignal (i) +
				   signal * .001);
      }
    malletWavetable.rescale (10);
  }
  public Marimba ()
  {
  }
  public void initialize (Timebase timebase)
  {
    super.initialize (timebase);
    wave = new OneCycleInterpolatingOscillator ();
    wave.initialize (timebase);
    wave.setFunctionTable (malletWavetable);
    //      Controls the type of stick.
    wave.setFrequency (600);
    setRatioAndResonance (0, 1.00, 0.9996);	/*
						 * Set all       132.0
						 */
    setRatioAndResonance (1, 3.99, 0.9994);	/*
						 * of our        523.0
						 */
    setRatioAndResonance (2, 10.65, 0.9994);	/*
						 * default       1405.0
						 */
    setRatioAndResonance (3, -2443.0, 0.999);	/*
						 * resonances    2443.0
						 */
    setFilterGain (0, 0.04);	/*
				 * and
				 */
    setFilterGain (1, 0.01);	/*
				 * gains
				 */
    setFilterGain (2, 0.01);	/*
				 * for each
				 */
    setFilterGain (3, 0.008);	/*
				 * resonance
				 */
    directGain = 0.1;
  }
  public void setStickHardness (double hardness)
  {
    stickHardness = hardness;
    wave.setFrequency (0.25 * Math.pow (4.0, stickHardness));
    masterGain = 0.1 + (1.8 * stickHardness);
  }
  public void setStrikePosition (double position)
  {
    //      Compute the first three resonant modes at this position.
    double temp;
    double temp2;
      temp2 = position * Math.PI;
      strikePosition = position;
      temp = Math.sin (temp2);
      setFilterGain (0, 0.12 * temp);
      temp = Math.sin (0.05 + (3.9 * temp2));
      setFilterGain (1, -0.03 * temp);
      temp = Math.sin (-0.05 + (11 * temp2));
      setFilterGain (2, 0.11 * temp);
  }
  public void setModulationSpeed (double speed)
  {
  }
  public void setModulationDepth (double depth)
  {
  }
  public void controlChange (int number, double value)
  {
    if (number == STICK_HARDNESS)
      {
	setStickHardness (value * Event.NORM_7);
      }
    else if (number == STRIKE_POSITION)
      {
	setStrikePosition (value * Event.NORM_7);
      }
    else if (number == Event.CONTROLLER_MODULATION)
      {
	vibrato.setFrequency (value * Event.NORM_7 * 12.0);
      }
    else if (number == Event.CONTROLLER_MOD_WHEEL)
      {
	vibratoGain = (value * Event.NORM_7);
      }
    else if (number == Event.CONTROLLER_CONTINUOUS_AFTERTOUCH)
      {
	strike (value * Event.NORM_7);
      }
    else
      {
	System.out.println ("Marimba: Undefined control number!");
      }
  }
}
