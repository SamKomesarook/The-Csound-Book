package Silence.Orchestra.Instruments;
import Silence.Conversions;
import Silence.Orchestra.Envelope;
import Silence.Orchestra.Event;
import Silence.Orchestra.StereoInstrument;
import Silence.Orchestra.FunctionTable;
import Silence.Orchestra.InterpolatingOscillator;
import Silence.Orchestra.Orchestra;
import Silence.Orchestra.Timebase;
/**
 * Java version of Jean-Claude Risset's phasing instrument from Mutations.
 * @author Copyright (C) 2000 by Michael Gogins. All rights reserved.
 * <ADDRESS>
 * gogins@pipeline.com
 * </ADDRESS>
 */
public class TibetanChant extends StereoInstrument
{
  public static void main (String[]args)
  {
    StereoInstrument.test (TibetanChant.class.getName ());
  }
  double rise;
  double decay;
  double offset;
  double amplitude;
    InterpolatingOscillator[] oscillators = null;
  Envelope envelope = null;
  static FunctionTable wave = null;
  static
  {
    wave = new FunctionTable ();
    wave.setHarmonic (1, 1, 0);
    wave.setHarmonic (5, .1, 0);
    wave.setHarmonic (6, .1, 0);
    wave.setHarmonic (7, .1, 0);
    wave.setHarmonic (8, .1, 0);
    wave.setHarmonic (9, .1, 0);
    wave.setHarmonic (10, .1, 0);
    wave.rescale (1);
  }
  public TibetanChant ()
  {
  }
  public void initialize (Timebase timebase)
  {
    rise = .06;
    decay = 1.75;
    offset = .03;
    this.timebase = timebase;
    oscillators = new InterpolatingOscillator[9];
    for (int i = 0; i < 9; i++)
      {
	oscillators[i] = new InterpolatingOscillator ();
	oscillators[i].initialize (timebase);
	oscillators[i].setFunctionTable (wave);
      }
    envelope = new Envelope ();
      envelope.initialize (timebase);
  }
  public void attack (double[]noteOnEvent)
  {
    this.noteOnEvent = noteOnEvent;
    amplitude = Event.getGain (noteOnEvent);
    envelope.setThreeSegments (rise, -3, 1.0, Event.getDuration (noteOnEvent),
			       0, 1.0, decay, -13);
    double frequency = Event.getFrequency (noteOnEvent);
      oscillators[0].reset ();
      oscillators[0].setFrequency (frequency);
      oscillators[1].reset ();
      oscillators[1].setFrequency (frequency + offset);
      oscillators[2].reset ();
      oscillators[2].setFrequency (frequency + (offset * 2.0));
      oscillators[3].reset ();
      oscillators[3].setFrequency (frequency + (offset * 3.0));
      oscillators[4].reset ();
      oscillators[4].setFrequency (frequency + (offset * 4.0));
      oscillators[5].reset ();
      oscillators[5].setFrequency (frequency - offset);
      oscillators[6].reset ();
      oscillators[6].setFrequency (frequency - (offset * 2.0));
      oscillators[7].reset ();
      oscillators[7].setFrequency (frequency - (offset * 3.0));
      oscillators[8].reset ();
      oscillators[8].setFrequency (frequency - (offset * 4.0));
      leftGain = Event.getLeftPan (noteOnEvent);
      rightGain = Event.getLeftPan (noteOnEvent);
  }
  public void release (double[]noteOnEvent)
  {
    envelope.release ();
  }
  public void tick ()
  {
    if (envelope.finished)
      {
        turnOff();
        return;
      }
    signal = oscillators[0].tick ();
    signal += oscillators[1].tick ();
    signal += oscillators[2].tick ();
    signal += oscillators[3].tick ();
    signal += oscillators[4].tick ();
    signal += oscillators[5].tick ();
    signal += oscillators[6].tick ();
    signal += oscillators[7].tick ();
    signal += oscillators[8].tick ();
    signal *= envelope.tick () * amplitude * 0.5;
  }
}
