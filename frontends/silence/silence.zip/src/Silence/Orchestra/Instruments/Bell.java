package Silence.Orchestra.Instruments;
import Silence.Conversions;
import Silence.Orchestra.ButterworthBandPassFilter;
import Silence.Orchestra.Envelope;
import Silence.Orchestra.LinearEnvelope;
import Silence.Orchestra.Event;
import Silence.Orchestra.StereoInstrument;
import Silence.Orchestra.FunctionTable;
import Silence.Orchestra.InterpolatingOscillator;
import Silence.Orchestra.InterpolatingPhaseOscillator;
import Silence.Orchestra.Orchestra;
import Silence.Orchestra.Noise;
import Silence.Orchestra.SchroederReverb;
import Silence.Orchestra.Timebase;
import Silence.Orchestra.SampleFrame;
/**
 * Port of John ffitch's enhanced FM bell from Csound.
 * @author Copyright (C) 2000 by Michael Gogins. All rights reserved.
 * <ADDRESS>
 * gogins@pipeline.com
 * </ADDRESS>
 */
public class Bell extends StereoInstrument
{
  public static void main (String[]args)
  {
    StereoInstrument.test (Bell.class.getName ());
  }
  public double maximumIndex = 10.0;
  public double modulatorRatio = 5.01;
  public double carrierRatio = 6.9999;
  public double attack = .00014;
  public double release = .08;
  public double exponent = -7;
  public double noiseGain = 0.0051;
  public transient double amplitude;
  public Envelope envelope = new Envelope ();
  public Envelope dynamic = new Envelope ();
  public InterpolatingPhaseOscillator modulator =
    new InterpolatingPhaseOscillator ();
  public InterpolatingPhaseOscillator carrier =
    new InterpolatingPhaseOscillator ();
  public InterpolatingOscillator vibrato =
    new InterpolatingOscillator ();
  public SchroederReverb schroederReverb = new SchroederReverb ();
  public ButterworthBandPassFilter butterworthBandPassFilter =
    new ButterworthBandPassFilter ();
  public LinearEnvelope noiseEnvelope = new LinearEnvelope ();
  public LinearEnvelope dampingEnvelope = new LinearEnvelope ();
  public Noise noise = new Noise ();
  public Bell ()
  {
  }
  public void initialize (Timebase timebase)
  {
    this.timebase = timebase;
    FunctionTable functionTable = FunctionTable.getFunctionTable ("Sine");
    if (functionTable == null)
      {
	functionTable = new FunctionTable ();
	functionTable.setHarmonic (1, 1, 0);
	functionTable.rescale (1.0);
	FunctionTable.setFunctionTable ("Sine", functionTable);
      }
    envelope.initialize (timebase);
      dynamic.initialize (timebase);
      modulator.initialize (timebase);
      modulator.setFunctionTable (functionTable);
      carrier.initialize (timebase);
      carrier.setFunctionTable (functionTable);
      vibrato.initialize (timebase);
      vibrato.setFunctionTable (functionTable);
      schroederReverb.initialize (timebase);
      schroederReverb.setSustain (2.0);
      schroederReverb.setWet (0.5);
      butterworthBandPassFilter.initialize (timebase);
      noiseEnvelope.initialize (timebase);
      dampingEnvelope.initialize (timebase);
      dampingEnvelope.setThreeSegments (0.01, 1.0, 1.0, 1.0, 0.05);
  }
  public void attack (double[]noteOnEvent)
  {
    double carrierFrequency =
      Event.getFrequency (noteOnEvent) / 2.0 * carrierRatio;
    double modulatorFrequency =
      Event.getFrequency (noteOnEvent) / 2.0 * modulatorRatio;
    double amplitude = Event.getGain (noteOnEvent);
    double duration = Event.getDuration (noteOnEvent) + attack + release;
      dampingEnvelope.resetSegment (1, duration);
      leftGain = Event.getLeftPan (noteOnEvent);
      rightGain = Event.getRightPan (noteOnEvent);
      envelope.setThreeSegments (attack, exponent, amplitude, 15.0, exponent,
				 amplitude * 0.001, release, exponent);
      envelope.setReleasePoint (duration);
      dynamic.setThreeSegments (attack, exponent, maximumIndex, 15.0, exponent,
				modulatorFrequency * maximumIndex * 0.001,
				release, exponent);
      dynamic.setReleasePoint (duration);
    double noiseAmplitude = amplitude / 1.0;
      noiseEnvelope.setTwoSegments (noiseAmplitude, 0.15, noiseAmplitude, 0.3, 0);
      modulator.setFrequency (modulatorFrequency);
      carrier.setFrequency (carrierFrequency);
      schroederReverb.reset ();
      butterworthBandPassFilter.setFrequencyAndBandwidth (amplitude * 32000, 200);
      butterworthBandPassFilter.reset ();
  }
  public void release (double[]noteOffEvent)
  {
    envelope.release ();
    dynamic.release ();
  }
  public void tick () throws SampleFrame.ShapeException
  {
    if (envelope.finished)
      {
        turnOff();
	return;
      }
    double noiseSignal = noise.tick () * noiseGain;
    double modulatorSignal =
      modulator.tick () * (dynamic.tick () + noiseSignal);
    signal = carrier.tickPhase (modulatorSignal) * envelope.tick () * 5.0;
    noiseSignal = noise.tick () * noiseEnvelope.tick ();
    noiseSignal = butterworthBandPassFilter.tick (noiseSignal);
    signal =
      schroederReverb.tick (signal + noiseSignal) * dampingEnvelope.tick ();
  }
}
