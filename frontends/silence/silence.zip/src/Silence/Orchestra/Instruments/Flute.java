package Silence.Orchestra.Instruments;
import Silence.Orchestra.StereoInstrument;
import Silence.Orchestra.Event;
import Silence.Orchestra.Timebase;
import Silence.Orchestra.FunctionTable;
import Silence.Orchestra.Envelope;
import Silence.Orchestra.DelayLineLinear;
import Silence.Orchestra.OnePole;
import Silence.Orchestra.DCBlock;
import Silence.Orchestra.Orchestra;
import Silence.Orchestra.JetTable;
import Silence.Orchestra.InterpolatingOscillator;
import Silence.Orchestra.Noise;
/**
 * Physical model of a blown flute, from Perry Cook's Synthesis Tool Kit.
 * @author Copyright (C) 2000 by Michael Gogins. All rights reserved.
 * <ADDRESS>
 * gogins@pipeline.com
 * </ADDRESS>
 */
public class Flute extends StereoInstrument
{
  public static void main (String[]args)
  {
    StereoInstrument.test (Flute.class.getName ());
  }
  static FunctionTable sineWave;
  {
    sineWave = new FunctionTable ();
    sineWave.setHarmonic (1, 1, 0);
  }
  DelayLineLinear jetDelay;
  DelayLineLinear boreDelay;
  JetTable jetTable;
  OnePole filter;
  DCBlock dcBlock;
  Noise noise;
  Envelope envelope;
  InterpolatingOscillator vibrato;
  double lastFrequency;
  double maximumPressure;
  double jetReflection;
  double endReflection;
  double noiseGain;
  double vibratoGain;
  double outputGain;
  double jetRatio;
  double frequency;
  double amplitude;
  double lowestFrequency;
  public Flute ()
  {
  }
  public void initialize (Timebase timebase)
  {
    this.timebase = timebase;
    lowestFrequency = 20.0;
    int length =
      (int) (timebase.audioSampleFramesPerSecond / (lowestFrequency + 1));
      boreDelay = new DelayLineLinear ();
      boreDelay.initialize (timebase);
      boreDelay.setLength (length);
      length >>= 1;
      jetDelay = new DelayLineLinear ();
      jetDelay.initialize (timebase);
      jetDelay.setLength (length);
      jetTable = new JetTable ();
      jetTable.initialize (timebase);
      filter = new OnePole ();
      filter.initialize (timebase);
      dcBlock = new DCBlock ();
      dcBlock.initialize (timebase);
      noise = new Noise ();
      noise.initialize (timebase);
      envelope = new Envelope ();
      envelope.initialize (timebase);
      vibrato = new InterpolatingOscillator ();
      vibrato.initialize (timebase);
      vibrato.setFunctionTable (sineWave);
      clear ();
      boreDelay.setDelay (100);
      jetDelay.setDelay (49);

      filter.setPole (0.7 -
		      (0.1 * (timebase.audioSampleFramesPerSecond / 2.0) /
		       timebase.audioSampleFramesPerSecond));
      filter.setGain (-1.0);
      vibrato.setFrequency (5.925);



























       envelope.setFourSegments (0.005, -1, 1.0, 0.01, -1, 0.5, 0.8, -1, 0.5, 0.01, -1);
      endReflection = 0.5;
      jetReflection = 0.5;
    //      Random component of breath pressure.
      noiseGain = 0.15;
    //      Periodic vibrato component of breath pressure.
      vibratoGain = 0.05;
    //jetRatio = 0.32;
      jetRatio = 0.32;
      maximumPressure = 0.0;
  }
  public void clear ()
  {
    jetDelay.clear ();
    boreDelay.clear ();
    filter.clear ();
    dcBlock.clear ();
  }
  public void startBlowing (double amplitude, double rate)
  {
    envelope.resetSegment (0, rate);
    maximumPressure = amplitude / 0.8;
  }
  public void stopBlowing (double rate)
  {
    envelope.resetSegment (3, rate);
    envelope.release ();
  }
  public void attack (double[]noteOnEvent)
  {
    this.noteOnEvent = noteOnEvent;
    leftGain = Event.getLeftPan (noteOnEvent);
    rightGain = Event.getRightPan (noteOnEvent);
    amplitude = Event.getGain (noteOnEvent) * 4.5;
    frequency = Event.getFrequency (noteOnEvent);
    setFrequency (frequency);
    envelope.resetSegment (2, Event.getDuration (noteOnEvent));
    startBlowing (1.1 + (amplitude * 0.20), amplitude * 0.02);
    outputGain = amplitude + 0.001;
  }
  public void release (double[]noteOffEvent)
  {
    double releaseAmplitude = Event.getGain (noteOffEvent);
      stopBlowing (amplitude * 0.02);
      envelope.release ();
  }
  public void setJetReflection (double reflection)
  {
    jetReflection = reflection;
  }
  public void setEndReflection (double reflection)
  {
    endReflection = reflection;
  }
  public void setFrequency (double frequency)
  {
    lastFrequency = frequency * 0.66666;	/*
						 * we're overblowing here
						 */
    double temp = timebase.audioSampleFramesPerSecond / lastFrequency - 2.0;	/*
										 * Length - approx. filter delay
										 */
    //lastFrequency = frequency;
    //double temp = timebase.audioSampleFramesPerSecond / lastFrequency - 2.0;  /* Length - approx. filter delay */
      boreDelay.setDelay (temp);	/*
					 * Length of bore tube
					 */
      jetDelay.setDelay (temp * jetRatio);	/*
						 * jet delay shorter
						 */
  }
  public void setJetDelay (double ratio)
  {
    //      Length == approximate filter delay.
    double temp = timebase.audioSampleFramesPerSecond / lastFrequency - 2.0;
      jetRatio = ratio;
      jetDelay.setDelay (temp * ratio);	/*
					 * Scaled by ratio
					 */
  }
  public void control (double[]controlEvent)
  {
    int controller = Event.getMidiControllerNumber (controlEvent);
    double value = Event.getMidiControllerValue (controlEvent);
    if (controller == Event.CONTROLLER_BREATH)
      {
	setJetDelay (0.08 + (0.48 * value * Event.NORM_7));
      }
    else if (controller == Event.CONTROLLER_FOOT)
      {
	noiseGain = (value * Event.NORM_7 * 0.4);
      }
    else if (controller == Event.CONTROLLER_EXPRESSION)
      {
	vibrato.setFrequency (value * Event.NORM_7 * 12.0);
      }
    else if (controller == Event.CONTROLLER_MOD_WHEEL)
      {
	vibratoGain = value * Event.NORM_7 * 0.4;
      }
  }
  public void tick ()
  {
    if (envelope.finished)
      {
        turnOff();
	return;
      }
    //      Breath pressure.
    double breathPressure = maximumPressure * envelope.tick ();
    //      Random deviation of breath pressure.
    double randomPressure = noiseGain * noise.tick ();
    //      Vibrato deviation of breath pressure.
    randomPressure += vibratoGain * vibrato.tick ();
    //      All scaled by overall breath envelope.
    randomPressure *= breathPressure;
    double temp = filter.tick (boreDelay.signal);
    //      Block DC on reflection.
    temp = dcBlock.tick (temp);
    //      Minus the reflection.
    double pressureDifference =
      breathPressure + randomPressure - (jetReflection * temp);
    //      Jet delay line.
    pressureDifference = jetDelay.tick (pressureDifference);
    pressureDifference =
      jetTable.lookup (pressureDifference) + (endReflection * temp);
    //      Bore delay and bell filter.
    signal = 0.3 * boreDelay.tick (pressureDifference);
    signal *= outputGain;
  }
}
