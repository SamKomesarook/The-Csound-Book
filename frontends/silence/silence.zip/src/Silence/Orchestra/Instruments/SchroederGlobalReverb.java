package Silence.Orchestra.Instruments;
import Silence.Orchestra.Orchestra;
import Silence.Orchestra.SignalFlowUnit;
import Silence.Orchestra.Event;
import Silence.Orchestra.Timebase;
import Silence.Orchestra.SchroederReverb;
/**
 * Applies Schroeder reverberation to the first two channels of the
 * timebase timebase. Assumes that this is the final instrument in the playlist.
 * @author Copyright (C) 2000 by Michael Gogins. All rights reserved.
 * <ADDRESS>
 * gogins@pipeline.com
 * </ADDRESS>
 */
public class SchroederGlobalReverb extends SignalFlowUnit
{
  public static void main (String[]args)
  {
    try
    {
      Orchestra orchestra = new Orchestra ();
        orchestra.instruments.add (new Marimba ());
        orchestra.instruments.add (new SchroederGlobalReverb ());
        orchestra.score.addNote (0, 0, 5, 60, 80, 0, 0, 0, 0, 4095);
        orchestra.score.addNote (0, 5, 3, 72, 80, 0, 0, 0, 0, 4095);
        orchestra.score.addNote (0, 8, 1, 74, 80, 0, 0, 0, 0, 4095);
        orchestra.score.addNote (0, 9, 1, 80, 80, 0, 0, 0, 0, 4095);
        orchestra.score.addNote (0, 10, 1, 81, 80, 0, 0, 0, 0, 4095);
        orchestra.score.addNote (0, 11, 1, 90, 80, 0, 0, 0, 0, 4095);
        orchestra.score.addNote (1, 0, 13, 0, 0, 0, 0, 0, 0, 0);
        orchestra.renderByWriting (1, 44100, 4, 2, "C:/SchroederTest.wav");
        orchestra.thread.join ();
    }
    catch (Exception x)
    {
      x.printStackTrace ();
    }
  }
  SchroederReverb reverb = new Silence.Orchestra.SchroederReverb ();
  SchroederReverb rightReverb = new Silence.Orchestra.SchroederReverb ();
  int sample = 0;
  int sampleCount = 0;
  public double signal = 0;
  public double rightSignal = 0;
  public SchroederGlobalReverb ()
  {
  }
  public void reset ()
  {
    signal = 0;
    rightSignal = 0;
    sample = 0;
    sampleCount = 0;
    reverb.reset ();
    rightReverb.reset ();
  }
  public void initialize (Timebase timebase)
  {
    this.timebase = timebase;
    reverb.initialize (timebase);
    rightReverb.initialize (timebase);
  }
  public void tick ()
  {
    //System.out.println("Sample: " + sample);
    signal = input.get(0);
    //System.out.println("Pre   : " + signal);
    rightSignal = input.get(1);
    signal = reverb.tick (signal);
    //System.out.println("Post  : " + signal);
    rightSignal = rightReverb.tick (rightSignal);
  }
  public void send()
  {
    output.add(signal, rightSignal);
  }
}
