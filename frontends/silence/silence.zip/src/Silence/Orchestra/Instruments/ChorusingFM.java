package Silence.Orchestra.Instruments;
import Silence.Conversions;
import Silence.Orchestra.Orchestra;
import Silence.Orchestra.Envelope;
import Silence.Orchestra.LinearEnvelope;
import Silence.Orchestra.Event;
import Silence.Orchestra.FunctionTable;
import Silence.Orchestra.InterpolatingPhaseOscillator;
import Silence.Orchestra.StereoInstrument;
import Silence.Orchestra.Timebase;
import cern.jet.math.Bessel;
/**
 * Port of Thomas Kung's Csound instrument.
 * @author Copyright (C) 2000 by Michael Gogins. All rights reserved.
 * <ADDRESS>
 * gogins@pipeline.com
 * </ADDRESS>
 */
public class ChorusingFM extends StereoInstrument
{
  public static void main (String[]args)
  {
    StereoInstrument.test (ChorusingFM.class.getName ());
  }
  public double exponent = -3;
  //      Absolute difference in Hertz.
  public double detune = 1.5;
  double attack = 0.05;
  double decay = 0.07;
  double release = 0.1;
  double duration = 0;
  double frequency = 0;
  double frequency1 = 0;
  double frequency2 = 0;
  double amplitude = 0;
  double octave = 0;
  double leftSignal = 0;
  double rightSignal = 0;
  Envelope envelope = new Envelope ();
  LinearEnvelope indexEnvelope = new LinearEnvelope ();
  LinearEnvelope ratioEnvelope = new LinearEnvelope ();
  InterpolatingPhaseOscillator modulator1 =
    new InterpolatingPhaseOscillator ();
  InterpolatingPhaseOscillator modulator2 =
    new InterpolatingPhaseOscillator ();
  InterpolatingPhaseOscillator carrier1 =
    new InterpolatingPhaseOscillator ();
  InterpolatingPhaseOscillator carrier2 =
    new InterpolatingPhaseOscillator ();
  InterpolatingPhaseOscillator bessel =
    new InterpolatingPhaseOscillator ();
  static FunctionTable lnBessel = new FunctionTable ();
  static
  {
    lnBessel.setSampleCount (8193);
    int i = 0;
    double x = 0;
    double xMax = 20.0;
    double dx = xMax / lnBessel.table.length;
    for (i = 0, x = 0; i < lnBessel.table.length; i++, x += dx)
      {
	lnBessel.table[i] = Math.log (Bessel.i0 (x));
      }
    lnBessel.rescale (1.0);
  }
  public ChorusingFM ()
  {
  }
  public void initialize (Timebase timebase)
  {
    super.initialize (timebase);
    FunctionTable sineWave = FunctionTable.getFunctionTable ("Sine");
    if (sineWave == null)
      {
	sineWave = new FunctionTable ();
	sineWave.setHarmonic (1, 1, 0);
      }
    envelope.initialize (timebase);
    indexEnvelope.initialize (timebase);
    ratioEnvelope.initialize (timebase);
    modulator1.initialize (timebase);
    modulator1.setFunctionTable (sineWave);
    modulator2.initialize (timebase);
    modulator2.setFunctionTable (sineWave);
    carrier1.initialize (timebase);
    carrier1.setFunctionTable (sineWave);
    carrier2.initialize (timebase);
    carrier2.setFunctionTable (sineWave);
    bessel.initialize (timebase);
    bessel.setFunctionTable (lnBessel);
    bessel.setFrequency (1.0);
  }
  public void attack (double[]noteOnEvent)
  {
    super.attack (noteOnEvent);
    amplitude = Event.getGain (noteOnEvent);
    octave = Event.getOctave (noteOnEvent);
    frequency = Event.getFrequency (noteOnEvent);
    frequency1 = Conversions.octaveToHz (octave) + detune;
    frequency2 = Conversions.octaveToHz (octave) - detune;
    duration = Event.getDuration (noteOnEvent);
    attack = duration / 3.0;
    decay = attack;
    release = attack;
    duration = attack + decay + release;
    envelope.setThreeSegments (attack, 1.0, -3, decay, 1.0, -3, release, -3);
    indexEnvelope.setThreeSegments (attack, 5.0, decay, 3.0, release);
    ratioEnvelope.setOneSegment (0.3, duration, 2.2);
    modulator1.setFrequency (frequency);
    modulator2.setFrequency (frequency);
    carrier1.setFrequency (frequency1);
    carrier2.setFrequency (frequency2);
  }
  public void release (double[]noteOffEvent)
  {
    envelope.release ();
    indexEnvelope.release ();
    ratioEnvelope.release ();
  }
  public void tick ()
  {
    if (envelope.finished)
      {
        turnOff();
        return;
      }
    double envelopeSignal = envelope.tick ();
    double indexEnvelopeSignal = indexEnvelope.tick ();
    double ratioEnvelopeSignal = ratioEnvelope.tick ();
    double a1 =
      indexEnvelopeSignal * (ratioEnvelopeSignal -
			     (1.0 / ratioEnvelopeSignal)) / 2.0;
    // a1*2 is argument normalized from 0-1.
    double a1ndx = Math.abs (a1 * 2.0 / 20.0);
    double a2 =
      indexEnvelopeSignal * (ratioEnvelopeSignal +
			     (1.0 / ratioEnvelopeSignal)) / 2.0;
    double a3 = lnBessel.getNormalizedInterpolatedSignal (a1ndx);
    double ao1 = modulator1.tick () * a1;
    double a4 = Math.exp (-0.5 * a3 + ao1);
    double ao2 = modulator2.tick () * a2 * frequency;
    carrier1.setFrequency (ao2 + frequency1);
    double finalEnvelope = amplitude * envelopeSignal * a4 * 0.375;
    leftSignal = carrier1.tick () * finalEnvelope;
    carrier2.setFrequency (ao2 + frequency2);
    rightSignal = carrier2.tick () * finalEnvelope;
    signal = (leftSignal + rightSignal);
  }
}
