package Silence.Orchestra.Instruments;
import Silence.Conversions;
import Silence.Orchestra.StereoInstrument;
import Silence.Orchestra.Orchestra;
import Silence.Orchestra.Timebase;
import Silence.Orchestra.Instruments.PluckedString;
import Silence.Orchestra.SampleFrame;
import Silence.Orchestra.TwoPole;
/**
 * Physical model of a Spanish guitar.
 * A plucked string with 3 2-pole resonant filters to model the body.
 * @author Copyright (C) 2000 by Michael Gogins. All rights reserved.
 * <ADDRESS>
 * gogins@pipeline.com
 * </ADDRESS>
 */
public class SpanishGuitar extends StereoInstrument
{
  public static void main (String[]args)
  {
    StereoInstrument.test (SpanishGuitar.class.getName ());
  }
  PluckedString pluckedString = new PluckedString ();
  TwoPole resonator1 = new TwoPole ();
  TwoPole resonator2 = new TwoPole ();
  TwoPole resonator3 = new TwoPole ();
  public SpanishGuitar ()
  {
  }
  public void initialize (Timebase timebase)
  {
    this.timebase = timebase;
    pluckedString.initialize (timebase);
    resonator1.initialize (timebase);
    resonator1.setFrequencyAndBandwidth (110, 80);
    resonator2.initialize (timebase);
    resonator2.setFrequencyAndBandwidth (220, 100);
    resonator3.initialize (timebase);
    resonator3.setFrequencyAndBandwidth (440, 80);
  }
  public void attack (double[]noteOnEvent)
  {
    this.noteOnEvent = noteOnEvent;
    pluckedString.attack (noteOnEvent);
    leftGain = pluckedString.leftGain;
    rightGain = pluckedString.rightGain;
    resonator1.reset ();
    resonator2.reset ();
    resonator3.reset ();
  }
  public void release (double[]noteOffEvent)
  {
    pluckedString.release (noteOffEvent);
  }
  public void tick () throws SampleFrame.ShapeException
  {
    if (pluckedString.envelope.finished)
      {
        turnOff();
        return;
      }
    double temp = pluckedString.tickOutput ();
      signal  = resonator1.tick (temp) * 0.3;
      signal += resonator2.tick (temp) * 0.3;
      signal += resonator3.tick (temp) * 0.6;
      signal *= 5.0;
  }
}
