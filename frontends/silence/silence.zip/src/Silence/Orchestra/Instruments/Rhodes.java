package Silence.Orchestra.Instruments;
import Silence.Orchestra.FM4Operator;
import Silence.Orchestra.FM4Algorithm5;
import Silence.Orchestra.Event;
import Silence.Orchestra.Envelope;
import Silence.Orchestra.Instrument;
import Silence.Orchestra.Orchestra;
import Silence.Orchestra.StereoInstrument;
import Silence.Orchestra.Timebase;
/**
 * Port of Perry Cook's Rhodey from his STK.
 * @author Copyright (C) 2000 by Michael Gogins. All rights reserved.
 * <ADDRESS>
 * gogins@pipeline.com
 * </ADDRESS>
 */
public class Rhodes extends FM4Algorithm5 implements java.io.Serializable
{
  public static void main (String[]args)
  {
    StereoInstrument.test (Rhodes.class.getName ());
  }
  public int currentSample;
  public int totalSamples;
  public Rhodes ()
  {
  }
  public void initialize (Timebase timebase)
  {
    super.initialize (timebase);
    setRatio (0, 1.0);
    setRatio (1, 0.5006);
    setRatio (2, 0.9993);
    setRatio (3, 15.0);
    gains[0] = operatorGains[99];
    gains[1] = operatorGains[90];
    gains[2] = operatorGains[99];
    gains[3] = operatorGains[67];
    envelope[0].setFourSegments (0.003, -9, 1.0, 5.00, -9, 0.1, 0.01, -9, 0.1,
				 0.07, -9);
    envelope[1].setFourSegments (0.003, -9, 1.0, 5.00, -9, 0.1, 0.01, -9, 0.1,
				 0.07, -9);
    envelope[2].setFourSegments (0.003, -9, 1.0, 1.25, -9, 0.1, 0.01, -9, 0.1,
				 0.07, -9);
    envelope[3].setFourSegments (0.003, -9, 1.0, 0.25, -9, 0.1, 0.01, -9, 0.1,
				 0.07, -9);
    twoZero.setGain (1.0);
  }
  public void attack (double[]noteOnEvent)
  {
    this.noteOnEvent = noteOnEvent;
    double amplitude = Event.getGain (noteOnEvent) * 5.0;
      leftGain = Event.getLeftPan (noteOnEvent);
      rightGain = Event.getLeftPan (noteOnEvent);
      currentSample = 0;
      totalSamples =
      (int) (timebase.audioSampleFramesPerSecond *
	     (Event.getDuration (noteOnEvent) + 0.001));
      gains[0] = amplitude * operatorGains[99];
      gains[1] = amplitude * operatorGains[90];
      gains[2] = amplitude * operatorGains[99];
      gains[3] = amplitude * operatorGains[67];
      envelope[0].reset ();
      envelope[1].reset ();
    double duration = Event.getDuration (noteOnEvent);
    if (duration > 1.293)
      {
	envelope[2].resetSegment (2, 5.043 - 1.293);
      }
    if (duration > 0.293)
      {
	envelope[3].resetSegment (2, 5.043 - 0.293);
      }
    envelope[0].setReleasePoint (duration);
    envelope[1].setReleasePoint (duration);
    envelope[2].setReleasePoint (duration);
    envelope[3].setReleasePoint (duration);
    baseFrequency = Event.getFrequency (noteOnEvent) * 2.0;
    waves[0].setFrequency (baseFrequency * ratios[0]);
    waves[1].setFrequency (baseFrequency * ratios[1]);
    waves[2].setFrequency (baseFrequency * ratios[2]);
    waves[3].setFrequency (baseFrequency * ratios[3]);
  }
  public void release (double[]noteOffEvent)
  {
    envelope[0].release ();
    envelope[1].release ();
    envelope[2].release ();
    envelope[3].release ();
  }
}
