package Silence.Orchestra.Instruments;
import Silence.Conversions;
import Silence.Orchestra.CombFilter;
import Silence.Orchestra.Envelope;
import Silence.Orchestra.FunctionTable;
import Silence.Orchestra.Event;
import Silence.Orchestra.InterpolatingPhaseOscillator;
import Silence.Orchestra.Orchestra;
import Silence.Orchestra.QuadratureOscillator;
import Silence.Orchestra.Timebase;
import Silence.Orchestra.StereoInstrument;
import java.awt.Component;
import javax.swing.*;
/**
 * Uses two phasing frequency modulated oscillators,
 * which are then comb filtered, with a decay envelope.
 * @author Copyright (C) 2000 by Michael Gogins. All rights reserved.
 * <ADDRESS>
 * gogins@pipeline.com
 * </ADDRESS>
 */
public class DynamicFMWithCombFilter extends StereoInstrument
{
  public static void main (String[]args)
  {
    StereoInstrument.test (DynamicFMWithCombFilter.class.getName ());
  }
  public double attack = 0.005;
  public double decay = 7.0;
  public double sustain = 1.0;
  public double sustainLevel = 0.01;
  public double exponent = -10.0;
  public double release = 0.5;
  public double detune1 = 1.002;
  public double detune2 = 0.998;
  public double modulatorRatio = 0.5;
  public double index = 27.5;
  public double amplitude = 1.0;
  public double delay = 0.03;
  public double reverbTime = 0.08;
  double duration;
  double frequency;
  FunctionTable sineWave = null;
  public InterpolatingPhaseOscillator oscillator1 =
    new InterpolatingPhaseOscillator ();
  public InterpolatingPhaseOscillator oscillator2 =
    new InterpolatingPhaseOscillator ();
  public QuadratureOscillator modulator1 = new QuadratureOscillator ();
  public QuadratureOscillator modulator2 = new QuadratureOscillator ();
  Envelope envelope = new Envelope ();
  public CombFilter combFilter = new CombFilter ();
  public DynamicFMWithCombFilter ()
  {
  }
  public void initialize (Timebase timebase)
  {
    super.initialize (timebase);
    sineWave = FunctionTable.getFunctionTable ("Sine");
    if (sineWave == null)
      {
	sineWave = new FunctionTable ();
	sineWave.setHarmonic (1, 1, 0);
	sineWave.rescale (1);
	FunctionTable.setFunctionTable ("Sine", sineWave);
      }
    modulator1.initialize (timebase);
      modulator2.initialize (timebase);
      oscillator1.initialize (timebase);
      oscillator1.setFunctionTable (sineWave);
      oscillator2.initialize (timebase);
      oscillator2.setFunctionTable (sineWave);
      envelope.initialize (timebase);
      combFilter.initialize (timebase);
  }
  public void attack (double[]noteOnEvent)
  {
    super.attack (noteOnEvent);
    duration = Event.getDuration (noteOnEvent);
    envelope.setFourSegments (attack, exponent, 1.0, decay, exponent,
			      sustainLevel, duration, exponent, sustainLevel,
			      release, exponent);
    envelope.setReleasePoint (duration);
    frequency = Event.getFrequency (noteOnEvent);
    amplitude = Event.getGain (noteOnEvent);
    combFilter.setDelay (delay);
    combFilter.setSustain (reverbTime);
    oscillator1.setFrequency (frequency);
    oscillator2.setFrequency (frequency);
    modulator1.setFrequency (frequency * detune1 * modulatorRatio);
    modulator2.setFrequency (frequency * detune2 * modulatorRatio);
  }
  public void release (double[]noteOffEvent)
  {
    envelope.release ();
  }
  public void tick ()
  {
    if (envelope.finished)
      {
        turnOff();
        return;
      }
    double envelopeSignal = envelope.tick ();
    double index = envelopeSignal * this.index * amplitude;
    double modulatorSignal1 = modulator1.tick ();
    double modulatorSignal2 = modulator1.tick ();
    signal = oscillator1.tickPhase (modulatorSignal1 * index);
    signal += oscillator2.tickPhase (modulatorSignal2 * index);
    signal += combFilter.tick (signal * envelopeSignal);
    signal *= (envelopeSignal * amplitude * 1.25);
  }
}
