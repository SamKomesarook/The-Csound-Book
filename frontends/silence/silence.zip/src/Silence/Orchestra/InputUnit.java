package Silence.Orchestra;
/**
Generic input unit in a synchronous data flow graph for signal processing.
Base class for signal consumers.
@author Copyright (C) 2000 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public abstract class InputUnit extends Unit
{
  public InputUnit ()
  {
  }
    /**
   	Consumes one audio sample frame input signal value,
    using the time values in timebase.
    */
  public abstract void tick (double inputSignal);
}
