package Silence.Orchestra;
import Silence.Conversions;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
/**
General-purpose non-interpolating digital oscillator.
@author Copyright (C) 1998, 2000 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class Oscillator extends OutputUnit implements java.io.Serializable
{
  public transient FunctionTable functionTable = null;
  public static void main (String[]args)
  {
    for (int trial = 0; trial < 3; trial++)
      {
	try
	{
	  Timebase timebase = new Timebase ();
	    timebase.audioSampleFramesPerSecond = 44100;
	  WaveSoundfile soundfile = new WaveSoundfile ();
	  FunctionTable functionTable = new FunctionTable ();
	    functionTable.initialize (timebase);
	    functionTable.setHarmonic (1, .001, 0);
	    soundfile.create ("/OscillatorTest.wav", 4, 2, 44100);
	    Oscillator[] tables = new Oscillator[30];
	    System.out.println ("Oscillators: " + tables.length + ".");
	  for (int k = 0; k < tables.length; k++)
	    {
	      Oscillator table = new Oscillator ();
	        table.initialize (timebase);
	        table.setFunctionTable (functionTable);
	        table.setOctave (8.0);
	        tables[k] = table;
	    }
	  double seconds = 10;
	  int sampleCount = (int) (seconds * timebase.audioSampleFramesPerSecond);
	  double began = System.currentTimeMillis ();
	  for (int i = 0; i < sampleCount; i++)
	    {
	      for (int j = 0; j < tables.length; j++)
		{
		  Oscillator oscillator = tables[j];
		    oscillator.tick ();
		    soundfile.input.assign (oscillator.signal, oscillator.signal);
		}
	      soundfile.tickWrite ();
	    }
	  double ended = System.currentTimeMillis ();
	  double elapsed = (ended - began) / 1000.0;
	  System.out.println ("Elapsed " + elapsed + " / Score " + seconds +
			      " = " + elapsed / seconds);
	  soundfile.close ();
	}
	catch (Exception e)
	{
	  e.printStackTrace ();
	}
      }
  }
  public static final int TABLE_PHASE = 0;
  public static final int PHASE = 1;
  public static final int PHASE_INCREMENT = 2;
  public static final int TABLE_INDEX = 3;
  public static final int SAMPLING_INCREMENT = 4;
  public static final int AMPLITUDE = 5;
  public static final int AMPLITUDE_INCREMENT = 6;
  public static final int PAN = 7;
  public static final int PAN_INCREMENT = 8;
  public static final int PARAMETER_COUNT = 9;
  public double frequencyIncrement;
  transient double frequencyAccumulator = 0;
  double cycleCount;
  public Oscillator ()
  {
  }
  public void setFunctionTable (FunctionTable functionTable)
  {
    this.functionTable = functionTable;
  }
  public FunctionTable getFunctionTable ()
  {
    return functionTable;
  }
  /**
   * Advances the sample index by the indicated sampling increment,
   * which must be positive. The sample index is wrapped back
   * after it passes the end of the table.
   */
  public double tick ()
  {
    frequencyAccumulator = frequencyAccumulator + frequencyIncrement;
    while (frequencyAccumulator >= functionTable.sampleCount)
      {
	frequencyAccumulator -= functionTable.sampleCount;
      }
    signal = functionTable.table[(int) frequencyAccumulator];
    return signal;
  }
  public double getBaseHz ()
  {
    return (functionTable.sampleCount /
	    timebase.audioSampleFramesPerSecond) / cycleCount;
  }
  public double getBaseOctave ()
  {
    return Conversions.hzToOctave (getBaseHz ());
  }
  public double getCycleCount ()
  {
    return cycleCount;
  }
  public void setBaseHz (double value)
  {
    double tableHz =
      functionTable.sampleCount / timebase.audioSampleFramesPerSecond;
      setCycleCount (value / tableHz);
  }
  public void setBaseOctave (double value)
  {
    setBaseHz (Conversions.octaveToHz (value));
  }
  public void setCycleCount (double value)
  {
    cycleCount = value;
  }
  public void setFrequency (double frequency)
  {
    frequencyIncrement =
      Conversions.hzToSamplingIncrement (frequency,
					 timebase.audioSampleFramesPerSecond,
					 functionTable.sampleCount /
					 cycleCount);
  }
  public double setOctave (double Octave)
  {
    frequencyIncrement =
      Conversions.octaveToSamplingIncrement (Octave,
					     timebase.audioSampleFramesPerSecond,
					     functionTable.sampleCount /
					     cycleCount);
    return frequencyIncrement;
  }
  public double setMidiKey (double midiKey)
  {
    frequencyIncrement =
      Conversions.midiToSamplingIncrement (midiKey,
					   timebase.audioSampleFramesPerSecond,
					   functionTable.sampleCount /
					   cycleCount);
    return frequencyIncrement;
  }
  public void initialize (Timebase timebase)
  {
    this.timebase = timebase;
    cycleCount = 1.0;
    reset ();
  }
  public void reset ()
  {
    signal = 0.0;
    frequencyAccumulator = 0.0;
  }
}
