package Silence.Orchestra;
import Silence.Global;
import Silence.Score.ScoreView;
import java.awt.*;
import java.io.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.sound.sampled.Mixer;
import javax.sound.sampled.AudioSystem;
/**
Provides a graphical user interface for an Orchestra object.
@author Copyright (C) 2000 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class OrchestraView extends JPanel
{
  public static void main (String[]args)
  {
    OrchestraView orchestraView = new OrchestraView ();
    JFrame jframe = new JFrame (OrchestraView.class.getName ());
      jframe.getContentPane ().add (orchestraView);
      jframe.setBounds (50, 50, 800, 600);
      jframe.setVisible (true);
  }
  public Orchestra orchestra = null;
  BorderLayout borderLayout1 = new BorderLayout ();
  JTabbedPane tabs = new JTabbedPane ();
  JSplitPane arrangementSplitPane = new JSplitPane ();
  JPanel pluginsPanel = new JPanel ();
  JPanel arrangementPanel = new JPanel ();
  JToolBar pluginsToolBar = new JToolBar ();
  JToolBar arrangementToolBar = new JToolBar ();
  BorderLayout borderLayout2 = new BorderLayout ();
  BorderLayout borderLayout3 = new BorderLayout ();
  JButton removeButton = new JButton ();
  JButton addButton = new JButton ();
  JButton downButton = new JButton ();
  JButton upButton = new JButton ();
  JScrollPane pluginsScrollPane = new JScrollPane ();
  JScrollPane arrangmentScrollPane = new JScrollPane ();
  JList pluginsList = new JList ();
  JList arrangementList = new JList ();
  JPanel setupPanel = new JPanel ();
  JPanel formatPanel = new JPanel ();
  TitledBorder titledBorder1;
  JPanel outputsPanel = new JPanel ();
  Border border1;
  TitledBorder titledBorder2;
  JComboBox samplingRateComboBox = new JComboBox ();
  JLabel samplingRateLabel = new JLabel ();
  JLabel ksmpsLabel = new JLabel ();
  JComboBox bytesPerSampleComboBox = new JComboBox ();
  JLabel sampleSizeLabel = new JLabel ();
  JLabel channelsLabel = new JLabel ();
  JComboBox samplesPerControlSampleComboBox = new JComboBox ();
  JComboBox channelsComboBox = new JComboBox ();
  JButton soundfileBrowseButton = new JButton ();
  JTextField soundfileTextField = new JTextField ();
  JCheckBox soundfileOutputEnabledCheckBox = new JCheckBox ();
  JPanel audioOutputPanel = new JPanel ();
  Border border2;
  TitledBorder titledBorder3;
  JCheckBox audioOutputEnabledCheckBox = new JCheckBox ();
  JComboBox audioOutputsComboBox = new JComboBox ();
  JLabel instrumentsLabel = new JLabel ();
  JLabel arrangementLabel = new JLabel ();
  JButton openButton = new JButton ();
  JButton renderButton = new JButton ();
  JButton saveButton = new JButton ();
  JButton playButton = new JButton ();
  JButton newButton = new JButton ();
  JToolBar toolBar = new JToolBar ();
  JButton exitButton = new JButton ();
  JButton saveAsButton = new JButton ();
  public OrchestraView ()
  {
    this (new Orchestra ());
  }
  public OrchestraView (Orchestra orchestra)
  {
    try
    {
      this.orchestra = orchestra;
      samplingRateComboBox.addItem ("96000");
      samplingRateComboBox.addItem ("88200");
      samplingRateComboBox.addItem ("48000");
      samplingRateComboBox.addItem ("44100");
      samplingRateComboBox.addItem ("32000");
      samplingRateComboBox.addItem ("22050");
      samplesPerControlSampleComboBox.addItem ("1");
      samplesPerControlSampleComboBox.addItem ("10");
      samplesPerControlSampleComboBox.addItem ("25");
      samplesPerControlSampleComboBox.addItem ("50");
      samplesPerControlSampleComboBox.addItem ("100");
      samplesPerControlSampleComboBox.addItem ("250");
      samplesPerControlSampleComboBox.addItem ("500");
      samplesPerControlSampleComboBox.addItem ("1000");
      bytesPerSampleComboBox.addItem ("4");
      bytesPerSampleComboBox.addItem ("3");
      bytesPerSampleComboBox.addItem ("2");
      bytesPerSampleComboBox.addItem ("1");
      channelsComboBox.addItem ("1");
      channelsComboBox.addItem ("2");
      channelsComboBox.addItem ("3");
      channelsComboBox.addItem ("4");
      channelsComboBox.addItem ("5");
      channelsComboBox.addItem ("6");
      channelsComboBox.addItem ("7");
      channelsComboBox.addItem ("8");
      jbInit ();
      Mixer.Info[] mixerInfos = AudioSystem.getMixerInfo ();
      for (int i = 0; i < mixerInfos.length; i++)
	{
	  audioOutputsComboBox.addItem (mixerInfos[i]);
	}
      updateView ();
    }
    catch (Exception ex)
    {
      ex.printStackTrace ();
    }
  }
  public void updateView ()
  {
    samplingRateComboBox.
      setSelectedItem (String.valueOf (orchestra.audioSampleFramesPerSecond).trim
		       ());
    samplesPerControlSampleComboBox.
      setSelectedItem (String.valueOf (orchestra.audioSampleFramesPerControlSample).trim
		       ());
    bytesPerSampleComboBox.
      setSelectedItem (String.valueOf (orchestra.bytesPerAudioSample).trim
		       ());
    channelsComboBox.
      setSelectedItem (String.valueOf (orchestra.outputChannelCount).trim ());
    soundfileTextField.setText (orchestra.outputSoundfileName);
    ArrayList instrumentNames = new ArrayList ();
    for (int i = 0, n = orchestra.instruments.size (); i < n; i++)
      {
	Instrument instrument = (Instrument) orchestra.instruments.get (i);
	  instrumentNames.add (instrument.getClass ().getName ());
      }
    arrangementList.setListData (instrumentNames.toArray ());
    audioOutputsComboBox.setSelectedItem (orchestra.mixerInfo);
    soundfileOutputEnabledCheckBox.
      setSelected (orchestra.soundfileOutputEnabled);
    audioOutputEnabledCheckBox.setSelected (orchestra.audioOutputEnabled);
  }
  void jbInit () throws Exception
  {
    titledBorder1 =
      new TitledBorder (BorderFactory.createEtchedBorder (Color.white,
							  new Color (142, 142,
								     142)),
			"Format");
    border1 =
      BorderFactory.createEtchedBorder (Color.white,
					new Color (142, 142, 142));
    titledBorder2 =
      new TitledBorder (BorderFactory.createEtchedBorder (Color.white,
							  new Color (142, 142,
								     142)),
			"Soundfile output");
    border2 =
      BorderFactory.createEtchedBorder (Color.white,
					new Color (142, 142, 142));
    titledBorder3 = new TitledBorder (border2, "Audio output");
    this.setLayout (borderLayout1);
    arrangementSplitPane.setDividerLocation (200);
    arrangementSplitPane.setBorder (null);
    pluginsPanel.setLayout (borderLayout2);
    arrangementPanel.setLayout (borderLayout3);
    removeButton.setText ("  Remove  ");
    removeButton.addActionListener (new java.awt.event.ActionListener ()
				    {
				    public void actionPerformed (ActionEvent
								 e)
				    {
				    removeButton_actionPerformed (e);
				    }
				    }
    );
    addButton.setText ("  Add  ");
    addButton.addActionListener (new java.awt.event.ActionListener ()
				 {
				 public void actionPerformed (ActionEvent e)
				 {
				 addButton_actionPerformed (e);
				 }
				 }
    );
    downButton.setText ("  Down  ");
    downButton.addActionListener (new java.awt.event.ActionListener ()
				  {
				  public void actionPerformed (ActionEvent e)
				  {
				  downButton_actionPerformed (e);
				  }
				  }
    );
    upButton.setText ("  Up  ");
    upButton.addActionListener (new java.awt.event.ActionListener ()
				{
				public void actionPerformed (ActionEvent e)
				{
				upButton_actionPerformed (e);
				}
				}
    );
    arrangementToolBar.setFloatable (false);
    pluginsToolBar.setFloatable (false);
    setupPanel.setLayout (null);
    formatPanel.setBorder (titledBorder1);
    formatPanel.setBounds (new Rectangle (11, 11, 320, 159));
    formatPanel.setLayout (null);
    outputsPanel.setBorder (titledBorder2);
    outputsPanel.setBounds (new Rectangle (11, 178, 320, 90));
    outputsPanel.setLayout (null);
    samplingRateComboBox.setBounds (new Rectangle (201, 21, 107, 26));
    samplingRateComboBox.addActionListener (new java.awt.event.
					    ActionListener ()
					    {
					    public void
					    actionPerformed (ActionEvent e)
					    {
					    samplingRateComboBox_actionPerformed
					    (e);}
					    }
    );
    samplingRateLabel.setText ("Samples per second");
    samplingRateLabel.setBounds (new Rectangle (14, 27, 172, 17));
    ksmpsLabel.setText ("Samples per control sample");
    ksmpsLabel.setBounds (new Rectangle (14, 90, 172, 17));
    bytesPerSampleComboBox.setBounds (new Rectangle (201, 54, 107, 26));
    bytesPerSampleComboBox.addActionListener (new java.awt.
					      event.ActionListener ()
					      {
					      public void
					      actionPerformed (ActionEvent e)
					      {
					      bytesPerSampleComboBox_actionPerformed
					      (e);}
					      }
    );
    sampleSizeLabel.setText ("Bytes per sample");
    sampleSizeLabel.setBounds (new Rectangle (14, 58, 172, 17));
    channelsLabel.setText ("Channels");
    channelsLabel.setBounds (new Rectangle (14, 121, 172, 17));
    samplesPerControlSampleComboBox.setBounds (new
					       Rectangle (201, 87, 107, 26));
    samplesPerControlSampleComboBox.addActionListener (new java.awt.
						       event.ActionListener ()
						       {
						       public void
						       actionPerformed
						       (ActionEvent e)
						       {
						       samplesPerControlSampleComboBox_actionPerformed
						       (e);}
						       }
    );
    channelsComboBox.setBounds (new Rectangle (201, 120, 107, 26));
    channelsComboBox.addActionListener (new java.awt.event.ActionListener ()
					{
					public void
					actionPerformed (ActionEvent e)
					{
					channelsComboBox_actionPerformed (e);
					}
					}
    );
    soundfileBrowseButton.setText ("Browse...");
    soundfileBrowseButton.setBounds (new Rectangle (11, 24, 99, 27));
    soundfileBrowseButton.addActionListener (new java.awt.
					     event.ActionListener ()
					     {
					     public void
					     actionPerformed (ActionEvent e)
					     {
					     soundfileBrowseButton_actionPerformed
					     (e);}
					     }
    );
    soundfileTextField.setEditable (false);
    soundfileTextField.setBounds (new Rectangle (118, 25, 189, 25));
    soundfileOutputEnabledCheckBox.setText ("Enabled");
    soundfileOutputEnabledCheckBox.setBounds (new Rectangle (11, 59, 93, 25));
    soundfileOutputEnabledCheckBox.addActionListener (new java.awt.
						      event.ActionListener ()
						      {

						      public void
						      actionPerformed
						      (ActionEvent e)
						      {
						      soundfileOutputEnabledCheckBox_actionPerformed
						      (e);}
						      }
    );
    audioOutputPanel.setBorder (titledBorder3);
    audioOutputPanel.setBounds (new Rectangle (11, 277, 320, 62));
    audioOutputPanel.setLayout (null);
    audioOutputEnabledCheckBox.setText ("Enabled");
    audioOutputEnabledCheckBox.setBounds (new Rectangle (11, 23, 70, 25));
    audioOutputEnabledCheckBox.addActionListener (new java.awt.
						  event.ActionListener ()
						  {

						  public void
						  actionPerformed (ActionEvent
								   e)
						  {
						  audioOutputEnabledCheckBox_actionPerformed
						  (e);}
						  }
    );
    audioOutputsComboBox.setBounds (new Rectangle (120, 22, 187, 26));
    audioOutputsComboBox.addActionListener (new java.awt.event.
					    ActionListener ()
					    {

					    public void
					    actionPerformed (ActionEvent e)
					    {
					    audioOutputsComboBox_actionPerformed
					    (e);}
					    }
    );
    instrumentsLabel.setText ("  Instruments  ");
    arrangementLabel.setText ("  Arrangement  ");
    openButton.setText ("  Open...  ");
    openButton.addActionListener (new java.awt.event.ActionListener ()
				  {
				  public void actionPerformed (ActionEvent e)
				  {
				  openButton_actionPerformed (e);
				  }
				  }
    );
    renderButton.setText ("  Render / Stop  ");
    renderButton.addActionListener (new java.awt.event.ActionListener ()
				    {
				    public void actionPerformed (ActionEvent
								 e)
				    {
				    renderButton_actionPerformed (e);
				    }
				    }
    );
    saveButton.setText ("  Save  ");
    saveButton.addActionListener (new java.awt.event.ActionListener ()
				  {
				  public void actionPerformed (ActionEvent e)
				  {
				  saveButton_actionPerformed (e);
				  }
				  }
    );
    playButton.setText ("  Play / Stop  ");
    playButton.addActionListener (new java.awt.event.ActionListener ()
				  {
				  public void actionPerformed (ActionEvent e)
				  {
				  playButton_actionPerformed (e);
				  }
				  }
    );
    newButton.setText ("  New  ");
    newButton.addActionListener (new java.awt.event.ActionListener ()
				 {
				 public void actionPerformed (ActionEvent e)
				 {
				 newButton_actionPerformed (e);
				 }
				 }
    );
    toolBar.setFloatable (false);
    exitButton.setText ("  Exit  ");
    exitButton.addActionListener (new java.awt.event.ActionListener ()
				  {
				  public void actionPerformed (ActionEvent e)
				  {
				  exitButton_actionPerformed (e);
				  }
				  }
    );
    saveAsButton.setText ("  Save as...  ");
    saveAsButton.addActionListener (new java.awt.event.ActionListener ()
				    {
				    public void actionPerformed (ActionEvent
								 e)
				    {
				    saveAsButton_actionPerformed (e);
				    }
				    }
    );
    this.add (tabs, BorderLayout.CENTER);
    tabs.add (arrangementSplitPane, "Arrangement");
    arrangementSplitPane.add (pluginsPanel, JSplitPane.LEFT);
    pluginsPanel.add (pluginsToolBar, BorderLayout.NORTH);
    pluginsToolBar.add (instrumentsLabel, null);
    pluginsToolBar.add (addButton, null);
    pluginsToolBar.add (removeButton, null);
    pluginsPanel.add (pluginsScrollPane, BorderLayout.CENTER);
    pluginsScrollPane.getViewport ().add (pluginsList, null);
    arrangementSplitPane.add (arrangementPanel, JSplitPane.RIGHT);
    arrangementPanel.add (arrangementToolBar, BorderLayout.NORTH);
    arrangementToolBar.add (arrangementLabel, null);
    arrangementToolBar.add (upButton, null);
    arrangementToolBar.add (downButton, null);
    arrangementPanel.add (arrangmentScrollPane, BorderLayout.CENTER);
    arrangmentScrollPane.getViewport ().add (arrangementList, null);
    tabs.add (setupPanel, "Setup");
    setupPanel.add (formatPanel, null);
    formatPanel.add (samplingRateLabel, null);
    formatPanel.add (samplingRateComboBox, null);
    formatPanel.add (sampleSizeLabel, null);
    formatPanel.add (ksmpsLabel, null);
    formatPanel.add (channelsLabel, null);
    formatPanel.add (samplesPerControlSampleComboBox, null);
    formatPanel.add (channelsComboBox, null);
    formatPanel.add (bytesPerSampleComboBox, null);
    setupPanel.add (outputsPanel, null);
    outputsPanel.add (soundfileTextField, null);
    outputsPanel.add (soundfileBrowseButton, null);
    outputsPanel.add (soundfileOutputEnabledCheckBox, null);
    setupPanel.add (audioOutputPanel, null);
    audioOutputPanel.add (audioOutputEnabledCheckBox, null);
    audioOutputPanel.add (audioOutputsComboBox, null);
    this.add (toolBar, BorderLayout.NORTH);
    toolBar.add (newButton, null);
    toolBar.add (openButton, null);
    toolBar.add (saveButton, null);
    toolBar.add (saveAsButton, null);
    toolBar.add (renderButton, null);
    toolBar.add (playButton, null);
    toolBar.add (exitButton, null);
  }
  void newButton_actionPerformed (ActionEvent e)
  {
    orchestra.instruments.clear ();
    updateView ();
  }
  void openButton_actionPerformed (ActionEvent e)
  {
    Cursor cursor = getCursor ();
    JFileChooser fileDialog = Global.createFileDialog ("Open");

      fileDialog.addChoosableFileFilter (Global.createFileFilter
					 ("Orchestra files", ".orch"));
    if (fileDialog.showOpenDialog (null) == fileDialog.APPROVE_OPTION)
      {
	setCursor (Cursor.getPredefinedCursor (Cursor.WAIT_CURSOR));
	File file = fileDialog.getSelectedFile ();
	String filename = file.getAbsolutePath ();
	if (filename.endsWith (".orch"))
	  {
	    try
	    {
	      orchestra =
		(Orchestra) orchestra.deserialize (file.getAbsolutePath ());
	      Container container = getParent ();
	        container.remove (this);
	      OrchestraView orchestraView =
		(OrchestraView) orchestra.getView ();
	        container.add (orchestraView);
	        orchestraView.updateView ();
	        container.repaint ();
	    }
	    catch (Exception x)
	    {
	      x.printStackTrace ();
	    }
	  }
      }
    setCursor (cursor);
  }
  void saveButton_actionPerformed (ActionEvent e)
  {
    String filename = orchestra.getName ();
    if (filename.indexOf (".orch") == -1)
      {
	filename += ".orch";
	orchestra.setName (filename);
      }
    try
    {
      orchestra.serialize (filename);
    }
    catch (IOException x)
    {
      x.printStackTrace ();
    }
    catch (IllegalAccessException x)
    {
      x.printStackTrace ();
    }
  }
  void saveAsButton_actionPerformed (ActionEvent e)
  {
    JFileChooser fileDialog = Global.createFileDialog ("Save as");

      fileDialog.addChoosableFileFilter (Global.createFileFilter
					 ("Orchestra files", ".orch"));
    if (fileDialog.showSaveDialog (this) == fileDialog.APPROVE_OPTION)
      {
	File file = fileDialog.getSelectedFile ();
	String filename = file.getAbsolutePath ();
	if (filename.indexOf (".orch") == -1)
	  {
	    filename += ".orch";
	  }
	orchestra.setName (filename);
	try
	{
	  orchestra.serialize (filename);
	}
	catch (Exception x)
	{
	  x.printStackTrace ();
	}
      }
  }
  void renderButton_actionPerformed (ActionEvent e)
  {
    orchestra.stopPlaying ();
    if (orchestra.isRendering ())
      {
	orchestra.stop ();
      }
    else
      {
	orchestra.renderByWriting ();
      }
  }
  void playButton_actionPerformed (ActionEvent e)
  {
    if (orchestra.isPlaying ())
      {
	orchestra.stopPlaying ();
      }
    else
      {
	orchestra.play ();
      }
  }
  void exitButton_actionPerformed (ActionEvent e)
  {
    System.exit (0);
  }
  void addButton_actionPerformed (ActionEvent e)
  {
    try
    {
      Object instrumentName = pluginsList.getSelectedValue ();
      if (instrumentName != null)
	{
	  Class clazz = Class.forName (instrumentName.toString ());
	  Instrument instrument = (Instrument) clazz.newInstance ();
	  int selectedIndex = arrangementList.getSelectedIndex ();
	  if (selectedIndex == -1)
	    {
	      selectedIndex = 0;
	    }
	  orchestra.instruments.add (selectedIndex, instrument);
	  updateView ();
	  arrangementList.setSelectedIndex (selectedIndex);
	}
    }
    catch (Exception x)
    {
      x.printStackTrace ();
    }
  }
  void removeButton_actionPerformed (ActionEvent e)
  {
    int selectedIndex = arrangementList.getSelectedIndex ();
    if (selectedIndex != -1)
      {
	orchestra.instruments.remove (selectedIndex);
	updateView ();
	arrangementList.setSelectedIndex (selectedIndex);
      }
  }
  void upButton_actionPerformed (ActionEvent e)
  {
    int selectedIndex = arrangementList.getSelectedIndex ();
    if (selectedIndex < 1 || arrangementList.getModel ().getSize () < 2)
      {
	return;
      }
    Object original = orchestra.instruments.get (selectedIndex);
    Object higher = orchestra.instruments.get (selectedIndex - 1);
    orchestra.instruments.set (selectedIndex, higher);
    orchestra.instruments.set (selectedIndex - 1, original);
    updateView ();
    arrangementList.setSelectedIndex (selectedIndex - 1);
  }
  void downButton_actionPerformed (ActionEvent e)
  {
    int selectedIndex = arrangementList.getSelectedIndex ();
    int size = arrangementList.getModel ().getSize ();
    if (size < 2 || selectedIndex < 0 || selectedIndex > size - 2)
      {
	return;
      }
    Object original = orchestra.instruments.get (selectedIndex);
    Object lower = orchestra.instruments.get (selectedIndex + 1);
    orchestra.instruments.set (selectedIndex, lower);
    orchestra.instruments.set (selectedIndex + 1, original);
    updateView ();
    arrangementList.setSelectedIndex (selectedIndex + 1);
  }
  void samplingRateComboBox_actionPerformed (ActionEvent e)
  {
    orchestra.audioSampleFramesPerSecond = Integer.parseInt (samplingRateComboBox.getSelectedItem ().toString ());
  }
  void bytesPerSampleComboBox_actionPerformed (ActionEvent e)
  {
    orchestra.bytesPerAudioSample = Integer.parseInt (bytesPerSampleComboBox.getSelectedItem ().toString ());
  }
  void samplesPerControlSampleComboBox_actionPerformed (ActionEvent e)
  {
    orchestra.audioSampleFramesPerControlSample = Integer.parseInt (samplesPerControlSampleComboBox.getSelectedItem ().toString ());
  }
  void channelsComboBox_actionPerformed (ActionEvent e)
  {
    orchestra.outputChannelCount = Integer.parseInt (channelsComboBox.getSelectedItem ().toString ());
  }
  void soundfileBrowseButton_actionPerformed (ActionEvent e)
  {
    JFileChooser fileDialog = Global.createFileDialog ("Save as");
      fileDialog.addChoosableFileFilter (Global.createFileFilter
					 ("Soundfiles", ".wav"));
      fileDialog.setSelectedFile (new File (orchestra.outputSoundfileName));
    if (fileDialog.showSaveDialog (this) == fileDialog.APPROVE_OPTION)
      {
	File file = fileDialog.getSelectedFile ();
	String filename = file.getAbsolutePath ();
	if (filename != null)
	  {
	    orchestra.outputSoundfileName = filename;
	    updateView ();
	  }
      }
  }
  void audioOutputsComboBox_actionPerformed (ActionEvent e)
  {
    Object selection = audioOutputsComboBox.getSelectedItem ();
    if (selection != null)
      {
	orchestra.mixerInfo = (Mixer.Info) selection;
      }
  }
  void soundfileOutputEnabledCheckBox_actionPerformed (ActionEvent e)
  {
    orchestra.soundfileOutputEnabled =
      soundfileOutputEnabledCheckBox.isSelected ();
  }
  void audioOutputEnabledCheckBox_actionPerformed (ActionEvent e)
  {
    orchestra.audioOutputEnabled = audioOutputEnabledCheckBox.isSelected ();
  }
  public void setModel (Orchestra orchestra)
  {
    this.orchestra = orchestra;
    pluginsList.setModel (orchestra.instrumentPlugins);
  }
}
