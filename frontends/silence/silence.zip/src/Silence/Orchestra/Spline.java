package Silence.Orchestra;
import Silence.Mathematics.Matrix;
import java.awt.Component;
import java.util.ArrayList;
import javax.swing.JFrame;
import ptolemy.plot.Plot;
/**
A forward-differencing spline generator.
The cubic curves can be set explicitly,
or as Bezier curves.
@author Copyright (C) 2000 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class Spline extends Unit
{
  public static void main (String[]args)
  {
    JFrame jframe = new JFrame (Spline.class.getName ());
    Spline spline = new Spline ();
      spline.addBezier (0, 0, 0, 0, 0, .75, 1, 1);
      spline.addBezier (1, 1, 1, .23, 40, 0, 4, 0);
    Component view = spline.getView ();
      jframe.getContentPane ().add (view);
      jframe.setBounds (50, 50, 600, 480);
      jframe.setVisible (true);
  }
  ArrayList curveList = new ArrayList ();
  public final static double[][] bezierBasis = Matrix.create (4, 4);
  static
  {
    bezierBasis[0][0] = -1;
    bezierBasis[0][1] = 3;
    bezierBasis[0][2] = -3;
    bezierBasis[0][3] = 1;
    bezierBasis[1][0] = 3;
    bezierBasis[1][1] = -6;
    bezierBasis[1][2] = 3;
    //bezierBasis[1][3] =  0;
    bezierBasis[2][0] = -3;
    bezierBasis[2][1] = 3;
    //bezierBasis[2][2] =  0;
    //bezierBasis[2][3] =  0;
    bezierBasis[3][0] = 1;
    //bezierBasis[3][1] =  0;
    //bezierBasis[3][2] =  0;
    //bezierBasis[3][3] =  0;
  }
	/**
	The parametic equation is the cubic polynomial
 	f(t) = a * t^3 + b * t^2 + c * t + d.
  	The equation is 3-dimensional to allow simpler use of matrices,
   	but only 2 dimensions are used.
   	*/ public class CubicCurve2D
  {
    int n = 1000;
    double duration = 0;
    double cumulativeDuration = 0;
    public double[][] coefficients = Matrix.create (4, 3);
    public double[][] differences = Matrix.create (4, 3);
    public CubicCurve2D ()
    {
    }
    public void setCurve (double ax, double bx, double cx, double dx,
			  double ay, double by, double cy, double dy)
    {
      coefficients[0][0] = ax;
      coefficients[1][0] = bx;
      coefficients[2][0] = cx;
      coefficients[3][0] = dx;
      coefficients[0][1] = ay;
      coefficients[1][1] = by;
      coefficients[2][1] = cy;
      coefficients[3][1] = dy;
    }
    public void setBezier (double end1x, double end1y, double control1x,
			   double control1y, double control2x,
			   double control2y, double end2x, double end2y)
    {
      double[][] bezierGeometry = Matrix.create (4, 3);
        bezierGeometry[0][0] = end1x;
        bezierGeometry[0][1] = end1y;
        bezierGeometry[0][2] = 0;
        bezierGeometry[1][0] = control1x;
        bezierGeometry[1][1] = control1y;
        bezierGeometry[1][2] = 0;
        bezierGeometry[2][0] = control2x;
        bezierGeometry[2][1] = control2y;
        bezierGeometry[2][2] = 0;
        bezierGeometry[3][0] = end2x;
        bezierGeometry[3][1] = end2y;
        bezierGeometry[3][2] = 0;
        Matrix.times (coefficients, bezierBasis, bezierGeometry);
    }
    public double[] evaluate (double x)
    {
      double[] t = new double[4];
        t[3] = 1;
        t[2] = x;
        t[1] = t[2] * x;
        t[0] = t[1] * x;
        return Matrix.times (t, coefficients);
    }
    public void findDifferences ()
    {
      double delta = 1.0 / n;
      double deltaSquared = delta * delta;
      double deltaCubed = deltaSquared * delta;
        differences[0][0] = coefficients[3][0];

        differences[1][0] =
	coefficients[0][0] * deltaCubed + coefficients[1][0] * deltaSquared +
	coefficients[2][0] * delta;
        differences[2][0] =
	6 * coefficients[0][0] * deltaCubed +
	2 * coefficients[1][0] * deltaSquared;
        differences[3][0] = 6 * coefficients[0][0] * deltaCubed;
        differences[0][1] = coefficients[3][1];

        differences[1][1] =
	coefficients[0][1] * deltaCubed + coefficients[1][1] * deltaSquared +
	coefficients[2][1] * delta;
        differences[2][1] =
	6 * coefficients[0][1] * deltaCubed +
	2 * coefficients[1][1] * deltaSquared;
        differences[3][1] = 6 * coefficients[0][1] * deltaCubed;
    }
    public void tick ()
    {
      differences[0][0] += differences[1][0];
      differences[1][0] += differences[2][0];
      differences[2][0] += differences[3][0];
      differences[0][1] += differences[1][1];
      differences[1][1] += differences[2][1];
      differences[2][1] += differences[3][1];
    }
  }
  public class View extends Plot
  {
    public View ()
    {
      CubicCurve2D cubicCurve2D;
        Object[] curves = curveList.toArray ();
      for (int i = 0; i < curves.length; i++)
	{
	  cubicCurve2D = (CubicCurve2D) curves[i];
	  cubicCurve2D.findDifferences ();
	  for (int j = 0; j < cubicCurve2D.n; j++)
	    {
	      cubicCurve2D.tick ();
	      //System.out.println("" + j + "=" + cubicCurve2D.differences[0][0] + "," + cubicCurve2D.differences[0][1]);
	      addPoint (i, cubicCurve2D.differences[0][0],
			cubicCurve2D.differences[0][1], true);
	    }
	}
    }
  }
  public Spline ()
  {
  }
  public void addCurve (double ax, double bx, double cx, double dx, double ay,
			double by, double cy, double dy)
  {
    CubicCurve2D cubicCurve2D = new CubicCurve2D ();
      cubicCurve2D.setCurve (ax, bx, cx, dx, ay, by, cy, dy);
      curveList.add (cubicCurve2D);
  }
  public void addBezier (double end1x, double end1y, double control1x,
			 double control1y, double control2x, double control2y,
			 double end2x, double end2y)
  {
    CubicCurve2D cubicCurve2D = new CubicCurve2D ();

      cubicCurve2D.setBezier (end1x, end1y, control1x, control1y, control2x,
			      control2y, end2x, end2y);
      curveList.add (cubicCurve2D);
  }
  public void tick ()
  {
  }
  public Component getView ()
  {
    return new View ();
  }
}
