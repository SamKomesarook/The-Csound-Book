package Silence.Orchestra;
/**
Generic output unit in a synchronous data flow graph for signal processing.
Base class for oscillators and other signal producers.
@author Copyright (C) 2000 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public abstract class OutputUnit extends Unit
{
  public OutputUnit ()
  {
  }
    /**
    Computes one audio sample frame signal value
    using the time values in the timebase,
    and returns the signal value.
    */
  public abstract double tick ();
}
