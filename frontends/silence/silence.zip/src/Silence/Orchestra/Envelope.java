package Silence.Orchestra;
import java.awt.Container;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JTabbedPane;
import ptolemy.plot.Plot;
/**
A multiple-breakpoint exponential envelope generator.
Breakpoints are specified as quadruples: {{amplitude1, duration1, exponent1, amplitude2},...}.
Positive exponents produce convex lines.
Exponents of 0 produce straight lines.
Negative exponents produce concave lines (more like acoustic instruments).
Amplitudes and durations of 0 are allowed.
The envelope can release itself (jump to its final segment),
or be released by a release event, to support real-time instruments.
The curves are computed by forward differencing.
@author Copyright (C) 2000 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class Envelope extends OutputUnit
{
  public static void main (String[]args)
  {
    JFrame jframe = new JFrame (Envelope.class.getName ());
    JTabbedPane tabs = new JTabbedPane ();
    Envelope envelope = new Envelope ();
    Timebase timebase = new Timebase ();
      envelope.initialize (timebase);
      envelope.setFourSegments (.1, -5, 1, .4, -5, .25, .3, -5, .125, .1, -5);
      envelope.setReleasePoint (.6);
      tabs.addTab ("Initial", envelope.getView ());
      envelope.resetSegment (1, .2);
      tabs.addTab ("Reset segment", envelope.getView ());
      envelope.reset ();
      tabs.addTab ("Reset envelope", envelope.getView ());
      jframe.getContentPane ().add (tabs);
      jframe.setBounds (50, 50, 500, 500);
      jframe.setVisible (true);
  }
  public boolean released = true;
  public boolean finished = true;
  public ArrayList segments = new ArrayList ();
  transient Segment currentSegment = null;
  int currentSegmentIndex = 0;
  int segmentCount = 0;
  int i = 0;
  int releasePoint = -1;
  public class Segment
  {
    public double duration;
    int n1;
    int n2;
    public double y1;
    public double y2;
    public double e;
    public double d;
    public double dd;
    public double f;
    public double y;
    public Segment ()
    {
    }
    public void setSegment (double amplitude1, double duration,
			    double exponent, double amplitude2)
    {
      y1 = amplitude1;
      this.duration = duration;
      e = exponent;
      y2 = amplitude2;
      reset ();
    }
    public void reset ()
    {
      n2 = n1 + timebase.getSampleCount (duration);
      if (e == 0)
	{
	  f = 1;
	}
      else
	{
	  f = (Math.exp (e) - 1) / e;
	}
      if (y2 != y1)
	{
	  d = (y2 - y1) / (n2 - n1);
	  dd = 1 + e * d / (y2 - y1);
	}
      else
	{
	  d = 0;
	  dd = 0;
	}
      y = 0;
    }
    public double tick ()
    {
      i++;
      y += d;
      d *= dd;
      return y1 + y / f;
    }
  }
  public Envelope ()
  {
  }
  public void clear ()
  {
    segments.clear ();
  }
  public void addSegment (double amplitude1, double duration, double exponent,
			  double amplitude2)
  {
    Segment segment = new Segment ();
      segment.setSegment (amplitude1, duration, exponent, amplitude2);
      segments.add (segment);
  }
  public void resetSegment (int index, double duration)
  {
    Segment segment = (Segment) segments.get (index);
      segment.duration = duration;
      reset ();
  }
    /**
     * Recomputes all internal parameters for running.
     */
  public void reset ()
  {
    segmentCount = segments.size ();
    double cumulativeTime = 0;
    if (segmentCount > 0)
      {
	for (currentSegmentIndex = 0; currentSegmentIndex < segmentCount;
	     currentSegmentIndex++)
	  {
	    currentSegment = (Segment) segments.get (currentSegmentIndex);
	    currentSegment.n1 = timebase.getSampleCount (cumulativeTime);
	    currentSegment.reset ();
	    cumulativeTime += currentSegment.duration;
	  }
	currentSegmentIndex = 0;
	currentSegment = (Segment) segments.get (currentSegmentIndex);
	signal = currentSegment.y1;
      }
    i = 0;
    released = false;
    finished = false;
  }
    /**
     * Returns one output signal sample frame.
     * If a release point has been set, releases the envelope
     * when the audio sample frame has advanced to the release point.
     */
  public double tick ()
  {
    if (finished)
      {
	return signal;
      }
    if (i == releasePoint)
      {
	release ();
      }
    if (i < currentSegment.n2)
      {
	signal = currentSegment.tick ();
      }
    else
      {
	currentSegmentIndex++;
	if (currentSegmentIndex < segmentCount)
	  {
	    currentSegment = (Segment) segments.get (currentSegmentIndex);
	    signal = currentSegment.tick ();
	  }
	else
	  {
	    finished = true;
	  }
      }
    return signal;
  }
	/**
   	Causes the final segment to begin immediately from the current amplitude
    and audio sample frame.
    */
  public void release ()
  {
    currentSegmentIndex = segmentCount - 1;
    currentSegment = (Segment) segments.get (currentSegmentIndex);
    currentSegment.y1 = signal;
    currentSegment.n1 = i;
    currentSegment.reset ();
    released = true;
  }
  public Container getView ()
  {
    Plot plot = new Plot ();
      reset ();
    int sampleIndex = 0;
    while (!released)
      {
	if ((sampleIndex % 50) == 0.0)
	  {
	    plot.addPoint (currentSegmentIndex,
			   sampleIndex *
			   timebase.secondsPerAudioSampleFrame, signal, true);
	  }
	tick ();
	sampleIndex++;
      }
    return plot;
  }
  public void setBreakpoints (double[]breakpoints)
  {
    clear ();
    double lastAmplitude = 0;
    for (int i = 0; i <= breakpoints.length; i += 3)
      {
	addSegment (lastAmplitude, breakpoints[i], breakpoints[i + 1],
		    breakpoints[i + 2]);
	lastAmplitude = breakpoints[i + 2];
      }
    reset ();
  }
  public void setOneSegment (double amplitude1, double duration1,
			     double exponent1, double amplitude2)
  {
    clear ();
    addSegment (amplitude1, duration1, exponent1, amplitude2);
    reset ();
  }
  public void setTwoSegments (double amplitude1, double duration1,
			      double exponent1, double amplitude2,
			      double duration2, double exponent2,
			      double amplitude3)
  {
    clear ();
    addSegment (amplitude1, duration1, exponent1, amplitude2);
    addSegment (amplitude2, duration2, exponent2, amplitude3);
    reset ();
  }
  public void setTwoSegments (double duration1, double exponent1,
			      double amplitude2, double duration2,
			      double exponent2)
  {
    clear ();
    addSegment (0, duration1, exponent1, amplitude2);
    addSegment (amplitude2, duration2, exponent2, 0);
    reset ();
  }
  public void setThreeSegments (double amplitude1, double duration1,
				double exponent1, double amplitude2,
				double duration2, double exponent2,
				double amplitude3, double duration3,
				double exponent3, double amplitude4)
  {
    clear ();
    addSegment (amplitude1, duration1, exponent1, amplitude2);
    addSegment (amplitude2, duration2, exponent2, amplitude3);
    addSegment (amplitude3, duration3, exponent3, amplitude4);
    reset ();
  }
  public void setThreeSegments (double duration1, double exponent1,
				double amplitude2, double duration2,
				double exponent2, double amplitude3,
				double duration3, double exponent3)
  {
    clear ();
    addSegment (0, duration1, exponent1, amplitude2);
    addSegment (amplitude2, duration2, exponent2, amplitude3);
    addSegment (amplitude3, duration3, exponent3, 0);
    reset ();
  }
  public void setFourSegments (double amplitude1, double duration1,
			       double exponent1, double amplitude2,
			       double duration2, double exponent2,
			       double amplitude3, double duration3,
			       double exponent3, double amplitude4,
			       double duration4, double exponent4,
			       double amplitude5)
  {
    clear ();
    addSegment (amplitude1, duration1, exponent1, amplitude2);
    addSegment (amplitude2, duration2, exponent2, amplitude3);
    addSegment (amplitude3, duration3, exponent3, amplitude4);
    addSegment (amplitude4, duration4, exponent4, amplitude5);
    reset ();
  }
  public void setFourSegments (double duration1, double exponent1,
			       double amplitude2, double duration2,
			       double exponent2, double amplitude3,
			       double duration3, double exponent3,
			       double amplitude4, double duration4,
			       double exponent4)
  {
    clear ();
    addSegment (0, duration1, exponent1, amplitude2);
    addSegment (amplitude2, duration2, exponent2, amplitude3);
    addSegment (amplitude3, duration3, exponent3, amplitude4);
    addSegment (amplitude4, duration4, exponent4, 0);
    reset ();
  }
	/**
     * Sets a time at which, if still playing,
     * the envelope will trigger its own release.
     * Useful, with approximately a 0.06 second release time,
     * for modeling instruments with unchanging decay rates
     * but variable note lengths, such as xylophones or guitars.
     */
  public void setReleasePoint (double time)
  {
    releasePoint = (int) Math.round (timebase.getSampleCount (time));
  }
}
