package Silence.Orchestra;
import Silence.Conversions;
import java.awt.Container;
import java.io.*;
import java.util.*;
/**
 * WAV soundfile reading, writing, and mixing in musical units.
 * Supports:
 * <ul>
 * <li>Unsigned 8 bit integer (1 byte) samples.</li>
 * <li>Signed 16 bit integer (2 byte) samples.</li>
 * <li>Signed 24 bit integer (3 byte) samples.</li>
 * <li>32-bit floating point (4 byte) samples.</li>
 * </ul>
 * The recommended practice is to use float samples for all purposes except
 * final mastering to 16 bit samples for consumer formats.
 * <p>
 * Note that all signals in Silence lie in the range from -1.0 to +1.0 (normalized);
 * such signals are automatically rescaled, just before writing and just after reading
 * in WaveSoundfile, relative to the maximum value of the format,
 * for example -32767.0 to +32767.0 for 16 bit PCM soundfiles.
 * @author Copyright (C) 1998, 2000 by Michael Gogins. All rights reserved.
 * <ADDRESS>
 * gogins@pipeline.com
 * </ADDRESS>
 */
public class WaveSoundfile extends SignalFlowUnit
{
    public static void main (String[]args)
    {
	try
	    {
              int test = 2;
              if(test == 1)
              {
		for (int trial = 0; trial < 3; trial++)
		    {
			Test.start
			    ("WaveSoundfile stereo write 1 minute 16 bit stereo samples");
			WaveSoundfile waveSoundfile = new WaveSoundfile ();
			waveSoundfile.create ("/16BitTest.wav", 2, 2, 44100);
			int sampleCount = waveSoundfile.seekSeconds (0, 60);
			for (int i = 0; i < sampleCount; i++)
			    {
				waveSoundfile.input.assign(1, 2);
				waveSoundfile.tickWrite ();
			    }
			waveSoundfile.close ();
			Test.stop ();
			System.out.println ("Ratio = " + Test.elapsed / 60.0);
			Test.start ("WaveSoundfile stereo write 1 minute float stereo samples");
			waveSoundfile = new WaveSoundfile ();
			waveSoundfile.create ("/floatTest.wav", 4, 2, 44100);
			sampleCount = waveSoundfile.seekSeconds (0, 60);
			for (int i = 0; i < sampleCount; i++)
			    {
				waveSoundfile.input.assign(1, 2);
				waveSoundfile.tickWrite ();
			    }
			waveSoundfile.close ();
			Test.stop ();
			System.out.println ("Ratio = " + Test.elapsed / 60.0);
			Timebase timebase = new Timebase ();
			timebase.initialize (1, 48000, 4, 2);
			FunctionTable sine = new FunctionTable ();
			sine.setHarmonic (1, 1, 0);
			InterpolatingPhaseOscillator interpolatingPhaseOscillator =
			    new InterpolatingPhaseOscillator ();
			interpolatingPhaseOscillator.initialize (timebase);
			interpolatingPhaseOscillator.setFunctionTable (sine);
			interpolatingPhaseOscillator.setFrequency (440.0);
			int n = 0;
			int i = 0;
			double signal = 0;
			waveSoundfile.create ("/OscillatorFloatTest.wav", 4, 2, 48000);
			n = waveSoundfile.seekSeconds (0, 1);
			for (i = 0; i < n; i++)
			    {
				signal = interpolatingPhaseOscillator.tick ();
				waveSoundfile.input.assign(signal);
				waveSoundfile.tickWrite ();
			    }
			waveSoundfile.close ();
			waveSoundfile.create ("/Oscillator24BitTest.wav", 3, 2, 48000);
			n = waveSoundfile.seekSeconds (0, 1);
			for (i = 0; i < n; i++)
			    {
				signal = interpolatingPhaseOscillator.tick ();
				waveSoundfile.input.assign(signal);
				waveSoundfile.tickWrite ();
			    }
			waveSoundfile.close ();
			waveSoundfile.create ("/Oscillator16BitTest.wav", 2, 2, 48000);
			n = waveSoundfile.seekSeconds (0, 1);
			for (i = 0; i < n; i++)
			    {
				signal = interpolatingPhaseOscillator.tick ();
				waveSoundfile.input.assign(signal);
				waveSoundfile.tickWrite ();
			    }
			waveSoundfile.close ();
			waveSoundfile.create ("/8BitTest.wav", 1, 2, 48000);
			n = waveSoundfile.seekSeconds (0, 1);
			for (i = 0; i < n; i++)
			    {
				signal = interpolatingPhaseOscillator.tick ();
				waveSoundfile.input.assign(signal);
				waveSoundfile.tickWrite ();
			    }
			waveSoundfile.close ();
		    }
                }
                else if(test == 2)
                {
                  System.out.println("BEGAN testing soundfile reading and writing.");
                  WaveSoundfile reader = new WaveSoundfile();
                  reader.open("/home/mkg/PhaseVocoderInput.wav");
                  WaveSoundfile writer = new WaveSoundfile();
                  writer.create("/home/mkg/PhaseVocoderOutput.wav", 4, 1, reader.getSamplingRate());
                  int sampleCount = reader.seekSeconds(0, 9);
                  for(int i = 0; i < sampleCount; i++)
                  {
                    reader.tickRead();
                    writer.input.assign(reader.output);
                    writer.tickWrite();
                  }
                  reader.close();
                  writer.close();
                  System.out.println("ENDED testing soundfile reading and writing.");
              }
	    }
	catch (Exception x)
	    {
		x.printStackTrace ();
	    }
    }
    public static final double NORMAL_TO_EIGHT_BIT = Math.pow (2.0, 7) - 1;
    public static final double EIGHT_BIT_TO_NORMAL = 1.0 / NORMAL_TO_EIGHT_BIT;
    public static final double NORMAL_TO_SIXTEEN_BIT = Math.pow (2.0, 15) - 1;
    public static final double SIXTEEN_BIT_TO_NORMAL =
	1.0 / NORMAL_TO_SIXTEEN_BIT;
    public static final double NORMAL_TO_TWENTY_FOUR_BIT =
	Math.pow (2.0, 23) - 1;
    public static final double TWENTY_FOUR_BIT_TO_NORMAL =
	1.0 / NORMAL_TO_TWENTY_FOUR_BIT;
    public WaveSoundfile ()
    {
	initialize ();
    }
    transient RandomAccessFile randomAccessFile;
    transient byte[] dataBuffer;
    transient float[] floatBuffer;
    transient double[][] signalBuffer;
    transient int signalBufferFrameIndex;
    transient int signalBufferChannelIndex;
    transient static int signalBufferFrameCount = 16384;
    transient double sampleBuffer;
    /**
     *  RIFF file chunk data.
     */
    transient int currentPosition;
    transient int currentChunkID;
    transient int buffer4Bytes;
    transient int currentChunkSize;
    transient int formChunkPosition;
    transient static int formChunkID = 0x52494646;
    transient int formChunkSize;
    transient static int formType = 0x57415645;
    /**
     *  WAVEFORMAT.
     */
    transient int formatChunkPosition;
    transient static int formatChunkID = 0x666d7420;
    transient int formatChunkSize;
    transient short formatFormatTag;
    short formatChannelCount;
    int formatSamplingRateHz;
    transient int formatSecondSize;
    transient short formatSampleFrameSize;
    short formatSampleBitCount;
    transient int dataChunkPosition;
    /**
     * Data chunk.
     */
    transient static int dataChunkID = 0x64617461;
    transient int dataChunkSize;
    transient int dataOffset;
    public void initialize ()
    {
	dataOffset = dataChunkPosition + 8;
	formatSampleFrameSize =
	    (short) (formatSampleBitCount / 8 * formatChannelCount);
	formatSecondSize = formatSampleFrameSize * formatSamplingRateHz;
	if (formatSampleBitCount < 32)
	    {
		formatFormatTag = 1;
	    }
	//#define  WAVE_FORMAT_IEEE_FLOAT 0x0003  /*  Microsoft Corporation  */
	//                            /*  IEEE754: range (+1, -1]  */
	//                            /*  32-bit/64-bit format as defined by */
	//                            /*  MSVC++ float/double type */
	else
	    {
		formatFormatTag = 3;
	    }
	signalBuffer = new double[signalBufferFrameCount][formatChannelCount];
	signalBufferFrameIndex = 0;
	int dataBufferSize =
	    signalBufferFrameCount * formatChannelCount * formatSampleBitCount / 8;
	dataBuffer = new byte[dataBufferSize];
    }
    public boolean open (String Filename)
    {
	try
	    {
		name = Filename;
		randomAccessFile = new RandomAccessFile (name, "rw");
		readHeader ();
		initialize ();
                input.resize(formatChannelCount);
                output.resize(formatChannelCount);
		seekSeconds (0.0);
	    }
	catch (java.io.IOException e)
	    {
		return false;
	    }
	return true;
    }
  public boolean create (String Filename, int SampleSize, int ChannelCount,
			 int SamplesHz)
  {
    try
    {
      name = Filename;
      File file = new File (name);
      if (file.exists ())
	{
	  if (!file.delete ())
	    {
	      System.out.println ("Failed to delete file: " +
				  file.getAbsolutePath ());
	    }
	}
      randomAccessFile = new RandomAccessFile (name, "rw");
      formatSampleBitCount = (short) (SampleSize * 8);
      formatChannelCount = (short) ChannelCount;
      formatSamplingRateHz = SamplesHz;
      initialize ();
      input.resize(formatChannelCount);
      output.resize(formatChannelCount);
      writeHeader ();
      seekFrames (0);
    }
    catch (java.io.IOException e)
    {
      System.out.println ("Exception in WaveSoundfile.create: " +
			  e.getMessage ());
      e.printStackTrace ();
      return false;
    }
    return true;
  }
  public void close ()
  {
    try
    {
      flush ();
      randomAccessFile.close ();
    }
    catch (java.io.IOException e)
    {
    }
  }
  public void flush () throws java.io.IOException
  {
    writeSignalBuffer (signalBufferFrameIndex);
    for (int i = 0; i < signalBufferFrameCount; i++)
      {
	for (int j = 0; j < formatChannelCount; j++)
	  {
	    signalBuffer[i][j] = 0.;
	  }
      }
    writeHeader ();
  }
  void readHeader () throws java.io.IOException
  {
    randomAccessFile.seek (0);
    buffer4Bytes = randomAccessFile.readInt ();
    if (buffer4Bytes != formChunkID)
      {
	throw new java.io.IOException ("Not a RIFF file.");
      }
    formChunkSize = Conversions.swapInt (randomAccessFile.readInt ());
    buffer4Bytes = randomAccessFile.readInt ();
    if (buffer4Bytes != formType)
      {
	throw new java.io.IOException ("Not a WAV form.");
      }
    buffer4Bytes = randomAccessFile.readInt ();
    if (buffer4Bytes != formatChunkID)
      {
	throw new java.io.IOException ("Not a fmt chunk.");
      }
    formatChunkSize = Conversions.swapInt (randomAccessFile.readInt ());
    formatFormatTag = Conversions.swapShort (randomAccessFile.readShort ());
    formatChannelCount =
      Conversions.swapShort (randomAccessFile.readShort ());
    formatSamplingRateHz = Conversions.swapInt (randomAccessFile.readInt ());
    formatSecondSize = Conversions.swapInt (randomAccessFile.readInt ());
    formatSampleFrameSize =
      Conversions.swapShort (randomAccessFile.readShort ());
    formatSampleBitCount =
      Conversions.swapShort (randomAccessFile.readShort ());
    dataChunkPosition = tell ();
    buffer4Bytes = randomAccessFile.readInt ();
    if (buffer4Bytes != dataChunkID)
      {
	throw new java.io.IOException ("Not a data chunk.");
      }
    dataChunkSize = Conversions.swapInt (randomAccessFile.readInt ());
    dataOffset = tell ();
  }
  public void writeHeader () throws java.io.IOException
  {
    currentPosition = tell ();
    randomAccessFile.seek (0);
    randomAccessFile.writeInt (formChunkID);
    formChunkSize = ((int) randomAccessFile.length ()) - tell () - 4;
    randomAccessFile.writeInt (Conversions.swapInt (formChunkSize));
    randomAccessFile.writeInt (formType);
    randomAccessFile.writeInt (formatChunkID);
    randomAccessFile.writeInt (Conversions.swapInt (16));
    randomAccessFile.writeShort (Conversions.swapShort (formatFormatTag));
    randomAccessFile.writeShort (Conversions.swapShort (formatChannelCount));
    randomAccessFile.writeInt (Conversions.swapInt (formatSamplingRateHz));
    randomAccessFile.writeInt (Conversions.swapInt (formatSecondSize));
    randomAccessFile.writeShort (Conversions.
				 swapShort (formatSampleFrameSize));
    randomAccessFile.writeShort (Conversions.
				 swapShort (formatSampleBitCount));
    dataChunkPosition = tell ();
    randomAccessFile.writeInt (dataChunkID);
    dataChunkSize = ((int) randomAccessFile.length ()) - tell () - 4;
    if (dataChunkSize < 0)
      {
	dataChunkSize = 0;
      }
    randomAccessFile.writeInt (Conversions.swapInt (dataChunkSize));
    dataOffset = tell ();
    seek (currentPosition);
  }
  public boolean createSilence (double DurationSeconds)
  {
    try
    {
      byte[]temporaryDataBuffer = new byte[dataBuffer.length];
      int frameCount = seekSeconds (0, DurationSeconds);
      int sampleCount = frameCount * formatSampleFrameSize;
      int bufferCount = sampleCount / dataBuffer.length;
      for (int bufferIndex = 0; bufferIndex < bufferCount; ++bufferIndex)
	{
	  randomAccessFile.write (temporaryDataBuffer);
	}
    }
    catch (java.io.IOException e)
    {
      return false;
    }
    return true;
  }
  public int getSampleSize ()
  {
    return (int) (formatSampleBitCount / 8);
  }
  public void setSampleSize(int byteCount)
  {
    formatSampleBitCount = (short) (byteCount * 8);
  }
  public int getChannelCount ()
  {
    return formatChannelCount;
  }
  public void setChannelCount(int channelCount)
  {
    formatChannelCount = (short) channelCount;
  }
  public int getSamplingRate ()
  {
    return (int) formatSamplingRateHz;
  }
  public void setSamplingRate (int samplingRateHz)
  {
    formatSamplingRateHz = samplingRateHz;
  }
  public int getSampleFrameSize ()
  {
    return formatSampleFrameSize;
  }
  public void seek (int Position) throws java.io.IOException
  {
    randomAccessFile.seek (Position);
  }
  public int tell () throws java.io.IOException
  {
    return (int) randomAccessFile.getFilePointer ();
  }
  public void readSignalBuffer () throws java.io.IOException
  {
    int i;
    int j;
    int k = 0;
    int frameCount;
    int intBuffer;
    long longBuffer;
    long length = randomAccessFile.length ();
    long position = randomAccessFile.getFilePointer ();
    int bytesAvailable = (int) (length - position);
    if (bytesAvailable < dataBuffer.length)
      {
	frameCount = bytesAvailable / formatSampleFrameSize;
      }
    else
      {
	frameCount = signalBufferFrameCount;
	bytesAvailable = dataBuffer.length;
      }
    int bytesRead = randomAccessFile.read (dataBuffer, 0, bytesAvailable);
    if (formatSampleBitCount == 16)
      {
	for (i = 0; i < frameCount; i++)
	  {
	    for (j = 0; j < formatChannelCount; j++)
	      {
		intBuffer =   (0x000000ff & dataBuffer[k++]);
		intBuffer += ((0x000000ff & dataBuffer[k++]) << 8);
		signalBuffer[i][j] = intBuffer * SIXTEEN_BIT_TO_NORMAL;
	      }
	  }
	for (; i < signalBufferFrameCount; i++)
	  {
	    for (j = 0; j < formatChannelCount; j++)
	      {
		signalBuffer[i][j] = 0.;
	      }
	  }
      }
    else if (formatSampleBitCount == 24)
      {
	for (i = 0; i < frameCount; i++)
	  {
	    for (j = 0; j < formatChannelCount; j++)
	      {
		intBuffer = (0x000000ff & dataBuffer[k++]);
		intBuffer += ((0x000000ff & dataBuffer[k++]) << 8);
		intBuffer += ((0x000000ff & dataBuffer[k++]) << 16);
		signalBuffer[i][j] = intBuffer * TWENTY_FOUR_BIT_TO_NORMAL;
	      }
	  }
	for (; i < signalBufferFrameCount; i++)
	  {
	    for (j = 0; j < formatChannelCount; j++)
	      {
		signalBuffer[i][j] = 0.;
	      }
	  }
      }
    else if (formatSampleBitCount == 32)
      {
	for (i = 0; i < frameCount; i++)
	  {
	    for (j = 0; j < formatChannelCount; j++)
	      {
		intBuffer =   (0x000000ff & dataBuffer[k++]);
		intBuffer += ((0x000000ff & dataBuffer[k++]) << 8);
		intBuffer += ((0x000000ff & dataBuffer[k++]) << 16);
		intBuffer += ((0x000000ff & dataBuffer[k++]) << 24);
		signalBuffer[i][j] = Float.intBitsToFloat (intBuffer);
	      }
	  }
	for (; i < signalBufferFrameCount; i++)
	  {
	    for (j = 0; j < formatChannelCount; j++)
	      {
		signalBuffer[i][j] = 0.;
	      }
	  }
      }
    else if (formatSampleBitCount == 8)
      {
	for (i = 0; i < frameCount; i++)
	  {
	    for (j = 0; j < formatChannelCount; j++)
	      {
		signalBuffer[i][j] =
		  ((0x000000ff & dataBuffer[k++]) * EIGHT_BIT_TO_NORMAL) -
		  1.0;
	      }
	  }
	for (; i < signalBufferFrameCount; i++)
	  {
	    for (j = 0; j < formatChannelCount; j++)
	      {
		signalBuffer[i][j] = 0.;
	      }
	  }
      }
    signalBufferFrameIndex = 0;
  }
  public void writeSignalBuffer (int FrameCount) throws java.io.IOException
  {
    int i;
    int j;
    int k = 0;
    int intBuffer;
    long longBuffer;
    if (formatSampleBitCount == 16)
      {
	for (i = 0; i < FrameCount; i++)
	  {
	    for (j = 0; j < formatChannelCount; j++)
	      {
		intBuffer =
		  (int) (signalBuffer[i][j] * NORMAL_TO_SIXTEEN_BIT);
		dataBuffer[k++] = (byte) (intBuffer & 0x000000ff);
		dataBuffer[k++] = (byte) ((intBuffer & 0x0000ff00) >> 8);
	      }
	  }
      }
    else if (formatSampleBitCount == 24)
      {
	for (i = 0; i < FrameCount; i++)
	  {
	    for (j = 0; j < formatChannelCount; j++)
	      {
		intBuffer =
		  (int) (signalBuffer[i][j] * NORMAL_TO_TWENTY_FOUR_BIT);
		dataBuffer[k++] = (byte) (intBuffer & 0x000000ff);
		dataBuffer[k++] = (byte) ((intBuffer & 0x0000ff00) >> 8);
		dataBuffer[k++] = (byte) ((intBuffer & 0x00ff0000) >> 16);
	      }
	  }
      }
    else if (formatSampleBitCount == 32)
      {
	for (i = 0; i < FrameCount; i++)
	  {
	    for (j = 0; j < formatChannelCount; j++)
	      {
		intBuffer = Float.floatToIntBits ((float) signalBuffer[i][j]);
		dataBuffer[k++] = (byte)  (intBuffer & 0x000000ff);
		dataBuffer[k++] = (byte) ((intBuffer & 0x0000ff00) >> 8);
		dataBuffer[k++] = (byte) ((intBuffer & 0x00ff0000) >> 16);
		dataBuffer[k++] = (byte) ((intBuffer & 0xff000000) >> 24);
	      }
	  }
      }
    else if (formatSampleBitCount == 8)
      {
	for (i = 0; i < FrameCount; i++)
	  {
	    for (j = 0; j < formatChannelCount; j++)
	      {
		dataBuffer[k++] =
		  (byte) ((signalBuffer[i][j] + 1.0) * NORMAL_TO_EIGHT_BIT);
	      }
	  }
      }
    randomAccessFile.write (dataBuffer, 0, k);
    signalBufferFrameIndex = 0;
  }
  public int tellFrames () throws java.io.IOException
  {
    return dataOffset + tell () / formatSampleFrameSize;
  }
  public void seekFrames (int SampleFrameIndex) throws java.io.IOException
  {
    int position =
      (dataChunkPosition + 8) + (SampleFrameIndex * formatSampleFrameSize);
      seek (position);
      readSignalBuffer ();
      //seek (position);
      currentPosition = position;
  }
  public double tellSeconds () throws java.io.IOException
  {
    return tellFrames () / formatSamplingRateHz;
  }
  public void seekSeconds (double StartSeconds) throws java.io.IOException
  {
    int frames = (int) (StartSeconds * formatSamplingRateHz);
      seekFrames (frames);
  }
  public int seekSeconds (double StartSeconds,
			  double DurationSeconds) throws java.io.IOException
  {
    seekSeconds (StartSeconds);
    return (int) (DurationSeconds * formatSamplingRateHz);
  }
  public double getSignal (int ChannelIndex)
  {
    return signalBuffer[signalBufferFrameIndex][ChannelIndex];
  }
  public void setSignal (int ChannelIndex, double Amplitude)
  {
    signalBuffer[signalBufferFrameIndex][ChannelIndex] = Amplitude;
  }
  public void mixSignal (int ChannelIndex, double Amplitude)
  {
    sampleBuffer = getSignal (ChannelIndex);
    setSignal (ChannelIndex, sampleBuffer + Amplitude);
  }
  public void tickRead () throws java.io.IOException
  {
    signalBufferFrameIndex++;
    if (signalBufferFrameIndex >= signalBufferFrameCount)
      {
	readSignalBuffer ();
      }
    for(int i = 0; i < formatChannelCount; i++)
    {
      output.signal[i] = signalBuffer[signalBufferFrameIndex][i];
    }
  }
  public void tickRead (SampleFrame output) throws java.io.IOException
  {
    tickRead ();
    for (int i = 0; i < output.signal.length; i++)
    {
      output.signal[i] = getSignal(i);
    }
  }
  public void tickWrite () throws java.io.IOException
  {
    for (int i = 0; i < input.signal.length; i++)
    {
      signalBuffer[signalBufferFrameIndex][i] = input.signal[i];
    }
    signalBufferFrameIndex++;
    if (signalBufferFrameIndex >= signalBufferFrameCount)
      {
	writeSignalBuffer (signalBufferFrameCount);
      }
  }
  public void tickMix () throws java.io.IOException
  {
    signalBufferFrameIndex++;
    if (signalBufferFrameIndex >= signalBufferFrameCount)
      {
	seek (currentPosition);
	writeSignalBuffer (signalBufferFrameCount);
	currentPosition = tell ();
	readSignalBuffer ();
      }
  }
  public void tickWrite(SampleFrame output) throws IOException
  {
    for (int i = 0; i < output.signal.length; i++)
    {
      setSignal (i, output.signal[i]);
    }
    tickWrite();
  }
  public void tickMix(SampleFrame output) throws IOException
  {
    for (int i = 0; i < output.signal.length; i++)
    {
      setSignal (i, getSignal(i) + output.signal[i]);
    }
    tickMix();
  }
  /**
   * If this has sources, writes from the input to the soundfile;
   * if this has no sources, writes to the output from the soundfile.
   */
  public void tick()
  {
    try
    {
      if(sources.isEmpty())
      {
        tickRead (output);
      }
      else
      {
        tickWrite (input);
      }
    }
    catch (Exception x)
    {
      x.printStackTrace();
    }
  }
  protected void finalize ()
  {
    close ();
  }
  /**
   * If this has sources, creates a soundfile for output;
   * if this has no sources, opens a soundfile for input.
   */
  public void open()
  {
    boolean returnValue = false;
    if(sources.isEmpty())
    {
      returnValue = open(name);
    }
    else
    {
      returnValue = create(name, formatSampleBitCount / 8, formatChannelCount, timebase.audioSampleFramesPerSecond);
    }
  }
  public Container getView()
  {
    return new WaveSoundfileView(this);
  }
  /**
   * Returns whether the internal sample frame pointer
   * is positioned at or beyond the physical end of the file.
   */
  public boolean eof()
  {
    try
    {
      long position = randomAccessFile.getFilePointer();
      long length = randomAccessFile.length();
      if((position < length) && (position >= 0))
      {
        return false;
      }
      position = currentPosition + (signalBufferFrameIndex * formatSampleFrameSize);
      if(position < length)
      {
        return false;
      }
    }
    catch(IOException x)
    {
      x.printStackTrace();
    }
    return true;
  }
}

