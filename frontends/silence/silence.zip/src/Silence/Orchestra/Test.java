package Silence.Orchestra;
import java.io.*;
import java.lang.reflect.*;
/**
Simple generic test and timing facility.
@author Copyright (C) 2000 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class Test
{
  static long startedAt = 0;
  static long stoppedAt = 0;
  static String message = null;
  public static double elapsed = 0;
  public Test ()
  {
  }
  public static void start (String m)
  {
    message = m;
    System.out.println ("BEGAN TESTING: " + message + "...");
    startedAt = System.currentTimeMillis ();
  }
  public static void stop ()
  {
    stoppedAt = System.currentTimeMillis ();
    elapsed = ((double) (stoppedAt - startedAt)) / 1000.0;
    System.out.println ("ENDED TESTING: " + message + ".");
    System.out.println ("               Elapsed " + elapsed + " seconds.");
  }
	/**
	The argument is serialized to a stream,
	deserialized from the stream, and returned
	for comparison to the original.
	*/
  public static Serializable serializationTest (Serializable serializable)
  {
    System.out.println ("BEGAN serialization test for: " +
			serializable.getClass ().getName () + "...");
    spill (serializable, false);
    try
    {
      ByteArrayOutputStream byteArrayOutputStream =
	new ByteArrayOutputStream ();
      ObjectOutputStream objectOutputStream =
	new ObjectOutputStream (byteArrayOutputStream);
        objectOutputStream.writeObject (serializable);
        objectOutputStream.flush ();
        objectOutputStream.close ();
        objectOutputStream = null;
        byte[] buffer = byteArrayOutputStream.toByteArray ();

        System.out.println ("Size of serialized stream in bytes: " +
			    buffer.length + ".");
      ByteArrayInputStream byteArrayInputStream =
	new ByteArrayInputStream (buffer);
      ObjectInputStream objectInputStream =
	new ObjectInputStream (byteArrayInputStream);
      Serializable newObject = (Serializable) objectInputStream.readObject ();
        spill (newObject, false);

        System.out.println ("PASSED serialization test for: " +
			    serializable.getClass ().getName () + ".");
        return newObject;
    }
    catch (IOException x)
    {
      x.printStackTrace ();
      System.out.println ("FAILED serialization test for: " +
			  serializable.getClass ().getName () + ".");
    }
    catch (ClassNotFoundException x)
    {
      x.printStackTrace ();
      System.out.println ("FAILED serialization test for: " +
			  serializable.getClass ().getName () + ".");
    }
    return null;
  }
	/**
	Prints, optionally recursively, the string representation of each field
	of the argument object.
	*/
  public static void spill (Object object, boolean deepSpill)
  {
    Class clazz = object.getClass ();
      try
    {
      System.out.println ("BEGAN spilling: " + clazz.getName () + "...");
      Field[] fields = clazz.getDeclaredFields ();
      for (int i = 0; i < fields.length; i++)
	{
	  Field field = fields[i];
	    field.setAccessible (true);
	    System.out.print (field.getName ());
	    System.out.print (" = ");
	  Object value = field.get (object);
	  if (value == null)
	    {
	      System.out.print ("null");
	    }
	  else
	    {
	      Class valueClazz = field.getType ();
	      if (valueClazz.isPrimitive () || valueClazz == Object.class)
		{
		  System.out.print (value.toString ());
		}
	      else
		{
		  if (deepSpill)
		    {
		      spill (value, deepSpill);
		    }
		  else
		    {
		      System.out.print (value.toString ());
		    }
		}
	    }
	  System.out.println ();
	}
    }
    catch (IllegalAccessException x)
    {
      x.printStackTrace ();
    }
    System.out.println ("ENDED spilling: " + clazz.getName () + ".");
  }
}
