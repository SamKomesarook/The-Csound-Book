package Silence.Orchestra;
import Silence.Conversions;
import java.io.Serializable;
import java.util.*;
/**
Data shared by signal processing units in a software synthesizer;
includes audio sample frame rate, output channel count, and the signal buss.
Each Unit object in an Orchestra must contain a reference
to the same Timekeeper object.
@author Copyright (C) 2000 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class Timekeeper implements Serializable
{
  public int audioSampleFramesPerControlSample = 100;
  public int audioSampleFramesPerSecond = 44100;
  public double secondsPerAudioSampleFrame;
  public double secondsPerControlSample;
	/**
  	For JavaSound and soundfile output.
  	*/
  public int bytesPerAudioSample = 2;
  public int outputChannelCount = 2;
  public int currentControlSample;
  public double currentTime;
	/**
   	Signal buss, two channels by default.
   	By convention, the first N channels of the buss go to the audio outputs,
    for example, the first 2 channels of the buss go to the stereo audio outputs.
    If the buss is set to a larger size, the higher channels can be used
    as an arbitrary patch matrix for routing signals. Note that
    instruments in the Orchestra instrument list are processed in strict
    list index order.
   	*/
  public Sample[] buss = new Sample[0];
	/**
   	Buffer used for transferring the buss output channel signal values
    to a JavaSound data line.
   	*/
  transient byte[] dataLineBuffer = new byte[0];
	/**
    Initializes the timekeeper, creates a buss, and computes all time value,
    using default time values.
    */
  public void initialize ()
  {
    initialize (audioSampleFramesPerSecond, audioSampleFramesPerControlSample,
		outputChannelCount);
  }
  public Timekeeper ()
  {
    initialize ();
  }
	/**
    Initializes the timekeeper, creates a buss, and computes all time values.
    */ public void initialize (int audioSampleFramesPerControlSample,
			       int audioSampleFramesPerSecond,
			       int bytesPerAudioSample,
			       int outputChannelCount)
  {
    this.bytesPerAudioSample = bytesPerAudioSample;
    initialize (audioSampleFramesPerSecond, audioSampleFramesPerControlSample,
		outputChannelCount);
  }
	/**
    Initializes the timekeeper, creates a buss, and computes all time values.
    */
  public void initialize (int audioSampleFramesPerSecond,
			  int audioSampleFramesPerControlSample,
			  int outputChannelCount)
  {
    this.audioSampleFramesPerSecond = audioSampleFramesPerSecond;
    secondsPerAudioSampleFrame = 1.0 / this.audioSampleFramesPerSecond;
    this.audioSampleFramesPerControlSample =
      audioSampleFramesPerControlSample;
    secondsPerControlSample =
      secondsPerAudioSampleFrame * this.audioSampleFramesPerControlSample;
    this.outputChannelCount = outputChannelCount;
    if (buss.length <= outputChannelCount)
      {
	setBussChannelCount (outputChannelCount);
      }
    resetBuss ();
      start ();
  }
  public void setBussChannelCount (int count)
  {
    buss = new Sample[count];
    for (int i = 0; i < count; i++)
      {
	buss[i] = new Sample ();
      }
  }
	/**
   	Returns the number of sample channels in the buss.
  	*/
  public int getBussChannelCount ()
  {
    return buss.length;
  }
    /**
   	Resets the time
    and the control sample index to zero,
    and resets the buss.
    */
  public void start ()
  {
    currentTime = 0;
    currentControlSample = 0;
    for (int i = 0; i < buss.length; i++)
      {
	buss[i].reset ();
      }
  }
	/**
  	Advances the control sample index,
   	and returns the current time in seconds,
    using the current time values.
   	*/
  public void nextControlSample ()
  {
    currentControlSample++;
    currentTime = currentControlSample * secondsPerControlSample;
  }
	/**
  	Resets the current signal values in the buss to zero.
	*/ public void resetBuss ()
  {
    for (int i = 0; i < buss.length; i++)
      {
	buss[i].signal = 0;
      }
  }
  public int getAudioSampleFrameSize ()
  {
    return bytesPerAudioSample * outputChannelCount;
  }
  public boolean areSimultaneous (double[]a, double[]b)
  {
    double deltaTime = Math.abs (Event.getTime (a) - Event.getTime (b));
    if (deltaTime <= secondsPerAudioSampleFrame)
      {
	return true;
      }
    else
      {
	return false;
      }
  }
  public boolean areOverlapping (double[]a, double[]b)
  {
    double overlap = 0;
      overlap = Event.getTime (b) - (Event.getTime (a) + Event.getDuration (a));
    if (overlap > secondsPerAudioSampleFrame)
      {
	return true;
      }
    overlap = Event.getTime (a) - (Event.getTime (b) + Event.getDuration (b));
    if (overlap > secondsPerAudioSampleFrame)
      {
	return true;
      }
    return false;
  }
	/**
    Returns the angular frequency in radians for the indicated frequency
    in Hertz, using the current time values.
    */
  public double getAngularFrequency (double frequency)
  {
    return Conversions.TWO_PI * frequency / audioSampleFramesPerSecond;
  }
    /**
   	Returns the number of audio sample frames for the indicated duration in seconds,
    using the current time values.
    */
  public int getSampleCount (double duration)
  {
    return (int) Math.round (duration * audioSampleFramesPerSecond);
  }
}
