package Silence.Orchestra;
import Silence.Conversions;
import java.awt.Container;
import java.util.ArrayList;
import java.util.TreeMap;
import java.util.Iterator;
import javax.swing.JFrame;
import javax.swing.JPanel;
import ptolemy.plot.Plot;
/**
General-purpose oscillator base class.
@author Copyright (C) 2000 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class FunctionTable extends OutputUnit
{
  public static void main (String[]args)
  {
    JFrame jframe = new JFrame ("Silence.FunctionTable");
    FunctionTable functionTable = new FunctionTable ();
    int partial = 1;
    for (partial = 1; partial <= 15; partial++)
      {
	functionTable.setHarmonic (partial, 1.0 / partial, 0);
      }
    jframe.getContentPane ().add (functionTable.getView ());
      jframe.setBounds (50, 50, 400, 400);
      jframe.setVisible (true);
  }
  public static final int DEFAULT_SAMPLE_COUNT = 16384;
  protected int sampleCount = 0;
  public double[] table = null;
  transient double maximum = 0;
  transient double minimum = 0;
  transient double sumAmplitudes = 0;
	/**
    Global table of named function tables.
    */
  public static TreeMap tables;
  static
  {
    tables = new TreeMap ();
  }
  public static FunctionTable getFunctionTable (String name)
  {
    return (FunctionTable) tables.get (name);
  }
  public static void setFunctionTable (String name,
				       FunctionTable functionTable)
  {
    tables.put (name, functionTable);
  }
  public FunctionTable (int sampleCount)
  {
    setSampleCount (sampleCount);
  }
  public FunctionTable ()
  {
    defaultsFunctionTable ();
  }
  public void defaultsFunctionTable ()
  {
    setSampleCount (DEFAULT_SAMPLE_COUNT);
  }
  public int getSampleCount ()
  {
    return sampleCount;
  }
  public void setSampleCount (int value)
  {
    sampleCount = value;
    table = new double[sampleCount + 1];
      reset ();
  }
  public void zero ()
  {
    if (table == null)
      {
	setSampleCount (DEFAULT_SAMPLE_COUNT);
      }
    for (int i = 0; i < table.length; i++)
      {
	table[i] = 0;
      }
  }
  public void findScale ()
  {
    double sumAmplitudes = 0;
      maximum = Double.MIN_VALUE;
      minimum = Double.MAX_VALUE;
    for (int i = 0; i < table.length; i++)
      {
	if (table[i] > maximum)
	  {
	    maximum = table[i];
	  }
	if (table[i] < minimum)
	  {
	    minimum = table[i];
	  }
	sumAmplitudes += table[i];
      }
  }
  public double getMinimum ()
  {
    return minimum;
  }
  public double getMaximum ()
  {
    return maximum;
  }
  public double getRange ()
  {
    return maximum - minimum;
  }
  public void rescale (double MaximumAmplitude)
  {
    findScale ();
    double meanAmplitude = sumAmplitudes / ((double) table.length);
    double move = 0.0 - meanAmplitude;
      minimum += move;
      maximum += move;
    double rescaleFactor;
    if (Math.abs (maximum) > Math.abs (minimum))
      {
	rescaleFactor = MaximumAmplitude / Math.abs (maximum);
      }
    else
      {
	rescaleFactor = MaximumAmplitude / Math.abs (minimum);
      }
    for (int i = 0; i < table.length; i++)
      {
	table[i] += move;
	table[i] *= rescaleFactor;
      }
  }
  public double getSignal (double index)
  {
    return table[(int) index];
  }
  public double getInterpolatedSignal (double index)
  {
    int indexFloor = (int) index;
    int indexCeiling = indexFloor + 1;
    double indexAboveFloor = index - ((double) indexFloor);
      return table[indexFloor] + (table[indexCeiling] - table[indexFloor]) * indexAboveFloor;
  }
  public double getNormalizedInterpolatedSignal (double index)
  {
    index = index / (double) sampleCount;
    while (index < 0)
      {
	index += sampleCount;
      }
    while (index > sampleCount)
      {
	index -= sampleCount;
      }
    int indexFloor = (int) index;
    int indexCeiling = indexFloor + 1;
    double indexAboveFloor = index - ((double) indexFloor);
    return table[indexFloor] + (table[indexCeiling] -
				table[indexFloor]) * indexAboveFloor;
  }
  public void setSignal (int index, double value)
  {
    table[index] = value;
  }
	/**
	Useful for Fourier synthesis.
	*/
  public void setHarmonic (double partial, double amplitude, double phase)
  {
    double angularFrequency = Conversions.TWO_PI * partial;
    for (int i = 0; i <= sampleCount; i++)
      {
	table[i] +=
	  amplitude * Math.sin ((angularFrequency * i / sampleCount) + phase);
      }
  }
  public void setHarmonics (double[]coefficients)
  {
    zero ();
    int i;
    int j;
    int n = coefficients.length;
    for (i = 0; i < n; i = i + 3)
      {
	setHarmonic (coefficients[i], coefficients[i + 1],
		     coefficients[i + 2]);
      }
  }
  public Container getView ()
  {
    Plot plot = new Plot ();
    for (int i = 0; i < table.length; i++)
      {
	plot.addPoint (0, i, table[i], true);
      }
    return plot;
  }
  public double tick ()
  {
    System.out.println (getClass ().getName () + ".tick() not implemented.");
    return Double.NaN;
  }
}
