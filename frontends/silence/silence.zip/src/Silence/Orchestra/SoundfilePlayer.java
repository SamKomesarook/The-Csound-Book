package Silence.Orchestra;
import java.io.*;
import javax.sound.sampled.*;
/**
   General-purpose soundfile player class.
   Plays a soundfile in a separate thread using the default javax.media.sound.sampled.Mixer.
   @author Copyright (C) 2000 by Michael Gogins. All rights reserved.
   <ADDRESS>
   gogins@pipeline.com
   </ADDRESS>
*/
public class SoundfilePlayer implements Runnable
{
    String filename = null;
    boolean keepPlaying = false;
    transient Thread thread = new Thread ();
    public SoundfilePlayer ()
    {
    }
    public void open (String filename)
    {
	this.filename = filename;
    }
    public void close ()
    {
	stop ();
    }
    public boolean isPlaying ()
    {
	return thread.isAlive ();
    }
    public synchronized void start ()
    {
	//System.out.println ("BEGAN SoundfilePlayer.start()...");
	stop ();
	thread = new Thread (this);
	thread.start ();
	//System.out.println ("ENDED SoundfilePlayer.start().");
    }
    public void pause ()
    {
	thread.suspend ();
    }
    public void stop ()
    {
	//System.out.println ("BEGAN SoundfilePlayer.halt()...");
	keepPlaying = false;
	try
	    {
		thread.interrupt ();
		if (thread.isAlive ())
		    {
			thread.join (500);
		    }
	    }
	catch (InterruptedException x)
	    {
		x.printStackTrace ();
	    }
	//System.out.println ("BEGAN SoundfilePlayer.halt().");
    }
    /**
     * The playing thread routine.
     * It gets an AudioInputStream from the soundfile,
     * gets the AudioFormat of the stream,
     * gets a SourceDataLine of that format from the default system mixer,
     * creates an audio buffer,
     * opens and starts the SourceDataLine,
     * and goes into a loop reading audio data from the stream and writing it to the line,
     * until the stream is at end of file, or stop() is called.
     */
    public void run ()
    {
	//System.out.println ("BEGAN SoundfilePlayer.run()...");
	try
	    {
		File file = new File (filename);
		if (file == null)
		    {
			System.out.println
			    ("Silence.Orchestra.SoundfilePlayer.run(): No File for " +
			     filename + ".");
			return;
		    }
		AudioInputStream audioInputStream =
		    AudioSystem.getAudioInputStream (file);
		if (audioInputStream == null)
		    {
			System.out.println
			    ("Silence.Orchestra.SoundfilePlayer.run(): No AudioInputStream.");
			return;
		    }
		AudioFormat audioFormat = audioInputStream.getFormat ();
		if (audioFormat == null)
		    {
			System.out.println
			    ("Silence.Orchestra.SoundfilePlayer.run(): No AudioFormat.");
			return;
		    }
		audioInputStream.reset ();
		System.out.println ("Soundfile format: " + audioFormat.toString ());
		int sampleFrameSize = audioFormat.getFrameSize ();
		int inputSize = 8192 * sampleFrameSize;
		DataLine.Info dataLineInfo =
		    new DataLine.Info (SourceDataLine.class, audioFormat);
		SourceDataLine sourceDataLine =
		    (SourceDataLine) AudioSystem.getLine (dataLineInfo);
		if (sourceDataLine == null)
		    {
			System.out.println
			    ("Silence.Orchestra.SoundfilePlayer.run(): No SourceDataLine.");
		    }
		sourceDataLine.open (audioFormat, inputSize);
		int bufferSize = sourceDataLine.getBufferSize ();
		byte[]buffer = new byte[bufferSize];
		System.out.println ("Input buffer size:  " + inputSize);
		System.out.println ("Output buffer size: " + bufferSize);
		System.out.println
		    ("Silence.Orchestra.SoundfilePlayer.run(): Began playing.");
		int bytesRead = 0;
		sourceDataLine.start ();
		keepPlaying = true;
		while (keepPlaying)
		    {
			bytesRead = audioInputStream.read (buffer, 0, inputSize);
			if (bytesRead == -1)
			    {
				break;
			    }
			int bytesWritten = sourceDataLine.write (buffer, 0, bufferSize);
		    }
		sourceDataLine.drain ();
		sourceDataLine.stop ();
		sourceDataLine.close ();
		sourceDataLine = null;
		audioInputStream.close ();
		audioInputStream = null;
		System.out.println
		    ("Silence.Orchestra.SoundfilePlayer.run(): Ended playing.");
	    }
	catch (java.io.FileNotFoundException e)
	    {
		e.printStackTrace ();
	    }
	catch (javax.sound.sampled.UnsupportedAudioFileException e)
	    {
		e.printStackTrace ();
	    }
	catch (javax.sound.sampled.LineUnavailableException e)
	    {
		e.printStackTrace ();
	    }
	catch (java.io.IOException e)
	    {
		e.printStackTrace ();
	    }
	//System.out.println ("ENDED SoundfilePlayer.run().");
    }
    protected void finalize ()
    {
	close ();
    }
}
