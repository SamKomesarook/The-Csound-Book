package Silence.Orchestra;
/**
Generic input/output unit in a synchronous data flow graph for signal processing.
Base class for filters and other classes that both consume and produce signals.
@author Copyright (C) 2000 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public abstract class InputOutputUnit extends Unit
{
  public InputOutputUnit ()
  {
  }
    /**
    Consumes one audio sample frame input signal value,
    processes it using the time values
    in the timebase, and returns the resulting output signal value.
    */
  public abstract double tick (double inputSignal);
}
