package Silence.Orchestra;
import Silence.Conversions;
import Silence.Mathematics.Maths;
import java.io.*;
/**
Isoperceptual grains are Hanning-windowed cosine waves whose phases
are rounded off as if the cosine waves always began at time 0 with phase 0,
and whose times are rounded off so that successive grains overlap at the
half-amplitude point. These constraints minimize perceptual artifacts,
such as tremolo, clicking, and smearing,
otherwise caused by mixing together large numbers of grains.
<p>
Isoperceptual grains are useful for rendering various fractal systems into
a time/frequency representation of sound in a musically transparent manner.
<p>
This class can render grains into memory soundfiles for high performance,
or into disk soundfiles for longer duration.
@author Copyright (C) 1998 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class IsoperceptualGrain extends WaveSoundfile implements java.
  io.Serializable
{
	/**
	Test cases.
	*/
  public static void main (String[]arguments)
  {
    try
    {
      Timebase timebase = new Timebase ();
        timebase.audioSampleFramesPerSecond = 48000;
      IsoperceptualGrain isoperceptualGrain = new IsoperceptualGrain ();
        isoperceptualGrain.initialize (timebase);
        isoperceptualGrain.setGrainDurationSeconds (1.0);
      double grainDurationSeconds =
	isoperceptualGrain.getGrainDurationSeconds ();
        System.out.println ("Grain duration in seconds: " +
			    grainDurationSeconds);
        isoperceptualGrain.createMemorySoundfile ("/IsoperceptualTest.wav",
						  90);
      double amplitude = .25;
        isoperceptualGrain.mixGrainOctaves (0.0, 8.0, amplitude, 0);
	 isoperceptualGrain.mixGrainOctaves (grainDurationSeconds / 2.0, 8.0, amplitude, 0);
	 isoperceptualGrain.mixGrainOctaves (grainDurationSeconds, 8.0, amplitude, 0);
        System.out.println ("Grain phase : " + isoperceptualGrain.grain.sinePhase);
      if (1 != 1)
	{
	  isoperceptualGrain.commit ();
	  isoperceptualGrain.close ();
	  System.out.println ("Finished.");
	  return;
	}
      isoperceptualGrain.setGrainDurationSeconds (0.01);
      if (1 != 1)
	{
	  double cincrement = (1.0 - .95) / 10000;
	  for (double c = .95, t = 3.0; c <= 1; c += cincrement, t += .005)
	    {
	      double y = 0.5;
	      double octave = 0;
	      for (int i = 0; i < 100; i++)
		{
		  y = 4.0 * c * y * (1.0 - y);
		  octave = y * 8 + 5;;
		  //System.out.println("Hz = " + hz);
		  isoperceptualGrain.mixGrainOctaves (t, octave, .001, 0);
		}
	      System.out.println ("c = " + c);
	    }
	}
      int column = 0;
      for (double time = 65.0; time < 85.0; time += 0.005, column++)
	{
	  for (double frequency = 32.0; frequency < 16000.0;
	       frequency += 32.0)
	    {
	      isoperceptualGrain.mixGrainHz (time, frequency, .001, 0);
	    }
	  System.out.println ("Column " + column);
	}
      isoperceptualGrain.commit ();
      isoperceptualGrain.close ();
      System.out.println ("Finished.");
    }
    catch (IOException e)
    {
      e.printStackTrace ();
    }
  }
	/**
  	Mix grains into a memory soundfile for higher performance (default).
  	The duration of the file will be limited by available memory.
  	*/
  static int RENDER_TO_MEMORY = 1;
	/**
  	Mix grains into a disk soundfile for longer durations.
  	Performance will be slower than rendering to memory.
  	*/
  static int RENDER_TO_FILE = 2;
  int renderingMode = RENDER_TO_MEMORY;
  double durationSeconds;
  double grainDurationSeconds;
  double halfGrainDurationSeconds;
  int grainSampleCount = 0;
  transient float[] soundBuffer = null;
  transient public Timebase timebase = null;
  transient Grain grain = new Grain ();
  transient int sampleIndex = 0;
	/**
  	Default constructor.
  	*/
  public IsoperceptualGrain ()
  {
    initialize ();
  }
	/**
	Initializes this with a quantized Hanning envelope.
	*/ public double setGrainDurationSeconds (double grainDurationSeconds)
  {
    grainSampleCount =
      (int) Math.rint (timebase.audioSampleFramesPerSecond *
		       grainDurationSeconds);
    this.grainDurationSeconds =
      ((double) grainSampleCount) /
      ((double) timebase.audioSampleFramesPerSecond);
    halfGrainDurationSeconds = this.grainDurationSeconds / 2.0;
    double frequency = 1.0 / this.grainDurationSeconds;
      return this.grainDurationSeconds;
  }
	/**
  	Returns the duration of the grain envelope.
  	*/
  public double getGrainDurationSeconds ()
  {
    return grainDurationSeconds;
  }
	/**
  	Initializes this with a Timebase.
  	*/
  public void initialize (Timebase timebase)
  {
    this.timebase = timebase;
    grain.initialize (timebase);
  }
	/**
	Seeks in the soundfile to that point in time
	nearest the half-amplitude point of the Hanning envelope,
	that is modulo 1/2 the envelope duration;
	adjusts the phase of the sine wave so that it is as if
	begun at time 0 with phase 0;
	and mixes one isoperceptual grain
	of the specified amplitude and pan into the soundfile.
	*/
  public void mixGrainHz (double seconds, double hertz, double amplitude,
			  double pan) throws IOException
  {
    //double startSeconds = Math.rint(seconds / halfGrainDurationSeconds) * halfGrainDurationSeconds;
    double startSeconds = seconds;
    if (startSeconds < 0.0 || startSeconds >= durationSeconds
	|| amplitude <= 0.0)
      {
	return;
      }
    try
    {
      if (renderingMode == RENDER_TO_MEMORY)
	{
	  seek (startSeconds);
	}
      else
	{
	  int soundfileSampleCount =
	    seekSeconds (startSeconds, grainDurationSeconds);
	}
      double secondsPerCycle = 1.0 / hertz;
      double cycleCount = startSeconds / secondsPerCycle;
      double cycleRemainder = cycleCount - Math.floor (cycleCount);
      double phase = cycleRemainder * Maths.TWO_PI;
      grain.set (hertz, amplitude, phase, grainDurationSeconds);
      double leftAmplitude = Conversions.leftPan (pan) * amplitude;
      double rightAmplitude = Conversions.rightPan (pan) * amplitude;
      if (renderingMode == RENDER_TO_MEMORY)
	{
	  for (int sampleIndex = 0; sampleIndex < grainSampleCount;
	       sampleIndex++)
	    {
	      double signal = grain.tick ();
	      mixTick (signal * leftAmplitude, signal * rightAmplitude);
	    }
	}
      else
	{
	  for (int sampleIndex = 0; sampleIndex < grainSampleCount;
	       sampleIndex++)
	    {
	      double signal = grain.tick ();
	      mixSignal (0, signal * leftAmplitude);
	      mixSignal (1, signal * rightAmplitude);
	      tickMix ();
	    }
	  flush ();
	}
    }
    catch (ArrayIndexOutOfBoundsException e)
    {
      e.printStackTrace ();
    }
  }
	/**
  	Mixes one grain into this with the specified time, grain duration in seconds,
   	pitch in MIDI key, amplitude, and pan.
  	*/
  public void mixGrainMidi (double seconds, double duration, double key,
			    double velocity, double pan) throws IOException
  {
    if (grainDurationSeconds != duration)
      {
	setGrainDurationSeconds (duration);
      }
    double hz = Conversions.midiToHz(key);
    double amplitude = Conversions.midiToGain(velocity);
    mixGrainHz (seconds, hz, amplitude, pan);
  }
	/**
  	Mixes one grain into this with the specified time, pitch in linear octaves,
  	amplitude, and pan.
  	*/
  public void mixGrainOctaves (double seconds, double octave,
			       double amplitude,
			       double pan) throws IOException
  {
    mixGrainHz (seconds, Conversions.octaveToHz (octave), amplitude, pan);
  }
	/**
  	Seeks in the memory soundfile to the specified time.
  	*/
  public void seek (double time)
  {
    sampleIndex = (int) (time * timebase.audioSampleFramesPerSecond * 2);
  }
	/**
  	Mixes one stereo sample frame into the memory soundfile at the current time.
  	*/
  public void mixTick (double left, double right)
  {
    float tempLeft = (float) left;
    float tempRight = (float) right;
    soundBuffer[sampleIndex++] += tempLeft;
    soundBuffer[sampleIndex++] += tempRight;
  }
	/**
  	Creates the underlying soundfile in memory, for faster performance.
  	The total duration is limited by system RAM.
  	*/
  public void createMemorySoundfile (String soundfileName,
				     double durationSeconds)
  {
    renderingMode = RENDER_TO_MEMORY;
    create (soundfileName, 4, 2, timebase.audioSampleFramesPerSecond);
    this.durationSeconds = durationSeconds - halfGrainDurationSeconds;
    int size = (int) (timebase.audioSampleFramesPerSecond * durationSeconds * 2);
      System.out.println ("Allocating array of " + size + " floats.");
      soundBuffer = new float[size];
  }
	/**
  	Creates the underlying soundfile on disk, for unlimited total duration.
  	Performance is not as fast as with a memory soundfile.
  	*/ public void createDiskSoundfile (String soundfileName,
				       double durationSeconds)
  {
    renderingMode = RENDER_TO_FILE;
    soundBuffer = null;
    create (soundfileName, 4, 2, timebase.audioSampleFramesPerSecond);
    this.durationSeconds = durationSeconds - halfGrainDurationSeconds;
    createSilence (durationSeconds);
  }
	/**
  	Returns the total duration of the soundfile in seconds.
  	*/
  public double getDurationSeconds ()
  {
    return durationSeconds;
  }
	/**
  	Flushes rendered data to the soundfile.
  	*/
  public void commit ()
  {
    try
    {
      if (renderingMode == RENDER_TO_MEMORY)
	{
          double maxSample = 0;
          double sample = 0;
          double leftSample = 0;
          double rightSample = 0;
	  seekSeconds (0);
	  for (int i = 0; i < soundBuffer.length; i++)
	    {
              sample = soundBuffer[i];
              if(Math.abs(sample) > maxSample)
              {
                maxSample = Math.abs(sample);
              }
	    }
          double gain = 1.0 / maxSample;
          System.out.println("Maximum amplitude = " + maxSample);
	  for (int sampleFrameIndex = 0, sampleIndex = 0, sampleFrameCount =
	       soundBuffer.length / 2; sampleFrameIndex < sampleFrameCount;
	       sampleFrameIndex++)
	    {
              leftSample = (double) soundBuffer[sampleIndex++];
              rightSample = (double) soundBuffer[sampleIndex++];
 	      input.assign (leftSample * gain, rightSample * gain);
	      tickWrite ();
	    }
	}
      flush ();
    }
    catch (IOException e)
    {
      e.printStackTrace ();
    }
  }
}
