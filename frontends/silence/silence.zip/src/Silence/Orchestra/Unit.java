package Silence.Orchestra;
/**
 * Generic signal processing unit in a synchronous data flow graph.
 * In contrast to SignalFlowUnits, the data flow graph
 * is defined by code at compile time; therefore,
 * Units and Unit-derived classes are more efficient for use inside hard-coded
 * signal processors and instruments.
 * @author Copyright (C) 2000 by Michael Gogins. All rights reserved.
 * <ADDRESS>
 * gogins@pipeline.com
 * </ADDRESS>
 */
public abstract class Unit extends Sample
{
    /**
     *  Reference to the container's global timebase.
     */
  public Timebase timebase = null;
  public Unit ()
  {
  }
    /**
     * Called by the container before using the unit.
     */
  public void initialize (Timebase timebase)
  {
    if(timebase == null)
    {
      throw new NullPointerException("Null timebase in Unit.initialize().");
    }
    this.timebase = timebase;
  }
    /**
     * Returns the current timebase.
     */
	public Timebase getTimekeeper ()
  {
    return timebase;
  }
    /**
     * Resets the unit to ground state with a valid signal value,
     * ready for tick to be called.
     */
  public void reset ()
  {
    signal = 0;
  }

}
