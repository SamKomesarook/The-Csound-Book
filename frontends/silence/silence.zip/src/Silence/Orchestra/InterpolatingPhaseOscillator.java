package Silence.Orchestra;
import Silence.Conversions;
import java.util.ArrayList;
import java.util.Iterator;
/**
General-purpose interpolating function lookup table
or phase-modulation digital oscillator. Can easily be used
to make accurate frequency modulation instruments.
@author Copyright (C) 1998, 2000 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class InterpolatingPhaseOscillator extends PhaseOscillator
{
  public InterpolatingPhaseOscillator ()
  {
  }
  public double tickPhase (double phase)
  {
    setPhase (phase);
    return tick ();
  }
  public double tickCyclePhase (double cycles)
  {
    lookupIndex = functionTable.sampleCount * cycles;
    return tick ();
  }
  /**
   * Advances the sample index by the indicated sampling increment,
   * which can be positive or negative,
   * or even phase modulated (for implementing phase or FM oscillators).
   * The sample index is wrapped back (or forward)
   * after it passes the end (or beginning) of the table.
   */
  public double tick ()
  {
    lookupIndex = frequencyAccumulator + phaseIndex;
    while (lookupIndex >= functionTable.sampleCount)
      {
	lookupIndex -= functionTable.sampleCount;
      }
    while (lookupIndex < 0)
      {
	lookupIndex += functionTable.sampleCount;
      }
    frequencyAccumulator = frequencyAccumulator + frequencyIncrement;
    while (frequencyAccumulator >= functionTable.sampleCount)
      {
	frequencyAccumulator -= functionTable.sampleCount;
      }
    while (frequencyAccumulator < 0)
      {
	frequencyAccumulator += functionTable.sampleCount;
      }
    int indexFloor = (int) Math.floor (lookupIndex);
    int indexCeiling = indexFloor + 1;
    double indexAboveFloor = lookupIndex - ((double) indexFloor);
    signal =
      functionTable.table[indexFloor] + (functionTable.table[indexCeiling] -
					 functionTable.table[indexFloor]) *
      indexAboveFloor;
    return signal;
  }
}
