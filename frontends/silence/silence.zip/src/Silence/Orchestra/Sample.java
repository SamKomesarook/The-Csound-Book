package Silence.Orchestra;
import java.io.Serializable;
/**
Generic audio sample in a synchronous data flow graph.
@author Copyright (C) 2000 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class Sample implements Serializable
{
	/**
  	Represents the instantaneous signal value
    at the current audio sample frame.
    The absolute value of the signal (its amplitude)
    is normalized between 0 and 1.
	*/
  public double signal = 0;
  public Sample ()
  {
  }
	/**
   	Returns the signal.
   	*/ public double get ()
  {
    return signal;
  }
	/**
  	Sets the signal.
   	*/
  public void set (double inputSignal)
  {
    signal = signal;
  }
	/**
   	Adds (mixes) an input signal to the current signal.
    */
  public void add (double inputSignal)
  {
    signal += inputSignal;
  }
	/**
    Resets the signal value to zero.
    */
  public void reset ()
  {
    signal = 0;
  }
}
