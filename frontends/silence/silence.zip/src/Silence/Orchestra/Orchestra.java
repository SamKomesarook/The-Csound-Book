package Silence.Orchestra;
import Silence.Plugin;
import Silence.PluginManager;
import Silence.Score.Score;
import Silence.Orchestra.Instruments.TestInstrument;
import java.awt.Container;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.ListIterator;
import javax.sound.midi.*;
import javax.sound.sampled.*;
/**
The simplest possible software synthesizer
that can render sound either by writing a synchronous stream of sound,
or by mixing notes asynchronously into a soundfile.
Capable of a limited degree of real-time performance,
and an unlimited degree of non-real-time performance.
All internal processing is performed in double precision.
The default output soundfile samples are float.
@author Copyright (C) 2000 by Michael Gogins. All rights reserved.
<ADDRESS>
gogins@pipeline.com
</ADDRESS>
*/
public class Orchestra extends Plugin
{
  public static void main (String[]args)
  {
    Orchestra synthesizer = new Orchestra ();
    double timeIncrement = 3;
    double key = 0;
    double time = 0.1;
    for (int i = 0; i < 100; i++)
      {
	key = (key + 3.0) % 60.0;
	synthesizer.score.
	  add (Event.createEvent (144., 0., time, 3., key + 36, 70, 0., 0.,
				  0., 0., 0.));
	time = time + timeIncrement;
	timeIncrement = timeIncrement * .95;
      }
    synthesizer.instruments.add (new TestInstrument ());
    //synthesizer.instruments.add(new PluckedString());
    //synthesizer.soundfileOutputEnabled = false;
    //synthesizer.audioOutputEnabled = true;
      synthesizer.renderByWriting (100, 44100, 2, 2, "C:/testWrite.wav");
    //synthesizer.renderByMixing(1, 44100, 2, 2, "C:/testMix.wav");
  }
  public Timebase timebase = null;
  MidiDevice.Info midiInputInfo = null;
  public int audioSampleFramesPerControlSample = 1;
  public int audioSampleFramesPerSecond = 44100;
  public int bytesPerAudioSample = 4;
  public int outputChannelCount = 2;
  public boolean soundfileOutputEnabled = true;
  transient public WaveSoundfile outputSoundfile = null;
  public String outputSoundfileName = "output.wav";
  public boolean audioOutputEnabled = false;
  transient byte[] audioOutputBuffer = null;
  Mixer.Info mixerInfo = null;
  transient SourceDataLine outputDataLine = null;
  transient SoundfilePlayer outputSoundfilePlayer = new SoundfilePlayer ();
  transient boolean keepRendering = false;
  transient public PluginManager instrumentPlugins = null;
  public ArrayList instruments = new ArrayList ();
  transient Object[] instrumentArray = null;
  public Score score = null;
  transient Object[] notes = null;
  transient Object[] events = null;
  transient double[] note = null;
  transient LinkedList[] playingLists = null;
  transient LinkedList[] restingLists = null;
  transient int instrumentIndex = 0;
  transient double startSeconds = 0;
  transient double durationSeconds = 0;
  transient int audioSampleFrameCount = 0;
  transient int noteIndex = 0;
  transient int tickIndex = 0;
  transient String noteString = null;
  transient double startedAtMilliseconds = 0;
  transient double soundingSeconds = 0;
  transient double[] event = null;
  transient Instrument instrument = null;
  transient LinkedList playingList = null;
  transient LinkedList restingList = null;
  transient ListIterator iterator = null;
  transient int playingListIndex = 0;
  transient int audioSampleFrameIndex = 0;
  transient boolean hasPendingEvents = false;
  transient boolean instrumentsArePlaying = false;
  public transient Thread thread = null;
  public Orchestra ()
  {
    this (new Score ());
  }
  public Orchestra (Score score)
  {
    try
    {
      this.score = score;
      instrumentPlugins = new PluginManager ("Silence.Orchestra.Instrument");
    }
    catch (Exception x)
    {
      x.printStackTrace ();
    }
    timebase = score.timebase;
  }
  public void renderByMixing (int audioSampleFramesPerControlSample,
			      int audioSampleFramesPerSecond,
			      int bytesPerAudioSample, int outputChannelCount,
			      String outputSoundfileName)
  {
    this.audioSampleFramesPerControlSample =
      audioSampleFramesPerControlSample;
    this.audioSampleFramesPerSecond = audioSampleFramesPerSecond;
    this.bytesPerAudioSample = bytesPerAudioSample;
    this.outputChannelCount = outputChannelCount;
    this.outputSoundfileName = outputSoundfileName;
    renderByMixing ();
  }
  public void renderByMixing ()
  {
    try
    {
      stop ();
      openForMixing (audioSampleFramesPerControlSample,
		     audioSampleFramesPerSecond, bytesPerAudioSample,
		     outputChannelCount, outputSoundfileName);
      thread = new MixingThread ();
      thread.start ();
    }
    catch (Exception x)
    {
      x.printStackTrace ();
    }
  }
  public synchronized void stop ()
  {
    System.out.println ("BEGAN Orchestra.stop()...");
    keepRendering = false;
    if (thread != null)
      {
	try
	{
	  thread.interrupt ();
	  thread.join (1000);
	  thread = null;
	}
	catch (InterruptedException x)
	{
	  x.printStackTrace ();
	}
      }
    System.out.println ("ENDED Orchestra.stop().");
  }
  public synchronized boolean isRendering ()
  {
    return keepRendering;
  }
  public synchronized boolean isPlaying ()
  {
    return outputSoundfilePlayer.isPlaying ();
  }
  public void openForMixing (int audioSampleFramesPerControlSample,
			     int audioSampleFramesPerSecond,
			     int bytesPerAudioSample, int outputChannelCount,
			     String outputSoundfileName)
  {
    close ();
    this.audioSampleFramesPerControlSample =
      audioSampleFramesPerControlSample;
    this.audioSampleFramesPerSecond = audioSampleFramesPerSecond;
    this.bytesPerAudioSample = bytesPerAudioSample;
    this.outputChannelCount = outputChannelCount;
    this.outputSoundfileName = outputSoundfileName;
    startedAtMilliseconds = System.currentTimeMillis ();
    System.out.println ("BEGAN rendering " + outputSoundfileName + "...");
    System.out.println ("Began initializing soundfile...");
    outputSoundfile = new WaveSoundfile ();
    outputSoundfile.create (outputSoundfileName, bytesPerAudioSample,
			    outputChannelCount, audioSampleFramesPerSecond);
    soundingSeconds = score.getTotalDurationSeconds ();
    outputSoundfile.createSilence (soundingSeconds);
    System.out.println ("Ended initializing soundfile.");
    assembleOrchestra ();
    initializeScore ();
  }
  public void assembleOrchestra ()
  {
    System.out.println ("Began initializing instruments...");
    timebase.initialize (audioSampleFramesPerControlSample,
		     audioSampleFramesPerSecond, bytesPerAudioSample,
		     outputChannelCount);
    instrumentArray = instruments.toArray ();
    Instrument instrument = null;
    for (int i = 0; i < instrumentArray.length; i++)
      {
	instrument = (Instrument) instrumentArray[i];
	System.out.println ("Instrument " + i + ": " +
			    instrument.getClass ().getName ());
	instrument.initialize (timebase);
      }
    System.out.println ("Ended initializing instruments.");
  }
  public void initializeScore ()
  {
    System.out.println ("Began initializing score...");
    score.reset ();
    notes = score.toArray ();
    System.out.println ("Ended initializing score.");
  }
  public class MixingThread extends Thread
  {
    public void run ()
    {
      try
      {
	mix ();
	close ();
      }
      catch (Exception x)
      {
	x.printStackTrace ();
      }
    }
  }
  public void mix () throws IOException, SampleFrame.ShapeException
  {
    System.out.println ("Began rendering notes...");
    int noteIndex = 0;
    double[] note = null;
      keepRendering = true;
    for (noteIndex = 0; noteIndex < notes.length && keepRendering;
	 noteIndex++)
      {
	note = (double[]) notes[noteIndex];
	noteString = Event.toString (note);
	System.out.print ("Note " + noteIndex + ": ");
	System.out.println (noteString);
	renderNote (note);
      }
    System.out.println ("Ended rendering notes.");
  }
  public void renderNote (double[]note) throws IOException, SampleFrame.ShapeException
  {
    instrumentIndex = Event.getMidiChannel (note);
    Instrument instrument = (Instrument) instrumentArray[instrumentIndex];
      renderInstrument (note, instrument);
  }
  public void renderInstrument (double[]note,
				Instrument instrument) throws IOException, SampleFrame.ShapeException
  {
    startSeconds = Event.getTime (note);
    durationSeconds = Event.getDuration (note);
    audioSampleFrameCount =
      outputSoundfile.seekSeconds (startSeconds, durationSeconds);
    instrument.attack (note);
    while (instrument.offTime <= timebase.currentTime)
      {
	instrument.tick ();
	outputSoundfile.tickMix (timebase.input);
      }
    outputSoundfile.flush ();
  }
  public void close ()
  {
    if (outputSoundfile != null || outputDataLine != null)
      {
	double endedAtMilliseconds = System.currentTimeMillis ();
	double renderingSeconds =
	  (endedAtMilliseconds - startedAtMilliseconds) / 1000.0;
	  System.out.println ("Sounding time        = " + soundingSeconds +
			      " seconds");
	  System.out.println ("Rendering time       = " + renderingSeconds +
			      " seconds");
	double ratio = renderingSeconds / soundingSeconds;
	  System.out.println ("Rendering / Sounding = " + ratio);
	  System.out.println ("ENDED rendering " + outputSoundfileName + ".");
      }
    if (outputSoundfile != null)
      {
	outputSoundfile.close ();
	outputSoundfile = null;
      }
    if (outputDataLine != null)
      {
	outputDataLine.drain ();
	outputDataLine.stop ();
	outputDataLine.close ();
	outputDataLine = null;
      }
    keepRendering = false;
  }
  public void renderByWriting (int audioSampleFramesPerControlSample,
			       int audioSampleFramesPerSecond,
			       int bytesPerAudioSample,
			       int outputChannelCount,
			       String outputSoundfileName)
  {
    this.audioSampleFramesPerControlSample =
      audioSampleFramesPerControlSample;
    this.audioSampleFramesPerSecond = audioSampleFramesPerSecond;
    this.bytesPerAudioSample = bytesPerAudioSample;
    this.outputChannelCount = outputChannelCount;
    this.outputSoundfileName = outputSoundfileName;
    renderByWriting ();
  }
  public synchronized void renderByWriting ()
  {
    try
    {
      stop ();
      openForWriting (audioSampleFramesPerControlSample,
		      audioSampleFramesPerSecond, bytesPerAudioSample,
		      outputChannelCount, outputSoundfileName);
      thread = new WritingThread ();
      thread.start ();
    }
    catch (Exception x)
    {
      x.printStackTrace ();
    }
  }
  public void openForWriting (int audioSampleFramesPerControlSample,
			      int audioSampleFramesPerSecond,
			      int bytesPerAudioSample, int outputChannelCount,
			      String outputSoundfileName) throws IOException,
    LineUnavailableException
  {
    close ();
    this.audioSampleFramesPerControlSample =
      audioSampleFramesPerControlSample;
    this.audioSampleFramesPerSecond = audioSampleFramesPerSecond;
    this.bytesPerAudioSample = bytesPerAudioSample;
    this.outputChannelCount = outputChannelCount;
    this.outputSoundfileName = outputSoundfileName;
    timebase.initialize(audioSampleFramesPerControlSample, audioSampleFramesPerSecond,bytesPerAudioSample, outputChannelCount);
    startedAtMilliseconds = System.currentTimeMillis ();
    System.out.println ("BEGAN rendering " + outputSoundfileName + "...");
    if (soundfileOutputEnabled)
      {
	System.out.println ("Began initializing soundfile...");
	outputSoundfile = new WaveSoundfile ();
	outputSoundfile.create (outputSoundfileName, bytesPerAudioSample,
				outputChannelCount,
				audioSampleFramesPerSecond);
	soundingSeconds = score.getTotalDurationSeconds ();
	System.out.println ("Ended initializing soundfile.");
      }
    if (audioOutputEnabled)
      {
	System.out.println ("Began initializing audio output line...");
	audioOutputBuffer = new byte[timebase.getAudioSampleFrameSize ()];
	AudioFormat audioFormat =
	  new AudioFormat (timebase.audioSampleFramesPerSecond,
			   timebase.bytesPerAudioSample * 8,
			   timebase.outputChannelCount, true, false);
	System.out.println ("Audio format:           " +
			    audioFormat.toString ());
	DataLine.Info outputLineInfo =
	  new DataLine.Info (SourceDataLine.class, audioFormat,
			     audioOutputBuffer.length * 6000);
        Mixer mixer = AudioSystem.getMixer(mixerInfo);
        mixer.open();
	outputDataLine = (SourceDataLine) mixer.getLine (outputLineInfo);
	System.out.println ("Output SourceDataLine: " +
			    outputDataLine.getLineInfo ().toString ());
	System.out.println ("Buffer size:           " +
			    outputDataLine.getBufferSize ());
	outputDataLine.open (audioFormat);
	outputDataLine.start ();
	System.out.println ("Ended initializing audio output line...");
      }
    assembleOrchestra ();
    playingLists = new LinkedList[instrumentArray.length];
    restingLists = new LinkedList[instrumentArray.length];
    for (int i = 0; i < instrumentArray.length; i++)
      {
	playingLists[i] = new LinkedList ();
	restingLists[i] = new LinkedList ();
	restingLists[i].add (instrumentArray[i]);
      }
    initializeScore ();
  }
  public class WritingThread extends Thread
  {
    public void run ()
    {
      try
      {
	System.out.println ("Began rendering notes...");
	for (keepRendering = true; tickControlSample () && keepRendering;);
	System.out.println ("Ended rendering notes.");
	close ();
      }
      catch (Exception x)
      {
	x.printStackTrace ();
      }
    }
  }
    /**
     * Computes one control sample's worth of audio.
     * Because the instruments are ticked off in order,
     * the final instrument or instruments in the list
     * has access to the signal computed by all prior instruments.
     * This means that a global stereo reverberation instrument,
     * for example, can be written as an insert to read
     * and rewrite the first two channels of the timebase bus,
     * if it is the final instrument in the list.
     */
  public boolean tickControlSample () throws IOException,
    IllegalAccessException, InstantiationException, SampleFrame.ShapeException
  {
    while (hasPendingEvents = score.hasPendingEvents ())
      {
	event = score.getCurrentEvent ();
	if (event == null)
	  {
	    break;
	  }
	System.out.print ("Note: ");
	System.out.println (Event.toString (event));
	instrumentIndex = Event.getMidiChannel (event);
	if (Event.isNoteOnEvent (event))
	  {
	    playingList = playingLists[instrumentIndex];
	    restingList = restingLists[instrumentIndex];
	    if (restingList.isEmpty ())
	      {
		instrument =
		  (Instrument) instrumentArray[instrumentIndex].
		  getClass ().newInstance ();
		instrument.initialize (timebase);
                timebase.addSource(instrument);
	      }
	    else
	      {
		instrument = (Instrument) restingList.removeFirst ();
	      }
	    instrument.attack (event);
	    playingList.add (instrument);
	  }
	else if (Event.isNoteOffEvent (event))
	  {
	    iterator = playingLists[instrumentIndex].listIterator ();
	    while (iterator.hasNext ())
	      {
		instrument = (Instrument) iterator.next ();
		if (Event.isMatchingNoteOffEvent
		    (instrument.noteOnEvent, event))
		  {
		    instrument.release (event);
		    break;
		  }
	      }
	  }
	else
	  {
	    iterator = playingLists[instrumentIndex].listIterator ();
	    while (iterator.hasNext ())
	      {
		instrument = (Instrument) iterator.next ();
		instrument.control (event);
	      }
	  }
      }
    for (audioSampleFrameIndex = 0, instrumentsArePlaying = false;
	 audioSampleFrameIndex < timebase.audioSampleFramesPerControlSample;
	 audioSampleFrameIndex++)
      {
	timebase.resetBuss ();
	for (playingListIndex = 0; playingListIndex < playingLists.length;
	     playingListIndex++)
	  {
	    iterator = playingLists[playingListIndex].listIterator ();
	    while (iterator.hasNext ())
	      {
		instrument = (Instrument) iterator.next ();
		if (instrument.offTime > timebase.currentTime)
		  {
		    instrumentsArePlaying = true;
		    instrument.tick ();
                    instrument.send ();
                    instrument.reset ();
		  }
		else
		  {
		    iterator.remove ();
		    restingLists[playingListIndex].add (instrument);
		  }
	      }
	  }
	if (soundfileOutputEnabled)
	  {
	    outputSoundfile.tickWrite (timebase.input);
	  }
	if (audioOutputEnabled)
	  {
	    int intBuffer;
	    for (int i = 0, k = 0; i < timebase.outputChannelCount; i++)
	      {
		intBuffer = (int) (timebase.input.signal[i] * 32767.0);
		audioOutputBuffer[k++] = (byte) (intBuffer & 0x000000ff);
		audioOutputBuffer[k++] =
		  (byte) ((intBuffer & 0x0000ff00) >> 8);
		timebase.input.signal[i] = 0;
	      }
	    intBuffer =
	      outputDataLine.write (audioOutputBuffer, 0,
				    audioOutputBuffer.length);
	    if (intBuffer != audioOutputBuffer.length)
	      {
		System.out.println ("Buffer underrun...");
	      }
	  }
      }
    timebase.nextControlSample ();
    return hasPendingEvents || instrumentsArePlaying;
  }
  public synchronized void play ()
  {
    stop ();
    outputSoundfilePlayer.open (outputSoundfileName);
    outputSoundfilePlayer.start ();
  }
  public synchronized void stopPlaying ()
  {
    outputSoundfilePlayer.stop ();
  }
  public Container getView ()
  {
    return new OrchestraView (this);
  }
  public void clear ()
  {
    stop ();
    close ();
  }
  public void clearAll ()
  {
    clear ();
    instruments.clear ();
  }
}
