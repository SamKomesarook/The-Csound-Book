#include "parametric.h"
#include "measure.h"
#include "browser.h"
#include "code.h"
#include <iostream>

using namespace std;
using namespace silence;

void main(int argc, char **argv)
{
	cout << "S I L E N C E   P A R A M E T R I C" << endl;
	Code<3> code;
	Browser browser;
	browser.write(cout);
	Measure<double> measure;
	measure.resize(100, 100);
}