#ifndef CODE_H
#define CODE_H
#include "parametric.h"
#include "xmlpersistence.h"
#include <string>
#include <newmat.h>

/**
 *	S I L E N C E
 *	An extensible system for making music on computers by means of software alone.
 *	Copyright (c) 2001 by Michael Gogins. All rights reserved.
 */
using namespace std;
namespace silence {

template<int N>
class Code : public CompoundPersistence
{
	string name;
	ColumnVector weights;
	vector<Matrix> transforms;	
public:
	Code(void) : CompoundPersistence("Code")
	{
		weights.ReSize(N);
		transforms.push_back(Matrix(N + 1, N + 1));
	}
	virtual ~Code(void){}
	virtual string getName(void) const
	{
		return name;
	}
	virtual void setName(const string &name)
	{
		this->name = name;
	}
	virtual Code<N> &operator=(const Code<N> &code)
	{
		name = code.name;
		weights = code.weights;
		transforms = code.transforms;
		return *this;
	}
};

}	//	namespace silence
#endif	//	CODE_H