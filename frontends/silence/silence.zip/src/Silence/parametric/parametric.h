#ifndef PARAMETRIC_H
#define PARAMETRIC_H
/**
 *	S I L E N C E
 *	An extensible system for making music on computers by means of software alone.
 *	Copyright (c) 2001 by Michael Gogins. All rights reserved.
 *	P A R A M E T R I C 
 *	Abstract interfaces that define an extensible system for parametric composition
 *	and evolutionary parametric composition. Parameters are usually virtual parameters
 *	for parametric codes.
 *
 */
namespace silence {
/**
 *	Generates and browses a set of parametric compositions,
 *	previews "thumbnail" musical renderings,
 *	selects a subset of compositions for further mapping or evolution,
 *	and saves finished renderings of pieces.
 */
class Browser;
/**
 *	A Browser that implements parametric mapping.
 */
class Mapper;
/**
 *	A Browser that implements the genetic algorithm.
 */
class Evolver;
/**
 *	Derives a set of new codes interpolated between two points in a virtual parameter space.
 */
class Interpolater;
/**
 *	Returns a single numerical parameter measuring
 *	some musically significant attribute of a measure.
 */
class Characterizer;
/**
 *	All data and algorithms required to represent,
 *	decode, and render a code.
 */
class CodeManager;
/**
 *	Represents a parametric code, that is, 
 *	a set of numerical parameters with an orthogonal basis.
 */
template<int N> class Code;
/**
 *	Computes a measure on the attractor produced by the code.
 */
class Decoder;
/**
 *	Represents a quantized measure on the attractor produced by a code.
 */
template<class T> class Measure;
/**
 *	Renders a quantized measure as music.
 */
class Renderer;
}	//	namespace silence
#endif	//	PARAMETRIC_H
