#ifndef XMLPERSISTENCE_H
#define XMLPERSISTENCE_H
#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
/**
 *	S I L E N C E
 *	An extensible system for making music on computers by means of software alone.
 *	Copyright (c) 2001 by Michael Gogins. All rights reserved.
 */
using namespace std;
namespace silence {
/**
 *	A simple-minded system to simplify implementation of XML-like persistence.
 *	All classes to be persisted should inherit from CompoundPersistence,
 *	and add members to be persisted using more specialized classes.
 *	class A : public CompoundPersistence
 *	{
 *	public:
 *		int id;
 *		vector<double> pfields;
 *		A()
 *		{
 *			persistent(ElementaryPersistence<int>("id", &id));
 *			persistent(VectorPersistence< <vector<double>, double>("pfields", &pfields));
 *		}
 *	};
 *	A a;
 *	a.save("a.txt");
 *	Complex classes that use these facilities can require more memory than one might like. 
 *	To prevent this, derive directly from Persistent, and override read() and write().
 */
class Persistence
{
public:
	Persistence(void){};
	virtual ~Persistence(void){};
	virtual void load(std::string filename)
	{
		ifstream stream(filename.c_str());
		read(stream);
		stream.close();
	}
	virtual void save(string filename) const
	{
		ofstream stream(filename.c_str());
		write(stream);
		stream.close();
	}
	virtual void fromString(string text)
	{
		istringstream stream(text);
		read(stream);
	}
	virtual string toString(void)
	{
		ostringstream stream;
		write(stream);
		string str = stream.str();
		return str;
	}
	virtual void read(istream &stream)=0;
	virtual void write(ostream &stream) const=0;
};

class CompoundPersistence : public Persistence
{
	std::string tag;
	vector<Persistence> members;
public:
	CompoundPersistence(string Tag) : tag(Tag){};
	virtual void read(istream &stream)
	{
		char buffer[0x1000];
		stream.getline(buffer, sizeof(buffer));
		for(int i = 0, n = members.size(); i < n; i++)
		{
			members[i].read(stream);
		}
		stream.getline(buffer, sizeof(buffer));
	}
	virtual void write(ostream &stream) const
	{
		stream << "<" << tag << ">" << endl;
		for(int i = 0, n = members.size(); i < n; i++)
		{
			members[i].write(stream);
		}
		stream << "</" << tag << ">" << endl;
	}};

template<class T>
class ElementaryPersistence : public Persistence
{
	std::string tag;
	T *value;
public:
	ElementaryPersistence(std::string Tag, T* Value = 0) : tag(Tag), value(Value){};
	virtual ~ElementaryPersistence(void){};
	virtual void read(istream &stream)
	{
		char buffer[0x1000];
		stream.getline(buffer, sizeof(buffer));
		stream >> (*value) >> endl;
		stream.getline(buffer, sizeof(buffer));
	}
	virtual void write(ostream &stream) const
	{
		stream << "<" << tag << ">" << endl;
		stream << (*value) << endl;
		stream << "</" << tag << ">" << endl;
	}
};
}	//	namespace silence
#endif	//	XMLPERSISTENCE_H