#ifndef DECODER_H
#define DECODER_H
#include "parametric.h"
#include <vector>
/**
 *	S I L E N C E
 *	An extensible system for making music on computers by means of software alone.
 *	Copyright (c) 2001 by Michael Gogins. All rights reserved.
 */
using namespace std;
namespace silence {

class Decoder : public CompoundPersistence
{
public:
	Decoder(void) : CompoundPersistence("Decoder"){};
	virtual ~Decoder(void){};
	virtual Code &getCode(void)=0;
	virtual void setCode(const Code &code)=0;
	virtual Measure &getMeasure(void)=0;
	virtual void setMeasure(const Measure &code)=0;
	virtual bool decode(void){}:
	virtual bool encode(void){};
};

}	//	namespace silence
#endif	//	DECODER_H