#ifndef BROWSER_H
#define BROWSER_H
#include "parametric.h"
#include "xmlpersistence.h"
#include <vector>
/**
 *	S I L E N C E
 *	An extensible system for making music on computers by means of software alone.
 *	Copyright (c) 2001 by Michael Gogins. All rights reserved.
 */
using namespace std;
namespace silence {

class Browser : public CompoundPersistence
{
public:
	Browser(void) : CompoundPersistence("Browser"){};
	virtual ~Browser(void){};
	//virtual Mapper &getMapper(void){return (0};
};

}	//	namespace silence
#endif	//	BROWSER_H