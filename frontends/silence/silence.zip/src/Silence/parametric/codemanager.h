#ifndef CODEMANAGER_H
#define CODEMANAGER_H
#include "parametric.h"
#include <vector>
/**
 *	S I L E N C E
 *	An extensible system for making music on computers by means of software alone.
 *	Copyright (c) 2001 by Michael Gogins. All rights reserved.
 */
using namespace std;
namespace silence {

class CodeManager : public CompoundPersistence
{
public:
	CodeManager(void) : CompoundPersistence("Decoder"){};
	virtual ~CodeManager(void){};
	virtual bool decode(void){}:
	virtual bool encode(void){};
	virtual bool render(void){};
};

}	//	namespace silence
#endif	//	CODEMANAGER_H