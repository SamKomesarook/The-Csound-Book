#ifndef MEASURE_H
#define MEASURE_H
#include <stdarg.h>
#include <vector>
/**
 *	S I L E N C E
 *	An extensible system for making music on computers by means of software alone.
 *	Copyright (c) 2001 by Michael Gogins. All rights reserved.
 */

using namespace std;
namespace silence {

/**
 *	An efficient array of from 1 to 3 dimensions.
 */
template<class T>
class Measure : public vector<T>
{
	int dimensionCount;
	int xn;
	int yn;
	int zn;
	vector<double> actualMinima;
	vector<double> actualRanges;
	vector<double> targetMinima;
	vector<double> targetRanges;
public:
	Measure(void){}
	virtual ~Measure(void){}
	void resize(int xn)
	{
		dimensionCount = 1;
		this->xn = xn;
		vector<T>::resize(xn);
	}
	void resize(int xn, int yn)
	{
		dimensionCount = 2;
		this->xn = xn;
		this->yn = yn;
		vector<T>::resize(xn * yn);
		clear();
	}
	void resize(int xn, int yn, int zn)
	{
		dimensionCount = 3;
		this->xn = xn;
		this->yn = yn;
		this->zn = zn;
		vector<T>::resize(xn * yn * zn);
		clear();
	}
	T &operator()(int i)
	{
		return (*this)[i];
	}
	T &operator()(int i, int j)
	{
		return (*this)[xn * j + i];
	}
	T &operator()(int i, int j, int k)
	{
		return (*this)[yn * xn * k + xn * j + i];
	}
	void getScale(T &minimum, T &range) const
	{
		minimum = *minimum_element(begin(), end());
		T maximum = *maximum_element(begin(), end());
		range = maximum - minimum;
	}
	void setScale(T minimum, T range)
	{
	}
	void clear(void)
	{
		erase(begin(), end());
	}
};

}	//	namespace silence
#endif	//	MEASURE_H