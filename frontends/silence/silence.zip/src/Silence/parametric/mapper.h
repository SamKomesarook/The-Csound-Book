#ifndef MAPPER_H
#define MAPPER_H
#include "parametric.h"
#include "interpolater.h"
#include "xmlpersistence.h"
#include <vector>
/**
 *	S I L E N C E
 *	An extensible system for making music on computers by means of software alone.
 *	Copyright (c) 2001 by Michael Gogins. All rights reserved.
 */
using namespace std;
namespace silence {

template<class T>
class Mapper : public CompoundPersistence, public vector<T>
{
public:
	Mapper(void) : CompoundPersistence("Mapper"){};
	virtual ~Mapper(void){};
	virtual setLowCorner(T &code)=0;
	virtual T &getLowCorner(void)=0;
	virtual setHighCorner(T &code)=0;
	virtual T &getHighCorner(void)=0;
	virtual Interpolator&
};

}	//	namespace silence
#endif	//	MAPPER_H