RELEASE NOTES Version 0.10 11/3/98
The current release enables users to read and generate text files that are
used to generate 2d sounds.

View http://www.washington.edu/cartah/soundspace/index.html
for the latest information on SoundSpace.

VERSION HISTORY
Version 0.01	First test release 7/27/98
Version 0.02	Second test release 8/3/98
		revised trackcontrols look/feel
		fixed timecanvas bug when capturing point 0.0
		rewrote file->open code.
		checks for correct file format.
		fixed Mac file reading bug.
Version 0.03	Third test release 8/10/98
		enhanced soundcanvas performance
		fixed file->save Mac bug
Version 0.04	Forth test release 9/8/98
		changed operation of track controls
Version 0.05	9/14/98
		changed point control methods
		changed menubar labels
Version 0.10	Added ability to show/hide sound canvas info 
	        fixed track switching bug.

KNOWN BUGS
Play option doesn't work.
Poor Mac performace
Start and end times cannot be typed into the text fields, only displayed.

FUTURE ENHANCEMENTS

Version .20	Get play option working
Version .30	Add angle/distance option when entering/nudging points
Version .40	Add expand/contract to nudge options
Version .50	Add basic undo feature.
Version .60	Add ability to view text version of graphics file.
Version .70	Add basic error/checking messages.
Version .80	Add keyboard shortcuts



