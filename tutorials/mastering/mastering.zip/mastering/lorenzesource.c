    /*********************************************/
    /* Loops for the Lorenz Opcode               */
    /* Coded by Hans Mikelson                    */
    /*********************************************/

    /* The outer do loop loops ksmps times.  This is the same ksmps */
    /* that is provided by the orchestra.  Output values generated  */
    /* inside of this loop will be at a-rate and output values      */
    /* generated outside of this loop be at k-rate.                 */

    nn = ksmps;
    do {

      /* The inner loop can be used to increase the pitch     */
      /* of the sound by skipping a given number of x, y and  */
      /* z values for each set of values output.              */

      do {

        /* Use Euler's method to update the x, y and z values. */
        /* This works if hstep is small compared to the        */
        /* curvature of the function.                          */

        xx   =      x+hstep*s*(y-x);      /* The x and y values must be saved in   */
        yy   =      y+hstep*(-x*z+r*x-y); /* temporary variables so they have not  */
        z    =      z+hstep*(x*y-b*z);    /* been changed when z is updated.  The  */
        x    =      xx;                   /* x and y values are then restored from */
        y    =      yy;                   /* temporary variables xx and yy.        */

      } while (--skip>0);                 /* Return to the top of the inner loop.  */

      /* Output the results */
      
      *outx++ = x;                        /* Output three audio rate signals for   */
      *outy++ = y;                        /* x, y and z.                           */
      *outz++ = z;
    }
    while (--nn);                         /* Return to the top of the outer loop.  */
