    p->outputGain = amp + 0.001f;

    /* The filter adds a small delay in addition to the delay line. */
    /* This would lower the pitch slightly.  This tries to correct  */
    /* for the filter delay.                                        */

    /* length - approx filter delay */
    DLineL_setDelay(&p->delayLine, (esr/ *p->frequency) * 0.5f - 1.5f);

    p->v_rate = *p->vibFreq * p->vibr->flen / esr;

    /* Check to see if into decay yet */
    if (p->kloop>0 && p->h.insdshead->relesing) p->kloop=1;

    if ((--p->kloop) == 0) {
      p->envelope.state = 1;  /* Start change */
      p->envelope.rate = p->envelope.value / (*p->dettack * esr);
      p->envelope.target =  0.0f;
    }

    /* This is the inner loop for generating the audio samples. */

    do {
        FLOAT pressureDiff;
        FLOAT breathPressure;
        long temp;
        FLOAT temp_time, alpha;
        FLOAT nextsamp;
        FLOAT v_lastOutput;
        FLOAT lastOutput;

        /* Get the breath pressure envelope and use it to shape the noise signal. */

        breathPressure = Envelope_tick(&p->envelope);
        breathPressure += breathPressure * nGain * Noise_tick(&p->noise);

        /* This section is for the vibrato. */

                                       /* Tick on vibrato table   */
        vTime += p->v_rate;            /* Update current time     */
        while (vTime >= v_len)         /* Check for end of sound  */
          vTime -= v_len;              /* loop back to beginning  */
        while (vTime < 0.0f)           /* Check for end of sound  */
          vTime += v_len;              /* loop back to beginning  */

        temp_time = vTime;

#ifdef have_phase
        if (p->v_phaseOffset != 0.0f) {
          temp_time += p->v_phaseOffset;   /*  Add phase offset       */
          while (temp_time >= v_len)       /*  Check for end of sound */
            temp_time -= v_len;            /*  loop back to beginning */
          while (temp_time < 0.0f)         /*  Check for end of sound */
            temp_time += v_len;            /*  loop back to beginning */
        }
#endif
        temp = (long) temp_time;         /*  Integer part of time address     */
                                         /*  fractional part of time address  */
        alpha = temp_time - (FLOAT)temp;
        v_lastOutput = v_data[temp];     /* Do linear interpolation */

        /*  same as alpha*data[temp+1] + (1-alpha)data[temp] */
        v_lastOutput += (alpha * (v_data[temp+1] - v_lastOutput));

        /* End of vibrato tick */

        breathPressure += breathPressure * vibGain * v_lastOutput;

        /* Filter the signal */
        pressureDiff = OneZero_tick(&p->filter,
DLineL_lastOut(&p->delayLine));

        /* differential pressure of reflected and mouth */
        pressureDiff = (-0.95f*pressureDiff) - breathPressure;

        /* Use a look up table to control the signal level so it does not "blow up." */
        nextsamp     = pressureDiff *
ReedTabl_LookUp(&p->reedTable,pressureDiff);
        nextsamp     = breathPressure + nextsamp;

        /* Update the delay line.               */
        /* perform scattering in economical way */
        lastOutput   = DLineL_tick(&p->delayLine, nextsamp);
        lastOutput  *= p->outputGain;

        *ar++        = lastOutput*AMP_SCALE; /* Output the result as audio. */

    } while (--nsmps); /* End of the ksmps loop. */

    p->v_time = vTime; /* Update the vibrato time. */
}
