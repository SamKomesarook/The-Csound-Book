#define ReedOsc(dP'Vr'fr'Qr'Ur'Hr)
# 
iwr = 2*ipi*$fr; normalized in radians/cycle
igr = iwr/$Qr

kx1 init ihr;previous reed aperture (at t=-1)
kx2 init ihr;initial reed aperture (at t=0)


;the constants are computed as:
it=1/sr;sampling period

ic1 = 2-iwr*iwr*it*it - igr*it
ic2 = igr*it - 1
ic3 = -it*it*$Vr/$Ur		
ic4 = it*it*iwr*iwr

kdp1 downsamp $dP;necessary to compute a k-rate variable

kx0 = kx1	
kx1 = kx2		
kx2 = ic1*kx1 + ic2*kx0 + ic3*kdp1 + ic4*$Hr
#
