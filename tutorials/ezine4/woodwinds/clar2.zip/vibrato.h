#define vibrato(depth'freq'zak)
#kdepth linseg 5,.5,$depth,0,$depth
kspeed linseg 3,.2,3,.5,$freq,0,$freq
kvibr oscil kdepth,kspeed,1
;vibrato is most noticeable at small amplitudes
zkwm kvibr,$zak#