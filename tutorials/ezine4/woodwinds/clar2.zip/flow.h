#define flow(zak)
#/* main flow input : A basic model of a real performer ;-)
set the optimum range of input pressures according to the note frequency
set the optimum transition time between fingerings, attack time and release time
*/ 
iminamp tablei ifreq,5,0; boundary values for the input flow pressure
imaxamp tablei ifreq,6,0

itemp=p3
iamp = (itemp>.2? ((imaxamp-iminamp)*iamp^2):(imaxamp-iminamp)*sqrt(iamp))
;to favour low pressures in general but higher pressures when playing fast

itemp=p3
ittime = (itemp>.1?6/ifreq:0.01);transition time between two different fingerings
;& attack time at the same time (short with shorter notes)

itemp=p3
irel = (itemp>.1? 4/ifreq:0.01);release time - experiment!

p3 = p3+irel

kp0 linseg 0,ittime,iminamp+iamp,p3-ittime-irel,iminamp+iamp,irel,0
zkwm kp0,$zak;mixes flows at zk location 3 ;for ALL the notes (1 or 2)
#
