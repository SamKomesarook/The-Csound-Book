#define header(rate'zak)
#sr   = $rate.
kr   = $rate.;use sr=kr please
ksmps= 1
zakinit $zak.,$zak.; locations 0,1,2 & 3#
