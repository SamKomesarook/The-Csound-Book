/* Clipping Routine for clarinet beating

the routine uses a value kclipd that sets the distance bewteen
g and kclipx1. So for high values of kclipd, the clipping is
very 'soft'. and for kclipd=0 there is no softening at all,
and the clipping is equivalent to the way we have it now.

Clipping Routine for clarinet beating
the clipping routine has two control parameters:
g = minimum value for x to clip at
m = 'softness' of clipping: m corresponds to
the half-width (kclipd) of the range in which the clipping
does 'circular' waveshaping
m is experessed in fraction(0 to 1) of the equilibrium opening ihr
0 means no softening at all
1 means very much softening
*/
#define ReedClip(g'm'h)
#
;initialisation part of the clipping routine

kclipd = $m*$h;
kclipk = 1 - sqrt(2);
kclipx1 = $g - kclipd;
kclipa = kclipx1;
kclipr = (kclipa-$g)/kclipk;
kclipb = kclipr + $g;
kclipx2 = (kclipx1 + kclipb)/2;

;the routine itself

if kx2 < kclipx1 goto full
goto nofull
full:
kx2 = $g;full clipping
goto clipped

nofull:
if kx2 > kclipx2 goto noclip
goto nonoclip
noclip:
kx2 = kx2;no clipping
goto clipped

nonoclip:
kx2 = kclipb - sqrt(kclipr*kclipr - (kx2-kclipx1)*(kx2-kclipx1));circular (soft) clipping
clipped:#