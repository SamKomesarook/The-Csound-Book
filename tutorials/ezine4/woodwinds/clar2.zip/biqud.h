/* Same as the biquad opcode with a gain control
	SECOND ORDER SECTION



                B0 + B1*z1 + B2*z2

H(z) = gain * --------------------

                A0 + A1*z1 + A2*z2


*/
#define biquad(input'output'gain'b0'b1'b2'a0'a1'a2)
#$output biquad $input,$b0,$b1,$b2,$a0,$a1,$a2
$output = $output*$gain
#
