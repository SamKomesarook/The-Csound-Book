;Backus equation implementation

#define Bflow15(Z0'Ir'Er'N)
#ic6 = isr/it
ic7 = -($Z0*it/$Ir + 1)
ic8 = -it*$Er/$Ir
ic9 = it/$Ir
;kur2 = ic6*(kx2 - kx1);must compensate for the phase delay induced by kur2!	
kur2 = 0;IN TUNE!!!!!!!	

id1 = ic7	
kd2 = ic8/(kx2 * kx2)	
kd3 = ic9*(kp0 - 2*kpr2 + $Z0*kur2) + kuf1	
	
;NEWTON-RHAPSON iteration.

;Uf(n) is used as initial value.

 kd4=kd2*iq;
 kd5=kd4-kd2;
 kxo=kuf1;

kcounter = $N;reinitialise counter
iter:

kbsaxo = abs(kxo)
ksign = kbsaxo;temp. variable
ksign_axo = (ksign<0?-1:1)
kbsaxoq1 = kbsaxo^(iq-1)
kbsaxoq  = kbsaxo*kbsaxoq1

   kxo=(kd5*ksign_axo*kbsaxoq-kd3)/(id1+kd4*kbsaxoq1)

kcounter = kcounter - 1
if kcounter > 0 goto iter; iterate inumb_iter times

kuf2 = kxo;get value
	
kub2 = kuf2 - kur2;total volume flow for next pass	
api2 = $Z0*kub2 + apr2;ingoing pressure wave into the tube
apm2 = api2 + apr2;mouthpiece pressure#
