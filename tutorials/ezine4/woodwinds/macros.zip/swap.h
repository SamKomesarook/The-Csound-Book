/* a routine to allow legato transitions by defining 2 bores
and swapping between them from note to note
please set zakflag = 0  and zak_transition = 4 by default
to better optimize the zak allocated space
*/

#define swap(TransitionTime'zakflag'zaktransition)
#icontrol zir $zakflag; = 0 at compilation start time
icontrol = (icontrol == 0 ? 1:0);this swaps bores at each new event
ziw icontrol,$zakflag
ziw ifreq, icontrol+1;writes frq. at zk location 1 or 2. First is 2 <-- !

;weighting factor for bore swap
;activated at each new event

istart = icontrol
iend = 1-istart
transition:
kweight line istart,$TransitionTime,iend
kweight tablei kweight,4,1;a smooth sigmoidal transition (optional)

zkw kweight,$zaktransition#
