#define breath(depth'fco'zak)
#kbreath gauss $depth*kp0;add some pressure-dependent breath noise
kbreath tonek kbreath, $fco
zkwm kbreath,$zak;mixes breath noise with flow flows at zk location 3 #
