Well, this is a preliminar release of my Grallot!
Things to improve:

a/ make it responsive to amplitude changes

b/ avoid the "wolfe" note ;-) (around 400 Hz)
possibly by changing the reed-lips pressure at high frequencies

c/ tabulate frequency values to avoid the need to use the pitch tracker.
taking into account a/ and b/

d/ recode all the stuff with macros for better readability

e/ write a MIDIfied version of Grallot

Josep M