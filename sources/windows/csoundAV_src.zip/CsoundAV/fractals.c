#include "cs.h"
#include "fractals.h"
#include <math.h>

/* mandelbrot set scanner */
void mandel_set(MANDEL *p)
{
	p->oldx=-99999; /* probably unused values */
	p->oldy=-99999;
	p->oldCount = -1;
}

void mandel(MANDEL *p)
{
	MYFLT px=*p->kx, py=*p->ky;
	if (*p->ktrig && (px != p->oldx || py != p->oldy)) {
		int maxIter = (int) *p->kmaxIter, j;
		MYFLT x=0.f, y=0.f, newx, newy;
		for (j=0; j<maxIter; j++) {
			newx = x*x - y*y + px;
			newy = 2*x*y + py;
			x=newx;
			y=newy;
			if (x*x+y*y >= 4) break;
		}
		p->oldx = px;
		p->oldy = py;
		if (p->oldCount != j) *p->koutrig = 1.f;
		else *p->koutrig = 0.f;
		*p->kr = (MYFLT) (p->oldCount = j);
	}
	else {
		*p->kr = (MYFLT) p->oldCount;
		*p->koutrig = 0.f;
	}
}


/*-------------------------*/
void ca_set(CELLA *p)  
{
	FUNC	*ftp;
	int elements;
	MYFLT *currLine, *initVec;

    if ((ftp = ftfind(p->ioutFunc)) != NULL) {
      p->outVec = ftp->ftable;
	  elements = (p->elements = (int) *p->ielements);
	  if ( elements >= ftp->flen ) initerror("cella: invalid num of elements");
    }
	else initerror("cella: invalid output table");
    if ((ftp = ftfind(p->initStateFunc)) != NULL) {
      initVec = (p->initVec = ftp->ftable);
	  if ( elements >= ftp->flen ) initerror("cella: invalid num of elements");
    }
	else initerror("cella: invalid initial state table");
    if ((ftp = ftfind(p->iRuleFunc)) != NULL) {
      p->ruleVec = ftp->ftable;
    }
	else initerror("cella: invalid rule table");
	
	if (p->auxch.auxp == NULL)
		auxalloc(elements * sizeof(MYFLT) * 2, &p->auxch);
	currLine = (p->currLine = (MYFLT *) p->auxch.auxp);
	p->NewOld = 0;
	p->ruleLen = (int) *p->irulelen;
	do	*currLine++ = *initVec++;
	while (--elements);
}


void ca(CELLA *p)
{					
	if (*p->kreinit) {
		MYFLT *currLine = p->currLine, *initVec = p->initVec;
		int elements =  p->elements;
		p->NewOld = 0;
		do	*currLine++ = *initVec++;
		while (--elements);
	}
	if (*p->ktrig) {
	   	int j, elements = p->elements, jm1, ruleLen = p->ruleLen;
		MYFLT *actual, *previous, *outVec = p->outVec, *ruleVec = p->ruleVec;
		previous = &(p->currLine[elements * p->NewOld]);
		p->NewOld += 1;
		p->NewOld %= 2;
		actual   = &(p->currLine[elements * p->NewOld]);
		if (*p->iradius == 1) {		
			for (j=0; j < elements; j++) {
				jm1 = (j < 1) ? elements-1 : j-1;
				outVec[j] = previous[j];
				actual[j] = ruleVec[ (int) (previous[jm1] + previous[j] + previous[(j+1) % elements] ) % ruleLen];
			}
		} else {
			int jm2;
			for (j=0; j < elements; j++) {
				jm1 = (j < 1) ? elements-1 : j-1;
				jm2 = (j < 2) ? elements-2 : j-2;
				outVec[j] = previous[j];
				actual[j] = ruleVec[ (int) (previous[jm2] +	previous[jm1] + 
											previous[j] + 
											previous[(j+1) % elements] + previous[(j+2) % elements])
											% ruleLen];
			}
		}

	} else {
		int elements =  p->elements;
		MYFLT *actual = &(p->currLine[elements * !(p->NewOld)]), *outVec = p->outVec;
		do  *outVec++ = *actual++ ;
		while (--elements);
	}
}


