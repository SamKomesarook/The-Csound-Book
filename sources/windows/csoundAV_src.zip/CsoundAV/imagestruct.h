
struct imageStruct {
    GLint           xsize;  /* columns */
    GLint   	    ysize; /* rows */
    GLint   	    csize; /* color (LUMINANCE = 1, RGBA = 4) */
    GLenum          format; /* the format - either GL_RGBA or GL_LUMINANCE */
    GLenum          type; /* data type */
    void   *data;   /*  the actual image data */
	void   *bmpObj;   /* pointers to CAnyBmp object; alternative format to *data */
	imageStruct() { data=NULL; bmpObj=NULL; }
};

#define RED		0
#define GREEN	1
#define BLUE	2
#define ALPHA	3

#ifdef __cplusplus

inline BYTE CLAMP(int x)
    { return(((x > 255) ? 255 : ( (x < 0) ? 0 : x))); }

inline BYTE CLAMP(MYFLT x)
    { return((unsigned char)((x > FL(255.0)) ? FL(255.0) : ( (x < FL(0.0)) ? FL(0.0) : x))); }

inline void copy2Image(imageStruct *to, imageStruct *from)
{
    if (!to || !from || !from->data)
    {
        initerror("bogus pointer to copy2Image");
        if (to) to->data = NULL;
        return;
    }

    // copy the information over
    to->xsize 	= from->xsize;
    to->ysize 	= from->ysize;
    to->csize 	= from->csize;
    to->format 	= from->format;
    to->type 	= from->type;
    to->data 	= new unsigned char[to->xsize * to->ysize * to->csize];
    // copy the data over
    memcpy(to->data, from->data, to->xsize * to->ysize * to->csize);
}

#endif