typedef struct
	{
	OPDS	h;
	MYFLT	*rcar, *rmod, *kfreq_max, *kfreq_min, *kband_max, *kband_min;
	} DSH;

