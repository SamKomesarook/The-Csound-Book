                                                         /* ugmoss.h */

typedef struct {
  OPDS          h;
  MYFLT         *ar, *ain, *isize, *ifn;
  MYFLT         *curp;
  FUNC          *ftp;
  AUXCH         sigbuf;
  long          len;
} DCONV;

/* end moss.h */
