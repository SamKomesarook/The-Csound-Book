typedef struct	{
	OPDS	h;
	MYFLT *ifps, *iresolution;
} GLPERIOD;

typedef struct	{
	OPDS	h;
	MYFLT  *name, *iwidth, *iheight, *ix, *iy, *border;
} GL_PANEL;


typedef struct	{
	OPDS	h;
	long vectorID;
} GL_BEGIN;

typedef struct	{
	OPDS	h;
	MYFLT	*cap;
} GL_ENABLE;

typedef struct	{
	OPDS	h;
	MYFLT	*map, *mapsize, *ifn_values;
	MYFLT *table;
} GL_PIXEL_MAP;

typedef struct	{
	OPDS	h;
	MYFLT *pos_level;
	long vectorID;
	int  p3type, relesing_flag, done_flag;
	long kcounterEnd;
} GL_INSERT;


typedef struct	{
	OPDS	h;
	MYFLT	*fovy, *zNear, *zFar;
} GL_PERSP;

typedef struct	{
	OPDS	h;
	MYFLT	*red, *green, *blue, *alpha;
} GL_COLOR4;

typedef struct	{
	OPDS	h;
	MYFLT	*red, *green, *blue;
} GL_COLOR3;

typedef struct	{
	OPDS	h;
	MYFLT	*pname, *red, *green, *blue, *alpha;
} GL_MATERIAL;


typedef struct	{
	OPDS	h;
	MYFLT	*mode;
} GL_MODE;

typedef struct	{
	OPDS	h;
} GL_NOARG;

typedef struct	{
	OPDS	h;
	MYFLT	*arg;
} GL_ONEARG;

typedef struct	{
	OPDS	h;
	MYFLT	*arg1, *arg2;
} GL_TWOARGS;

#ifdef WIN32 /* ================== */

typedef struct	{
	OPDS	h;
	MYFLT	*nLists,  *typeface, *depth, *weight, *italic;
	char *style;
} GL_3D_FONT;

typedef struct	{
	OPDS	h;
	MYFLT	*string, *nFontList;
	int text_length;
	char *text;
} GL_TEXT3D;

typedef struct	{
	OPDS	h;
	MYFLT *tex_handle, *video_handle, *reqFrame;
	long curFrame;
	int old_video_handle;
} GL_VIDEO2TEX;

typedef struct	{
	OPDS	h;
	MYFLT *video_handle, *filename, *backGroundAlpha;
} GL_OPEN_VIDEO_FILE;

typedef struct	{
	OPDS	h;
	MYFLT  *device_num, *vid_xsize, *vid_ysize,  *img_handle, *img_xsize, *img_ysize, *vid_xpos, *vid_ypos;
} GL_OPEN_VIDEO_CAM;


typedef struct	{
	OPDS	h;
	MYFLT  *device_num;
	int flag;
	void *cam_obj;
} GL_CAMPERF;

typedef struct	{
	OPDS	h;
	MYFLT  *device_num;
	int done;
} GL_CAM_DLG;

#endif  /* WIN32 ==================  */


typedef struct	{
	OPDS	h;
	MYFLT	*light, *pname, *param;
} GL_LIGHT;

typedef struct	{
	OPDS	h;
	MYFLT	*pname, *param;
} GL_LIGHT_MODEL;

typedef struct	{
	OPDS	h;
	MYFLT	*pname, *param0, *param1, *param2, *param3;
} GL_LIGHT_MODELV;

typedef struct	{
	OPDS	h;
	MYFLT	*light, *pname, *param0, *param1, *param2, *param3;
} GL_LIGHTV;

typedef struct	{
	OPDS	h;
	MYFLT	*flag;
	int px,py,pw,ph;
} GL_FULLSCREEN;


typedef struct	{
	OPDS	h;
	MYFLT	*sfactor, *dfactor;
} GL_BLENDFUNC;

typedef struct	{
	OPDS	h;
	MYFLT	*coord, *pname, *coeff_X,*coeff_Y,*coeff_Z,*coeff_W;
} GL_TEXGENFV;

typedef struct	{
	OPDS	h;
	MYFLT *stride, *offset, *ifn;
	MYFLT *table;
} GL_POINTER;

typedef struct	{
	OPDS	h;
	MYFLT *mode, *count, *ifn;
	AUXCH aux;
	long *table;
} GL_DRAWELEMENTS;

typedef struct	{
	OPDS	h;
	MYFLT *mode, *first, *count;
	
} GL_DRAWARRAYS;

typedef struct	{
	OPDS	h;
	MYFLT	*x,*y,*z;
} GL_AXIS;

typedef struct	{
	OPDS	h;
	MYFLT	*kleft,*kright,*kbottom,*ktop,*knear,*kfar;
} GL_ORTHO;

typedef struct	{
	OPDS	h;
	MYFLT	*x,*y,*z;
	double v[3];
} GLU_TES_VERTEX;


typedef struct	{
	OPDS	h;
	MYFLT	*angle, *x,*y,*z;
} GL_ROTATE;



//--------------------
typedef struct	{
	OPDS	h;
	MYFLT	*kradius, *kslices, *kstacks, *itype;
} GLUTSPHERE;

typedef struct	{
	OPDS	h;
	MYFLT	*QuadricObj,*radius,*slices,*stacks;
} GLU_SPHERE;

typedef struct	{
	OPDS	h;
	MYFLT	*QuadricObj, *innerRadius, *outerRadius, *slices, *loops;
} GLU_DISK;

typedef struct	{
	OPDS	h;
	MYFLT	*QuadricObj, *baseRadius, *topRadius, *height, *slices, *stacks;
} GLU_CYLINDER	;

typedef struct	{
	OPDS	h;
	MYFLT	*size, *coord1s, *coord1t, *coord2s, *coord2t, *coord3s,*coord3t, *coord4s, *coord4t;
} GL_TEXSQUARE;

typedef struct	{
	OPDS	h;
	MYFLT	*radius, *slices, *coord1s, *coord1t, *zooms, *zoomt;
	int num_slices;
	#define MAX_CIRCLE_PNTS 100
	MYFLT	m_cos[MAX_CIRCLE_PNTS], m_sin[MAX_CIRCLE_PNTS];
} GL_TEXCIRCLE;

typedef struct	{
	OPDS	h;
	MYFLT	*ifn, *index;
	MYFLT	*table;
	double	v[3];
} GLU_TESS_VERTEXV;

typedef struct	{
	OPDS	h;
	MYFLT  *eyex, *eyey, *eyez, *centerx, *centery, *centerz, *upx, *upy, *upz; 
	
} GLU_LOOKAT;

typedef struct	{
	OPDS	h;
	MYFLT	*target, *u1, *u2, *ustride, *uorder, *ifn_points ;
	MYFLT   *table;
} GL_MAP1;

typedef struct	{
	OPDS	h;
	MYFLT	*target, *u1, *u2, *ustride, *uorder, *v1,*v2, *vstride, *vorder, *ifn_points ;
	MYFLT   *table;
} GL_MAP2;

typedef struct	{
	OPDS	h;
	MYFLT	*un, *u1, *u2;
} GL_MAPGRID1;


typedef struct	{
	OPDS	h;
	MYFLT	*un, *u1, *u2, *vn, *v1, *v2;
} GL_MAPGRID2;

typedef struct	{
	OPDS	h;
	MYFLT	*mode, *u1, *u2;
} GL_EVALMESH1;

typedef struct	{
	OPDS	h;
	MYFLT	*mode, *u1, *u2, *v1, *v2;
} GL_EVALMESH2;

typedef struct	{
	OPDS	h;
	MYFLT	*nobj, *nknots, *ifn_knot, *stride, *ifn_ctlarray, *order, *type;
	MYFLT   *table1, *table2;
} GLU_NURBSCURVE;

typedef struct	{
	OPDS	h;
	MYFLT	*nobj, *Uknot_count, *ifn_Uknot, *Vknot_count, *ifn_Vknot, *Ustride, *Vstride, *ifn_ctlarray, *Uorder, *Vorder, *type;
	MYFLT   *table1, *table2, *table3;
} GLU_NURBSSURFACE;

typedef struct	{
	OPDS	h;
	MYFLT	*nobj,*property,*value ;
} GLU_NURBSPROPERTY;

typedef struct	{
	OPDS	h;
	MYFLT	*nobj, *count, *ifn_array, *stride, *type;
	MYFLT   *table;
} GLU_PWLCURVE;

typedef struct	{
	OPDS	h;
	MYFLT	*innerRadius, *outerRadius, *sides, *rings, *itype;
} GLUTORUS;


typedef struct	{
	OPDS	h;
	MYFLT	*texID, *filename, *trans, *wrapst;
} GL_LOAD_TEXTURE;
/*
typedef struct	{
	OPDS	h;
	MYFLT	*texID;
	int		texObj;
} GL_BINDTEXTURE;
*/
typedef struct	{
	OPDS	h;
	MYFLT	*dispList, *filename, *mode, *smooth_angle, *texture_type, *wireframe;
} GL_READ_OBJECT;

typedef struct	{
	OPDS	h;
	MYFLT *ifn;
	MYFLT *table;
} GL_MATRIXV;

typedef struct	{
	OPDS	h;
	MYFLT *m0,*m1, *m2, *m3, *m4, *m5, *m6, *m7, *m8, *m9, *m10, *m11, *m12, *m13, *m14, *m15;
} GL_MATRIX;

typedef struct	{
	OPDS	h;
	MYFLT  *left, *right, *bottom, *top, *znear, *zfar; 
} GL_FRUSTUM;

typedef struct	{
	OPDS	h;
	MYFLT  *planeNum, *coeff0, *coeff1, *coeff2, *coeff3; 
} GL_CLIPLANE;

//--------------------

typedef struct	{
	OPDS	h;
	MYFLT *var, *start, *stop, *incr;
	void * opdsVector;
} GL_FOR;

typedef struct	{
	OPDS	h;
	MYFLT  *val1, *ioperator, *val2;
	void * opdsVector1;
	void * opdsVector2;
} GL_IF;


typedef struct {
	OPDS	h;
	MYFLT	*sr, *frames_per_cycle, *iphs;
	double	curphs;
} GL_PHASOR;


typedef struct {
	OPDS	h;
	MYFLT	*sr, *frames_per_cycle, *iphs;
	double	curphs;
	int flag;
} GL_METRO;

typedef struct	{
	OPDS	h;
	MYFLT	*out, *amp, *frames_per_cycle, *ift, *iphs;
	FUNC	*ftp;
	long	tablen;
	double	phs;
} GL_OSCIL;

typedef struct	{
	OPDS	h;
	MYFLT	*itexHandle, *trigger, *imageHandle, *clamp, *filter;
	int xsize, ysize, csize;
	unsigned int texObj;
	int old_handle, init_flag, changed;
} GL_PIX2TEX;

typedef struct {
	OPDS	h;
	MYFLT	*kout, *kin;
	AUXCH	aux;
	double  kcount, framecount;
	long	left, indx;
	int flag;
} G_RATE;

typedef struct {
	OPDS	h;
	MYFLT	*itab_out, *itab_in, *ielem, *istart_ndx;
	MYFLT	*tab_in, *tab_out;
	AUXCH	aux;
	double  kcount, framecount;
	long	left, indx, elem, start_ndx;
} G_RATE_TAB;

typedef struct {
	OPDS	h;
	MYFLT	*delay;
} GL_SET_FDELAY;


typedef struct	{
	OPDS	h;
	MYFLT *handle, *numObjects, *filename;
	//MYFLT *ftable
} LOAD_PICASSO;

typedef struct	{
	OPDS	h;
	MYFLT *handle,*mode, *inargs[VARGMAX];
	int numPieces, numTriangles[256], index;
} RENDER_PICASSO;
