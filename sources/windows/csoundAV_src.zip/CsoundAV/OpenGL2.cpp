#include <GL/glut.h>
#include <GL/glu.h>
#include <GL/gl.h>

#if defined (_WIN32)
#	pragma warning(disable:4786 4117 4804 985)
#	include <windows.h>
#	include <vfw.h>
#endif

#include <vector>
#include <map>
#include <string>
#include <math.h>

using namespace std;

extern "C" {
#undef __cplusplus
	#include "Cs.h"
	//#include "musmon.h"
	#include "OpenGL1.h"
	
#define __cplusplus
	#include "GL/glpng.h"
	#include "GL/glm.h"

	extern EVTBLK *currevent;
	extern int	strsmax;
	extern char **strsets;


}

typedef vector<OPDS*> OPDSvectType;


struct LOOP_STACK {	
	OPDS *h;
	int	count;
	OPDSvectType LoopVect;
	LOOP_STACK(OPDS *new_h,  int new_count) : h(new_h), count(new_count) {}
	LOOP_STACK() { h=NULL; 	count=0; }
};

#include "imagestruct.h"


struct VIDEO_OBJ {
	PAVISTREAM		m_streamVid;
	PGETFRAME		m_getFrame;
	long			m_numFrames;
	int				m_xsize;
	int				m_ysize;
	imageStruct		m_pixBlock;
	GLuint			texture_obj;
};

struct VIDEO_CAMERA_OBJ {
	HWND	m_hWndC;
	CAPDRIVERCAPS gCapDriverCaps;
	int		m_vidXSize,	m_vidYSize;
	int		img_xsize,	img_ysize;
	int		xPos,		yPos;
	int		xSize,		ySize;
	BYTE*			img_data;
	imageStruct*	m_pixBlock;
	VIDEO_CAMERA_OBJ() { m_hWndC = NULL; img_data=NULL; m_pixBlock=NULL; }
};

struct PICA_TRIANGLE {
	short x1,x2, y1,y2, z1,z2;
	float normal[3]; 
};
//typedef vector<vector<PICA_TRIANGLE>> PICASSO_OBJ;

typedef vector<PICA_TRIANGLE> VEC_SHORT;
typedef vector<VEC_SHORT> PICASSO_OBJ;

static CRITICAL_SECTION criticalSection;

static vector<LOOP_STACK> loopStack; 
static vector<void *> allocatedItems;
static vector<GLuint> v_texture;
static vector<void *> v_gluQuadricObj;
static vector<void *> v_gluNurbsObj;
static vector<VIDEO_OBJ> v_videoObj;
extern map<int,imageStruct> Bm_image; // map of pointers to CAnyBmp objects
static map<int,VIDEO_CAMERA_OBJ> v_VideoCameraObj;
static map<int,VIDEO_CAMERA_OBJ>::iterator vCam_it;
static vector <PICASSO_OBJ> v_picassoObj;

static int loopStack_count=0; 
static int num_display_lists=0;
static GLUtesselator *Tess = NULL;


#define M_F_DEL 16
static		int		MAX_FRAME_DELAY = M_F_DEL;
static		int		frame_delay = M_F_DEL/4;

extern bool OpenGL_enabled;
extern HWND callback_target;
extern bool OpenGL_init_stage;
extern OPDSvectType currVect;  
extern GLfloat	fAspect;
extern char * GetString(MYFLT pname, char *t);
extern long	FrameDiff;


#define PBACK              {							 \
	if (loopStack_count > 0)							 \
		loopStack.back().LoopVect.push_back( (OPDS*)p);	 \
	else												 \
		currVect.push_back((OPDS*)p);					 \
}

#define INIT_F(func)									 \
{														 \
	p->h.GLadr=(void (*)(void *))(func);				 \
	if (loopStack_count > 0)							 \
		loopStack.back().LoopVect.push_back( (OPDS*)p);	 \
	else												 \
		currVect.push_back( (OPDS*)p);			 		 \
}

GLint nFontList;

#ifdef RESET

void OpenGL_RESET2();

void GLerror(LPSTR lpszFunction) 
{ 
     
	LPVOID lpMsgBuf;// szBuf[512];

    DWORD dw = GetLastError(); 
	FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
		NULL,
		dw,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
		(LPTSTR) &lpMsgBuf,
		0,
		NULL );

    printf("%s failed: GetLastError returned %u: %s\n", 
        lpszFunction, dw, lpMsgBuf ); 
	LocalFree( lpMsgBuf );
 
    //MessageBox(NULL, szBuf, "ERROR", MB_OK); 
    //ExitProcess(dw); 
} 
 

extern "C" void OpenGL_RESET()
{
	int j;
	OpenGL_RESET2();
	for(j=0; j<	v_gluQuadricObj.size(); j++) {
		gluDeleteQuadric((GLUquadricObj*)( v_gluQuadricObj[j]));
	}
	v_gluQuadricObj.clear();

	for(j=0; j<	v_gluNurbsObj.size(); j++) {
		gluDeleteNurbsRenderer((GLUnurbsObj*)( v_gluNurbsObj[j]));
	}
	v_gluNurbsObj.clear();
	
	if(v_texture.size() > 0)
		glDeleteTextures(v_texture.size(), &v_texture[0]);
	v_texture.clear();
	
	glDeleteLists(1, num_display_lists);
	num_display_lists=0;
	glPopAttrib();
	
	for (j = allocatedItems.size()-1; j >=0; j--)  {
		delete allocatedItems[j];
		allocatedItems.pop_back();
	}
	
	for (j =0; j < v_videoObj.size(); j++) {
		delete [] v_videoObj[j].m_pixBlock.data;
		AVIFileExit(); 
	}
	v_videoObj.clear();

	#ifdef WIN32
	int flag = 0;
	for(vCam_it = v_VideoCameraObj.begin(); vCam_it != v_VideoCameraObj.end(); vCam_it++) { 
		if (!flag) EnterCriticalSection(&criticalSection);		
		flag =1;
		if ((*vCam_it).second.m_hWndC   != NULL) { //destroys allocated map elements
			char name[255], description[255]; 
			int device_num = (*vCam_it).first,   ret;
			HWND m_hWndC = (*vCam_it).second.m_hWndC;

			ret = capGetDriverDescription(device_num, name, 255, description, 0);
			
			printf("Closing capture driver: %s \n", name);
			ret = capCaptureStop(m_hWndC);
			if (!ret) GLerror("capCaptureStop");
			Sleep(300);
			ret = capSetCallbackOnVideoStream(m_hWndC, NULL) ;
			if (!ret) GLerror("capSetCallbackOnVideoStream");
			Sleep(300);
			ret = capDriverDisconnect(m_hWndC);
			if (!ret) GLerror("capDriverDisconnect");
			Sleep(300);
			ret = DestroyWindow(m_hWndC);
			if (!ret) GLerror("DestroyWindow");
			Sleep(300);
			
		}
	}

	if (flag) 	{ 
		LeaveCriticalSection(&criticalSection);
		DeleteCriticalSection(&criticalSection);
	}
	v_VideoCameraObj.clear();
	#endif
	v_picassoObj.clear();
	currVect.clear();
	loopStack_count=0;
	Tess =  NULL;
	OpenGL_init_stage = true;
	MAX_FRAME_DELAY = M_F_DEL;
	frame_delay = M_F_DEL/4;
}

#endif

//--------------------------------
extern "C" void GLfor(GL_FOR *p) {
	loopStack.push_back(LOOP_STACK(&p->h, loopStack_count));
	loopStack_count++;
}

void GLfor_runtime(GL_FOR *p) {

	if (*p->incr > 0) {
		for (*p->var = *p->start; *p->var <= *p->stop; *p->var += *p->incr) {
			OPDS **v =  &(*(( OPDSvectType *) p->opdsVector))[0];
			for (int k = 0; k< (const int) (*(( OPDSvectType *) p->opdsVector)).size(); k++) {
				OPDS *pds = v[k];
				(*pds->GLadr)(pds);
			}
		}
	}
	else {
		for (*p->var = *p->start; *p->var >= *p->stop; *p->var += *p->incr) {
			OPDS **v =  &(*(( OPDSvectType *) p->opdsVector))[0];
			for (int k = 0; k< (const int) (*(( OPDSvectType *) p->opdsVector)).size(); k++) {
				OPDS *pds = v[k];
				(*pds->GLadr)(pds);
			}
		}
	}
}

extern "C" void GLfor_end(GL_FOR *p) {
	loopStack_count--;
	//LOOP_STACK loop_stk = loopStack.back();
	GL_FOR *p_old = (GL_FOR *) loopStack.back().h;
	p->var = p_old->var;
	p->start = p_old->start;
	p->stop = p_old->stop;
	p->incr = p_old->incr;
	if (strcmp( loopStack.back().h->optext->t.opcod, "GLfor")) {
		initerror("GLfor_end: invalid stack pointer: verify its placement");
		return;
	}
	if(loopStack.back().count != loopStack_count) {
		initerror("GLend_for: invalid stack count: verify GLfor/GLend_for count and placement");
		return;
	}
	if (p->opdsVector == NULL) {
		p->opdsVector = (void *) new OPDSvectType;
		allocatedItems.push_back(p->opdsVector);
	}
	*((OPDSvectType *) p->opdsVector) = loopStack.back().LoopVect;
	loopStack.pop_back();
	
	/////////////////////////////////////////////////
	p->h.GLadr=(void (*)(void *))(GLfor_runtime);	
	if (loopStack_count > 0)	
		loopStack.back().LoopVect.push_back( (OPDS*)p);
	else
		currVect.push_back( (OPDS*)p);			 


}

//--------------------------------

/*
typedef struct	{
	OPDS	h;
	MYFLT  *val1, *ioperator, *val2;
	void * opdsVector1;
	void * opdsVector2;
} GL_IF;
*/
extern "C" void GLif(GL_IF *p) {
	loopStack.push_back(LOOP_STACK(&p->h, loopStack_count));
	loopStack_count++;
	p->opdsVector1 = NULL;
}


extern "C" void GLelse(GL_IF *p) {
	loopStack_count--;
	GL_IF *p_old = (GL_IF *) loopStack.back().h;
	p->val1 = p_old->val1;
	p->ioperator = p_old->ioperator;
	p->val2 = p_old->val2;
	
	if (strcmp( loopStack.back().h->optext->t.opcod, "GLif")) {
		die("GLelse: invalid stack pointer: verify its placement");
		return;
	}
	if(loopStack.back().count != loopStack_count) {
		die("GLelse: invalid stack count: verify GLif/GLelse count and placement");
		return;
	}
	if (p->opdsVector1 == NULL) {
		p->opdsVector1 = (void *) new OPDSvectType;
		allocatedItems.push_back(p->opdsVector1);
	}
	*((OPDSvectType *) p->opdsVector1) = loopStack.back().LoopVect;
	loopStack.pop_back();

//	if (loopStack_count > 0)	
//		loopStack.back().LoopVect.push_back( (OPDS*)p);
//	else
//		currVect.push_back( (OPDS*)p);			 

///////
	loopStack.push_back(LOOP_STACK(&p->h, loopStack_count));
	loopStack_count++;
///////


}

void GLif_runtime(GL_IF *p) {

	bool boolean;
	switch((int) *p->ioperator) {
		case 0: boolean = (*p->val1 == *p->val2); break;// equal
		case 1: boolean = (*p->val1 >= *p->val2); break;// grater or equal than
		case 2: boolean = (*p->val1 >  *p->val2); break;// grater than
		case 3: boolean = (*p->val1 <= *p->val2); break;// less or equal than
		case 4: boolean = (*p->val1 <  *p->val2); break;// less than
		default: initerror ("GLif: invalid operator");
	}
	
	if (p->opdsVector1 != NULL) {
		if (boolean) {
			OPDS **v =  &(*(( OPDSvectType *) p->opdsVector1))[0];
			for (int k = 0; k< (const int) (*(( OPDSvectType *) p->opdsVector1)).size(); k++) {
				OPDS *pds = v[k];
				(*pds->GLadr)(pds);
			}
		}
		else {
			OPDS **v =  &(*(( OPDSvectType *) p->opdsVector2))[0];
			for (int k = 0; k< (const int) (*(( OPDSvectType *) p->opdsVector2)).size(); k++) {
				OPDS *pds = v[k];
				(*pds->GLadr)(pds);
			}
		}
	}
	else {
		if (boolean) {
			
			OPDS **v =  &(*(( OPDSvectType *) p->opdsVector2))[0];
			for (int k = 0; k< (const int) (*(( OPDSvectType *) p->opdsVector2)).size(); k++) {
				OPDS *pds = v[k];
				(*pds->GLadr)(pds);
			}
		}
	}
}

extern "C" void GLend_if(GL_IF *p) {
	loopStack_count--;
	//LOOP_STACK loop_stk = loopStack.back();
	GL_IF *p_old = (GL_IF *) loopStack.back().h;
	p->val1 = p_old->val1;
	p->ioperator = p_old->ioperator;
	p->val2 = p_old->val2;
	p->opdsVector1 = p_old->opdsVector1;
	OPDS* pippo = loopStack.back().h;
	if (strcmp( loopStack.back().h->optext->t.opcod, "GLif") 
		&& strcmp( loopStack.back().h->optext->t.opcod, "GLelse")) {
		die("GLfor_end: invalid stack pointer: verify its placement");
		return;
	}
	if(loopStack.back().count != loopStack_count) {
		die("GLend_if: invalid stack count: verify GLif/GLelse/GLend_if count and placement");
		return;
	}
	if (p->opdsVector2 == NULL) {
		p->opdsVector2 = (void *) new OPDSvectType;
		allocatedItems.push_back(p->opdsVector2);
	}
	*((OPDSvectType *) p->opdsVector2) = loopStack.back().LoopVect;
	loopStack.pop_back();
	
	/////////////////////////////////////////////////
	p->h.GLadr=(void (*)(void *))(GLif_runtime);	

	if (loopStack_count > 0)	
		loopStack.back().LoopVect.push_back( (OPDS*)p);
	else
		currVect.push_back( (OPDS*)p);			 

}

//-----------------------
extern "C" {
	#undef IN
	#undef OUT
	#include "aops.h"
	void	addkk(void*), subkk(void*), mulkk(void*), divkk(void*), modkk(void*);
	void	int1(void*), frac1(void*), rnd1(void*), birnd1(void*);
	void	abs1(void*), exp01(void*), log01(void*), sqrt1(void*);
	void	sin1(void*), cos1(void*), tan1(void*), asin1(void*), acos1(void*);
	void	atan1(void*), sinh1(void*), cosh1(void*), tanh1(void*), log101(void*);
}

extern "C" void GLsum(AOP *p) {	INIT_F(addkk); }
extern "C" void GLsub(AOP *p) { INIT_F(subkk); }
extern "C" void GLmul(AOP *p) {	INIT_F(mulkk); }
extern "C" void GLdiv(AOP *p) {	INIT_F(divkk); }
extern "C" void GLmod(AOP *p) {	INIT_F(modkk); }

extern "C" void GLint1(EVAL *p) { INIT_F(int1); }
extern "C" void GLfrac(EVAL *p) { INIT_F(frac1); }
extern "C" void GLrnd(EVAL *p) { INIT_F(rnd1); }
extern "C" void GLbirnd(EVAL *p) { INIT_F(birnd1); }
extern "C" void GLabs(EVAL *p) { INIT_F(abs1); }
extern "C" void GLexp(EVAL *p) { INIT_F(exp01); } 
extern "C" void GLlog(EVAL *p) { INIT_F(log01); }
extern "C" void GLsqr(EVAL *p) { INIT_F(sqrt1); }
extern "C" void GLsin(EVAL *p) { INIT_F(sin1); }
extern "C" void GLcos(EVAL *p) { INIT_F(cos1); }
extern "C" void GLtan(EVAL *p) { INIT_F(tan1); }
extern "C" void GLasin(EVAL *p) { INIT_F(asin1); }
extern "C" void GLacos(EVAL *p) { INIT_F(acos1); } 
extern "C" void GLatan(EVAL *p) { INIT_F(atan1); }
extern "C" void GLsinh(EVAL *p) { INIT_F(sinh1); }
extern "C" void GLcosh(EVAL *p) { INIT_F(cosh1); }
extern "C" void GLtanh(EVAL *p) { INIT_F(tanh1); }
extern "C" void GLlog10(EVAL *p) { INIT_F(log101); }

//-----------------------
extern "C" {
	#include "newopcodes.h" 
	void fastab_set(void*), fastabk(void*), fastabkw(void*);
	void mtab_set(void*), mtab_k(void*), mtabw_set(void*), mtabw_k(void*);
}

extern "C" void GLtab(FASTAB *p) { 	fastab_set(p);	INIT_F(fastabk); }
extern "C" void GLtabw(FASTAB *p) {	fastab_set(p);	INIT_F(fastabkw); }

extern "C" void GLvtab(MTAB *p) { 	mtab_set(p);	INIT_F(mtab_k); }
extern "C" void GLvtabw(MTABW *p) {	mtabw_set(p);	INIT_F(mtabw_k); }

//-----------------------
extern "C" {
	#include "vpvoc.h"
	#include "vectorial.h" 
	void vectorOp_set(void*), vectorsOp_set(void*), vadd(void*),vmult(void*),vpow(void*),vexp(void*);
	void vaddv(void*), vsubv(void*), vmultv(void*),vdivv(void*),vpowv(void*),vexpv(void*);
	void vcopy(void*), vmap(void*), vlimit(void*),vwrap(void*),vmirror(void*),vlinseg(void*);
	void vexpseg(void*), vrandh(void*), vrandi(void*), vport(void*), vecdly(void*);
	void vphaseseg_set(void*), vphaseseg(void*), vlimit_set(void*);

}

extern "C" void GLvadd(VECTOROP *p) { 	vectorOp_set(p);	INIT_F(vadd); }
extern "C" void GLvmult(VECTOROP *p) {	vectorOp_set(p);	INIT_F(vmult); }
extern "C" void GLvpow(VECTOROP *p) { 	vectorOp_set(p);	INIT_F(vpow); }
extern "C" void GLvexp(VECTOROP *p) {	vectorOp_set(p);	INIT_F(vexp); }

extern "C" void GLvaddv(VECTORSOP *p) { vectorsOp_set(p);	INIT_F(vaddv); }
extern "C" void GLvsubv(VECTORSOP *p) {	vectorsOp_set(p);	INIT_F(vsubv); }
extern "C" void GLvmultv(VECTORSOP *p){ vectorsOp_set(p);	INIT_F(vmultv); }
extern "C" void GLvdivv(VECTORSOP *p) {	vectorsOp_set(p);	INIT_F(vdivv); }
extern "C" void GLvpowv(VECTORSOP *p) { vectorsOp_set(p);	INIT_F(vpowv); }
extern "C" void GLvexpv(VECTORSOP *p) {	vectorsOp_set(p);	INIT_F(vexpv); }
extern "C" void GLvcopy(VECTORSOP *p) { vectorsOp_set(p);	INIT_F(vcopy); }
extern "C" void GLvmap(VECTORSOP *p) {	vectorsOp_set(p);	INIT_F(vmap); }

extern "C" void GLvlimit(VLIMIT *p)	{	vlimit_set(p);		INIT_F(vlimit); }
extern "C" void GLvwrap(VLIMIT *p)	{	vlimit_set(p);		INIT_F(vwrap); }
extern "C" void GLvmirror(VLIMIT *p){	vlimit_set(p);		INIT_F(vmirror); }

extern "C" void GLvphaseseg(VPSEG *p) {	vphaseseg_set(p);	INIT_F(vphaseseg); }

//-----------------------
void gl_phsor(GL_PHASOR *p)
{
    double	phs;
    *p->sr = (MYFLT)(phs = p->curphs);
    if ((phs += (1.0 +  FrameDiff) / *p->frames_per_cycle) >= 1.0)
      phs -= 1.0;
    else if (phs < 0.0)
      phs += 1.0;
    p->curphs = phs;
}

extern "C" void GLphasor(GL_PHASOR *p)
{
    MYFLT	phs;
    long  longphs;
	if ((phs = *p->iphs) >= FL(0.0)) {
		if ((longphs = (long)phs))
			warning(Str(X_911,"init phase truncation"));
		p->curphs = phs - (MYFLT)longphs;
	}
	INIT_F(gl_phsor);
}
//-----------------------



void gl_metro(GL_METRO *p)
{
    double	phs= p->curphs;
	if(phs == FL(0.0) && p->flag) {
		*p->sr = FL(1.0);
		p->flag = 0;
	}
	else if ((phs += (1.0 +  FrameDiff) / *p->frames_per_cycle) >= 1.0) {
		*p->sr = FL(1.0);
		phs -= 1.0;
		p->flag = 0;
	}
	else 
		*p->sr = FL(0.0);
	p->curphs = phs;
	
}

extern "C" void GLmetro(GL_METRO *p)
{
    double	phs;
    long  longphs;
	if ((phs = *p->iphs) >= 0.0) {
		if ((longphs = (long)phs))
			warning("FLmetro:init phase truncation");
		p->curphs = phs - (MYFLT)longphs;
	}
	p->flag=1;
	INIT_F(gl_metro);
}

//-----------------------



void gl_oscil(GL_OSCIL *p)
{
    double	phs = p->phs;
    *p->out = *p->amp * p->ftp->ftable[(long) phs];
    phs    += (1.0 +  FrameDiff) * (p->tablen / *p->frames_per_cycle);
    while (phs >= p->tablen)
      phs -= p->tablen;
    while (phs < 0 )
      phs += p->tablen;	
    p->phs = phs;
}

extern "C" void GLoscil( GL_OSCIL *p)
{
    FUNC *ftp;
    if ((ftp = ftnp2find(p->ift)) == NULL) return;
    p->ftp    = ftp;
    p->tablen = ftp->flen;
    p->phs    = *p->iphs * p->tablen;
	INIT_F(gl_oscil);
}

//-----------------------
void gl_oscili(GL_OSCIL *p)
{
    double	phs = p->phs;

    MYFLT	*curr_samp = p->ftp->ftable + (long)phs;
    MYFLT	fract = (MYFLT)(phs - (long)phs);

    *p->out = *p->amp * (*curr_samp +(*(curr_samp+1)-*curr_samp)*fract);
    phs    += (1.0 + FrameDiff) * (p->tablen / *p->frames_per_cycle);
    while (phs >= p->tablen)
      phs -= p->tablen;
    while (phs < 0 )
      phs += p->tablen;	
    p->phs = phs;
}

extern "C" void GLoscili( GL_OSCIL *p)
{
    FUNC *ftp;
    if ((ftp = ftnp2find(p->ift)) == NULL) return;
    p->ftp    = ftp;
    p->tablen = ftp->flen;
    p->phs    = *p->iphs * p->tablen;
	INIT_F(gl_oscili);
}

//-----------------------

void GlutSphereSolidDraw(GLUTSPHERE *p) {
	glutSolidSphere((GLdouble) *p->kradius, (GLint) *p->kslices, (GLint) *p->kstacks);
}

void GlutSphereWireDraw(GLUTSPHERE *p) {
	glutWireSphere((GLdouble) *p->kradius, (GLint) *p->kslices, (GLint) *p->kstacks);
}

extern "C" void GLUTsphere(GLUTSPHERE *p)
{
	if ( *p->itype) p->h.GLadr =  (void (*)(void *)) GlutSphereSolidDraw;
	else		   p->h.GLadr =  (void (*)(void *)) GlutSphereWireDraw;
	PBACK
}

//-----------------------
void GlutCubeSolidDraw(GL_TWOARGS *p) {
	glutSolidCube((GLdouble) *p->arg1);
}

void GlutCubeWireDraw(GL_TWOARGS *p) {
	glutWireCube((GLdouble) *p->arg1);
}

extern "C" void GLUTcube(GL_TWOARGS *p)
{
	if ( *p->arg2) p->h.GLadr =  (void (*)(void *)) GlutCubeSolidDraw;
	else		  p->h.GLadr =  (void (*)(void *)) GlutCubeWireDraw;
	PBACK
}

//-----------------------
void GlutTorusSolidDraw(GLUTORUS *p) {
	glutSolidTorus((GLdouble) *p->innerRadius, (GLdouble) *p->outerRadius, (GLint) *p->sides, (GLint) *p->rings);
	//glutSolidSphere((GLdouble) *p->kradius, (GLint) *p->kslices, (GLint) *p->kstacks);
}

void GlutTorusWireDraw(GLUTORUS *p) {
	glutWireTorus((GLdouble) *p->innerRadius, (GLdouble) *p->outerRadius, (GLint) *p->sides, (GLint) *p->rings);
}

extern "C" void GLUTtorus(GLUTORUS *p)
{
	if ( *p->itype) p->h.GLadr =  (void (*)(void *)) GlutTorusSolidDraw;
	else		   p->h.GLadr =  (void (*)(void *)) GlutTorusWireDraw;
	PBACK
}

//-----------------------
void glutDodecahedronSolidDraw(GL_ONEARG *p) {
	glutSolidDodecahedron();
}

void glutDodecahedronWireDraw(GL_ONEARG *p) {
	glutWireDodecahedron();
}

extern "C" void GLUTdodecahedron(GL_ONEARG *p)
{
	if ( *p->arg)	p->h.GLadr =  (void (*)(void *)) glutDodecahedronSolidDraw;
	else			p->h.GLadr =  (void (*)(void *)) glutDodecahedronWireDraw;
	PBACK
}
//-----------------------
void glutOctahedronSolidDraw(GL_ONEARG *p) {
	glutSolidOctahedron();
}

void glutOctahedronWireDraw(GL_ONEARG *p) {
	glutWireOctahedron();
}

extern "C" void GLUToctahedron(GL_ONEARG *p)
{
	if ( *p->arg)	p->h.GLadr =  (void (*)(void *)) glutOctahedronSolidDraw;
	else			p->h.GLadr =  (void (*)(void *)) glutOctahedronWireDraw;
	PBACK
}
//-----------------------
void glutTetrahedronSolidDraw(GL_ONEARG *p) {
	glutSolidTetrahedron();
}

void glutTetrahedronWireDraw(GL_ONEARG *p) {
	glutWireTetrahedron();
}

extern "C" void GLUTtetrahedron(GL_ONEARG *p)
{
	if ( *p->arg)	p->h.GLadr =  (void (*)(void *)) glutTetrahedronSolidDraw;
	else			p->h.GLadr =  (void (*)(void *)) glutTetrahedronWireDraw;
	PBACK
}
//-----------------------
void glutIcosahedronSolidDraw(GL_ONEARG *p) {
	glutSolidIcosahedron();
}

void glutIcosahedronWireDraw(GL_ONEARG *p) {
	glutWireIcosahedron();
}

extern "C" void GLUTicosahedron(GL_ONEARG *p)
{
	if ( *p->arg)	p->h.GLadr =  (void (*)(void *)) glutIcosahedronSolidDraw;
	else			p->h.GLadr =  (void (*)(void *)) glutIcosahedronWireDraw;
	PBACK
}

//-----------------------

void gltexCube(GL_TEXSQUARE *p) {
    static GLfloat n[6][3] =  {
		{ 0.0f, 0.0f, 1.0f}, {1.0f, 0.0f, 0.0f}, {0.0f,  0.0f, -1.0f},
		{-1.0f, 0.0f, 0.0f}, {0.0f, 1.0f, 0.0f}, {0.0f, -1.0f,  0.0f}
    };
    static GLfloat v[8][3] =    {
		{-1.0f, -1.0f,  1.0f}, { 1.0f, -1.0f,  1.0f}, { 1.0f, 1.0f,  1.0f}, {-1.0f, 1.0f,  1.0f},
		{ 1.0f, -1.0f, -1.0f}, {-1.0f, -1.0f, -1.0f}, {-1.0f, 1.0f, -1.0f}, { 1.0f, 1.0f, -1.0f}
    };
    static GLint faces[6][4] =  {
		{ 0, 1, 2, 3 }, { 1, 4, 7, 2 }, { 4, 5, 6, 7 },
		{ 5, 0, 3, 6 }, { 3, 2, 7, 6 }, { 1, 0, 5, 4 }
    };

	GLfloat coord1s = *p->coord1s, coord1t = *p->coord1t, 
			coord2s = *p->coord2s, coord2t = *p->coord2t,  
			coord3s = *p->coord3s, coord3t = *p->coord3t,  
			coord4s = *p->coord4s, coord4t = *p->coord4t;
	GLfloat size = *p->size;

	glBegin(GL_QUADS);
    for (int i = 0; i < 6; i++) {
		glNormal3fv(&n[i][0]);

		glTexCoord2f(coord1s, coord1t);
		glVertex3f(	v[faces[i][0]][0] * size, 
					v[faces[i][0]][1] * size, 
					v[faces[i][0]][2] * size);

		glTexCoord2f(coord2s, coord2t);
	    glVertex3f( v[faces[i][1]][0] * size, 
					v[faces[i][1]][1] * size, 
					v[faces[i][1]][2] * size);

		glTexCoord2f(coord3s, coord3t);
	    glVertex3f( v[faces[i][2]][0] * size, 
					v[faces[i][2]][1] * size, 
					v[faces[i][2]][2] * size);

		glTexCoord2f(coord4s, coord4t);
	    glVertex3f( v[faces[i][3]][0] * size, 
					v[faces[i][3]][1] * size, 
					v[faces[i][3]][2] * size);
    }
	glEnd();
}

extern "C" void GLtexCube(GL_TEXSQUARE *p)  { INIT_F(gltexCube) }



void gltexSquare(GL_TEXSQUARE *p) {
	GLfloat coord1s = *p->coord1s, coord1t = *p->coord1t, 
			coord2s = *p->coord2s, coord2t = *p->coord2t,  
			coord3s = *p->coord3s, coord3t = *p->coord3t,  
			coord4s = *p->coord4s, coord4t = *p->coord4t;
	GLfloat size = *p->size;

    glNormal3f(0.0f, 0.0f, 1.0f);
    glBegin(GL_QUADS);
    	glTexCoord2f(coord1s, coord1t); glVertex3f(-size, -size, 0.0f);
    	glTexCoord2f(coord2s, coord2t); glVertex3f( size, -size, 0.0f);
    	glTexCoord2f(coord3s, coord3t); glVertex3f( size,  size, 0.0f);
    	glTexCoord2f(coord4s, coord4t); glVertex3f(-size,  size, 0.0f);
    glEnd();

}


extern "C" void GLtexSquare(GL_TEXSQUARE *p)  { INIT_F(gltexSquare) }

//-----------------------

void gltexCircle(GL_TEXCIRCLE *p) {
	GLfloat coord1s = *p->coord1s, coord1t = *p->coord1t, zooms = *p->zooms, zoomt = *p->zoomt;  
	GLfloat radius = *p->radius;
	MYFLT *m_cos = p->m_cos, *m_sin = p->m_sin;
	int slices = p->num_slices;
    glNormal3f(0.0f, 0.0f, 1.0f);
    glBegin(GL_POLYGON);
	    for (int n = 0; n < slices; n++) {
		    glTexCoord2f((m_cos[n]+coord1s) * zooms, (m_sin[n]+coord1t) * zoomt);
		    glVertex3f(m_cos[n] * radius, m_sin[n] * radius, 0.0);
	    }
    glEnd();

}


extern "C" void GLtexCircle(GL_TEXCIRCLE *p)  {
	MYFLT *m_cos = p->m_cos, *m_sin = p->m_sin;
	int slices;
	if ((slices = p->num_slices = (int) *p->slices) > MAX_CIRCLE_PNTS)
		initerror("GLtexCircle: too many slices");

    for(int i = 0; i < slices; i++)    {
	    m_cos[i] = (MYFLT)cos(TWOPI * (double)i / (double)slices);
	    m_sin[i] = (MYFLT)sin(TWOPI * (double)i / (double)slices);
    }
	INIT_F(gltexCircle) 
}


//-----------------------
void glPerspective(GL_PERSP *p) {
	gluPerspective((GLdouble) *p->fovy , fAspect, *p->zNear, *p->zFar);
}

extern "C" void GLperspective(GL_PERSP *p) { INIT_F(glPerspective)}

//-----------------------
void glMatMode(GL_MODE *p) {
	switch ((int) *p->mode) {
		case 0:	glMatrixMode(GL_MODELVIEW); break;
		case 1: glMatrixMode(GL_PROJECTION); break;
		case 2: glMatrixMode(GL_TEXTURE); break;
	}
}

extern "C" void GLmatrixMode(GL_MODE *p) { 	INIT_F(glMatMode) }

//-----------------------
void glClr(GL_MODE *p) {
	/*switch ((int) *p->mode) {
	
		case 0:	glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT ); break;
		case 1: glClear(GL_COLOR_BUFFER_BIT); break; 
		case 2: glClear(GL_TEXTURE_BIT ); break;
		case 3: glClear(GL_TRANSFORM_BIT ); break;
		case 4: glClear(GL_LIGHTING_BIT ); break;
		case 5: glClear(GL_FOG_BIT ); break;
		case 6: glClear(GL_ACCUM_BUFFER_BIT ); break;
		case 7: glClear(GL_STENCIL_BUFFER_BIT ); break;
		case 8: glClear(GL_VIEWPORT_BIT ); break;
		default: glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT ); break;
	*/
		glClear( (int) (*p->mode + .5));

	//}
}

extern "C" void GLclear(GL_MODE *p) { INIT_F(glClr) }
//-----------------------
void glclearwhen(GL_TWOARGS *p) {
	if (*p->arg1) {
		/*
		switch ((int) (*p->arg2 + .5)) {
			case 0:	glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT ); break;
			case 1: glClear(GL_COLOR_BUFFER_BIT); break; 
			case 2: glClear(GL_TEXTURE_BIT ); break;
			case 3: glClear(GL_TRANSFORM_BIT ); break;
			case 4: glClear(GL_LIGHTING_BIT ); break;
			case 5: glClear(GL_FOG_BIT ); break;
			case 6: glClear(GL_ACCUM_BUFFER_BIT ); break;
			case 7: glClear(GL_STENCIL_BUFFER_BIT ); break;
			case 8: glClear(GL_VIEWPORT_BIT ); break;
			default: glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT ); break;
		}
		*/
		glClear( (int) (*p->arg2 + .5));
	}
}

extern "C" void GLclearWhen(GL_NOARG *p) { INIT_F(glclearwhen) }

//-----------------------
void glLdIdentity(GL_NOARG *p) {
	glLoadIdentity();
}

extern "C" void GLloadIdentity(GL_NOARG *p) { INIT_F(glLdIdentity) }

//-----------------------
void glPshMatrix(GL_NOARG *p) {
	glPushMatrix();
}

extern "C" void GLpushMatrix(GL_NOARG *p) {	INIT_F(glPshMatrix) }

//-----------------------
void glpopMatr(GL_NOARG *p) {
	glPopMatrix();
}

extern "C" void GLpopMatr(GL_NOARG *p) { INIT_F(glpopMatr) }

//-----------------------
void gltransl(GL_AXIS *p) {
	glTranslatef((GLfloat) *p->x, (GLfloat) *p->y, (GLfloat) *p->z);
}

extern "C" void GLtranslate(GL_AXIS *p) { INIT_F(gltransl) }

//-----------------------
void glrot(GL_ROTATE *p) {
	glRotatef((GLfloat) *p->angle, (GLfloat) *p->x, (GLfloat) *p->y, (GLfloat) *p->z);
}

extern "C" void GLrotate(GL_ROTATE *p) { INIT_F(glrot) }

//-----------------------
void gl_ortho(GL_ORTHO *p) {
	if (fAspect > 1)
		glOrtho((GLfloat) *p->kleft, (GLfloat) *p->kright, (GLfloat) *p->kbottom / fAspect, (GLfloat) *p->ktop / fAspect, (GLfloat) *p->knear, (GLfloat) *p->kfar);
		
	else 
		glOrtho((GLfloat) *p->kleft * fAspect, (GLfloat) *p->kright *  fAspect , (GLfloat) *p->kbottom, (GLfloat) *p->ktop, (GLfloat) *p->knear, (GLfloat) *p->kfar);
}

extern "C" void GLortho(GL_ORTHO *p) { INIT_F(gl_ortho) }

//-----------------------
void glscale(GL_AXIS *p) {
	glScalef((GLfloat) *p->x, (GLfloat) *p->y, (GLfloat) *p->z);
}

extern "C" void GLscale(GL_AXIS *p) { INIT_F(glscale) }

//-----------------------
void glenab(GL_ENABLE *p) {
	GLenum cap;
	switch ((int) *p->cap) {
		case 0: cap =  GL_ALPHA_TEST; break;
		case 1: cap =  GL_AUTO_NORMAL; break;
		case 2: cap =  GL_BLEND; break;
		case 3: cap =  GL_CLIP_PLANE0; break;
		case 4: cap =  GL_CLIP_PLANE1; break;
		case 5: cap =  GL_CLIP_PLANE2; break;
		case 6: cap =  GL_CLIP_PLANE3; break;
		case 7: cap =  GL_CLIP_PLANE4; break;
		case 8: cap =  GL_CLIP_PLANE5; break;
		case 9: cap =  GL_COLOR_MATERIAL; break;
		case 10: cap =  GL_CULL_FACE; break;
		case 11: cap =  GL_DEPTH_TEST; break;
		case 12: cap =  GL_DITHER; break;
		case 13: cap =  GL_FOG; break;
		case 14: cap =  GL_LIGHT0; break;
		case 15: cap =  GL_LIGHT1; break;
		case 16: cap =  GL_LIGHT2; break;
		case 17: cap =  GL_LIGHT3; break;
		case 18: cap =  GL_LIGHT4; break;
		case 19: cap =  GL_LIGHT5; break;
		case 20: cap =  GL_LIGHT6; break;
		case 21: cap =  GL_LIGHT7; break;
		case 22: cap =  GL_LIGHTING; break;
		case 23: cap =  GL_LINE_SMOOTH; break;
		case 24: cap =  GL_LINE_STIPPLE; break;
		case 25: cap =  GL_LOGIC_OP; break;
		case 26: cap =  GL_MAP1_COLOR_4; break;
		case 27: cap =  GL_MAP1_INDEX; break;
		case 28: cap =  GL_MAP1_NORMAL; break;
		case 29: cap =  GL_MAP1_TEXTURE_COORD_1; break;
		case 30: cap =  GL_MAP1_TEXTURE_COORD_2; break;
		case 31: cap =  GL_MAP1_TEXTURE_COORD_3; break;
		case 32: cap =  GL_MAP1_TEXTURE_COORD_4; break;
		case 33: cap =  GL_MAP1_VERTEX_3; break;
		case 34: cap =  GL_MAP1_VERTEX_4; break;
		case 35: cap =  GL_MAP2_COLOR_4; break;
		case 36: cap =  GL_MAP2_INDEX; break;
		case 37: cap =  GL_MAP2_NORMAL; break;
		case 38: cap =  GL_MAP2_TEXTURE_COORD_1; break;
		case 39: cap =  GL_MAP2_TEXTURE_COORD_2; break;
		case 40: cap =  GL_MAP2_TEXTURE_COORD_3; break;
		case 41: cap =  GL_MAP2_TEXTURE_COORD_4; break;
		case 42: cap =  GL_MAP2_VERTEX_3; break;
		case 43: cap =  GL_MAP2_VERTEX_4; break;
		case 44: cap =  GL_NORMALIZE; break;
		case 45: cap =  GL_POINT_SMOOTH; break;
		case 46: cap =  GL_POLYGON_SMOOTH; break;
		case 47: cap =  GL_POLYGON_STIPPLE; break;
		case 48: cap =  GL_SCISSOR_TEST; break;
		case 49: cap =  GL_STENCIL_TEST; break;
		case 50: cap =  GL_TEXTURE_1D; break;
		case 51: cap =  GL_TEXTURE_2D; break;
		case 52: cap =  GL_TEXTURE_GEN_Q; break;
		case 53: cap =  GL_TEXTURE_GEN_R; break;
		case 54: cap =  GL_TEXTURE_GEN_S; break;
		case 55: cap =  GL_TEXTURE_GEN_T; break;
		default: initerror("invalid argument value"); return;
  	}
	glEnable(cap);
}

extern "C" void GLenable(GL_ENABLE *p) { INIT_F(glenab) }

//----------------------
void glcullFace(GL_ONEARG *p) {
	GLenum mode;
	switch ((int) *p->arg) {
		case 0: mode =  GL_FRONT; break;
		case 1: mode =  GL_BACK; break;
		default: initerror("invalid argument value"); return;
  	}
	glCullFace(mode);
}

extern "C" void GLcullFace(GL_ONEARG *p) { INIT_F(glcullFace) }
//----------------------
void glfrontFace(GL_ONEARG *p) {
	GLenum mode;
	switch ((int) *p->arg) {
		case 0: mode =  GL_CCW; break;
		case 1: mode =  GL_CW; break;
		default: initerror("invalid argument value"); return;
  	}
	glFrontFace(mode);
}

extern "C" void GLfrontFace(GL_ONEARG *p) { INIT_F(glfrontFace) }

//-----------------------
void gldisab(GL_ENABLE *p) {
	GLenum cap;
	switch ((int) *p->cap) {
		case 0: cap =  GL_ALPHA_TEST; break;
		case 1: cap =  GL_AUTO_NORMAL; break;
		case 2: cap =  GL_BLEND; break;
		case 3: cap =  GL_CLIP_PLANE0; break;
		case 4: cap =  GL_CLIP_PLANE1; break;
		case 5: cap =  GL_CLIP_PLANE2; break;
		case 6: cap =  GL_CLIP_PLANE3; break;
		case 7: cap =  GL_CLIP_PLANE4; break;
		case 8: cap =  GL_CLIP_PLANE5; break;
		case 9: cap =  GL_COLOR_MATERIAL; break;
		case 10: cap =  GL_CULL_FACE; break;
		case 11: cap =  GL_DEPTH_TEST; break;
		case 12: cap =  GL_DITHER; break;
		case 13: cap =  GL_FOG; break;
		case 14: cap =  GL_LIGHT0; break;
		case 15: cap =  GL_LIGHT1; break;
		case 16: cap =  GL_LIGHT2; break;
		case 17: cap =  GL_LIGHT3; break;
		case 18: cap =  GL_LIGHT4; break;
		case 19: cap =  GL_LIGHT5; break;
		case 20: cap =  GL_LIGHT6; break;
		case 21: cap =  GL_LIGHT7; break;
		case 22: cap =  GL_LIGHTING; break;
		case 23: cap =  GL_LINE_SMOOTH; break;
		case 24: cap =  GL_LINE_STIPPLE; break;
		case 25: cap =  GL_LOGIC_OP; break;
		case 26: cap =  GL_MAP1_COLOR_4; break;
		case 27: cap =  GL_MAP1_INDEX; break;
		case 28: cap =  GL_MAP1_NORMAL; break;
		case 29: cap =  GL_MAP1_TEXTURE_COORD_1; break;
		case 30: cap =  GL_MAP1_TEXTURE_COORD_2; break;
		case 31: cap =  GL_MAP1_TEXTURE_COORD_3; break;
		case 32: cap =  GL_MAP1_TEXTURE_COORD_4; break;
		case 33: cap =  GL_MAP1_VERTEX_3; break;
		case 34: cap =  GL_MAP1_VERTEX_4; break;
		case 35: cap =  GL_MAP2_COLOR_4; break;
		case 36: cap =  GL_MAP2_INDEX; break;
		case 37: cap =  GL_MAP2_NORMAL; break;
		case 38: cap =  GL_MAP2_TEXTURE_COORD_1; break;
		case 39: cap =  GL_MAP2_TEXTURE_COORD_2; break;
		case 40: cap =  GL_MAP2_TEXTURE_COORD_3; break;
		case 41: cap =  GL_MAP2_TEXTURE_COORD_4; break;
		case 42: cap =  GL_MAP2_VERTEX_3; break;
		case 43: cap =  GL_MAP2_VERTEX_4; break;
		case 44: cap =  GL_NORMALIZE; break;
		case 45: cap =  GL_POINT_SMOOTH; break;
		case 46: cap =  GL_POLYGON_SMOOTH; break;
		case 47: cap =  GL_POLYGON_STIPPLE; break;
		case 48: cap =  GL_SCISSOR_TEST; break;
		case 49: cap =  GL_STENCIL_TEST; break;
		case 50: cap =  GL_TEXTURE_1D; break;
		case 51: cap =  GL_TEXTURE_2D; break;
		case 52: cap =  GL_TEXTURE_GEN_Q; break;
		case 53: cap =  GL_TEXTURE_GEN_R; break;
		case 54: cap =  GL_TEXTURE_GEN_S; break;
		case 55: cap =  GL_TEXTURE_GEN_T; break;
		case 56: cap =  GL_STEREO; break;
		default: initerror("invalid argument value"); return;
  	}
	glDisable(cap);
}

extern "C" void GLdisable(GL_ENABLE *p) { INIT_F(gldisab) }
//-----------------------
void glpixelTransferf(GL_TWOARGS *p) {
	GLenum pname;  

	switch ((int) *p->arg1) {
		case 0: pname =  GL_MAP_COLOR; break;
		case 1: pname =  GL_MAP_STENCIL; break;
		case 2: pname =  GL_INDEX_SHIFT; break;
		case 3: pname =  GL_INDEX_OFFSET; break;
		case 4: pname =  GL_RED_SCALE; break;
		case 5: pname =  GL_RED_BIAS; break;
		case 6: pname =  GL_GREEN_SCALE; break;
		case 7: pname =  GL_GREEN_BIAS; break;
		case 8: pname =  GL_BLUE_SCALE; break;
		case 9: pname =  GL_BLUE_BIAS; break;
		case 10: pname =  GL_ALPHA_SCALE; break;
		case 11: pname =  GL_ALPHA_BIAS; break;
		case 12: pname =  GL_DEPTH_SCALE; break;
		case 13: pname =  GL_DEPTH_BIAS; break;
		default: initerror("invalid argument value"); return;
  	}
	glPixelTransferf(pname, (GLfloat) *p->arg2);
}

extern "C" void GLpixelTransfer(GL_TWOARGS *p) { INIT_F(glpixelTransferf) }

//-----------------------
#ifdef CSD_DOUBLE
	#define MAXARRAYSIZE 512
	static GLfloat userGLfloatarray[MAXARRAYSIZE];
#endif

void glpixelMapf(GL_PIXEL_MAP *p) {
	GLenum map;
	switch ((int) *p->map) {
		case 0: map =  GL_PIXEL_MAP_I_TO_I; break;
		case 1: map =  GL_PIXEL_MAP_S_TO_S; break;
		case 2: map =  GL_PIXEL_MAP_I_TO_R; break;
		case 3: map =  GL_PIXEL_MAP_I_TO_G; break;
		case 4: map =  GL_PIXEL_MAP_I_TO_B; break;
		case 5: map =  GL_PIXEL_MAP_I_TO_A; break;
		case 6: map =  GL_PIXEL_MAP_R_TO_R; break;
		case 7: map =  GL_PIXEL_MAP_G_TO_G; break;
		case 8: map =  GL_PIXEL_MAP_B_TO_B; break;
		case 9: map =  GL_PIXEL_MAP_A_TO_A; break;
		case 10: map =  GL_PIXEL_MAP_I_TO_I_SIZE; break;
		case 11: map =  GL_PIXEL_MAP_S_TO_S_SIZE; break;
		case 12: map =  GL_PIXEL_MAP_I_TO_R_SIZE; break;
		case 13: map =  GL_PIXEL_MAP_I_TO_G_SIZE; break;
		case 14: map =  GL_PIXEL_MAP_I_TO_B_SIZE; break;
		case 15: map =  GL_PIXEL_MAP_I_TO_A_SIZE; break;
		case 16: map =  GL_PIXEL_MAP_R_TO_R_SIZE; break;
		case 17: map =  GL_PIXEL_MAP_G_TO_G_SIZE; break;
		case 18: map =  GL_PIXEL_MAP_B_TO_B_SIZE; break;
		case 19: map =  GL_PIXEL_MAP_A_TO_A_SIZE; break;

		default: initerror("invalid argument value"); return;
  	}

//void glPixelMapfv( GLenum map, GLint mapsize, const GLfloat *values ); 
 

#ifdef CSD_DOUBLE
	MYFLT* t = p->table;
	GLint mapsize = (GLint) *p->mapsize;

	for(int j =0; j<mapsize; j++)
		userGLfloatarray[j] = (GLfloat) t[j];
	glPixelMapfv(map, (GLint) *p->mapsize, userGLfloatarray);
#else
	glPixelMapfv(map, (GLint) *p->mapsize, p->table);
#endif
}

extern "C" void GLpixelMap(GL_PIXEL_MAP *p) { 
#ifdef CSD_DOUBLE
	if((int) *p->mapsize >  MAXARRAYSIZE){
		initerror ("glPixelMap: mapsize too large");
		return;
	}
#endif
	FUNC *ftp;
	if((ftp = ftfind(p->ifn_values)) != NULL) {
		p->table = ftp->ftable;
		INIT_F(glpixelMapf)
	}
	else return;
}


//-----------------------
void gldrawBuffer(GL_ONEARG *p) {
	GLenum mode;
	switch ((int) *p->arg) {
		case 0: mode =  GL_FRONT; break;
		case 1: mode =  GL_BACK; break;
		case 2: mode =  GL_LEFT; break;
		case 3: mode =  GL_RIGHT; break;
		case 4: mode =  GL_FRONT_AND_BACK; break;
		case 5: mode =  GL_FRONT_LEFT; break;
		case 6: mode =  GL_FRONT_RIGHT; break;
		case 7: mode =  GL_BACK_LEFT; break;
		case 8: mode =  GL_BACK_RIGHT; break;
		case 9: mode =  GL_AUX0; break;
		case 10: mode =  GL_AUX1; break;
		case 11: mode =  GL_AUX2; break;
		case 12: mode =  GL_AUX3; break;
		case 100: mode=  GL_NONE; break;
		default: initerror("invalid argument value"); return;
  	}
	glDrawBuffer(mode);
}

extern "C" void GLdrawBuffer(GL_ONEARG *p) { INIT_F(gldrawBuffer) }


//-----------------------
void glhint(GL_TWOARGS *p) {
	GLenum target, mode;
	switch ((int) *p->arg1) {
		case 0: target =  GL_PERSPECTIVE_CORRECTION_HINT; break;
		case 1: target =  GL_POINT_SMOOTH_HINT; break;
		case 2: target =  GL_LINE_SMOOTH_HINT; break;
		case 3: target =  GL_POLYGON_SMOOTH_HINT; break;
		case 4: target =  GL_FOG_HINT; break;
		default: initerror("invalid argument value"); return;
	}
	switch ((int) *p->arg2) {
		case 0: mode =  GL_DONT_CARE; break;
		case 1: mode =  GL_FASTEST; break;
		case 2: mode =  GL_NICEST; break;
		default: initerror("invalid argument value"); return;
	}
	glHint(target, mode);
}

extern "C" void GLhint(GL_TWOARGS *p) { INIT_F(glhint) }
//-----------------------
void gllight(GL_LIGHT *p) {
	GLenum light, pname;
	switch ((int) *p->light) {
		case 14: light =  GL_LIGHT0; break;
		case 15: light =  GL_LIGHT1; break;
		case 16: light =  GL_LIGHT2; break;
		case 17: light =  GL_LIGHT3; break;
		case 18: light =  GL_LIGHT4; break;
		case 19: light =  GL_LIGHT5; break;
		case 20: light =  GL_LIGHT6; break;
		case 21: light =  GL_LIGHT7; break;
		default: initerror("invalid light value"); return;
	}
	switch ((int) *p->pname) {
		case 9: pname =  GL_SPOT_EXPONENT; break;
		case 10: pname =  GL_SPOT_CUTOFF; break;
		case 11: pname =  GL_CONSTANT_ATTENUATION ; break;
		case 12: pname =  GL_LINEAR_ATTENUATION ; break;
		case 13: pname =  GL_QUADRATIC_ATTENUATION ; break;
		default: initerror("invalid pname value"); return;
	}
	glLightf(light, pname, (GLfloat) *p->param);
}

extern "C" void GLlight(GL_LIGHT *p) { INIT_F(gllight) }

//-----------------------


void gllightv(GL_LIGHTV *p) {
	GLenum light, pname;
	switch ((int) *p->light) {
		case 14: light =  GL_LIGHT0; break;
		case 15: light =  GL_LIGHT1; break;
		case 16: light =  GL_LIGHT2; break;
		case 17: light =  GL_LIGHT3; break;
		case 18: light =  GL_LIGHT4; break;
		case 19: light =  GL_LIGHT5; break;
		case 20: light =  GL_LIGHT6; break;
		case 21: light =  GL_LIGHT7; break;
		default: initerror("invalid light value"); return;
	}
	switch ((int) *p->pname) {
		case 0: pname =  GL_AMBIENT ; break;
		case 1: pname =  GL_DIFFUSE ; break;
		case 2: pname =  GL_SPECULAR  ; break;
		case 7: pname =  GL_POSITION  ; break;
		case 8: pname =  GL_SPOT_DIRECTION  ; break;
		case 9: pname =  GL_SPOT_EXPONENT   ; break;
		case 10: pname =  GL_SPOT_CUTOFF   ; break;
		case 11: pname =  GL_CONSTANT_ATTENUATION   ; break;
		case 12: pname =  GL_LINEAR_ATTENUATION ; break;
		case 13: pname =  GL_QUADRATIC_ATTENUATION; break;
		default: initerror("invalid pname value"); return;
	}
	GLfloat param[4];
	param[0] =  (GLfloat) *p->param0;
	param[1] =  (GLfloat) *p->param1;
	param[2] =  (GLfloat) *p->param2;
	param[3] =  (GLfloat) *p->param3;

	glLightfv(light, pname, param);
}

extern "C" void GLlightv(GL_LIGHTV *p) { INIT_F(gllightv) }
//-----------------------
void gllightmodel(GL_LIGHT_MODEL *p) {
	GLenum pname;
	switch ((int) *p->pname) {
		case 0: pname =  GL_LIGHT_MODEL_LOCAL_VIEWER ; break;
		case 1: pname =  GL_LIGHT_MODEL_TWO_SIDE ; break;
		default: initerror("invalid lightModel pname value"); return;
	}
	glLightModelf(pname, (GLfloat) *p->param);
}

extern "C" void GLlightModel(GL_LIGHT_MODEL *p) { INIT_F(gllightmodel) }
//-----------------------
void gllightmodelv(GL_LIGHT_MODELV *p) {
	GLenum pname;
	switch ((int) *p->pname) {
		case 0: pname =  GL_LIGHT_MODEL_LOCAL_VIEWER  ; break;
		case 1: pname =  GL_LIGHT_MODEL_TWO_SIDE ; break;
		case 2: pname =  GL_LIGHT_MODEL_AMBIENT  ; break;
		default: initerror("invalid lightModelv pname value"); return;
	}
	GLfloat param[4];
	param[0] =  (GLfloat) *p->param0;
	param[1] =  (GLfloat) *p->param1;
	param[2] =  (GLfloat) *p->param2;
	param[3] =  (GLfloat) *p->param3;

	glLightModelfv(pname, param);
}

extern "C" void GLlightModelv(GL_LIGHT_MODELV *p) { INIT_F(gllightmodelv) }

//-----------------------
void glclearcol(GL_COLOR4 *p) {
	glClearColor((GLclampf) *p->red, (GLclampf) *p->green, (GLclampf) *p->blue, (GLclampf) *p->alpha);
}

extern "C" void GLclearcolor(GL_COLOR4 *p) { INIT_F(glclearcol) }

//-----------------------
void glcol(GL_COLOR4 *p) {
	glColor4f((GLclampf) *p->red, (GLclampf) *p->green, (GLclampf) *p->blue, (GLclampf) *p->alpha);
}

extern "C" void GLcolor(GL_COLOR4 *p) { INIT_F(glcol) }
//-----------------------
void glcol3(GL_COLOR3 *p) {
	glColor3f((GLclampf) *p->red, (GLclampf) *p->green, (GLclampf) *p->blue);
}

extern "C" void GLcolor3(GL_COLOR3 *p) { INIT_F(glcol3) }
//-----------------------
void glshadmod(GL_ONEARG *p) {
	GLenum mode;
	switch((int) *p->arg) {
		case 0:	mode = GL_SMOOTH; break;
		case 1:	mode = GL_FLAT; break;
		default: initerror("invalid argument value");  return;
	}
	glShadeModel(mode);
}

extern "C" void GLshademodel(GL_ONEARG *p) { INIT_F(glshadmod) }
//-----------------------

void glMater(GL_MATERIAL *p) {
	GLfloat  col[4];
	col[0] = *p->red;
	col[1] = *p->green;
	col[2] = *p->blue;
	col[3] = *p->alpha;
	GLenum parameter;

	switch ((int) *p->pname) {
		case 0:	 parameter = GL_AMBIENT; break; 
		case 1:	 parameter = GL_DIFFUSE; break; 
		case 2:	 parameter = GL_SPECULAR; break; 
		case 3:	 parameter = GL_EMISSION; break; 
		case 4:	 parameter = GL_SHININESS; break; 
		case 5:	 parameter = GL_AMBIENT_AND_DIFFUSE; break; 
		case 6:	 parameter = GL_COLOR_INDEXES; break; 
		default: initerror("invalid parameter number"); return;
	}	

	//glMaterialfv(GL_FRONT_AND_BACK,parameter, col);
	glMaterialfv(GL_FRONT,parameter, col);
}

extern "C" void glmaterial(GL_MATERIAL *p) { INIT_F(glMater) }
//-----------------------
void glShininess(GL_ONEARG *p) {
	glMaterialf(GL_FRONT_AND_BACK,GL_SHININESS, (GLfloat) *p->arg);
}

extern "C" void glshininess(GL_ONEARG *p) { INIT_F(glShininess) }

//-----------------------
void gllinewid(GL_ONEARG *p) {
	glLineWidth((GLfloat) *p->arg);
}

extern "C" void GLlinewidth(GL_ONEARG *p) {	INIT_F(gllinewid) }

//-----------------------
void glblendfunc(GL_BLENDFUNC *p) {
	GLenum sfactor,dfactor;
	switch ((int) *p->sfactor) {
		case  0:  sfactor = GL_ZERO; break;
		case  1:  sfactor = GL_ONE; break;
		case  2:  sfactor = GL_DST_COLOR; break;
		case  3:  sfactor = GL_ONE_MINUS_DST_COLOR; break;
		case  4:  sfactor = GL_SRC_ALPHA; break;
		case  5:  sfactor = GL_ONE_MINUS_SRC_ALPHA; break;
		case  6:  sfactor = GL_DST_ALPHA; break;
		case  7:  sfactor = GL_ONE_MINUS_DST_ALPHA; break;
		case  8:  sfactor = GL_SRC_ALPHA_SATURATE; break;
		default: initerror("invalid sfactor value");  return;
	}
	switch ((int) *p->dfactor) {
		case  0:  dfactor = GL_ZERO; break;
		case  1:  dfactor = GL_ONE; break;
		// some missing...
		case  4:  dfactor = GL_SRC_ALPHA; break;
		case  5:  dfactor = GL_ONE_MINUS_SRC_ALPHA; break;
		case  6:  dfactor = GL_DST_ALPHA; break;
		case  7:  dfactor = GL_ONE_MINUS_DST_ALPHA; break;
		case  8:  dfactor = GL_SRC_ALPHA_SATURATE; break;
		case  9:  dfactor = GL_DST_COLOR; break;
		case  10: dfactor = GL_ONE_MINUS_DST_COLOR; break;
		default: initerror("invalid dfactor value");  return;
	}
	glBlendFunc(sfactor,dfactor);
}

extern "C" void GLblendfunc(GL_BLENDFUNC *p) { 	INIT_F(glblendfunc) }

//-----------------------
extern "C" char *imgdir_path;

extern "C" unsigned int 
APIENTRY pngBind(const char *filename, int mipmap, int trans, pngInfo *info, int wrapst, int minfilter, int magfilter);

void glloadtexture(GL_LOAD_TEXTURE *p) {  // from glpng.lib

	char s[MAXNAME];
	string filename;

	if (*p->filename == sstrcod) { 
		if (p->STRARG == NULL) strcpy(s,unquote(currevent->strarg));
		else strcpy(s, unquote(p->STRARG));
		
	} 
	else if ((long)*p->filename <= strsmax && strsets != NULL && strsets[(long)*p->filename]) {
		strcpy(s, strsets[(long)*p->filename]);
	}

	if (isfullpath(s) || imgdir_path == NULL)  filename = s;
	else filename = catpath(imgdir_path, s);


	int trans;
	switch ((int) *p->trans) {
		case 0: trans = PNG_ALPHA; break;
		case 1: trans = PNG_SOLID; break;
		case 2: trans = PNG_STENCIL; break;
		case 3: trans = PNG_BLEND1; break;
		case 4: trans = PNG_BLEND2; break;
		case 5: trans = PNG_BLEND3; break;
		case 6: trans = PNG_BLEND4; break;
		case 7: trans = PNG_BLEND5; break;
		case 8: trans = PNG_BLEND6; break;
  		case 9: trans = PNG_BLEND7; break;
		case 10: trans = PNG_BLEND8; break;
		default: initerror("invalid trans value"); return;

	}
	int wrapst;
	switch ((int) *p->wrapst) {
		case 0: wrapst = GL_CLAMP; break;
		case 1: wrapst = GL_REPEAT; break;
		default: initerror("invalid wrapst value"); return;
	}

	GLuint texID;
	pngInfo info;		  // from glpng.lib
	texID = pngBind(filename.c_str(), PNG_BUILDMIPMAPS, trans, &info, wrapst, GL_LINEAR_MIPMAP_NEAREST, GL_LINEAR_MIPMAP_NEAREST);
	*p->texID= (MYFLT) texID;
	v_texture.push_back(texID);
}


extern "C" void GLloadTexture(GL_LOAD_TEXTURE *p) { INIT_F(glloadtexture) }
//-----------------------
/*
void glopenvideo(GL_LOAD_TEXTURE *p) {  // from glpng.lib

	char s[MAXNAME];
	string filename;

	if (*p->filename == sstrcod) { 
		if (p->STRARG == NULL) strcpy(s,unquote(currevent->strarg));
		else strcpy(s, unquote(p->STRARG));
		
	} 
	else if ((long)*p->filename <= strsmax && strsets != NULL && strsets[(long)*p->filename]) {
		strcpy(s, strsets[(long)*p->filename]);
	}

	if (isfullpath(s) || imgdir_path == NULL)  filename = s;
	else filename = catpath(imgdir_path, s);


	int trans;
	switch ((int) *p->trans) {
		case 0: trans = PNG_ALPHA; break;
		case 1: trans = PNG_SOLID; break;
		case 2: trans = PNG_STENCIL; break;
		case 3: trans = PNG_BLEND1; break;
		case 4: trans = PNG_BLEND2; break;
		case 5: trans = PNG_BLEND3; break;
		case 6: trans = PNG_BLEND4; break;
		case 7: trans = PNG_BLEND5; break;
		case 8: trans = PNG_BLEND6; break;
  		case 9: trans = PNG_BLEND7; break;
		case 10: trans = PNG_BLEND8; break;
		default: initerror("invalid trans value"); return;

	}
	int wrapst;
	switch ((int) *p->wrapst) {
		case 0: wrapst = GL_CLAMP; break;
		case 1: wrapst = GL_REPEAT; break;
		default: initerror("invalid wrapst value"); return;
	}

	GLuint texID;
	pngInfo info;		  // from glpng.lib
	texID = pngBind(filename.c_str(), PNG_BUILDMIPMAPS, trans, &info, wrapst, GL_LINEAR, GL_LINEAR);
	*p->texID= (MYFLT) texID;
	v_texture.push_back(texID);
}


extern "C" void GLopenVideo(GL_LOAD_TEXTURE *p) { INIT_F(glopenvideo) }
*/
//-----------------------
void glbindtex(GL_ONEARG *p) { 
	glBindTexture(GL_TEXTURE_2D, (GLuint) *p->arg );
}

extern "C" void GLbindtexture(GL_ONEARG *p) {	INIT_F(glbindtex) }

//-----------------------
void glbegin(GL_ONEARG *p) {
/*
0  GL_POINTS 
1  GL_LINES 
2  GL_LINE_STRIP 
3  GL_LINE_LOOP 
4  GL_TRIANGLES 
5  GL_TRIANGLE_STRIP 
6  GL_TRIANGLE_FAN 
7  GL_QUADS 
8  GL_QUAD_STRIP 
9  GL_POLYGON 
*/
	glBegin((GLenum) *p->arg);
}

extern "C" void GLbegin(GL_ONEARG *p) {	INIT_F(glbegin) }

//-----------------------
void glend(GL_NOARG *p) {
	glEnd();
}

extern "C" void GLend(GL_NOARG *p) {	INIT_F(glend) }

//-----------------------
void gltexcoo2(GL_TWOARGS *p) {
	glTexCoord2f((GLfloat) *p->arg1 ,(GLfloat) *p->arg2 );
}

extern "C" void GLtexcoord2(GL_TWOARGS *p) {	INIT_F(gltexcoo2) }

//-----------------------
void glvert3(GL_AXIS *p) {
	glVertex3f((GLfloat) *p->x, (GLfloat) *p->y, (GLfloat) *p->z);
}

extern "C" void GLvertex3(GL_AXIS *p) {	INIT_F(glvert3) }
//-----------------------
void glnormal3(GL_AXIS *p) {
	glNormal3f((GLfloat) *p->x, (GLfloat) *p->y, (GLfloat) *p->z);
}

extern "C" void GLnormal3(GL_AXIS *p) {	INIT_F(glnormal3) }

/*
//-----------------------
void glreadobj(GL_READ_OBJECT *p) {

	char s[MAXNAME];
	if (*p->filename == sstrcod) { 
		if (p->STRARG == NULL) strcpy(s,unquote(currevent->strarg));
		else strcpy(s, unquote(p->STRARG));
	} 

	else if ((long)*p->filename <= strsmax && strsets != NULL && strsets[(long)*p->filename]) {
		strcpy(s, strsets[(long)*p->filename]);
	}

	string filename;
	if (isfullpath(s) || imgdir_path == NULL)  filename = s;
	else filename = catpath(imgdir_path, s);
	
	TDobject *tdObject = tdReadObject((char*) filename.c_str());
	if (!tdObject) 	return;    
			
	tdSize(tdObject, 0.0);	// set the size to -1 to 1
				
	if (tdObject->num_normals == 0)	// generate normals if this	object doesn't have them.
			tdGenSmoothNormals(tdObject);
		
	// generate texture vertices if this object doesn't have them
	if (tdObject->num_texvertices == 0)
		tdGenLinearTexvertices(tdObject);
				
	tdGenTriangles(tdObject); // build a display list
	GLuint dispList;
	
	TDprimitive mode;

	switch ((int) *p->mode){
		case 0: mode =  TD_POINTS; break;
		case 1: mode =  TD_LINES; break;
		case 2: mode =  TD_LINE_STRIP; break;
		case 3: mode =  TD_LINE_LOOP; break;
		case 4: mode =  TD_TRIANGLES; break;
		case 5: mode =  TD_TRIANGLE_STRIP; break;
		case 6: mode =  TD_TRIANGLE_FAN; break;
		case 7: mode =  TD_QUADS; break;
		case 8: mode =  TD_QUAD_STRIP; break;
		case 9: mode =  TD_POLYGON; break;
		default: mode = TD_TRIANGLES;
	}
	
	dispList = tdGenDList(tdObject, mode, TD_VERTEX | TD_NORMAL | TD_TEXVERTEX); 
			
	tdDeleteObject(tdObject); // nuke it, we don't need it anymore 
	*p->dispList = (MYFLT) dispList;
	num_display_lists++;
}

*/
void glreadobj(GL_READ_OBJECT *p) {

	char s[MAXNAME];

	if (*p->filename == sstrcod) { 
		if (p->STRARG == NULL) strcpy(s,unquote(currevent->strarg));
		else strcpy(s, unquote(p->STRARG));
	} 
	else if ((long)*p->filename <= strsmax && strsets != NULL && strsets[(long)*p->filename]) {
		strcpy(s, strsets[(long)*p->filename]);
	}

	string filename;
	if (isfullpath(s) || imgdir_path == NULL)  filename = s;
	else filename = catpath(imgdir_path, s);
	
	GLMmodel *model = glmReadOBJ((char*) filename.c_str());
	if (!model) {
		initerror("unable to load wavefront object");
		return;    
	}
		
	MYFLT scale = glmUnitize(model); // set the size to -1 to 1
				
	if (model->numnormals == 0)	{ // generate normals if this object doesn't have them.
			glmFacetNormals(model);
			glmVertexNormals(model, (GLfloat) *p->smooth_angle);
	}
	
	
	if (model->numtexcoords == 0) { // generate texture vertices if this object doesn't have them
		switch ((int) *p->texture_type){
			case 0: break; //no texture coordinates
			case 1: glmLinearTexture( model); break;
			case 2: glmSpheremapTexture( model); break;
			default: glmLinearTexture( model); break;
		}
	}
	
/* glmList: Generates and returns a display list for the model using the mode specified.
 *
 * model - initialized GLMmodel structure
 * mode  - a bitwise OR of values describing what is to be rendered.
 *             GLM_NONE     -  render with only vertices
 *             GLM_FLAT     -  render with facet normals
 *             GLM_SMOOTH   -  render with vertex normals
 *             GLM_TEXTURE  -  render with texture coords
 *             GLM_COLOR    -  render with colors (color material)
 *             GLM_MATERIAL -  render with materials
 *             GLM_COLOR and GLM_MATERIAL should not both be specified.  
 * GLM_FLAT and GLM_SMOOTH should not both be specified.
 
   mode2 = 0 -> GL_TRIANGLES
   mode2 = 1 -> GL_LINE_STRIP
 */
	GLint mode2;
	if (*p->wireframe) mode2 = GL_LINE_STRIP;
	else mode2 = GL_TRIANGLES;
	GLuint dispList = glmList(model, (GLuint) *p->mode, mode2);

	glmDelete(model); // nuke it, we don't need it anymore 
	*p->dispList = (MYFLT) dispList;
	num_display_lists++;
}



extern "C" void GLreadObject(GL_READ_OBJECT *p) {	INIT_F(glreadobj) }

//-----------------------
void glnewlist(GL_ONEARG *p) {
	glNewList((GLuint) *p->arg, GL_COMPILE);
	num_display_lists++;
}

extern "C" void GLnewList(GL_ONEARG *p) {	INIT_F(glnewlist) }

//-----------------------
void glendlist(GL_NOARG *p) {
	glEndList();
}

extern "C" void GLendList(GL_ONEARG *p) {	INIT_F(glendlist) }

//-----------------------
void glcallist(GL_ONEARG *p) {
	glCallList((GLuint) *p->arg);
}

extern "C" void GLcallList(GL_ONEARG *p) {	INIT_F(glcallist) }

//-----------------------
void glucylinder(GLU_CYLINDER *p) {
	
	gluCylinder( (GLUquadricObj*) (v_gluQuadricObj[(int) *p->QuadricObj]) ,
				(GLdouble) *p->baseRadius , (GLdouble) *p->topRadius, 
				(GLdouble) *p->height, (GLint) *p->slices, (GLint) *p->stacks);

}

extern "C" void GLUcylinder(GLU_CYLINDER *p) {	INIT_F(glucylinder) }

//-----------------------
void glusphere(GLU_SPHERE *p) {
	
	gluSphere( (GLUquadricObj*) (v_gluQuadricObj[(int) *p->QuadricObj]) ,
				(GLdouble) *p->radius , (GLint) *p->slices, (GLint) *p->stacks);

}

extern "C" void GLUsphere(GLU_SPHERE *p) {	INIT_F(glusphere) }
//-----------------------

void gludisk(GLU_DISK *p) {
	gluDisk( (GLUquadricObj*) (v_gluQuadricObj[(int) *p->QuadricObj]) ,
				(GLdouble) *p->innerRadius , (GLdouble) *p->outerRadius ,(GLint) *p->slices, (GLint) *p->loops);

}

extern "C" void GLUdisk(GLU_DISK *p) {	INIT_F(gludisk) }

//-----------------------
void glunewquadric(GL_TWOARGS *p) {

	GLUquadricObj* obj; 
	obj = gluNewQuadric();
	v_gluQuadricObj.push_back((void*) obj);
	*p->arg1= (MYFLT) v_gluQuadricObj.size()-1;
	if (*p->arg2)
		gluQuadricOrientation(obj,GLU_INSIDE);
	else
		gluQuadricOrientation(obj,GLU_OUTSIDE); 
}

extern "C" void GLUnewquadric(GL_TWOARGS *p) {	INIT_F(glunewquadric) }

//-----------------------

void gluquadricDrawStyle(GL_TWOARGS *p) {
	GLenum style;
	switch ((int) *p->arg2) {
		case 0: style = GLU_FILL; break;
		case 1: style = GLU_LINE; break;
		case 2: style = GLU_SILHOUETTE; break;
		case 3: style = GLU_POINT; break;
		default: initerror("invalid style value"); return;

	}
	gluQuadricDrawStyle((GLUquadricObj*) (v_gluQuadricObj[(int) *p->arg1]) , style);

}

extern "C" void GLUquadricDrawStyle(GL_TWOARGS *p) {	INIT_F(gluquadricDrawStyle) }

//-----------------------
void gluquadricNormals(GL_TWOARGS *p) {
	GLenum normals;
	switch ((int) *p->arg2) {
		case 0: normals = GLU_NONE; break;
		case 1: normals = GLU_FLAT; break;
		case 2: normals = GLU_SMOOTH; break;
		default: initerror("invalid normals value"); return;

	}
	gluQuadricNormals((GLUquadricObj*) (v_gluQuadricObj[(int) *p->arg1]) , normals);

}

extern "C" void GLUquadricNormals(GL_TWOARGS *p) {	INIT_F(gluquadricNormals) }

//-----------------------
void gluquadricTexture(GL_TWOARGS *p) {
	GLboolean boolean;
	switch ((int) *p->arg2) {
		case 0: boolean = GL_FALSE; break;
		case 1: boolean = GL_TRUE; break;
		default: initerror("gluQuadricTexture: invalid true/false value"); return;

	}
	gluQuadricTexture((GLUquadricObj*) (v_gluQuadricObj[(int) *p->arg1]) , boolean);

}

extern "C" void GLUquadricTexture(GL_TWOARGS *p) {	INIT_F(gluquadricTexture) }



//-----------------------
void gltexEnvi(GL_ONEARG *p) {
	GLint param;
	switch ((int) *p->arg) {
		case 0: param = GL_MODULATE; break;
		case 1: param = GL_DECAL; break;
		case 2: param = GL_BLEND; break;
		default: initerror("invalid param value"); return;
	}
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, param);
}

extern "C" void GLtexEnvi(GL_ONEARG *p) {	INIT_F(gltexEnvi) }

//-----------------------
void gltexEnvfv(GL_COLOR4 *p) {
	GLfloat param[4];
	param[0]=(GLfloat) *p->red;
	param[1]=(GLfloat) *p->green;
	param[2]=(GLfloat) *p->blue;
	param[3]=(GLfloat) *p->alpha;
	glTexEnvfv(GL_TEXTURE_ENV, GL_TEXTURE_ENV_COLOR, param);
}

extern "C" void GLtexEnvfv(GL_COLOR4 *p) {	INIT_F(gltexEnvfv) }

//-----------------------

void gltexGeni(GL_TWOARGS *p) {
	GLenum coord;
	switch ((int) *p->arg1) {
		case 0: coord = GL_S; break;
		case 1: coord = GL_T; break;
		case 2: coord = GL_R; break;
		case 3: coord = GL_Q; break;
		default: initerror("invalid coordinate value"); return;
	}

	GLint param;
	switch ((int) *p->arg2) {
		case 0: param = GL_OBJECT_LINEAR; break;
		case 1: param = GL_EYE_LINEAR; break;
		case 2: param = GL_SPHERE_MAP; break;
		default: initerror("invalid param value"); return;
	}
	glTexGeni(coord, GL_TEXTURE_GEN_MODE, param);
}

extern "C" void GLtexGeni(GL_TWOARGS *p) {	INIT_F(gltexGeni) }

//-----------------------
void gltexGenfv(GL_TEXGENFV *p) {
	GLenum coord;
	switch ((int) *p->coord) {
		case 0: coord = GL_S; break;
		case 1: coord = GL_T; break;
		case 2: coord = GL_R; break;
		case 3: coord = GL_Q; break;
		default: initerror("invalid coordinate value"); return;
	}

	GLenum pname;
	switch ((int) *p->pname) {
		case 0: pname = GL_TEXTURE_GEN_MODE; break;
		case 1: pname = GL_OBJECT_PLANE; break;
		case 2: pname = GL_EYE_PLANE; break;
		//case 3: pname = GL_Q; break;
		default: initerror("invalid pname value"); return;
	}


	GLfloat coeff[4];
	coeff[0] = *p->coeff_X;
	coeff[1] = *p->coeff_Y;
	coeff[2] = *p->coeff_Z;
	coeff[3] = *p->coeff_W;

	glTexGenfv(coord, pname, coeff);
}

extern "C" void GLtexGenfv(GL_TEXGENFV *p) {	INIT_F(gltexGenfv) }
//-----------------------

void glenableClientState(GL_ONEARG *p) {
	GLenum array;
	switch ((int) *p->arg) {
		case 0: array = GL_VERTEX_ARRAY  ; break;
		case 1: array = GL_NORMAL_ARRAY ; break;
		case 2: array = GL_COLOR_ARRAY; break;
		case 3: array = GL_INDEX_ARRAY ; break;
		case 4: array = GL_TEXTURE_COORD_ARRAY  ; break;		
		case 5: array = GL_EDGE_FLAG_ARRAY ; break;
		default: initerror("invalid array value"); return;
	}

	glEnableClientState(array);
}

extern "C" void GLenableClientState(GL_ONEARG *p) {	INIT_F(glenableClientState) }
//-----------------------

void gldisableClientState(GL_ONEARG *p) {
	GLenum array;
	switch ((int) *p->arg) {
		case 0: array = GL_VERTEX_ARRAY  ; break;
		case 1: array = GL_NORMAL_ARRAY ; break;
		case 2: array = GL_COLOR_ARRAY; break;
		case 3: array = GL_INDEX_ARRAY ; break;
		case 4: array = GL_TEXTURE_COORD_ARRAY  ; break;		
		case 5: array = GL_EDGE_FLAG_ARRAY ; break;
		default: initerror("invalid array value"); return;
	}

	glDisableClientState(array);
}

extern "C" void GLdisableClientState(GL_ONEARG *p) {	INIT_F(gldisableClientState) }



//-----------------------



void glvertexPointer(GL_POINTER *p) {		// change it for DOUBLE Csound version
	glVertexPointer(3, GL_FLOAT, (GLsizei) *p->stride * sizeof(GL_FLOAT), (GLvoid*) p->table);
}

extern "C" void GLvertexPointer(GL_POINTER *p) {
	FUNC *ftp;
	if((ftp = ftfind(p->ifn)) != NULL) {
		p->table = ftp->ftable + (int) *p->offset;
			
		INIT_F(glvertexPointer)
	}
	else return;
	
}

//-----------------------

void glnormalPointer(GL_POINTER *p) {		// change it for DOUBLE Csound version
	glNormalPointer( GL_FLOAT, (GLsizei) *p->stride * sizeof(GL_FLOAT), (GLvoid*) p->table);
}

extern "C" void GLnormalPointer(GL_POINTER *p) {
	FUNC *ftp;
	if((ftp = ftfind(p->ifn)) != NULL) {
		p->table = ftp->ftable + (int) *p->offset;
			
		INIT_F(glnormalPointer)
	}
	else return;
	
}
//-----------------------

void glcolorPointer(GL_POINTER *p) {		// change it for DOUBLE Csound version
	glColorPointer(4, GL_FLOAT, (GLsizei) *p->stride * sizeof(GL_FLOAT), (GLvoid*) p->table);
}

extern "C" void GLcolorPointer(GL_POINTER *p) {
	FUNC *ftp;
	if((ftp = ftfind(p->ifn)) != NULL) {
		p->table = ftp->ftable + (int) *p->offset;
			
		INIT_F(glcolorPointer)
	}
	else return;
}
//-----------------------

void glindexPointer(GL_POINTER *p) {		// change it for DOUBLE Csound version
	glIndexPointer(GL_FLOAT, (GLsizei) *p->stride * sizeof(GL_FLOAT), (GLvoid*) p->table);
}

extern "C" void GLindexPointer(GL_POINTER *p) {
	FUNC *ftp;
	if((ftp = ftfind(p->ifn)) != NULL) {
		p->table = ftp->ftable + (int) *p->offset;
			
		INIT_F(glindexPointer)
	}
	else return;
}

//-----------------------
void gltexCoordPointer(GL_POINTER *p) {		// change it for DOUBLE Csound version
	glTexCoordPointer(2,GL_FLOAT, (GLsizei) *p->stride * sizeof(GL_FLOAT), (GLvoid*) p->table);
}

extern "C" void GLtexCoordPointer(GL_POINTER *p) {
	FUNC *ftp;
	if((ftp = ftfind(p->ifn)) != NULL) {
		p->table = ftp->ftable + (int) *p->offset;
			
		INIT_F(gltexCoordPointer)
	}
	else return;
}
//-----------------------
void gledgeFlagPointer(GL_POINTER *p) {		// change it for DOUBLE Csound version
	glEdgeFlagPointer((GLsizei) *p->stride * sizeof(GL_FLOAT), (GLvoid*) p->table);
}

extern "C" void GLedgeFlagPointer(GL_POINTER *p) {
	FUNC *ftp;
	if((ftp = ftfind(p->ifn)) != NULL) {
		p->table = ftp->ftable + (int) *p->offset;
			
		INIT_F(gledgeFlagPointer)
	}
	else return;
}


//-----------------------
void glarrayElement(GL_ONEARG *p) {		// change it for DOUBLE Csound version
	glArrayElement((GLint) *p->arg);
}

extern "C" void GLarrayElement(GL_ONEARG *p) {	INIT_F(glarrayElement) }



//-----------------------
void gldrawElements(GL_DRAWELEMENTS *p) {		// change it for DOUBLE Csound version
/*
MODE:

0  GL_POINTS 
1  GL_LINES 
2  GL_LINE_STRIP 
3  GL_LINE_LOOP 
4  GL_TRIANGLES 
5  GL_TRIANGLE_STRIP 
6  GL_TRIANGLE_FAN 
7  GL_QUADS 
8  GL_QUAD_STRIP 
9  GL_POLYGON 
*/
	//glDrawElements (GLenum mode, GLsizei count, GLenum type, const GLvoid *indices);
	glDrawElements((GLenum) *p->mode, (GLsizei) *p->count, GL_UNSIGNED_INT, (GLvoid*) p->table);
}

extern "C" void GLdrawElements(GL_DRAWELEMENTS *p) {
	FUNC *ftp;
	long *itab, count = *p->count;
	if((ftp = ftfind(p->ifn)) != NULL) {
		MYFLT *ftab = ftp->ftable;

		auxalloc(sizeof(long) * count, &p->aux);
		p->table = itab = (long*)p->aux.auxp;

	
		do {
			*itab++ = (long) *ftab++;
		} while (--count);
			
		INIT_F(gldrawElements)
	}
	else return;
}

//-----------------------
void gldrawArrays(GL_DRAWARRAYS *p) {		// change it for DOUBLE Csound version
/*
MODE:

0  GL_POINTS 
1  GL_LINES 
2  GL_LINE_STRIP 
3  GL_LINE_LOOP 
4  GL_TRIANGLES 
5  GL_TRIANGLE_STRIP 
6  GL_TRIANGLE_FAN 
7  GL_QUADS 
8  GL_QUAD_STRIP 
9  GL_POLYGON 
*/
	//glDrawElements (GLenum mode, GLsizei count, GLenum type, const GLvoid *indices);
	glDrawArrays((GLenum) *p->mode, (GLint) *p->first, (GLsizei) *p->count);
}

extern "C" void GLdrawArrays(GL_DRAWARRAYS *p) { INIT_F(gldrawArrays) }

//-----------------------



void glulookAt(GLU_LOOKAT *p) {
	gluLookAt(	(GLdouble) *p->eyex,	(GLdouble) *p->eyey,	(GLdouble) *p->eyez, 
				(GLdouble) *p->centerx,	(GLdouble) *p->centery,	(GLdouble) *p->centerz, 
				(GLdouble) *p->upx,		(GLdouble) *p->upy,		(GLdouble) *p->upz ); 
}

extern "C" void GLUlookAt(GLU_LOOKAT *p) {	INIT_F(glulookAt) }

//-----------------------


void glloadMatrixv(GL_MATRIXV *p) {
#ifdef CSD_DOUBLE
	glLoadMatrixd( p->table ); 
#else
	glLoadMatrixf( p->table ); 
#endif
}


extern "C" void GLloadMatrixv(GL_MATRIXV *p) {
	FUNC *ftp;
	if((ftp = ftfind(p->ifn)) != NULL) {
		p->table = ftp->ftable;
		INIT_F(glloadMatrixv)
	}
	else return;
}

//-----------------------
void glmultMatrixv(GL_MATRIXV *p) {
#ifdef CSD_DOUBLE
	glMultMatrixd( p->table ); 
#else
	glMultMatrixf( p->table ); 
#endif
}

extern "C" void GLmultMatrixv(GL_MATRIXV *p) {
	FUNC *ftp;
	if((ftp = ftfind(p->ifn)) != NULL) {
		p->table = ftp->ftable;
		INIT_F(glmultMatrixv)
	}
	else return;
}
//-----------------------
void glloadMatrix(GL_MATRIX *p) {
	GLfloat m[16];
	m[0]= *p->m0;
	m[1]= *p->m1;
	m[2]= *p->m2;
	m[3]= *p->m3;
	m[4]= *p->m4;
	m[5]= *p->m5;
	m[6]= *p->m6;
	m[7]= *p->m7;
	m[8]= *p->m8;
	m[9]= *p->m9;
	m[10]= *p->m10;
	m[11]= *p->m11;
	m[12]= *p->m12;
	m[13]= *p->m13;
	m[14]= *p->m14;
	m[15]= *p->m15;
	glLoadMatrixf( m ); 
}

extern "C" void GLloadMatrix(GL_MATRIX *p) { INIT_F(glloadMatrix)}

//-----------------------
void glmultMatrix(GL_MATRIX *p) {
	GLfloat m[16];
	m[0]= *p->m0;
	m[1]= *p->m1;
	m[2]= *p->m2;
	m[3]= *p->m3;
	m[4]= *p->m4;
	m[5]= *p->m5;
	m[6]= *p->m6;
	m[7]= *p->m7;
	m[8]= *p->m8;
	m[9]= *p->m9;
	m[10]= *p->m10;
	m[11]= *p->m11;
	m[12]= *p->m12;
	m[13]= *p->m13;
	m[14]= *p->m14;
	m[15]= *p->m15;

	glMultMatrixf( m ); 
}

extern "C" void GLmultMatrix(GL_MATRIX *p) { INIT_F(glmultMatrix) }

//-----------------------
void glfrustum(GL_FRUSTUM *p) {
	glFrustum(	(GLdouble) *p->left, (GLdouble) *p->right, 
				(GLdouble) *p->bottom, (GLdouble) *p->top, 
				(GLdouble) *p->znear, (GLdouble) *p->zfar ); 
}

extern "C" void GLfrustum(GL_FRUSTUM *p) {	INIT_F(glfrustum) }

//-----------------------
void glclipPlane(GL_CLIPLANE *p) {
	
	GLenum planeNum;
	switch ((int) *p->planeNum){
		case 0: planeNum = GL_CLIP_PLANE0; break;
		case 1: planeNum = GL_CLIP_PLANE1; break;
		case 2: planeNum = GL_CLIP_PLANE2; break;
		case 3: planeNum = GL_CLIP_PLANE3; break;
		case 4: planeNum = GL_CLIP_PLANE4; break;
		case 5: planeNum = GL_CLIP_PLANE5; break;
		default: initerror("invalid clip plane number"); return;
	}

	GLdouble equation[4];
	equation[0]= *p->coeff0;
	equation[1]= *p->coeff1;
	equation[2]= *p->coeff2;
	equation[3]= *p->coeff3;
	glClipPlane( planeNum,  equation); 
}

extern "C" void GLclipPlane(GL_CLIPLANE *p) {	INIT_F(glclipPlane) }



//****** EVALUATORS *********
//-----------------------
void glevalCoord1(GL_ONEARG *p) {
	glEvalCoord1f((GLfloat) *p->arg); 
}

extern "C" void GLevalCoord1(GL_ONEARG *p) {	INIT_F(glevalCoord1) }

//-----------------------
void glevalCoord2(GL_TWOARGS *p) {
	glEvalCoord2f((GLfloat) *p->arg1, (GLfloat) *p->arg2 ); 
}

extern "C" void GLevalCoord2(GL_TWOARGS *p) {	INIT_F(glevalCoord2) }
//-----------------------
void glevalMesh1(GL_EVALMESH1 *p) {
	GLenum mode;
	switch ((int) *p->mode){
		case 0: mode = GL_POINT ; break;
		case 1: mode = GL_LINE ; break;
		default: initerror("invalid mode value"); return;
	}

	glEvalMesh1(mode, (GLint) *p->u1, (GLint) *p->u2); 
}

extern "C" void GLevalMesh1(GL_EVALMESH1 *p) {	INIT_F(glevalMesh1) }

//-----------------------

void glevalMesh2(GL_EVALMESH2 *p) {
	GLenum mode;
	switch ((int) *p->mode){
		case 0: mode = GL_POINT ; break;
		case 1: mode = GL_LINE ; break;
		case 2: mode = GL_FILL ; break;
		default: initerror("invalid mode value"); return;
	}

	glEvalMesh2(mode, (GLint) *p->u1, (GLint) *p->u2,(GLint) *p->v1, (GLint) *p->v2 ); 
}

extern "C" void GLevalMesh2(GL_EVALMESH2 *p) {	INIT_F(glevalMesh2) }
//-----------------------


void glmap1(GL_MAP1 *p) {
	GLenum target;
	switch ((int) *p->target){
		case 33: target = GL_MAP1_VERTEX_3 ; break;
		case 34: target = GL_MAP1_VERTEX_4 ; break;
		case 27: target = GL_MAP1_INDEX ; break;
		case 26: target = GL_MAP1_COLOR_4; break;
		case 28: target = GL_MAP1_NORMAL ; break;
		case 29: target = GL_MAP1_TEXTURE_COORD_1 ; break;
		case 30: target = GL_MAP1_TEXTURE_COORD_2 ; break;
		case 31: target = GL_MAP1_TEXTURE_COORD_3 ; break;
		case 32: target = GL_MAP1_TEXTURE_COORD_4 ; break;
		default: initerror("invalid target identifier"); return;
	}

#ifdef CSD_DOUBLE
	glMap1d(target, (GLfloat) *p->u1, (GLfloat) *p->u2,  (GLint)   *p->ustride, (GLint)   *p->uorder, p->table); 
#else
	glMap1f(target, (GLfloat) *p->u1, (GLfloat) *p->u2,  (GLint)   *p->ustride, (GLint)   *p->uorder, p->table); 
#endif
}

extern "C" void GLmap1(GL_MAP1 *p) {
	FUNC *ftp;
	if ((ftp = ftfind(p->ifn_points)) == NULL) {
		  initerror("glMap1: invalid ifn_points table number");
          return;
	}
	p->table = ftp->ftable;
	INIT_F(glmap1) 
}


//-----------------------

void glmap2(GL_MAP2 *p) {
	GLenum target;
	switch ((int) *p->target){
		case 42: target = GL_MAP2_VERTEX_3 ; break;
		case 43: target = GL_MAP2_VERTEX_4 ; break;
		case 36: target = GL_MAP2_INDEX ; break;
		case 35: target = GL_MAP2_COLOR_4; break;
		case 37: target = GL_MAP2_NORMAL ; break;
		case 38: target = GL_MAP2_TEXTURE_COORD_1 ; break;
		case 39: target = GL_MAP2_TEXTURE_COORD_2 ; break;
		case 40: target = GL_MAP2_TEXTURE_COORD_3 ; break;
		case 41: target = GL_MAP2_TEXTURE_COORD_4 ; break;
		default: initerror("invalid target identifier"); return;
	}
#ifdef CSD_DOUBLE
	glMap2d(target, (GLfloat) *p->u1,      (GLfloat) *p->u2,   
					(GLint)   *p->ustride, (GLint)   *p->uorder,  
					(GLfloat) *p->v1,      (GLfloat) *p->v2, 
					(GLint)   *p->vstride, (GLint)   *p->vorder, p->table); 
#else
	glMap2f(target, (GLfloat) *p->u1,      (GLfloat) *p->u2,   
					(GLint)   *p->ustride, (GLint)   *p->uorder,  
					(GLfloat) *p->v1,      (GLfloat) *p->v2, 
					(GLint)   *p->vstride, (GLint)   *p->vorder, p->table); 
#endif
}

extern "C" void GLmap2(GL_MAP2 *p) {
	FUNC *ftp;
	if ((ftp = ftfind(p->ifn_points)) == NULL) {
		  initerror("glMap2: invalid ifn_points table number");
          return;
	}
	p->table = ftp->ftable;
	INIT_F(glmap2) 
}
//-----------------------
void glmapGrid1(GL_MAPGRID1 *p) {

	glMapGrid1f((GLint) *p->un, (GLfloat) *p->u1, (GLfloat) *p->u2); 
}

extern "C" void GLmapGrid1(GL_MAPGRID1 *p) {	INIT_F(glmapGrid1) }
//-----------------------

void glmapGrid2(GL_MAPGRID2 *p) {

	glMapGrid2f((GLint) *p->un, (GLfloat) *p->u1, (GLfloat) *p->u2,
			    (GLint) *p->vn, (GLfloat) *p->v1, (GLfloat) *p->v2); 
}

extern "C" void GLmapGrid2(GL_MAPGRID2 *p) {	INIT_F(glmapGrid2) }

//****** NURBS *********
//----------------------

void glunewNurbsRenderer(GL_ONEARG *p) {
	GLUnurbsObj* obj; 
	obj = gluNewNurbsRenderer();
	v_gluNurbsObj.push_back((void*) obj);
	*p->arg= (MYFLT) v_gluNurbsObj.size()-1;
}

extern "C" void GLUnewNurbsRenderer (GL_ONEARG *p) {	INIT_F(glunewNurbsRenderer) }

//-----------------------
void glubeginCurve(GL_ONEARG *p) {
	gluBeginCurve((GLUnurbsObj *) v_gluNurbsObj[(int) *p->arg]);
}

extern "C" void GLUbeginCurve(GL_ONEARG *p) {	INIT_F(glubeginCurve) }
//-----------------------
void gluendCurve(GL_ONEARG *p) {
	gluEndCurve((GLUnurbsObj *) v_gluNurbsObj[(int) *p->arg]);
}

extern "C" void GLUendCurve(GL_ONEARG *p) {	INIT_F(gluendCurve) }
//-----------------------
void glubeginSurface(GL_ONEARG *p) {
	gluBeginSurface((GLUnurbsObj *) v_gluNurbsObj[(int) *p->arg]);
}

extern "C" void GLUbeginSurface(GL_ONEARG *p) {	INIT_F(glubeginSurface) }
//-----------------------
void gluendSurface(GL_ONEARG *p) {
	gluEndSurface((GLUnurbsObj *) v_gluNurbsObj[(int) *p->arg]);
}

extern "C" void GLUendSurface(GL_ONEARG *p) {	INIT_F(gluendSurface) }
//-----------------------
void glubeginTrim(GL_ONEARG *p) {
	gluBeginTrim((GLUnurbsObj *) v_gluNurbsObj[(int) *p->arg]);
}

extern "C" void GLUbeginTrim(GL_ONEARG *p) {	INIT_F(glubeginTrim) }
//-----------------------
void gluendTrim(GL_ONEARG *p) {
	gluEndTrim((GLUnurbsObj *) v_gluNurbsObj[(int) *p->arg]);
}

extern "C" void GLUendTrim(GL_ONEARG *p) {	INIT_F(gluendTrim) }

//-----------------------

void glunurbsCurve(GLU_NURBSCURVE *p) {
	GLenum type;
	switch ((int) *p->type){
		case 33: type = GL_MAP1_VERTEX_3 ; break;
		case 34: type = GL_MAP1_VERTEX_4 ; break;
		case 27: type = GL_MAP1_INDEX ; break;
		case 26: type = GL_MAP1_COLOR_4; break;
		case 28: type = GL_MAP1_NORMAL ; break;
		case 29: type = GL_MAP1_TEXTURE_COORD_1 ; break;
		case 30: type = GL_MAP1_TEXTURE_COORD_2 ; break;
		case 31: type = GL_MAP1_TEXTURE_COORD_3 ; break;
		case 32: type = GL_MAP1_TEXTURE_COORD_4 ; break;
		case 0: type = GLU_MAP1_TRIM_2 ; break;
		case 1: type = GLU_MAP1_TRIM_3 ; break;

		default: initerror("gluNurbsCurve: invalid type identifier"); return;
	}
#ifdef CSD_DOUBLE

 	MYFLT *t1 = p->table1, *t2 = p->table2;
	GLfloat *sknot = userGLfloatarray;
	GLfloat *ctlarray = &userGLfloatarray[MAXARRAYSIZE/2];
	int j, nknots = (int) *p->nknots, npoints = (int) (*p->order * *p->stride);
	for(j =0; j<nknots; j++)
		sknot[j] = (GLfloat) t1[j];
	for(j =0; j<npoints; j++)
		ctlarray[j] = (GLfloat) t2[j];

	gluNurbsCurve((GLUnurbsObj *) v_gluNurbsObj[(int) *p->nobj] , 
		(GLint)  *p->nknots, sknot, (GLint) *p->stride, ctlarray, (GLint) *p->order, type); 
#else
	gluNurbsCurve((GLUnurbsObj *) v_gluNurbsObj[(int) *p->nobj] , 
		(GLint)  *p->nknots, p->table1, (GLint) *p->stride, p->table2, (GLint) *p->order, type); 
#endif
}

extern "C" void GLUnurbsCurve(GLU_NURBSCURVE *p) {
	FUNC *ftp;
	if ((ftp = ftfind(p->ifn_knot)) == NULL) {
		  initerror("gluNurbsCurve: invalid ifn_knot table number");
          return;
	}
	p->table1 = ftp->ftable;
	
	if ((ftp = ftfind(p->ifn_ctlarray)) == NULL) {
		  initerror("gluNurbsCurve: invalid ifn_ctlarray table number");
          return;
	}
	p->table2 = ftp->ftable;
	INIT_F(glunurbsCurve) 
}

//-----------------------

void glunurbsSurface(GLU_NURBSSURFACE *p) {
	GLenum type;
	switch ((int) *p->type){
		case 42: type = GL_MAP2_VERTEX_3 ; break;
		case 43: type = GL_MAP2_VERTEX_4 ; break;
		case 36: type = GL_MAP2_INDEX ; break;
		case 35: type = GL_MAP2_COLOR_4; break;
		case 37: type = GL_MAP2_NORMAL ; break;
		case 38: type = GL_MAP2_TEXTURE_COORD_1 ; break;
		case 39: type = GL_MAP2_TEXTURE_COORD_2 ; break;
		case 40: type = GL_MAP2_TEXTURE_COORD_3 ; break;
		case 41: type = GL_MAP2_TEXTURE_COORD_4 ; break;

		default: initerror("gluNurbsSurface: invalid type identifier"); return;
	}
#ifdef CSD_DOUBLE

 	MYFLT *t1 = p->table1, *t2 = p->table2, *t3 = p->table3;
	GLfloat *Uknot = userGLfloatarray;
	GLfloat *Vknot = &userGLfloatarray[MAXARRAYSIZE/4];
	GLfloat *ctlarray = &userGLfloatarray[MAXARRAYSIZE/2];
	int j;
	int	nUknots = (int) *p->Uknot_count;
	int nVknots = (int) *p->Vknot_count;
	int	npoints = (int) (*p->Uorder * *p->Vorder 
		* ((*p->Vstride< *p->Ustride) ? *p->Vstride : *p->Ustride ));
	for(j =0; j<nUknots; j++)
		Uknot[j] = (GLfloat) t1[j];
	for(j =0; j<nVknots; j++)
		Vknot[j] = (GLfloat) t2[j];
	for(j =0; j<npoints; j++)
		ctlarray[j] = (GLfloat) t3[j];

	gluNurbsSurface((GLUnurbsObj *) v_gluNurbsObj[(int) *p->nobj] , 
		nUknots, Uknot, 
		nVknots, Vknot, 
		(GLint) *p->Ustride, (GLint) *p->Vstride, ctlarray, 
		(GLint) *p->Uorder,  (GLint) *p->Vorder, type); 
#else
	gluNurbsSurface((GLUnurbsObj *) v_gluNurbsObj[(int) *p->nobj], 
		(GLint) *p->Uknot_count, p->table1, 
		(GLint) *p->Vknot_count, p->table2, 
		(GLint) *p->Ustride, (GLint) *p->Vstride, p->table3, 
		(GLint) *p->Uorder,  (GLint) *p->Vorder, type); 
#endif
}

extern "C" void GLUnurbsSurface(GLU_NURBSSURFACE *p) {
	FUNC *ftp;
	if ((ftp = ftfind(p->ifn_Uknot)) == NULL) {
		  initerror("gluNurbsSurface: invalid ifn_Uknot table number");
          return;
	}
	p->table1 = ftp->ftable;
	
	if ((ftp = ftfind(p->ifn_Vknot)) == NULL) {
		  initerror("gluNurbsSurface: invalid ifn_Vknot table number");
          return;
	}
	p->table2 = ftp->ftable;
	if ((ftp = ftfind(p->ifn_ctlarray)) == NULL) {
		  initerror("gluNurbsSurface: invalid ifn_ctlarray table number");
          return;
	}
	p->table3 = ftp->ftable;

	INIT_F(glunurbsSurface) 
}

//-----------------------

void glupwlCurve(GLU_PWLCURVE *p) {
	GLenum type;
	switch ((int) *p->type){
		case 0: type = GLU_MAP1_TRIM_2 ; break;
		case 1: type = GLU_MAP1_TRIM_3 ; break;

		default: initerror("gluPwlCurve: invalid type identifier"); return;
	}
#ifdef CSD_DOUBLE
	MYFLT* t = p->table;
	GLint size = (GLint) (*p->count * *p->stride);

	for(int j =0; j<size; j++)
		userGLfloatarray[j] = (GLfloat) t[j];
	gluPwlCurve((GLUnurbsObj *) v_gluNurbsObj[(int) *p->nobj] , 
		(GLint)  *p->count, userGLfloatarray, (GLint) *p->stride,  type); 

#else
	gluPwlCurve((GLUnurbsObj *) v_gluNurbsObj[(int) *p->nobj] , 
		(GLint)  *p->count, p->table, (GLint) *p->stride,  type); 
#endif
}

extern "C" void GLUpwlCurve(GLU_PWLCURVE *p) {
	FUNC *ftp;
	if ((ftp = ftfind(p->ifn_array)) == NULL) {
		  initerror("gluPwlCurve: incorrect ifn_array table number");
          return;
	}
	p->table = ftp->ftable;
	
	INIT_F(glupwlCurve) 
}
//--------------------------
void glunurbsProperty(GLU_NURBSPROPERTY *p) {
	GLenum property;
	switch ((int) *p->property) {
		case 0: property = GLU_SAMPLING_TOLERANCE  ; break;
		case 1: property = GLU_DISPLAY_MODE ; break;
		case 2: property = GLU_CULLING; break;
		case 3: property = GLU_AUTO_LOAD_MATRIX ; break;
		case 4: property = GLU_PARAMETRIC_TOLERANCE  ; break;		
		case 5: property = GLU_SAMPLING_METHOD ; break;
		case 6: property = GLU_U_STEP ; break;
		case 7: property = GLU_V_STEP ; break;

		default: initerror("invalid property value"); return;
	}

	gluNurbsProperty((GLUnurbsObj *) v_gluNurbsObj[(int) *p->nobj],	property, *p->value);
}

extern "C" void GLUnurbsProperty(GLU_NURBSPROPERTY *p) { INIT_F(glunurbsProperty) }

//--------------------------
//--------------------------

/*
void CALLBACK glVertexCallback(GLdouble *v)
{
   glVertex3dv(v);
}
*/

void glutessBeginPolygon(GL_NOARG *p) {

	Tess = gluNewTess();
	
    gluTessCallback(Tess, GLU_BEGIN,  (void (CALLBACK *)(void)) glBegin);
    gluTessCallback(Tess, GLU_VERTEX, (void (CALLBACK *)(void)) glVertex3dv);
    gluTessCallback(Tess, GLU_END,     glEnd);
	
	gluTessBeginPolygon(Tess, NULL);
}

extern "C" void GLUtessBeginPolygon(GL_NOARG *p) { INIT_F(glutessBeginPolygon) }
//--------------------------
void glutessEndPolygon(GL_NOARG *p) {
	if (!Tess) {
		initerror("gluTessEndPolygon: gluTessBeginPolygon not found");
		return;
	}
	gluTessEndPolygon(Tess);
	gluDeleteTess(Tess);
	Tess = NULL;

}

extern "C" void GLUtessEndPolygon(GL_NOARG *p) { INIT_F(glutessEndPolygon) }

//--------------------------
void glutessBeginContour(GL_NOARG *p) {
	gluTessBeginContour(Tess);

}

extern "C" void GLUtessBeginContour(GL_NOARG *p) { INIT_F(glutessBeginContour) }
//--------------------------
void glutessEndContour(GL_NOARG *p) {
	gluTessEndContour(Tess);

}
extern "C" void GLUtessEndContour(GL_NOARG *p) { INIT_F(glutessEndContour) }
//--------------------------

void glutessVertexv(GLU_TESS_VERTEXV *p) {
	long index = (long) *p->index * 3;
	double *v = p->v;
	v[0] = p->table[index];
	v[1] = p->table[index+1];
	v[2] = p->table[index+2];
	gluTessVertex(Tess, v, v);

}

extern "C" void GLUtessVertexv(GLU_TESS_VERTEXV *p) { 
	FUNC *ftp;
	if((ftp = ftfind(p->ifn)) != NULL) {
		p->table = ftp->ftable;
		INIT_F(glutessVertexv) 
	}
	else return;
}
//--------------------------
void glutessVertex(GLU_TES_VERTEX *p) {
	double *v = p->v;

	v[0] = *p->x;
	v[1] = *p->y;
	v[2] = *p->z;
	gluTessVertex(Tess, v, v);

}

extern "C" void GLUtessVertex(GLU_TES_VERTEX *p) { INIT_F(glutessVertex) }


//--------------------------

void glpix2tex(GL_PIX2TEX *p) {
	if (p->changed) {
		if (p->init_flag) {
			glGenTextures(1, &p->texObj);
			p->init_flag =0;
			*p->itexHandle = p->texObj;
			v_texture.push_back(p->texObj);
		}
		glBindTexture(GL_TEXTURE_2D, p->texObj);
		
		if ((int) *p->imageHandle != p->old_handle) {
			imageStruct* image = &(Bm_image[(int) *p->imageHandle]);
			if (image->data == NULL) {
				initerror("invalid image");
				return;
			}
			//image->data = Bm_image[(int) *p->imageHandle].data;
			if (p->xsize != image->xsize 
				||p->ysize != image->ysize 
				||p->csize != image->csize  ) {
				GLenum clamp, filter;
				clamp = (*p->clamp) ? GL_REPEAT : GL_CLAMP;
				filter = (*p->filter) ? GL_LINEAR : GL_NEAREST;


				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, filter);
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, filter);
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, clamp);
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, clamp);
				glTexImage2D(GL_TEXTURE_2D, 0,
					image->csize,
					image->xsize,
					image->ysize, 0,
					image->format,
					image->type,
					image->data);
				p->xsize = image->xsize;
				p->ysize = image->ysize;
				p->csize = image->csize;
			}
			else {
	 			glTexSubImage2D(GL_TEXTURE_2D, 0,
	    		0, 0,							// position
	    		image->xsize,
	    		image->ysize,
	    		image->format,
    			image->type,
    			image->data);		
			}
		}
		p->changed = 0;
	}
	//else {
	//	glBindTexture(GL_TEXTURE_2D, p->texObj);
	//}

}

extern "C" void GLpix2tex(GL_PIX2TEX *p) {
	if (*p->trigger)
		p->changed = 1;
}


extern "C" void GLpix2tex_set(GL_PIX2TEX *p) 
{ 
	p->old_handle = -1;
	p->xsize = p->ysize = p->csize = 0;
	p->changed = 1;
	INIT_F(glpix2tex) 
}
//--------------------------
#ifdef WIN32 

#define RED 0
#define GREEN 1
#define BLUE 2
#define ALPHA 3

static inline int powerOfTwo(int value) // video on Windows only
{
    int x = 1;
    while(x < value) x <<= 1;
    return(x);
}

/*
struct VIDEO_CAMERA_OBJ {
	HWND	m_hWndC;
	CAPDRIVERCAPS gCapDriverCaps;
	int		m_vidXSize,	m_vidYSize;
	int		img_xsize,	img_ysize;
	int		xPos,		yPos;
	int		xSize,		ySize;
	BYTE*			img_data;
	imageStruct*	m_pixBlock;
	VIDEO_CAMERA_OBJ() { m_hWndC = NULL; img_data=NULL; m_pixBlock=NULL; }
};
*/



//=================
/*
void videoFrameCallback(HWND hWnd, LPVIDEOHDR lpVHdr)
{
	if (OpenGL_enabled ) {
		EnterCriticalSection(&criticalSection);
		VIDEO_CAMERA_OBJ *cam_obj = (VIDEO_CAMERA_OBJ *)(capGetUserData(hWnd));
		BYTE *srcLine = lpVHdr->lpData;
		BYTE *dstLine = cam_obj->img_data;
		
		const int srcXSize = cam_obj->m_vidXSize * 3;
		const int dstXSize = cam_obj->img_xsize * 4;
		int ySize = cam_obj->ySize;
		int xSize = cam_obj->xSize;
		do {
			const unsigned char *srcPix = srcLine;
			unsigned char *dstPix = dstLine;
			int xS = xSize;
			do {
				dstPix[RED] = srcPix[2];
				dstPix[GREEN] = srcPix[1];
				dstPix[BLUE] = srcPix[0];
				// remember that we memset the data to 255
				//			dst[ALPHA] = 255;
				dstPix += 4;
				srcPix += 3;
			} while (--xS);
			srcLine += srcXSize;
			dstLine += dstXSize;
		} while (--ySize);
		LeaveCriticalSection(&criticalSection);
	}
}
*/

void videoFrameCallback(HWND hWnd, LPVIDEOHDR lpVHdr)
{
	if (OpenGL_enabled ) {
		EnterCriticalSection(&criticalSection);
		VIDEO_CAMERA_OBJ *cam_obj = (VIDEO_CAMERA_OBJ *)(capGetUserData(hWnd));
		BYTE *srcLine = lpVHdr->lpData;
		BYTE *dstLine = cam_obj->img_data + (cam_obj->xPos * 4) + (cam_obj->yPos * 4);
		
		const int srcXSize = cam_obj->m_vidXSize * 3;
		const int dstXSize = cam_obj->img_xsize * 4;
		int xSize = cam_obj->xSize;
		int ySize = cam_obj->ySize;
		do {
			const unsigned char *srcPix = srcLine;
			unsigned char *dstPix = dstLine;
			int xS = xSize;
			do {
				dstPix[RED] = srcPix[2];
				dstPix[GREEN] = srcPix[1];
				dstPix[BLUE] = srcPix[0];
				// remember that we memset the data to 255
				//			dst[ALPHA] = 255;
				dstPix += 4;
				srcPix += 3;
			} while (--xS);
			srcLine += srcXSize;
			dstLine += dstXSize;
		} while (--ySize);
		LeaveCriticalSection(&criticalSection);
	}
}


/*
typedef struct	{
	OPDS	h;
	MYFLT  *device_num, *vid_xsize, *vid_ysize,  *img_handle, *img_xsize, *img_ysize, *vid_xpos, *vid_ypos;
} GL_OPEN_VIDEO_CAM;

*/
void gl_openVideoCam(GL_OPEN_VIDEO_CAM *p) // init rate
{	
	EnterCriticalSection(&criticalSection);
	int device_num = (int) *p->device_num;
	VIDEO_CAMERA_OBJ  *cam_obj = &v_VideoCameraObj[device_num];

	cam_obj->m_hWndC = capCreateCaptureWindow (
		(LPTSTR)TEXT("Csound video"),	// window name if pop-up 
		WS_CHILD,						// window style (not visible)
		0, 0, cam_obj->m_vidXSize, cam_obj->m_vidYSize, // window position and dimensions
		GetDesktopWindow(), (int) 0);
	
	if (!cam_obj->m_hWndC) {
		die("GLopenVideoCam: Unable to create capture window");
		return;
	} 

	if (!capDriverConnect(cam_obj->m_hWndC, device_num)) {
		die("GLopenVideoCam: Unable to connect to video driver");
		return;
	}
	capDriverGetCaps(cam_obj->m_hWndC, &(cam_obj->gCapDriverCaps), sizeof(CAPDRIVERCAPS)) ;

	CAPTUREPARMS params;
	if (!capCaptureGetSetup(cam_obj->m_hWndC, &params, sizeof(CAPTUREPARMS))) {
		die("GLopenVideoCam: Unable to get capture parameters");
		return;
	}
	params.fYield = TRUE;
	params.fCaptureAudio = FALSE;
	params.wPercentDropForError = 100;
	params.fLimitEnabled = FALSE;
	params.AVStreamMaster = AVSTREAMMASTER_NONE;
	params.fStepCaptureAt2x = FALSE;
	params.fAbortLeftMouse = FALSE;
	params.fAbortRightMouse = FALSE;
	
	if (!capCaptureSetSetup(cam_obj->m_hWndC, &params, sizeof(CAPTUREPARMS))) {
		die("GLopenVideoCam: Unable to set capture parameters");
		return;
	}

	if (!capSetCallbackOnVideoStream(cam_obj->m_hWndC, videoFrameCallback)) {
		die("GLopenVideoCam: Unable to set frame callback");
		return;
	}

	if (!capSetUserData(cam_obj->m_hWndC, cam_obj)) {
		die("GLopenVideoCam: Unable to set user data");
		return;
	}
	
	DWORD formSize = capGetVideoFormat(cam_obj->m_hWndC, NULL, 0);
	BITMAPINFO *videoFormat = (BITMAPINFO *)(new char[formSize]);

	if (!capGetVideoFormat(cam_obj->m_hWndC, videoFormat, formSize))	{
		die("GLopenVideoCam: Unable to get video format");
		return;
	}

	videoFormat->bmiHeader.biWidth = cam_obj->m_vidXSize;
	videoFormat->bmiHeader.biHeight = cam_obj->m_vidYSize;
	videoFormat->bmiHeader.biBitCount = 24;
	videoFormat->bmiHeader.biCompression = BI_RGB;
	videoFormat->bmiHeader.biClrUsed = 0;
	videoFormat->bmiHeader.biClrImportant = 0;
	videoFormat->bmiHeader.biSizeImage = 0;
	if (!capSetVideoFormat(cam_obj->m_hWndC, videoFormat, formSize))
	{
		die("GLopenVideoCam: Unable to set video format");
		return;
	}
	printf("GLopenVideoCam: Connected at x: %d, y: %d, c: %d\n",
			(int)(videoFormat->bmiHeader.biWidth),
			(int)(videoFormat->bmiHeader.biHeight),
			(int)(videoFormat->bmiHeader.biBitCount));
	delete videoFormat;
	
    imageStruct* out = &(Bm_image[(int) *p->img_handle]);	
	if ( out->data == NULL
		||	out->xsize < cam_obj->img_xsize						
		||	out->ysize < cam_obj->img_ysize						
		||	out->csize < 4) 
	{					
		warning("GLopenVideoCam: allocating capture image\n");						
		out->xsize = cam_obj->img_xsize;							
		out->ysize = cam_obj->img_ysize;							
		out->csize = 4;
		out->format = GL_RGBA;
		out->type = GL_UNSIGNED_BYTE;
		if (out->data != NULL) {
			warning("GLopenVideoCam: previous loaded image is deleted!!\n");						
			delete [] out->data;	
		}
		long size = out->xsize * out->ysize * out->csize;
		out->data = new BYTE[ size ];
		memset(out->data, 255, size);
	}
	out->xsize = cam_obj->img_xsize;							
	out->ysize = cam_obj->img_ysize;							

	cam_obj->xPos = (int) *p->vid_xpos;
	cam_obj->yPos = (int) *p->vid_ypos;

	if (cam_obj->m_vidXSize < cam_obj->img_xsize) {
		cam_obj->xSize = cam_obj->m_vidXSize;
	}
	else {
		cam_obj->xSize = cam_obj->img_xsize;
	}
	if (cam_obj->m_vidYSize < cam_obj->img_ysize) {
		cam_obj->ySize = cam_obj->m_vidYSize ;
	}
	else {
		cam_obj->ySize = cam_obj->img_ysize;
	}
	

	cam_obj->img_data = (BYTE*) out->data;
	cam_obj->m_pixBlock = out;
	LeaveCriticalSection(&criticalSection);
	
	Sleep(200);
	
	if (!capCaptureSequenceNoFile( cam_obj->m_hWndC )  )	{
		die("GLopenVideoCam: Unable to start capture");
		return;
	}
	Sleep(200);
	
}

extern "C" void GLopenVideoCam(GL_OPEN_VIDEO_CAM *p) // init rate
{	
	VIDEO_CAMERA_OBJ  *cam_obj, ob;
	int device_num = (int) *p->device_num;
	v_VideoCameraObj[device_num] = ob; // creates a map element
	cam_obj = &v_VideoCameraObj[device_num];

	cam_obj->m_vidXSize = (int) *p->vid_xsize; 
	cam_obj->m_vidYSize = (int) *p->vid_ysize;

	cam_obj->img_xsize = (*p->img_xsize == 0) ? powerOfTwo(cam_obj->m_vidXSize) : (int) *p->img_xsize; 
	cam_obj->img_ysize = (*p->img_ysize == 0) ? powerOfTwo(cam_obj->m_vidYSize) : (int) *p->img_ysize;
	{
		char name[255], description[255]; 
		capGetDriverDescription(device_num, name, 255, description, 512);
		printf("Activating capture driver: %s \n%s\n", name, description);
	}

	InitializeCriticalSection(&criticalSection);
///////

	INIT_F(gl_openVideoCam)
}

//------

// NOT USEABLE YET!!!!!!
void gl_camDialog(GL_CAM_DLG *p) // init rate
{	
	if (p->done) return;
	int ret=0;
	VIDEO_CAMERA_OBJ *cam_obj = &v_VideoCameraObj[(int) *p->device_num];

    if (cam_obj->gCapDriverCaps.fHasDlgVideoSource) 
		ret = capDlgVideoSource(cam_obj->m_hWndC);
	
	if(!ret)
		warning("Source Dialog Box not available for this video capture device");
	
	p->done =1;

}

extern "C" void GLcamDialog(GL_CAM_DLG *p) // init rate
{	
	p->done = 0;
	INIT_F(gl_camDialog)
}

//=================

void glvideo2tex(GL_VIDEO2TEX *p) {
	VIDEO_OBJ* vid_obj = &(v_videoObj[(int) *p->video_handle]);

	long reqFrame = (long) (*p->reqFrame + FL(0.5)), curFrame = p->curFrame;
	unsigned char *pt;
	
	if(curFrame != reqFrame) {

		long numFrames = vid_obj->m_numFrames;
		reqFrame = (reqFrame < 0) ? 0 : ((reqFrame >= numFrames) ? numFrames-1 : reqFrame);
		pt = (unsigned char *)AVIStreamGetFrame(vid_obj->m_getFrame, reqFrame);
		
		glBindTexture(GL_TEXTURE_2D, vid_obj->texture_obj);
		
		if ((int) *p->video_handle != p->old_video_handle) {
			glTexImage2D(GL_TEXTURE_2D, 0,
				vid_obj->m_pixBlock.csize,
				vid_obj->m_pixBlock.xsize,
				vid_obj->m_pixBlock.ysize, 0,
				vid_obj->m_pixBlock.format,
				vid_obj->m_pixBlock.type,
				vid_obj->m_pixBlock.data);

			p->old_video_handle = (int) *p->video_handle;
		}

		glTexSubImage2D(GL_TEXTURE_2D, 0,
   			0, 0,							// position
   			vid_obj->m_xsize,				// the x size of the data
   			vid_obj->m_ysize,				// the y size of the data
   			vid_obj->m_pixBlock.format,		// the format
			vid_obj->m_pixBlock.type,		// the type
			pt + 40);						// the data + header offset
		p->curFrame = reqFrame;
	}
	*p->tex_handle = vid_obj->texture_obj;

}

extern "C" void GLvideo2tex(GL_VIDEO2TEX *p)
{ 
	p->curFrame = -1; 
	p->old_video_handle = -1;
	INIT_F(glvideo2tex) 
}

//------------
void  glopenVideoFile(GL_OPEN_VIDEO_FILE *p) {
	VIDEO_OBJ* vid_obj = &(v_videoObj[(int) *p->video_handle]);
	GLuint tex;
    glGenTextures(1, &tex);
	vid_obj->texture_obj = tex;
	v_texture.push_back(tex);
    
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, tex);
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

	glTexImage2D(GL_TEXTURE_2D, 0,
		vid_obj->m_pixBlock.csize,
		vid_obj->m_pixBlock.xsize,
		vid_obj->m_pixBlock.ysize, 0,
		vid_obj->m_pixBlock.format,
		vid_obj->m_pixBlock.type,
		vid_obj->m_pixBlock.data);
}

extern "C" void GLopenVideoFile(GL_OPEN_VIDEO_FILE *p) // init rate
{	
	char s[MAXNAME];
	string filename;

	if (*p->filename == sstrcod) { 
		if (p->STRARG == NULL) strcpy(s,unquote(currevent->strarg));
		else strcpy(s, unquote(p->STRARG));
		
	} 
	else if ((long)*p->filename <= strsmax && strsets != NULL && strsets[(long)*p->filename]) {
		strcpy(s, strsets[(long)*p->filename]);
	}

	if (isfullpath(s) || imgdir_path == NULL)  filename = s;
	else filename = catpath(imgdir_path, s);

	AVIFileInit();
	VIDEO_OBJ		vid_obj;		
	
	if (AVIStreamOpenFromFile(&vid_obj.m_streamVid, filename.c_str(), streamtypeVIDEO, 0, OF_READ, NULL)) {
		initerror("GLopenVideoFile: Unable to open file");
		return;
	}

	vid_obj.m_getFrame = AVIStreamGetFrameOpen(vid_obj.m_streamVid,NULL);
	if (vid_obj.m_getFrame == NULL ) {
		initerror("GLopenVideoFile: cannot find a decompressor for avi file"); 
		die("GLopenVideoFile: cannot find a decompressor for for avi file");
		return;
	}
	AVISTREAMINFO	psi;
	AVIStreamInfo(vid_obj.m_streamVid, &psi, sizeof(AVISTREAMINFO));
	
	vid_obj.m_numFrames = psi.dwLength;
	vid_obj.m_xsize = psi.rcFrame.right - psi.rcFrame.left;
	vid_obj.m_ysize = psi.rcFrame.bottom - psi.rcFrame.top;

	const int powXSize = powerOfTwo(vid_obj.m_xsize); // allocate a buffer that is the next power of two of the movie
	const int powYSize = powerOfTwo(vid_obj.m_ysize);

	vid_obj.m_pixBlock.xsize = powXSize;
	vid_obj.m_pixBlock.ysize = powYSize;
	vid_obj.m_pixBlock.csize = 3;
    vid_obj.m_pixBlock.format = GL_BGR_EXT;
	//vid_obj.m_pixBlock.csize = 4;
    //vid_obj.m_pixBlock.format = GL_BGRA_EXT;

	
    vid_obj.m_pixBlock.type = GL_UNSIGNED_BYTE;

	int dataSize = vid_obj.m_pixBlock.xsize * vid_obj.m_pixBlock.ysize * vid_obj.m_pixBlock.csize;
	vid_obj.m_pixBlock.data = new GLubyte[dataSize];
	memset(vid_obj.m_pixBlock.data, (GLubyte) (*p->backGroundAlpha / 255.0) , dataSize);
	v_videoObj.push_back(vid_obj);
	*p->video_handle = (MYFLT) v_videoObj.size()-1;

	INIT_F(glopenVideoFile)
}

//====

//--------------------------
//--------------------------

void gltext3d(GL_TEXT3D *p) {  // 3D text on Windows only
	glListBase((GLint) *p->nFontList);
	glCallLists (p->text_length, GL_UNSIGNED_BYTE, p->text); 	
}

extern "C" void GLtext3d(GL_TEXT3D *p) { 
	p->text = GetString(*p->string,p->STRARG);
	p->text_length = strlen(p->text);
	INIT_F(gltext3d) 
}

//----------
void gl3Dfont(GL_3D_FONT *p) {
	
		HDC hDC = GetDC(callback_target);		
		HGLRC hRC = wglCreateContext(hDC);

		wglMakeCurrent(hDC, hRC);
		
		LOGFONT logfont;
		HFONT hFont;
		GLuint nFontList;
		
		logfont.lfHeight = -10;
		logfont.lfWidth = 0;
		logfont.lfEscapement = 0;
		logfont.lfOrientation = 0;
		logfont.lfWeight = *p->weight; 
		logfont.lfItalic =  *p->italic;
		logfont.lfUnderline = FALSE;
		logfont.lfStrikeOut = FALSE;
		logfont.lfCharSet = ANSI_CHARSET;
		logfont.lfOutPrecision = OUT_DEFAULT_PRECIS;
		logfont.lfClipPrecision = CLIP_DEFAULT_PRECIS;
		logfont.lfQuality = DEFAULT_QUALITY;
		logfont.lfPitchAndFamily = DEFAULT_PITCH;
		strcpy(logfont.lfFaceName,p->style);
		
		hFont = CreateFontIndirect(&logfont);
		SelectObject (hDC, hFont); 
		nFontList = glGenLists(128);
		num_display_lists+=128;
		wglUseFontOutlines(hDC, 0, 128, nFontList, 0.0f, *p->depth, WGL_FONT_POLYGONS, NULL); 
		
		DeleteObject(hFont);
		*p->nLists = nFontList;
}

extern "C" void GL3Dfont(GL_3D_FONT *p) { 
	p->style = GetString(*p->typeface,p->STRARG);
	INIT_F(gl3Dfont) 
}

#endif  //WIN32

/*-------------------------*/
/*-------------------------*/
/*-------------------------*/
extern "C"	long	kcounter;
extern		double	GLperiod;
extern		double	FrameCounter;



void glgk(G_RATE *p)              
{
/*
	if (p->flag) {
		*p->kout =0;
		p->framecount = p->left;
		p->flag = 0;
		//return;
	}
*/
	MYFLT *buf = (MYFLT *)p->aux.auxp;
	int index = p->framecount - frame_delay;
	if (p->framecount > p->left - frame_delay+8)
		p->framecount = p->left - frame_delay;
	else if (p->framecount < p->left - frame_delay-8)
		p->framecount = p->left - frame_delay;

	if (index < 0)	
		index = 0;
	else 
		index %= MAX_FRAME_DELAY;
	
	//while (index >= MAX_FRAME_DELAY) 
	//		index = (long) p->framecount;
		//index = 0 ;
	*p->kout = buf[index];
	double diff = FrameCounter - p->framecount;
	p->framecount += 1.0 + diff;
//	if (diff >1 )
//		printf("%.0lf-", diff);

}	


extern "C" void GLgk(G_RATE *p)              
{
/*	
		if (p->flag) {
			p->framecount = 0;//FrameCounter;
			p->flag=0;
		}
*/
	if (kcounter > p->kcount + GLperiod) {
	    MYFLT *buf = (MYFLT *)p->aux.auxp;
		if (buf==NULL) {            
			initerror("not initialized");
			return;
		}
		p->kcount += GLperiod;
		buf[p->left % MAX_FRAME_DELAY] = *p->kin;
		//++(p->left) %= MAX_FRAME_DELAY;
		++(p->left);

	}
}

extern "C" void GLgk_set(G_RATE *p)
{
	if (p->aux.auxp == NULL || (MAX_FRAME_DELAY*sizeof(MYFLT)) > p->aux.size) 
			auxalloc(MAX_FRAME_DELAY * sizeof(MYFLT), &p->aux);
	else {
		MYFLT *buf = (MYFLT *)p->aux.auxp;  
		for (int j =0; j< MAX_FRAME_DELAY; j++) {
			*buf++ = 0.0f;
		} 
	}
	p->flag =1 ;
	p->kcount = kcounter;
	p->framecount = 0;//FrameCounter;
	p->left =0;
	INIT_F (glgk)
}



/*

void glgk(G_RATE *p)              
{
	MYFLT *buf = (MYFLT *)p->aux.auxp;
	int index = p->framecount - frame_delay;
//	if (index < 0)	
//		index += MAX_FRAME_DELAY;
	while (index >= MAX_FRAME_DELAY) 
		index -= MAX_FRAME_DELAY;
	*p->kout = buf[index];
	double diff = FrameCounter - p->framecount;
	p->framecount += 1.0 + diff;
}	


extern "C" void GLgk(G_RATE *p)              
{
	if (kcounter > p->kcount + GLperiod) {
	    MYFLT *buf = (MYFLT *)p->aux.auxp;
		if (buf==NULL) {            
			initerror("not initialized");
			return;
		}
		p->kcount += GLperiod;
		buf[p->left] = *p->kin;
		if (++(p->left) == MAX_FRAME_DELAY) p->left = 0;
	}
}

extern "C" void GLgk_set(G_RATE *p)
{
	if (p->aux.auxp == NULL || (MAX_FRAME_DELAY*sizeof(MYFLT)) > p->aux.size) 
			auxalloc(MAX_FRAME_DELAY * sizeof(MYFLT), &p->aux);
	else {
		MYFLT *buf = (MYFLT *)p->aux.auxp;  
		for (int j =0; j< MAX_FRAME_DELAY; j++) {
			*buf++ = 0.0f;
		} 
	}
	p->kcount = kcounter;
	p->framecount = 0;//FrameCounter;
	p->left =0;
	INIT_F (glgk)
}

*/



/*-------------------------*/

extern "C" void GLsetFrameDelay(GL_SET_FDELAY *p)
{
	/*
	frame_delay = *p->delay;
	MAX_FRAME_DELAY = frame_delay *4;
	*/
	
	MAX_FRAME_DELAY = *p->delay;
	frame_delay = *p->delay/4;

}

/*-------------------------*/
extern "C" int ShowMacroDef = 0;
/*

extern "C" void showMacroDef(GL_ONEARG *p)
{
	ShowMacroDef = (int) *p->arg;
}
*/
/*-------------------------*/


void tab2grate(G_RATE_TAB *p)              
{
	MYFLT *buf = (MYFLT *)p->aux.auxp;
	int index = p->framecount - frame_delay;
//	while (index < 0)	
//		index += MAX_FRAME_DELAY;
	while (index >= MAX_FRAME_DELAY) 
		index -= MAX_FRAME_DELAY;

	long elem = p->elem;
	MYFLT *b = &buf[index * elem];
	MYFLT *tab = p->tab_out;

	do 	*tab++ = *b++;
	while (--elem);

	double diff = FrameCounter - p->framecount;
	p->framecount += 1.0 + diff;
}	


extern "C" void GLtab2grate(G_RATE_TAB *p)              
{
	if (kcounter > p->kcount + GLperiod) {
	    MYFLT *buf = (MYFLT *)p->aux.auxp;

		if (buf==NULL) {            
			initerror("not initialized");
			return;
		}

		p->kcount += GLperiod;
		
		long elem = p->elem;
		MYFLT *b = &buf[p->left * elem];
		MYFLT *tab = p->tab_in + p->start_ndx;
		
		do 	*b++ = *tab++;
		while (--elem);

		if (++(p->left) == MAX_FRAME_DELAY) p->left = 0;
	}
}

extern "C" void tab2grate_set(G_RATE_TAB *p)
{
    FUNC *ftp;
	long elem = p->elem = (long) *p->ielem;
    if ((ftp = ftfind(p->itab_in)) == NULL) return;
	if (ftp->flen < elem) initerror("tab2grate: invalid number of elements (input table is too short)");
    p->tab_in    = ftp->ftable;

	if ((ftp = ftfind(p->itab_out)) == NULL) return;
	if (ftp->flen < elem) initerror("tab2grate: invalid number of elements (output table is too short)");
    p->tab_out    = ftp->ftable;

	
	if (p->aux.auxp == NULL || (MAX_FRAME_DELAY*sizeof(MYFLT)*elem) > p->aux.size) 
			auxalloc(MAX_FRAME_DELAY * sizeof(MYFLT)*elem, &p->aux);
	else {
		MYFLT *buf = (MYFLT *)p->aux.auxp;  
		for (int j =0; j< MAX_FRAME_DELAY*elem; j++) {
			*buf++ = 0.0f;
		} 
	}
	p->kcount = kcounter;
	p->framecount = FrameCounter;
	p->left =0;
	p->start_ndx = *p->istart_ndx;
	INIT_F (tab2grate)
}


//----------------
#include <fstream.h>

/*
struct PICA_TRIANGLE {
	short x1,x2, y1,y2, z1,z2;
};

typedef vector<PICA_TRIANGLE> VEC_SHORT;
typedef vector<VEC_SHORT> PICASSO_OBJ;
vector <PICASSO_OBJ> v_picassoObj;

typedef struct	{
	OPDS	h;
	MYFLT *handle, *numObjects, *filename;
	//MYFLT *ftable
} LOAD_PICASSO;

typedef struct	{
	OPDS	h;
	MYFLT *handle,*inargs[VARGMAX];
	int numPieces, numTriangles[256], index;
} RENDER_PICASSO;

*/

/*
// Reduces a normal vector specified as a set of three coordinates,
// to a unit normal vector of length one.

inline void ReduceToUnit(MYFLT vector[3], short out[3])
{
	MYFLT length;
	length = (MYFLT)sqrt((vector[0]*vector[0]) + (vector[1]*vector[1]) +(vector[2]*vector[2]));
	if(length == 0.0f)	length = 1.0f;
	vector[0] /= length;
	vector[1] /= length;
	vector[2] /= length;
	out[0] = (short) (vector[0] * 32767);
	out[1] = (short) (vector[1] * 32767);
	out[2] = (short) (vector[2] * 32767);

}


// Points p1, p2, & p3 specified in counter clock-wise order
inline void calcNormal(MYFLT v[3][3], short out[3])
{
	MYFLT v1[3],v2[3], outf[3];
	static const int x = 0;
	static const int y = 1;
	static const int z = 2;

	v1[x] = v[0][x] - v[1][x];
	v1[y] = v[0][y] - v[1][y];
	v1[z] = v[0][z] - v[1][z];

	v2[x] = v[1][x] - v[2][x];
	v2[y] = v[1][y] - v[2][y];
	v2[z] = v[1][z] - v[2][z];

	outf[x] = v1[y]*v2[z] - v1[z]*v2[y];
	outf[y] = v1[z]*v2[x] - v1[x]*v2[z];
	outf[z] = v1[x]*v2[y] - v1[y]*v2[x];

	ReduceToUnit(outf, out);
}

*/


inline void ReduceToUnit(float vector[3])
	{
	float length;
	
	// Calculate the length of the vector		
	length = (float)sqrt((vector[0]*vector[0]) + 
						(vector[1]*vector[1]) +
						(vector[2]*vector[2]));

	// Keep the program from blowing up by providing an exceptable
	// value for vectors that may calculated too close to zero.
	if(length == 0.0f)
		length = 1.0f;

	// Dividing each element by the length will result in a
	// unit normal vector.
	vector[0] /= length;
	vector[1] /= length;
	vector[2] /= length;
	}


// Points p1, p2, & p3 specified in counter clock-wise order
inline void calcNormal(float v[3][3], float out[3])
	{
	float v1[3],v2[3];
	static const int x = 0;
	static const int y = 1;
	static const int z = 2;

	// Calculate two vectors from the three points
	v1[x] = v[0][x] - v[1][x];
	v1[y] = v[0][y] - v[1][y];
	v1[z] = v[0][z] - v[1][z];

	v2[x] = v[1][x] - v[2][x];
	v2[y] = v[1][y] - v[2][y];
	v2[z] = v[1][z] - v[2][z];

	// Take the cross product of the two vectors to get
	// the normal vector which will be stored in out
	out[x] = v1[y]*v2[z] - v1[z]*v2[y];
	out[y] = v1[z]*v2[x] - v1[x]*v2[z];
	out[z] = v1[x]*v2[y] - v1[y]*v2[x];

	// Normalize the vector (shorten length to one)
	ReduceToUnit(out);
	}

#define NUM_PICASSO_FIELDS 5

void renderPicasso(RENDER_PICASSO* p)
{
	int  index = p->index, j;
	if (index != (int) *p->handle) {
		index = p->index = (int) *p->handle;
		p->numPieces = v_picassoObj[index].size();
		for (j = 0; j< p->numPieces; j++) {
			p->numTriangles[j] = v_picassoObj[index][j].size();
		}
	}
	MYFLT inargs[VARGMAX];
	for (j = 0; j < (const int) p->INOCOUNT-2; j++)
	 		inargs[j] = *(p->inargs[j]);
	
	GLenum mode = (GLenum) *p->mode;
	if (mode >= 10) {
		mode -=10;
		for (j = 0; j < (const int) p->numPieces; j++) {
			int ndx = j * NUM_PICASSO_FIELDS;
			const int numtri = p->numTriangles[j];
			MYFLT scale = inargs[ndx];
			glColor4f(inargs[ndx+1], inargs[ndx+2], inargs[ndx+3],inargs[ndx+4]);
			PICA_TRIANGLE *triangle = &v_picassoObj[index][j][0];
			glBegin(mode);
			for(int k =0; k< numtri; k++) {
				glVertex3f(	triangle[k].x1 + scale *  triangle[k].x2,  
					triangle[k].y1 + scale *  triangle[k].y2,  
					triangle[k].z1 + scale *  triangle[k].z2);
			}
			glEnd();
		}
	}
	else {
		for (j = 0; j < (const int) p->numPieces; j++) {
			int ndx = j * NUM_PICASSO_FIELDS;
			const int numtri = p->numTriangles[j];
			MYFLT scale = inargs[ndx];
			glColor4f(inargs[ndx+1], inargs[ndx+2], inargs[ndx+3],inargs[ndx+4]);
			PICA_TRIANGLE *triangle = &v_picassoObj[index][j][0];
			glBegin(mode);
			int triCount = 0;
			for(int k =0; k< numtri; k++) {
				if (!triCount) glNormal3fv(triangle[k].normal);
				triCount++ ;
				triCount %= 3;
				glVertex3f(	triangle[k].x1 + scale *  triangle[k].x2,  
					triangle[k].y1 + scale *  triangle[k].y2,  
					triangle[k].z1 + scale *  triangle[k].z2);
			}
			glEnd();
		}
	}
}


extern "C" void GLrender_picasso(RENDER_PICASSO* p)
{
	int index = p->index = (int) *p->handle;
	p->numPieces = v_picassoObj[index].size();
	for (int j = 0; j< p->numPieces; j++) {
		p->numTriangles[j] = v_picassoObj[index][j].size();
	}

	INIT_F (renderPicasso)

}


extern "C" void GLload_picasso(LOAD_PICASSO* p)
{
	char     s[MAXNAME];
	string  filename;
	if (*p->filename == sstrcod) { // if char string name given 
		if (p->STRARG == NULL) strcpy(s,unquote(currevent->strarg));
		else strcpy(s, unquote(p->STRARG));
	} 
	else if ((long)*p->filename <= strsmax && strsets != NULL && strsets[(long)*p->filename])
		strcpy(s, strsets[(long)*p->filename]);
	else sprintf(s,"snap.%d", (int)*p->filename); 
		
	if (isfullpath(s) || imgdir_path == NULL)  
		filename = s;
	else 
		filename = catpath(imgdir_path, s);

	//char* s[MAXNAME] = GetString(*p->filename,p->STRARG);
	
	fstream file(filename.c_str(), ios::in);
	if (!file.is_open()) die("load_picasso: unable to open file");
	
	
	int j=0,k=0;

	PICA_TRIANGLE *pica, P;
	PICASSO_OBJ a;
	v_picassoObj.push_back(a);
	//int size_picObj;
	VEC_SHORT b;
	int index = v_picassoObj.size()-1;
	//size_picObj = v_picassoObj.size();
	v_picassoObj[index].push_back(b);

//	size_vecShort = v_picassoObj[size_picObj-1].size()-1;
	
	int triCount = 0;
	float v[3][3];

	while (!(file.eof())) {
		char buf[MAXNAME], *cp, *x1, *x2, *y1, *y2, *z1, *z2;
		int X1, X2, Y1;
		
		file.getline(buf,MAXNAME);
		if (*buf == '\0') continue; // empty line
		x1 = cp = buf;
		cp = strchr(cp, ' ');
		if (!cp) 
			die("load_picasso: invalid char");
		*cp++ = '\0';

		x2 = cp;
		cp = strchr(cp, ' ');
		if (!cp) 
			die("load_picasso: invalid char");
		*cp++ ='\0';

		y1 = cp;

		int flag = 0;
		X1 = atoi(x1); X2 = atoi(x2); Y1 = atoi(y1);
		if(X1 == X2 && X2 == X1 && X1 == -11111) {
			flag = 1;
			goto avanti;
		}

		cp = strchr(cp, ' ');
		if (!cp) 
			die("load_picasso: invalid char");
		*cp++ ='\0';

		

		y2 = cp;
		cp = strchr(cp, ' ');
		if (!cp) 
			die("load_picasso: invalid char");
		*cp++ ='\0';
		
		z1 = cp;
		cp = strchr(cp, ' ');
		if (!cp) 
			die("load_picasso: invalid char");
		*cp++ ='\0';

		z2 = cp;
		
		v_picassoObj[index][j].push_back(P);
		
		v_picassoObj[index][j][k].x1 = atoi(x1);
		v_picassoObj[index][j][k].x2 = atoi(x2);
		v_picassoObj[index][j][k].y1 = atoi(y1);
		v_picassoObj[index][j][k].y2 = atoi(y2);
		v_picassoObj[index][j][k].z1 = atoi(z1);
		v_picassoObj[index][j][k].z2 = atoi(z2);
		
		v[triCount][0] = v_picassoObj[index][j][k].x1 = atoi(x1);
		v_picassoObj[index][j][k].x2 = atoi(x2);
		v[triCount][1] = v_picassoObj[index][j][k].y1 = atoi(y1);
		v_picassoObj[index][j][k].y2 = atoi(y2);
		v[triCount][2] = v_picassoObj[index][j][k].z1 = atoi(z1);
		v_picassoObj[index][j][k].z2 = atoi(z2);
		
		triCount++;
		triCount %= 3;

		if (!triCount) {
			float out[3];
			calcNormal(v,out);
			memcpy (v_picassoObj[index][j][k-2].normal, out, 3 * sizeof(float));
			memcpy (v_picassoObj[index][j][k-1].normal, out, 3 * sizeof(float));
			memcpy (v_picassoObj[index][j][k  ].normal, out, 3 * sizeof(float));
		}

		pica = &(v_picassoObj[index][j][0]);
		
		k++;
avanti:		
		if (flag) {
			triCount = 0;
			v_picassoObj[index].push_back(b);
			j++;
			k=0;
		}
	}
	file.close();
	*p->handle = index;
	v_picassoObj[index].pop_back();
	*p->numObjects = v_picassoObj[index].size();
	
}



		/*		
		strstream sbuf;
		sbuf << buf;
		
		string opc, opc_orig;
		getline(sbuf, opc, ' ');
		const char *ss = opc.c_str();
		if (*ss == '-') { // if it is a separation line
			k++; j=0; 
			if (snapshots.size() < k+1)
			snapshots.resize(k+1);
		}
		else if (*ss != '\0' && *ss != ' ' && *ss != '\n'){ //ignore blank lines
			ADDR_SET_VALUE& v = AddrSetValue[j];
			if (snapshots[k].fields.size() < j+1)
				snapshots[k].fields.resize(j+1);
			snapshots[k].is_empty = 0;
			VALUATOR_FIELD& fld = snapshots[k].fields[j];
			opc_orig = ((OPDS *) (v.opcode))->optext->t.opcod;

			if (!(opc_orig == opc)) {
				initerror("unmatched widget, probably due to a modified orchestra. Modifying an orchestra makes it incompatible with old snapshot files");
				return;
			}
			if (opc == "FLjoy") {
				fld.opcode_name = opc;
				string s;
				getline(sbuf,s, ' ');  fld.value = atof(s.c_str());
				getline(sbuf,s, ' ');  fld.value2 = atof(s.c_str());
				getline(sbuf,s, ' ');  fld.min = atof(s.c_str());
				getline(sbuf,s, ' ');  fld.max = atof(s.c_str());
				getline(sbuf,s, ' ');  fld.min2 = atof(s.c_str());
				getline(sbuf,s, ' ');  fld.max2 = atof(s.c_str());
				getline(sbuf,s, ' ');  fld.exp = atoi(s.c_str()); 
				getline(sbuf,s, ' ');  fld.exp2 = atoi(s.c_str());
				getline(sbuf,s, '\"'); 
				getline(sbuf,s, '\"');  fld.widg_name = s;
			}
			else if (opc == "FLslidBnk") {
				fld.opcode_name = opc;
				string s;
				getline(sbuf,s, ' ');  fld.exp = atoi(s.c_str()); // EXCEPTIONAL CASE! fld.exp contains the number of sliders and not the exponential flag
				fld.sldbnkValues = new MYFLT[fld.exp];
				allocatedStrings.push_back((char *) fld.sldbnkValues);

				for (int k =0; k < fld.exp; k++) {
					getline(sbuf,s, ' ');  fld.sldbnkValues[k] = atof(s.c_str());

				}
				getline(sbuf,s, '\"'); 
				getline(sbuf,s, '\"');  fld.widg_name = s;
			}
			else {
				fld.opcode_name = opc;
				string s;
				getline(sbuf,s, ' ');  fld.value = atof(s.c_str()); 
				getline(sbuf,s, ' ');  fld.min = atof(s.c_str()); 
				getline(sbuf,s, ' ');  fld.max = atof(s.c_str()); 
				getline(sbuf,s, ' ');  fld.exp = atoi(s.c_str());
				getline(sbuf,s, '\"'); 
				getline(sbuf,s, '\"');  fld.widg_name = s;
			}
			j++;
		}
*/
