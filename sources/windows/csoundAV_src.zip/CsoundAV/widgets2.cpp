
//                      ######
//                  ##############
//            #########################
//       ######### WIDGET CALLBACKS #########
//            #########################
//                  ##############
//                      ######

inline void displ(MYFLT val, MYFLT index)
{
	if (index >= 0) {//display current value of valuator 
		char valString[MAXNAME]; 
		((Fl_Output*) (AddrSetValue[(long) index]).WidgAddress)->value(gcvt( val, 5, valString )); 
	}
}


static void fl_callbackButton(Fl_Button* w, void *a) 
{
	FLBUTTON *p = (FLBUTTON *) a;
	MYFLT val = *((FLBUTTON*) a)->kout =  (w->value()) ? *p->ion : *p->ioff;
	if (*p->args[0] >= 0) {
		if (*p->itype == 1 || *p->itype == 11 || w->value())
			ButtonSched(p->args, p->INOCOUNT-8);
	}
}	

static void fl_callbackButtonBank(Fl_Button* w, void *a) 
{
	FLBUTTONBANK *p = (FLBUTTONBANK *) a;
	MYFLT val = *((FLBUTTONBANK*) a)->kout = (MYFLT) atoi(w->label());
	if (*p->args[0] >= 0) ButtonSched(p->args, p->INOCOUNT-7);
}	


static void fl_callbackCounter(Fl_Counter* w, void *a) 
{
	FLCOUNTER *p = (FLCOUNTER *) a;
	MYFLT val = *((FLCOUNTER*) a)->kout =  w->value();
	if (*p->args[0] >= 0) ButtonSched(p->args, p->INOCOUNT-10);
}	

static void fl_callbackLinearSlider(Fl_Valuator* w, void *a) 
{
	FLSLIDER *p = ((FLSLIDER*) a);
	displ(*p->kout = w->value(), *p->idisp);
}	

static void fl_callbackExponentialSlider(Fl_Valuator* w, void *a) 
{
	FLSLIDER *p = ((FLSLIDER*) a);
	displ(*p->kout = p->min * pow (p->base, w->value()), *p->idisp);
}



static void fl_callbackInterpTableSlider(Fl_Valuator* w, void *a) 
{
	FLSLIDER *p = ((FLSLIDER*) a);
	MYFLT ndx = w->value() * (p->tablen-1);
	int index = (long) ndx;
	MYFLT v1 = p->table[index];
	displ(*p->kout = p->min+ ( v1 + (p->table[index+1] - v1) * (ndx - index)) * (*p->imax - p->min), *p->idisp);
}


static void fl_callbackTableSlider(Fl_Valuator* w, void *a) 
{
	FLSLIDER *p = ((FLSLIDER*) a);
	displ(*p->kout = p->min+ p->table[(long) (w->value() * p->tablen)] * (*p->imax - p->min), *p->idisp);
}

//************************************************************

static void fl_callbackLinearSliderBank(Fl_Valuator* w, void *a) 
{
	SLDBK_ELEMENT* p = (SLDBK_ELEMENT*) a;
	*p->out = w->value();
}	

static void fl_callbackExponentialSliderBank(Fl_Valuator* w, void *a) 
{
	SLDBK_ELEMENT* p = (SLDBK_ELEMENT*) a;
	*p->out = p->min * pow (p->base, w->value());
}



static void fl_callbackInterpTableSliderBank(Fl_Valuator* w, void *a) 
{
	SLDBK_ELEMENT *p = ((SLDBK_ELEMENT*) a);
	
	MYFLT ndx = w->value() * (p->tablen-1);
	int index = (long) ndx;
	MYFLT v1 = p->table[index];
	*p->out = p->min+ ( v1 + (p->table[index+1] - v1) * (ndx - index)) * (p->max - p->min);
}


static void fl_callbackTableSliderBank(Fl_Valuator* w, void *a) 
{
	SLDBK_ELEMENT *p = ((SLDBK_ELEMENT*) a);
	*p->out = p->min+ p->table[(long) (w->value() * p->tablen)] * (p->max - p->min);
}


//************************************************************

static void fl_callbackJoystick(Fl_Widget* w, void *a) 
{
	FLJOYSTICK *p = (FLJOYSTICK*) a;
	Fl_Positioner *j = (Fl_Positioner*) w;
	MYFLT val;
	int iexpx = *p->iexpx, iexpy = *p->iexpy;
	switch (iexpx) {
		case LIN_: 
			val = j->xvalue();
			break;	
		case EXP_:
			val = *p->iminx * pow (p->basex, j->xvalue());
			break;
		default:
			if (iexpx > 0) { //interpolated
				MYFLT ndx = j->xvalue() * (p->tablenx-1);
				int index = (long) ndx;
				MYFLT v1 = p->tablex[index];
				val = *p->iminx + ( v1 + (p->tablex[index+1] - v1) * (ndx - index)) * (*p->imaxx - *p->iminx);
			}
			else // non-interpolated
				val = *p->iminx+ p->tablex[(long) (j->xvalue() * p->tablenx)] * (*p->imaxx - *p->iminx);
	}
	displ(*p->koutx = val,*p->idispx);
	switch (iexpy) {
		case LIN_: 
			val = j->yvalue();
			break;	
		case EXP_:
			val = *p->iminy * pow (p->basey, j->yvalue());
			break;
		default:
			if (iexpy > 0) { //interpolated
				MYFLT ndx = j->yvalue() * (p->tableny-1);
				long index = (long) ndx;
				MYFLT v1 = p->tabley[index];
				val = *p->iminy + ( v1 + (p->tabley[index+1] - v1) * (ndx - index)) * (*p->imaxy - *p->iminy);
			}
			else { // non-interpolated
				MYFLT g = j->yvalue();
				long index = (long) (j->yvalue()* p->tableny);
				val = *p->iminy+ p->tabley[index] * (*p->imaxy - *p->iminy);
			
			}
	}
	displ(*p->kouty = val, *p->idispy);
}	

static void fl_callbackLinearRoller(Fl_Valuator* w, void *a) 
{
	FLROLLER *p = ((FLROLLER*) a);
	displ(*p->kout =  w->value(),*p->idisp);
}


static void fl_callbackExponentialRoller(Fl_Valuator* w, void *a) 
{
	FLROLLER *p = ((FLROLLER*) a);
	displ(*p->kout = ((FLROLLER*) a)->min * pow (p->base, w->value()), *p->idisp);
}


static void fl_callbackInterpTableRoller(Fl_Valuator* w, void *a) 
{
	FLROLLER *p = ((FLROLLER*) a);
	MYFLT ndx = w->value() * (p->tablen-1);
	int index = (long) ndx;
	MYFLT v1 = p->table[index];
	displ(*p->kout = p->min+ ( v1 + (p->table[index+1] - v1) * (ndx - index)) * (*p->imax - p->min), *p->idisp);
}


static void fl_callbackTableRoller(Fl_Valuator* w, void *a) 
{
	FLROLLER *p = ((FLROLLER*) a);
	displ(*p->kout = p->min+ p->table[(long) (w->value() * p->tablen)] * (*p->imax - p->min), *p->idisp);
}


static void fl_callbackLinearKnob(Fl_Valuator* w, void *a) 
{
	FLKNOB *p = ((FLKNOB*) a);
	displ( *p->kout = w->value(), *p->idisp);
}


static void fl_callbackExponentialKnob(Fl_Valuator* w, void *a) 
{
	FLKNOB *p = ((FLKNOB*) a);
	displ( *p->kout = ((FLKNOB*) a)->min * pow (p->base, w->value()), *p->idisp);
}


static void fl_callbackInterpTableKnob(Fl_Valuator* w, void *a) 
{
	FLKNOB *p = ((FLKNOB*) a);
	MYFLT ndx = w->value() * (p->tablen-1);
	int index = (long) ndx;
	MYFLT v1 = p->table[index];
	displ(*p->kout = p->min+ ( v1 + (p->table[index+1] - v1) * (ndx - index)) * (*p->imax - p->min), *p->idisp);
}


static void fl_callbackTableKnob(Fl_Valuator* w, void *a) 
{
	FLKNOB *p = ((FLKNOB*) a);
	displ(*p->kout = p->min+ p->table[(long) (w->value() * p->tablen)] * (*p->imax - p->min), *p->idisp);
}


static void fl_callbackLinearValueInput(Fl_Valuator* w, void *a) 
{
	*((FLTEXT*) a)->kout =  w->value();
}

//                          #### 
//                       ##########
//                    ################
// ----------------######## RUN #########------------------
//                    ################
//                       ##########
//                          #### 

#ifdef WIN32 
extern int Frame_thread_exit;

#endif



static void __cdecl fltkRun(void *s)
{
	int j;
	for (j=0; j < fl_windows.size(); j++) {
		fl_windows[j].panel->show();
	}


#ifdef WIN32 // to make this thread to update GUI when no events are present
	SetTimer(0,0,400,NULL);
	if (j > 0)
		callback_target = fl_xid(fl_windows[0].panel);
	wait_run = 1;
#endif

	Fl::run();

#ifdef WIN32 
	extern MMRESULT FL_TimId;

	if (FL_TimId != NULL) {
		timeKillEvent( FL_TimId );
		Sleep(100);
		FL_TimId = NULL;
	}
	callback_target = 0;	
	Frame_thread_exit =1;
#endif
	printf("\nWARNING: end of widget thread\n");
}
/*
static void __cdecl fltkKeybRun(void *s)
{
	oKeyb->show();
	//Fl::run();
	
	while(Fl::wait()) {
		int temp = FLkeyboard_sensing();
		if (temp != 0 && *keybp->args[1] >=1 ) { 
			*keybp->kout = temp;
			ButtonSched(keybp->args, keybp->INOCOUNT);
		}

	}
	warning("end of keyboard thread\n");
}
*/
extern "C" void FL_run(FLRUN *p)
{
	if (flruns) {
		initerror("FLrun must not be called more than once\n");
	}
	flruns++;
#ifdef _WINDOWS
  threadHandle = _beginthread(fltkRun, 0, NULL);
  
  while (wait_run) Sleep(30);
/*
  if (isActivatedKeyb) 
	  threadHandle = _beginthread(fltkKeybRun, 0, NULL);
*/
#elif defined( LINUX ) || defined(someotherUNIXes)
  // create a new thread in the proper way here
  pthread_t thread1;
  threadHandle = pthread_create(&thread1, (pthread_attr_t *) NULL,
  				(void *(*)(void *)) fltkRun, NULL);
#endif
}

extern "C" void fl_update(FLRUN *p)
{
	for(int j=0; j< AddrSetValue.size()-1; j++) {
		ADDR_SET_VALUE v = AddrSetValue[j];
		Fl_Valuator *o = (Fl_Valuator *) v.WidgAddress;
		o->do_callback(o, v.opcode);
	}
}
