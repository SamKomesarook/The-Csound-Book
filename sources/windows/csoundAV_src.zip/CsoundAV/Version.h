# define VERSION (4)
# define SUBVER  (17)
# define VERSIONSTRING  " v4.17"
# define PVERSION "\p                                               Csound 4.17"
# define CSOUNDAV_VERSION "0.01"

