typedef struct {
	OPDS	h;
	MYFLT	*ipoints, *iminfreq, *imaxfreq;
	SPECDAT *wsig;
} SPECINFO;

typedef struct {
	OPDS	h;
	SPECDAT *wsig;
	MYFLT	*ifnout, *kfilter, *istartoffset, *inumelem;
	long	count;
	MYFLT	*table, *sourcedata;
	AUXCH	filterStuff;
	MYFLT	c1, c2, *yt1, prvhp;

} SPEC2TABLE;

