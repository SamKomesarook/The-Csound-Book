#include "widg.h"

SNAPSHOT::SNAPSHOT (vector<ADDR_SET_VALUE>& valuators)
{ // the constructor captures current values of all widgets by copying all current
  //  values from "valuators" vector (AddrSetValue) to the "fields" vector	
	is_empty =0;

	for ( int i=0; i < valuators.size(); i++) {
			string  opcode_name, widg_name;
			ADDR_SET_VALUE& v  = valuators[i];
			if (fields.size() < i+1) 
				fields.resize(i+1);
			VALUATOR_FIELD& fld = fields[i];
			float val, min, max;
			opcode_name = fld.opcode_name = ((OPDS *) (v.opcode))->optext->t.opcod;
			FLlock(); //<=================
			if (opcode_name == "FLslider") {
				FLSLIDER *p = (FLSLIDER *) (v.opcode);
				fld.widg_name = GetString(*p->name, p->STRARG);
				fld.exp = (int) *p->iexp;
				min = fld.min = *p->imin; max = fld.max = *p->imax;
				switch (fld.exp) {
					case LIN_: case EXP_: val = *p->kout; 
						if (val < min) val=min;
						else if(val>max) val=max;
						break;
					default: val = ((Fl_Valuator *)v.WidgAddress)->value();
				}
				fld.value = val; 
			} else if (opcode_name == "FLknob") {
				FLKNOB *p = (FLKNOB *) (v.opcode);
				fld.widg_name = GetString(*p->name, p->STRARG);
				fld.exp = (int) *p->iexp;
				min = fld.min = *p->imin; max = fld.max = *p->imax;
				switch (fld.exp) {
					case LIN_: case EXP_: 
						val = *p->kout; 
						if (val < min) val=min;
						else if(val>max) val=max;
						break;
					default: val = ((Fl_Valuator *)v.WidgAddress)->value();
				}
				fld.value = val; 
			} else if (opcode_name == "FLroller") {
				FLROLLER *p = (FLROLLER *) (v.opcode);
				fld.widg_name = GetString(*p->name, p->STRARG);
				fld.exp = (int) *p->iexp;
				min = fld.min = *p->imin; max = fld.max = *p->imax;
				switch (fld.exp) {
					case LIN_: case EXP_: 
						val = *p->kout;
						if (val < min) val=min;
						else if(val>max) val=max;
						break;
					default: val = ((Fl_Valuator *)v.WidgAddress)->value();
				}
				fld.value = val; 
			} else if (opcode_name == "FLtext") {
				FLTEXT *p = (FLTEXT *) (v.opcode);
				fld.widg_name = GetString(*p->name, p->STRARG);
				val = *p->kout; min = fld.min = *p->imin; max = fld.max = *p->imax;
				if (val < min) val=min;
				else if(val>max) val=max;
				fld.value = val; 
				fld.exp = LIN_;
			} else if (opcode_name == "FLjoy") {
				FLJOYSTICK *p = (FLJOYSTICK *) (v.opcode);
				fld.widg_name = GetString(*p->name, p->STRARG);
				
				fld.exp  = (int) *p->iexpx;
				min = fld.min = *p->iminx; max = fld.max = *p->imaxx;
				switch (fld.exp) {
					case LIN_: case EXP_: 
						val = *p->koutx;
						if (val < min) val=min;
						else if(val>max) val=max;
						break;
					default: val = ((Fl_Positioner *)v.WidgAddress)->xvalue();
				}
				fld.value = val;
				
				fld.exp2 = (int) *p->iexpy;
				min = fld.min2 = *p->iminy; max = fld.max2 = *p->imaxy;
				switch (fld.exp2) {
					case LIN_: case EXP_: 
						val = *p->kouty;
						if (val < min) val=min;
						else if(val>max) val=max;
						break;
					default: val = ((Fl_Positioner *)v.WidgAddress)->yvalue();
				}
				fld.value2 =val;

			} else if (opcode_name == "FLslidBnk") {
				FLSLIDERBANK *p = (FLSLIDERBANK *) (v.opcode);
				fld.widg_name = GetString(*p->names, p->STRARG);
				int numsliders = (int) *p->inumsliders;
				fld.sldbnk = p->slider_data;
				fld.sldbnkValues = new MYFLT[numsliders];
				extern vector<char*> allocatedStrings;
				allocatedStrings.push_back((char *) fld.sldbnkValues);
				fld.exp = numsliders; // EXCEPTIONAL CASE! fld.exp contains the number of sliders and not the exponential flag
				for (int j =0; j < numsliders; j++) {
					switch (fld.sldbnk[j].exp) {
						case LIN_: case EXP_:
							val = *fld.sldbnk[j].out;
							min = fld.sldbnk[j].min; max = fld.sldbnk[j].max;
							if (val < min) val = min;
							if (val > max) val = max;
							break;
						default:
							val = ((Fl_Valuator *) ((Fl_Group*) v.WidgAddress)->child(j))->value();
					}
					fld.sldbnkValues[j]= val;
				}
			} else if (opcode_name == "FLbutton") {
				FLBUTTON *p = (FLBUTTON *) (v.opcode);
				fld.widg_name = GetString(*p->name, p->STRARG);
				fld.value = *p->kout;
				int children = ((Fl_Group*) v.WidgAddress)->children();
				fld.min = 0; fld.max = children-1; fld.exp = LIN_;
			} else if (opcode_name == "FLbutBank") {
				FLBUTTONBANK *p = (FLBUTTONBANK *) (v.opcode);
				fld.widg_name = "No name for FLbutbank";
				//fld.widg_name = GetString(*p->name, p->STRARG);
				fld.value = *p->kout;
				fld.min = 0; fld.max = 1; fld.exp = LIN_;
			} else if (opcode_name == "FLcount") {
				FLCOUNTER *p = (FLCOUNTER *) (v.opcode);
				fld.widg_name = GetString(*p->name, p->STRARG);
				val = *p->kout; min = *p->imin; max =*p->imax;
				if (min != max) {
					if (val < min) val=min;
					else if(val>max) val=max;
				}
				fld.value = val; 
				fld.min = *p->imin; fld.max = *p->imax; fld.exp = LIN_;
			} else if (opcode_name == "FLvalue") {
				FLVALUE *p = (FLVALUE *) (v.opcode);
				fld.widg_name = GetString(*p->name, p->STRARG);
			}
			else if (opcode_name == "FLbox") {
				FL_BOX *p = (FL_BOX *) (v.opcode);
				fld.widg_name = GetString(*p->itext, p->STRARG);
			}
			FLunlock(); //<=================
	}
}



void SNAPSHOT::get(vector<ADDR_SET_VALUE>& valuators) 
{  
	if(is_empty) {
		initerror("empty snapshot");
		return;
	}

	for (int j =0; j< valuators.size(); j++) {
		Fl_Widget* o = (Fl_Widget*) (valuators[j].WidgAddress);
		void *opcode = valuators[j].opcode;
		VALUATOR_FIELD& fld = fields[j];
		string opcode_name = fld.opcode_name;
		
		MYFLT val = fld.value, min=fld.min, max=fld.max, range,base;
		if (val < min) val =min;
		else if (val >max) val = max;
		FLlock(); //<=================
		if (opcode_name == "FLjoy") {
			switch(fld.exp) {
				case LIN_:	((Fl_Positioner*) o)->xvalue(val); 
					break;
				case EXP_:	
					range  = fld.max - fld.min;
					base = pow(fld.max / fld.min, 1/range);
					((Fl_Positioner*) o)->xvalue(log(val/fld.min) / log(base)) ;
					break;
				default:
					((Fl_Positioner*) o)->xvalue(val); 
					//warning("not implemented yet");
					break;
			}
			val = fld.value2; min = fld.min2; max = fld.max2;
			if (val < min) val =min;
			else if (val >max) val = max;
			switch(fld.exp2) {
				case LIN_:	((Fl_Positioner*) o)->yvalue(val); 
					break;
				case EXP_:	
					range  = fld.max2 - fld.min2;
					base = pow(fld.max2 / fld.min2, 1/range);
					((Fl_Positioner*) o)->yvalue(log(val/fld.min2) / log(base)) ;
					break;
				default:
					((Fl_Positioner*) o)->yvalue(val); 
					//warning("not implemented yet");
					break;
			}
			o->do_callback(o, opcode); 
		}
		else if (opcode_name == "FLbutton") {
			FLBUTTON *p = (FLBUTTON*) (opcode);
			if (*p->itype < 10) {//  don't allow to retreive its value if >= 10
				((Fl_Button*) o)->value(fld.value);
				o->do_callback(o, opcode); 
			}
		}
		else if (opcode_name == "FLbutBank") {
			FLBUTTONBANK *p = (FLBUTTONBANK*) (opcode);
			if (*p->itype < 10) {//  don't allow to retreive its value if >= 10
				//((Fl_Group*) o)->value(fld.value);
				set_butbank_value((Fl_Group*) o, fld.value);
				//o->do_callback(o, opcode); 
				*p->kout=fld.value;

			}
		}
		else if (opcode_name == "FLcount") {
			FLCOUNTER *p = (FLCOUNTER*) (opcode);
			if (*p->itype < 10) { //  don't allow to retreive its value if >= 10
				((Fl_Counter*) o)->value(fld.value);
				o->do_callback(o, opcode); 
			}
		}
		else if (opcode_name == "FLslidBnk") {
			FLSLIDERBANK *p = (FLSLIDERBANK*) (opcode);
			int numsliders = (int) *p->inumsliders;
			Fl_Group * grup = (Fl_Group *) o;
			for (int j =0; j < numsliders; j++) {
				MYFLT val = fld.sldbnkValues[j];
				switch (p->slider_data[j].exp) {
					case LIN_:
						((Fl_Valuator *) grup->child(j))->value(val);
						break;
					case EXP_:
						range  = p->slider_data[j].max - p->slider_data[j].min;
						base = pow(p->slider_data[j].max / p->slider_data[j].min, 1/range);
						((Fl_Valuator*) grup->child(j))->value(log(val/p->slider_data[j].min) / log(base)) ;
						break;
					default:
						((Fl_Valuator *) grup->child(j))->value(val);
						//warning("not implemented yet (bogus)");
						break;
				}
				grup->child(j)->do_callback( grup->child(j), (void *) &(p->slider_data[j])); 
			}
		}
		else {
			switch(fld.exp) {
				case LIN_:	
					if (opcode_name == "FLbox" || opcode_name == "FLvalue" ) continue;
					((Fl_Valuator*) o)->value(val); 
					break;
				case EXP_:	
					range  = fld.max - fld.min;
					base = pow(fld.max / fld.min, 1/range);
					((Fl_Valuator*) o)->value(log(val/fld.min) / log(base)) ;
					break;
				default:
					((Fl_Valuator*) o)->value(val);
					//warning("not implemented yet (bogus)");
					break;
			}
			o->do_callback(o, opcode); 
		}

		FLunlock(); //<=================
	}
	//Fl::check();
}



