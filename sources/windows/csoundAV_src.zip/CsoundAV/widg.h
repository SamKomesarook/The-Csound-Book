#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#if defined (_WIN32)
#	pragma warning(disable: 985 4786 4117 4804 985)
#	include <process.h>
#	include <windows.h>

#endif /* defined(_WIN32) */

#include "GL/gl.h"
#include <alloc.h>
#include <vector>
#include <map>
#include <string>
#include <list>
#include <fstream.h>  //or <fstream> according to compiler
#include <strstrea.h> //or <strstream> according to compiler

using namespace std;

#if defined(LINUX)
#	include <pthread.h>
#	include "../config.h"
#endif /* defined(LINUX) */

#include <FL/Fl.H>
#include <FL/x.H>
#include <FL/Fl_Window.H>
#include <FL/Fl_Gl_Window.H>
#include <FL/Fl_Box.H>
#include <FL/Fl_Slider.H>
#include <FL/Fl_Value_Slider.H>
#include <FL/Fl_Adjuster.H>
#include <FL/Fl_Counter.H>
#include <FL/Fl_Dial.H>
#include <FL/Fl_Roller.H>
#include <FL/Fl_Value_Input.H>
#include <FL/Fl_Value_Output.H>
#include <FL/Fl_Scrollbar.H>
#include <FL/Fl_Scrollbar.H>
#include <FL/fl_draw.H>
#include <FL/Fl_Output.H>
#include <FL/Fl_Scroll.H>
#include <FL/Fl_Pack.H>
#include <FL/Fl_Tabs.H>
#include <FL/Fl_Positioner.H>
#include <FL/Fl_Button.H>
#include <FL/Fl_Light_Button.H>
#include <FL/Fl_Check_Button.H>
#include <FL/Fl_Round_Button.H>
#include <FL/Fl_Overlay_Window.H>
#include <FL/Fl_Image.H>
#include <FL/Fl_Tiled_Image.H>
#include "FL/Fl_Knob.H"
#include "FL/Fl_flews.H"


#include "stdpch.h"
#include "anydec.h"
#include "anybmp.h"
using namespace std ;

#define LIN_ 0
#define EXP_ -1
#undef min
#undef max


extern "C" {
	#undef __cplusplus
	#include "cs.h"
	#include "image.h"
	#include "widgets.h"
	#include "oload.h"
	#define __cplusplus
    extern EVTBLK *currevent; 
	extern char *unquote(char *name);
#if defined (_WIN32)
#	include <windows.h>
#	include "win_specific/resource.h" 
	extern "C" HINSTANCE hProcessInstance;
#endif

}
#include "imagestruct.h"


#undef exit

struct PANELS {
	Fl_Window *panel;
	int	is_subwindow;
	PANELS(Fl_Window *new_panel, int flag) : panel(new_panel), is_subwindow(flag){}
	PANELS() {panel = NULL; is_subwindow=0;	}
};

struct ADDR {
	void *opcode;
	void *WidgAddress;
};

struct ADDR_STACK {
	OPDS *h;
	void *WidgAddress;
	int	count;
	ADDR_STACK(OPDS *new_h,void *new_address,  int new_count) : h(new_h),WidgAddress(new_address), count(new_count) {}
	ADDR_STACK() { h=NULL; WidgAddress = NULL;	count=0; }
};

struct ADDR_SET_VALUE {
	int exponential;
	MYFLT min,max;
	void  *WidgAddress,  *opcode;
	ADDR_SET_VALUE(int new_exponential,MYFLT new_min, MYFLT new_max, void *new_WidgAddress, void *new_opcode) :
		exponential(new_exponential),min(new_min), max(new_max),WidgAddress(new_WidgAddress),opcode(new_opcode)	{}
	ADDR_SET_VALUE() { exponential=LIN_; min=0; max=0; WidgAddress=0; opcode=0; }
};

struct VALUATOR_FIELD {
	MYFLT value, value2;
	MYFLT min,max, min2,max2;
	int	exp, exp2;
	string widg_name;
	string opcode_name;
	SLDBK_ELEMENT *sldbnk;
	MYFLT	*sldbnkValues;
	VALUATOR_FIELD() {  value = 0; value2 =0; widg_name= ""; opcode_name =""; 
		min = 0; max =1; min2=0; max2=1; exp=LIN_; exp2=LIN_; sldbnk=0; sldbnkValues=0; }
//	~VALUATOR_FIELD() { if (sldbnk != 0) delete sldbnk; 
//		if (sldbnkValues !=0) delete sldbnkValues; }
};



struct SNAPSHOT {
	int is_empty;
	vector<VALUATOR_FIELD> fields;
	SNAPSHOT(vector<ADDR_SET_VALUE>& valuators);
	SNAPSHOT() { is_empty = 1; }
	void get(vector<ADDR_SET_VALUE>& valuators);
};


class overlay_BOX : public Fl_Box{
	int rx,ry,rw,rh;
	int red, green, blue;

public:
	overlay_BOX(int x, int y, int w, int h, const char *l=0) : Fl_Box(x,y,w,h,l) {
		red = 250; green =0; blue=0;
		rx=-1;
		void draw();
	}
	void  draw() {
		Fl_Box::draw();
		if (rx >=0) {
			fl_color(red,green,blue);
			fl_rect(rx+x(),ry+y(),rw,rh);
		}
	}
	void set_rect (int newrx, int newry, int newrw, int newrh) {
		rx = newrx; ry=newry; rw=newrw; rh=newrh;
		redraw();
	}
	void set_color (int newred, int newgreen, int newblue){
		red=newred; blue=newblue; green=newgreen;
	}
};


inline void set_butbank_value (Fl_Group *o, MYFLT value)
{
	int childr = o->children();
	Fl_Button *b;
	MYFLT label;
	int j;
	for (j=0; j< childr; j++) {
		b = (Fl_Button *) o->child(j);
		b->value(0); //deactivate all buttons
	}
	for (j=0; j< childr; j++) {
		b = (Fl_Button *) o->child(j);
		label = atof(b->label());
		if (label == value)
			b->value(1);
	}
}



char * GetString(MYFLT pname, char *t);
Fl_Window * FLkeyboard_init();
int FLkeyboard_sensing();

extern "C" void ButtonSched(MYFLT  *args[], int numargs);
extern "C" void deact(INSDS *ip);

extern int wait_run; // blocks Audio Thread until Widget Thread is running

inline void FLlock() {
	/*
	if (wait_run) {
		Fl::lock();
	}
	*/
	
}

extern HWND callback_target;

inline void FLunlock() {
	/*
	if(wait_run) {
		Fl::unlock();
#ifdef WIN32
		if (callback_target)
			PostMessage(callback_target,0,0,0); //bogus message to make thread to react
#else
		Fl::awake((void*) 1);
#endif
	}
*/
	PostMessage(callback_target,0,0,0); //bogus message to make thread to react
}
