#ifndef BYTE
#	define BYTE unsigned char
#endif


typedef struct	{
	OPDS	h;
	MYFLT	 *ioutHandle, *trig, *m_range, *kmatrix_fn, *ihandle; 
	int width, height, depth;
	void *pixels_in, *pixels_out;
	int old_matrix_fn, m_cols, m_rows;
	MYFLT *m_matrix;
} IMG_CONVOLVE;

typedef struct	{
	OPDS	h;
	MYFLT	*outTrig, *ioutHandle, *trig, *red, *green, *blue, *alpha, *ihandle, *iprocessing_time;
	int width, height, depth;
	void *pixels_in, *pixels_out;
	int pix_per_kcycle, isNotFinished;
	long datasize, pix_done;
} IMG_GAIN;

typedef struct	{
	OPDS	h;
	MYFLT	*trig,  *x, *y,   *r,*g,*b,*a, *imageHandle;
	void *pixels;
	int width, height, totSize;
} IMG_SETPIXEL;
