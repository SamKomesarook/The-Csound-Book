#ifndef _FL_flews_H_
#define _FL_flews_H_
#include <FL/Fl.H>
#include <FL/Fl_Value_Input_Spin.H>
#include <FL/Fl_Value_Slider_Input.H>
#include <FL/Fl_Spin.H>
#include <FL/Fl_Ball.H>
#endif
