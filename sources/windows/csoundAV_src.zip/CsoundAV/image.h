#ifndef BYTE
#	define BYTE unsigned char
#endif


typedef struct	{
	OPDS	h;
	MYFLT	*iwidth, *iheight, *ibpp; //outputs
	MYFLT   *ifilno, *ihandle, *iflag; //inputs
} BMOPEN;

typedef struct	{
	OPDS	h;
	MYFLT	*iwidth, *iheight, *ibpp, *ihandle, *r, *g, *b, *a;
} BMCREATE;


typedef struct	{
	OPDS	h;
	MYFLT	*kr, *kg, *kb, *ka; //outputs
	MYFLT   *kx, *ky, *ihandle; //inputs
	BYTE  ** LineArray;
	int height;
} BMTABLE;

typedef struct	{
	OPDS	h;
	MYFLT	*kr, *kg, *kb, *ka; //outputs
	MYFLT   *ktrig, *kxinc, *kyinc, *ktrig_xphreset, *ktrig_yphreset, *kxphs, *kyphs, *ihandle; //inputs
	BYTE  ** LineArray;
	int width, height;
	MYFLT Xphase, Yphase;
	int flag;
} BMOSCIL;


typedef struct	{
	OPDS	h;
	MYFLT	*hue, *sat, *val, *lum; //outputs
	MYFLT   *r, *g, *b; //inputs
} RGB2HSVL;

typedef struct	{
	OPDS	h;
	MYFLT	*kphs, *ihorLines, *ihandle, *istartLine, *ifnR, *ifnG, *ifnB;
	BYTE  ** LineArray;
	int width, height;
	int flag;
	MYFLT *ftpLines,*ftpR,*ftpG,*ftpB;
} BMSCAN;



