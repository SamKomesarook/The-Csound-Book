#include "cs.h"
#include <math.h>
#include "newopcodes.h"
/*-------------- START Gab --------------------------------------------*/ /* gab d5*/

void krsnsetx(KRESONX *p) /* Gabriel Maldonado, modifies for arb order */
{
    int scale;
    p->scale = scale = (int) *p->iscl;
    if((p->loop = (int) (*p->ord + .5)) < 1) p->loop = 4; /*default value*/
    if (!*p->istor && (p->aux.auxp == NULL ||
                      (int)(p->loop*2*sizeof(MYFLT)) > p->aux.size))
      auxalloc((long)(p->loop*2*sizeof(MYFLT)), &p->aux);
    p->yt1 = (MYFLT*)p->aux.auxp; p->yt2 = (MYFLT*)p->aux.auxp + p->loop;
    if (scale && scale != 1 && scale != 2) {
      sprintf(errmsg,"illegal reson iscl value, %f",*p->iscl);
      initerror(errmsg);
    }
    p->prvcf = p->prvbw = -100.0f;

    if (!(*p->istor)) {
      int j;
      for (j=0; j< p->loop; j++) p->yt1[j] = p->yt2[j] = 0.0f;
    }
}

void kresonx(KRESONX *p) /* Gabriel Maldonado, modified  */
{
    int	flag = 0, j;
    MYFLT	*ar, *asig;
    MYFLT	c3p1, c3t4, omc3, c2sqr;
    MYFLT *yt1, *yt2, c1,c2,c3; 
	
    if (*p->kcf != p->prvcf) {
		p->prvcf = *p->kcf;
		p->cosf = (MYFLT) cos((double)(*p->kcf * tpidsr * ksmps));
		flag = 1;
    }
    if (*p->kbw != p->prvbw) {
		p->prvbw = *p->kbw;
		p->c3 = (MYFLT) exp((double)(*p->kbw * mtpdsr * ksmps));
		flag = 1;
    }
    if (flag) {
		c3p1 = p->c3 + 1.0f;
		c3t4 = p->c3 * 4.0f;
		omc3 = 1.0f - p->c3;
		p->c2 = c3t4 * p->cosf / c3p1;		/* -B, so + below */
		c2sqr = p->c2 * p->c2;
		if (p->scale == 1)
			p->c1 = omc3 * (MYFLT)sqrt(1.0 - (double)(c2sqr / c3t4));
		else if (p->scale == 2)
			p->c1 = (MYFLT)sqrt((double)((c3p1*c3p1-c2sqr) * omc3/c3p1));
		else p->c1 = 1.0f;
    }
    c1=p->c1; 
    c2=p->c2;
    c3=p->c3;
    yt1= p->yt1;
    yt2= p->yt2;
    asig = p->asig;
	ar = p->ar;
    for (j=0; j< p->loop; j++) {
		*ar = c1 * *asig + c2 * *yt1 - c3 * *yt2;
		*yt2 = *yt1;
		*yt1 = *ar;
		yt1++;
		yt2++;
		asig= p->ar;
    }
}

/*-------------- END Gab --------------------------------------------*/ /* gab d5*/





/*//////////////////////////////////////////*/

/*--------------------------------*/
//#define FZERO	FL(0.0)
//#define FONE	FL(1.0)

void metro_set(METRO *p)
{
    double	phs = *p->iphs;
    long  longphs;
	
	if (phs >= 0.0) {
		if ((longphs = (long)phs))
			warning("metro:init phase truncation");
		p->curphs = phs - (MYFLT)longphs;
	}
	p->flag=1;
}


void metro(METRO *p)
{
    double	phs= p->curphs;
	if(phs == 0.0 && p->flag) {
		*p->sr = FL(1.0);
		p->flag = 0;
	}
	else if ((phs += *p->xcps * onedkr) >= 1.0) {
		*p->sr = FL(1.0);
		phs -= 1.0;
		p->flag = 0;
	}
	else 
		*p->sr = FL(0.0);
	p->curphs = phs;
	
}





/*--------------------------------*/

void mtable_i(MTABLEI *p)
{
	
	FUNC *ftp;
	int j, nargs;
	MYFLT *table, xbmul, **out = p->outargs;
	if ((ftp = ftfind(p->xfn)) == NULL) {
		  initerror("mtablei: incorrect table number");
          return;
	}
	table = ftp->ftable;
	nargs = p->INOCOUNT-4;
	if (*p->ixmode)
		xbmul = (MYFLT) (ftp->flen / nargs);

	if (*p->kinterp) {
		MYFLT 	v1, v2 ;
		MYFLT fndx = (*p->ixmode) ? *p->xndx * xbmul : *p->xndx;
		long indx = (long) fndx;
		MYFLT fract = fndx - indx;
		for (j=0; j < nargs; j++) {
		    v1 = table[indx * nargs + j];
			v2 = table[(indx + 1) * nargs + j];
			**out++ = v1 + (v2 - v1) * fract;
		}
	}
	else {
		long indx = (*p->ixmode) ? (long)(*p->xndx * xbmul) : (long) *p->xndx;
		for (j=0; j < nargs; j++)
			**out++ =  table[indx * nargs + j];
	}
}

void mtable_set(MTABLE *p)	 /* mtab by G.Maldonado */
{
	FUNC *ftp;
	if ((ftp = ftfind(p->xfn)) == NULL) {
		  initerror("mtable: incorrect table number");
          return;
	}
	p->ftable = ftp->ftable;
	p->nargs = p->INOCOUNT-4;
	p->len = ftp->flen / p->nargs;
	p->pfn = (long) *p->xfn;
	if (*p->ixmode)
		p->xbmul = (MYFLT) ftp->flen / p->nargs;
}

void mtable_k(MTABLE *p)
{
	int j, nargs = p->nargs;
	MYFLT **out = p->outargs;
	MYFLT *table;
	long len;
    if (p->pfn != (long)*p->xfn) {
		FUNC *ftp;
		if ( (ftp = ftfindp(p->xfn) ) == NULL) {
			perferror("mtable: incorrect table number");
			return;
		}
		p->pfn = (long)*p->xfn;
		p->ftable = ftp->ftable;
		p->len = ftp->flen / nargs;
		if (*p->ixmode)
			p->xbmul = (MYFLT) ftp->flen / nargs;
    }
	table= p->ftable;
	len = p->len;
	if (*p->kinterp) {
		MYFLT fndx;
		long indx;
		MYFLT fract;
		long indxp1;
		MYFLT 	v1, v2 ;
		fndx = (*p->ixmode) ? *p->xndx * p->xbmul : *p->xndx;
		if (fndx >= len)
			fndx = (MYFLT) fmod(fndx, len);
		indx = (long) fndx;
		fract = fndx - indx;
		indxp1 = (indx < len-1) ? (indx+1) * nargs : 0;
		indx *=nargs;
		for (j=0; j < nargs; j++) {
		    v1 = table[indx + j];
			v2 = table[indxp1 + j];
			**out++ = v1 + (v2 - v1) * fract;
		}
	}
	else {
		long indx = (*p->ixmode) ? ((long)(*p->xndx * p->xbmul) % len) * nargs : ((long) *p->xndx % len ) * nargs ;
		for (j=0; j < nargs; j++)
			**out++ =  table[indx + j];
	}
}

void mtable_a(MTABLE *p)
{
	int j, nargs = p->nargs;
	int	nsmps = ksmps, ixmode = (int) *p->ixmode, k=0;
	MYFLT **out = p->outargs;
	MYFLT *table;
	MYFLT *xndx = p->xndx, xbmul;
	long len;

    if (p->pfn != (long)*p->xfn) {
		FUNC *ftp;
		if ( (ftp = ftfindp(p->xfn) ) == NULL) {
			perferror("mtable: incorrect table number");
			return;
		}
		p->pfn = (long)*p->xfn;
		p->ftable = ftp->ftable;
		p->len = ftp->flen / nargs;
		if (ixmode)
			p->xbmul = (MYFLT) ftp->flen / nargs;
    }
	table = p->ftable;
	len = p->len;
	xbmul = p->xbmul;
	if (*p->kinterp) {
		MYFLT fndx;
		long indx;
		MYFLT fract;
		long indxp1;
		do {
			MYFLT 	v1, v2 ;
			fndx = (ixmode) ? *xndx++ * xbmul : *xndx++;
			if (fndx >= len)
				fndx = (MYFLT) fmod(fndx, len);
			indx = (long) fndx;
			fract = fndx - indx;
			indxp1 = (indx < len-1) ? (indx+1) * nargs : 0;
			indx *=nargs;
			for (j=0; j < nargs; j++) {
				v1 = table[indx + j];
				v2 = table[indxp1 + j];
				out[j][k] = v1 + (v2 - v1) * fract;
				
			}
			k++;
		} while(--nsmps);

	}
	else {
		do {
			long indx = (ixmode) ? ((long)(*xndx++ * xbmul)%len) * nargs : ((long) *xndx++ %len) * nargs;
			for (j=0; j < nargs; j++) {
				out[j][k] =  table[indx + j];
			}
			k++;
		} while(--nsmps);
	}
}




//////////// mtab start /////////////


void mtab_i(MTABI *p)
{
	FUNC *ftp;
	int j, nargs;
	long indx;
	MYFLT *table, **out = p->outargs;
	if ((ftp = ftfind(p->xfn)) == NULL) {
		  initerror("mtabi: incorrect table number");
          return;
	}
	table = ftp->ftable;
	nargs = p->INOCOUNT-2;

	indx = (long) *p->xndx;
	for (j=0; j < nargs; j++)
			**out++ =  table[indx * nargs + j];
}

void mtab_set(MTAB *p)	 /* mtab by G.Maldonado */
{
	FUNC *ftp;
	if ((ftp = ftfind(p->xfn)) == NULL) {
		  initerror("mtable: incorrect table number");
          return;
	}
	p->ftable = ftp->ftable;
	p->nargs = p->INOCOUNT-2;
	p->len = ftp->flen / p->nargs;
	p->pfn = (long) *p->xfn;
}

void mtab_k(MTAB *p)
{
	int j, nargs = p->nargs;
	MYFLT **out = p->outargs;
	MYFLT *table;
	long len, indx;

	table= p->ftable;
	len = p->len;
	indx = ((long) *p->xndx % len ) * nargs ;
	for (j=0; j < nargs; j++)
			**out++ =  table[indx + j];
}

void mtab_a(MTAB *p)
{
	int j, nargs = p->nargs;
	int	nsmps = ksmps, k=0;
	MYFLT **out = p->outargs;
	MYFLT *table;
	MYFLT *xndx = p->xndx;
	long len;
	table = p->ftable;
	len = p->len;
	do {
			long indx = ((long) *xndx++ %len) * nargs;
			for (j=0; j < nargs; j++) {
				out[j][k] =  table[indx + j];
			}
			k++;
	} while(--nsmps);
	
}


//////////// mtab end ///////////////


void mtablew_i(MTABLEIW *p)
{
	
	FUNC *ftp;
	int j, nargs;
	long indx;
	MYFLT *table, xbmul, **in = p->inargs;
	if ((ftp = ftfind(p->xfn)) == NULL) {
		  initerror("mtablewi: incorrect table number");
          return;
	}
	table = ftp->ftable;
	nargs = p->INOCOUNT-3;
	if (*p->ixmode)
		xbmul = (MYFLT) (ftp->flen / nargs);
	indx = (*p->ixmode) ? (long)(*p->xndx * xbmul) : (long) *p->xndx;
	for (j=0; j < nargs; j++)
		table[indx * nargs + j] = **in++;
}

void mtablew_set(MTABLEW *p)	 /* mtabw by G.Maldonado */
{
	FUNC *ftp;
	if ((ftp = ftfind(p->xfn)) == NULL) {
		  initerror("mtabw: incorrect table number");
          return;
	}
	p->ftable = ftp->ftable;
	p->nargs = p->INOCOUNT-3;
	p->len = ftp->flen / p->nargs;
	p->pfn = (long) *p->xfn;
	if (*p->ixmode)
		p->xbmul = (MYFLT) ftp->flen / p->nargs;
}

void mtablew_k(MTABLEW *p)
{
	int j, nargs = p->nargs;
	MYFLT **in = p->inargs;
	MYFLT *table;
	long len, indx;
    if (p->pfn != (long)*p->xfn) {
		FUNC *ftp;
		if ( (ftp = ftfindp(p->xfn) ) == NULL) {
			perferror("mtabw: incorrect table number");
			return;
		}
		p->pfn = (long)*p->xfn;
		p->ftable = ftp->ftable;
		p->len = ftp->flen / nargs;
		if (*p->ixmode)
			p->xbmul = (MYFLT) ftp->flen / nargs;
    }
	table= p->ftable;
	len = p->len;
	indx = (*p->ixmode) ? ((long)(*p->xndx * p->xbmul) % len) * nargs : ((long) *p->xndx % len ) * nargs ;
	for (j=0; j < nargs; j++)
		table[indx + j] = **in++;
}

void mtablew_a(MTABLEW *p)
{
	int j, nargs = p->nargs;
	int	nsmps = ksmps, ixmode = (int) *p->ixmode, k=0;
	MYFLT **in = p->inargs;
	MYFLT *table;
	MYFLT *xndx = p->xndx, xbmul;
	long len;

    if (p->pfn != (long)*p->xfn) {
		FUNC *ftp;
		if ( (ftp = ftfindp(p->xfn) ) == NULL) {
			perferror("mtabw: incorrect table number");
			return;
		}
		p->pfn = (long)*p->xfn;
		p->ftable = ftp->ftable;
		p->len = ftp->flen / nargs;
		if (ixmode)
			p->xbmul = (MYFLT) ftp->flen / nargs;
    }
	table = p->ftable;
	len = p->len;
	xbmul = p->xbmul;
	do {
		long indx = (ixmode) ? ((long)(*xndx++ * xbmul)%len) * nargs : ((long) *xndx++ %len) * nargs;
		for (j=0; j < nargs; j++) {
			table[indx + j] = in[j][k];
		}
		k++;
	} while(--nsmps);
}

////////////////////////////////////////

void mtabw_i(MTABIW *p)
{
	FUNC *ftp;
	int j, nargs;
	long indx;
	MYFLT *table, **in = p->inargs;
	if ((ftp = ftfind(p->xfn)) == NULL) {
		  initerror("mtabwi: incorrect table number");
          return;
	}
	table = ftp->ftable;
	nargs = p->INOCOUNT-2;
	indx = (long) *p->xndx;
	for (j=0; j < nargs; j++)
		table[indx * nargs + j] = **in++;
}

void mtabw_set(MTABW *p)	 /* mtabw by G.Maldonado */
{
	FUNC *ftp;
	if ((ftp = ftfind(p->xfn)) == NULL) {
		  initerror("mtabw: incorrect table number");
          return;
	}
	p->ftable = ftp->ftable;
	p->nargs = p->INOCOUNT-2;
	p->len = ftp->flen / p->nargs;
	p->pfn = (long) *p->xfn;
}

void mtabw_k(MTABW *p)
{
	int j, nargs = p->nargs;
	MYFLT **in = p->inargs;
	MYFLT *table;
	long len, indx;
    if (p->pfn != (long)*p->xfn) {
		FUNC *ftp;
		if ( (ftp = ftfindp(p->xfn) ) == NULL) {
			perferror("mtablew: incorrect table number");
			return;
		}
		p->pfn = (long)*p->xfn;
		p->ftable = ftp->ftable;
		p->len = ftp->flen / nargs;
    }
	table= p->ftable;
	len = p->len;
	indx = ((long) *p->xndx % len ) * nargs ;
	for (j=0; j < nargs; j++)
		table[indx + j] = **in++;
}

void mtabw_a(MTABW *p)
{
	int j, nargs = p->nargs;
	int	nsmps = ksmps, k=0;
	MYFLT **in = p->inargs;
	MYFLT *table;
	MYFLT *xndx = p->xndx;
	long len;

    if (p->pfn != (long)*p->xfn) {
		FUNC *ftp;
		if ( (ftp = ftfindp(p->xfn) ) == NULL) {
			perferror("mtabw: incorrect table number");
			return;
		}
		p->pfn = (long)*p->xfn;
		p->ftable = ftp->ftable;
		p->len = ftp->flen / nargs;
    }
	table = p->ftable;
	len = p->len;
	do {
		long indx = ((long) *xndx++ %len) * nargs;
		for (j=0; j < nargs; j++) {
			table[indx + j] = in[j][k];
		}
		k++;
	} while(--nsmps);
}

/*/////////////////////////////////////////////*/

void fastab_set(FASTAB *p)
{
	FUNC *ftp;
	if ((ftp = ftfind(p->xfn)) == NULL) {
		  initerror("fastab: incorrect table number");
          return;
	}
	p->table = ftp->ftable;
	p->xmode = (int) *p->ixmode;
	if (p->xmode)
		p->xbmul = (MYFLT) ftp->flen;
	else 
		p->xbmul = FL(1.0);
 
}

void fastabw (FASTAB *p)
{
	int	nsmps = ksmps;
	MYFLT *tab = p->table;
	MYFLT *rslt = p->rslt, *ndx = p->xndx;
	if (p->xmode) {
		do *(tab + (long) (*ndx++ * p->xbmul)) = *rslt++;
		while(--nsmps);
	}
	else {
		do *(tab + (long) *ndx++) = *rslt++;
		while(--nsmps);
	}
}

void fastabk(FASTAB *p) 
{
	if (p->xmode)
		*p->rslt =  *(p->table + (long) (*p->xndx * p->xbmul));
	else
		*p->rslt =  *(p->table + (long) *p->xndx);
}

void fastabkw(FASTAB *p) 
{
	
	if (p->xmode) 
		*(p->table + (long) (*p->xndx * p->xbmul)) = *p->rslt;		
	else
		*(p->table + (long) *p->xndx) = *p->rslt;
}


void fastabi(FASTAB *p) 
{
	
	FUNC *ftp;
	//ftp = ftfind(p->xfn);

	if ((ftp = ftfind(p->xfn)) == NULL) {
		  initerror("tab_i: incorrect table number");
          return;
	}
	if (*p->ixmode)
		*p->rslt =  *(ftp->ftable + (long) (*p->xndx * ftp->flen));
	else
		*p->rslt =  *(ftp->ftable + (long) *p->xndx);
}

void fastabiw(FASTAB *p) 
{
	FUNC *ftp;
	//ftp = ftfind(p->xfn);
	if ((ftp = ftfind(p->xfn)) == NULL) {
		  initerror("tabw_i: incorrect table number");
          return;
	}
	if (*p->ixmode)
		*(ftp->ftable + (long) (*p->xndx * ftp->flen)) = *p->rslt;
	else
		*(ftp->ftable + (long) *p->xndx) = *p->rslt;
}


void fastab(FASTAB *p)
{
	int	nsmps = ksmps;
	MYFLT *tab = p->table;
	MYFLT *rslt = p->rslt, *ndx = p->xndx;
	if (p->xmode) {
		do *rslt++ = *(tab + (long) (*ndx++ * p->xbmul));
		while(--nsmps);
	}
	else {
		do *rslt++ = *(tab + (long) *ndx++ );
		while(--nsmps);
	}
}


;/////////////////////////////////

static MYFLT *tb0,*tb1,*tb2,*tb3,*tb4,*tb5,*tb6,*tb7,*tb8,*tb9,*tb10,*tb11,*tb12,*tb13,*tb14,*tb15;

#define tabMacro 	FUNC *ftp;\
	if ((ftp = ftfind(p->ifn)) == NULL) {\
		  initerror("tab_init: incorrect table number");\
          return;\
	}\

void tab0_init(TB_INIT *p) { tabMacro 	tb0 = ftp->ftable; }
void tab1_init(TB_INIT *p) { tabMacro 	tb1 = ftp->ftable; }
void tab2_init(TB_INIT *p) { tabMacro 	tb2 = ftp->ftable; }
void tab3_init(TB_INIT *p) { tabMacro 	tb3 = ftp->ftable; }
void tab4_init(TB_INIT *p) { tabMacro 	tb4 = ftp->ftable; }
void tab5_init(TB_INIT *p) { tabMacro 	tb5 = ftp->ftable; }
void tab6_init(TB_INIT *p) { tabMacro 	tb6 = ftp->ftable; }
void tab7_init(TB_INIT *p) { tabMacro 	tb7 = ftp->ftable; }
void tab8_init(TB_INIT *p) { tabMacro 	tb8 = ftp->ftable; }
void tab9_init(TB_INIT *p) { tabMacro 	tb9 = ftp->ftable; }
void tab10_init(TB_INIT *p) { tabMacro 	tb10 = ftp->ftable; }
void tab11_init(TB_INIT *p) { tabMacro 	tb11 = ftp->ftable; }
void tab12_init(TB_INIT *p) { tabMacro 	tb12 = ftp->ftable; }
void tab13_init(TB_INIT *p) { tabMacro 	tb13 = ftp->ftable; }
void tab14_init(TB_INIT *p) { tabMacro 	tb14 = ftp->ftable; }
void tab15_init(TB_INIT *p) { tabMacro 	tb15 = ftp->ftable; }


void tab0(FASTB *p) { *p->r = tb0[(long) *p->ndx]; }
void tab1(FASTB *p) { *p->r = tb1[(long) *p->ndx]; }
void tab2(FASTB *p) { *p->r = tb2[(long) *p->ndx]; }
void tab3(FASTB *p) { *p->r = tb3[(long) *p->ndx]; }
void tab4(FASTB *p) { *p->r = tb4[(long) *p->ndx]; }
void tab5(FASTB *p) { *p->r = tb5[(long) *p->ndx]; }
void tab6(FASTB *p) { *p->r = tb6[(long) *p->ndx]; }
void tab7(FASTB *p) { *p->r = tb7[(long) *p->ndx]; }
void tab8(FASTB *p) { *p->r = tb8[(long) *p->ndx]; }
void tab9(FASTB *p) { *p->r = tb9[(long) *p->ndx]; }
void tab10(FASTB *p) { *p->r = tb10[(long) *p->ndx]; }
void tab11(FASTB *p) { *p->r = tb11[(long) *p->ndx]; }
void tab12(FASTB *p) { *p->r = tb12[(long) *p->ndx]; }
void tab13(FASTB *p) { *p->r = tb13[(long) *p->ndx]; }
void tab14(FASTB *p) { *p->r = tb14[(long) *p->ndx]; }
void tab15(FASTB *p) { *p->r = tb15[(long) *p->ndx]; }








/* ************************************************************ */
/* Opcodes from Peter Neub�cker                              */
/* ************************************************************ */


void printi(PRINTI *p)
{
    char    *sarg;

    if ((*p->ifilcod != sstrcod) || (*p->STRARG == 0)) 
    {   sprintf(errmsg, "printi parameter was not a \"quoted string\"\n");
        initerror(errmsg);
        return;
    }
    else 
    {   sarg = p->STRARG;
        do 
        { putchar(*sarg);
        } while (*++sarg != 0);
        putchar(10);
        putchar(13);
    }
}


/*====================
opcodes from Jens Groh
======================*/

void nlalp_set(NLALP *p) {
   if (!(*p->istor)) {
      p->m0 = 0.;
      p->m1 = 0.;
   }
}



void nlalp(NLALP *p) {
   int nsmps;
   MYFLT *rp;
   MYFLT *ip;
   double m0;
   double m1;
   double tm0;
   double tm1;
   double klfact;
   double knfact;

   nsmps = ksmps;
   rp = p->aresult;
   ip = p->ainsig;
   klfact = (double)*p->klfact;
   knfact = (double)*p->knfact;
   tm0 = p->m0;
   tm1 = p->m1;
   if (knfact == 0.) { /* linear case */
      if (klfact == 0.) { /* degenerated linear case */
         m0 = (double)*ip++ - tm1;
         *rp++ = (MYFLT)(tm0);
         while (--nsmps) {
            *rp++ = (MYFLT)(m0);
            m0 = (double)*ip++;
         }
         tm0 = m0;
         tm1 = 0.;
      } else { /* normal linear case */
         do {
            m0 = (double)*ip++ - tm1;
            m1 = m0 * klfact;
            *rp++ = (MYFLT)(tm0 + m1);
            tm0 = m0;
            tm1 = m1;
         } while (--nsmps);
      }
   } else { /* non-linear case */
      if (klfact == 0.) { /* simplified non-linear case */
         do {
            m0 = (double)*ip++ - tm1;
            m1 = fabs(m0) * knfact;
            *rp++ = (MYFLT)(tm0 + m1);
            tm0 = m0;
            tm1 = m1;
         } while (--nsmps);
      } else { /* normal non-linear case */
         do {
            m0 = (double)*ip++ - tm1;
            m1 = m0 * klfact + fabs(m0) * knfact;
            *rp++ = (MYFLT)(tm0 + m1);
            tm0 = m0;
            tm1 = m1;
         } while (--nsmps);
      }
   }
   p->m0 = tm0;
   p->m1 = tm1;
}


/* -----------------------------------------------*/

void adsynt2_set(ADSYNT2 *p)
{
    FUNC    *ftp;
    int     count;
    long    *lphs;
	MYFLT	*pAmp;
    p->inerr = 0;

    if ((ftp = ftfind(p->ifn)) != NULL) {
      p->ftp = ftp;
    }
    else {
      p->inerr = 1;
      initerror(Str(X_173,"adsynt: wavetable not found!"));
      return;
    }

    count = (int)*p->icnt;
    if (count < 1)
      count = 1;
    p->count = count;

    if ((ftp = ftfind(p->ifreqtbl)) != NULL) {
      p->freqtp = ftp;
    }
    else {
      p->inerr = 1;
      initerror(Str(X_309,"adsynt: freqtable not found!"));
      return;
    }
    if (ftp->flen < count) {
      p->inerr = 1;
      initerror(Str(X_1424,"adsynt: partial count is greater than freqtable size!"));
      return;
    }

    if ((ftp = ftfind(p->iamptbl)) != NULL) {
      p->amptp = ftp;
    }
    else {
      p->inerr = 1;
      initerror(Str(X_1473, "adsynt: amptable not found!"));
      return;
    }
    if (ftp->flen < count) {
      p->inerr = 1;
      initerror(Str(X_1474,"adsynt: partial count is greater than amptable size!"));
      return;
    }

    if (p->lphs.auxp==NULL || p->lphs.size < (long)(sizeof(long)+sizeof(MYFLT))*count)
      auxalloc((sizeof(long)+sizeof(MYFLT))*count, &p->lphs);

    lphs = (long*)p->lphs.auxp;
    if (*p->iphs > 1) {
      do
        *lphs++ = ((long)((MYFLT)((double)rand()/(double)RAND_MAX)
                          * fmaxlen)) & PHMASK;
      while (--count);
    }
    else if (*p->iphs >= 0){
      do
        *lphs++ = ((long)(*p->iphs * fmaxlen)) & PHMASK;
      while (--count);
    }
	pAmp = p->previousAmp = (MYFLT *) lphs + sizeof(MYFLT)*count;
	count = (int)*p->icnt;
	do 
		*pAmp++ = FL(0.);
    while (--count);
}

void adsynt2(ADSYNT2 *p)
{
    FUNC    *ftp, *freqtp, *amptp;
    MYFLT   *ar, *ar0, *ftbl, *freqtbl, *amptbl, *prevAmp;
    MYFLT   amp0, amp, cps0, cps, ampIncr,amp2;
    long    phs, inc, lobits;
    long    *lphs;
    int     nsmps, count;

    if (p->inerr) {
      initerror(Str(X_1475,"adsynt: not initialized"));
      return;
    }
    ftp = p->ftp;
    ftbl = ftp->ftable;
    lobits = ftp->lobits;
    freqtp = p->freqtp;
    freqtbl = freqtp->ftable;
    amptp = p->amptp;
    amptbl = amptp->ftable;
    lphs = (long*)p->lphs.auxp;
	prevAmp = p->previousAmp;

    cps0 = *p->kcps;
    amp0 = *p->kamp;
    count = p->count;

    ar0 = p->sr;
    ar = ar0;
    nsmps = ksmps;
    do
      *ar++ = FL(0.0);
    while (--nsmps);

    do {
      ar = ar0;
      nsmps = ksmps;
      amp2 = *prevAmp;
	  amp = *amptbl++ * amp0;
      cps = *freqtbl++ * cps0;
      inc = (long) (cps * sicvt);
      phs = *lphs;
	  ampIncr = (amp - *prevAmp) / ensmps;
      do {
        *ar++ += *(ftbl + (phs >> lobits)) * amp2;
        phs += inc;
        phs &= PHMASK;
		amp2 += ampIncr;
      }
      while (--nsmps);
	  *prevAmp++ = amp;
      *lphs++ = phs;
    }
    while (--count);
}


void exitnow(EXITNOW *p) 
{ /* gab c3*/
	fcloseall(); 
#undef exit
	exit(0);
}

void turnoffk(TURNOFFK *p) 
{ /* gab c3*/
	//extern void turnoff(void);
	//if  (*p->ktrig) turnoff();
	extern void deact(INSDS *ip)  ;
	if  (*p->ktrig) deact(p->h.insdshead) ;
}


#include "UGRW1.h"
extern MYFLT *zkstart;
extern MYFLT *zastart;


void zread(ZKR *p)
{
	*p->rslt = zkstart[(long) *p->ndx];
}

#include "ugens6.h"

void a_k_set(INDIFF *p)
{
	p->prev = FL(0.0);
}

//===================================================================


void split_trig_set( SPLIT_TRIG *p)
{

	/* syntax of each table element:
   numtics_elem1, 
   tic1_out1, tic1_out2, ... , tic1_outN,
   tic2_out1, tic2_out2, ... , tic2_outN,
   tic3_out1, tic3_out2, ... , tic3_outN,
   .....
   ticN_out1, ticN_out2, ... , ticN_outN,
   
   numtics_elem2, 
   tic1_out1, tic1_out2, ... , tic1_outN,
   tic2_out1, tic2_out2, ... , tic2_outN,
   tic3_out1, tic3_out2, ... , tic3_outN,
   .....
   ticN_out1, ticN_out2, ... , ticN_outN,

	*/	

    FUNC *ftp;
    if ((ftp = ftfind(p->ifn)) == NULL) {
      initerror(Str(X_1535,"splitrig: incorrect table number"));
      return;
    }
    p->table = ftp->ftable;
	p->numouts =  p->INOCOUNT-4; 
	p->currtic = 0;

}


void split_trig(SPLIT_TRIG *p)
{
	int	j;
	int numouts =  p->numouts;
	MYFLT **outargs = p->outargs;
	
	if (*p->trig) {
		int ndx = (int) *p->ndx * (numouts * (int) *p->maxtics + 1);
		int	numtics =  (int) p->table[ndx];
		MYFLT *table = &(p->table[ndx+1]);
		int kndx = (int) *p->ndx;
		int currtic;

		if (kndx != p->old_ndx) {
			p->currtic = 0;
			p->old_ndx = kndx;
		}
		currtic = p->currtic;
		
		for (j = 0; j < numouts; j++) 
			*outargs[j] = table[j +  currtic * numouts ]; 
		
		p->currtic = (currtic +1) % numtics;
		
	}

	else {
		for(j =0; j< numouts; j++) 
			*outargs[j] = FL(0.0);
	}
}


/*-------------------------*/
void kdel_set(KDEL *p)
{
    unsigned long n;
    MYFLT *buf;
	n = (p->maxd = (long) (*p->imaxd * ekr));
    if (n == 0)	n = (p->maxd = 1);
    	 
	

    if (!*p->istod) {
		if (p->aux.auxp == NULL || (int)(n*sizeof(MYFLT)) > p->aux.size) 
			auxalloc(n * sizeof(MYFLT), &p->aux);
		else {
			buf = (MYFLT *)p->aux.auxp;  
			do {
				*buf++ = 0.0f;
			} while (--n);
		}
		p->left = 0;
    }
}

void kdelay(KDEL *p)              
{
    long maxd = p->maxd, indx, v1, v2;
    MYFLT *buf = (MYFLT *)p->aux.auxp, fv1, fv2;

    if (buf==NULL) {            
		initerror("vdelayk: not initialized");
		return;
    }

    indx = p->left;
	buf[indx] = *p->kin;
    fv1 = indx - *p->kdel * ekr;
    while (fv1 < 0.0f)	fv1 += (MYFLT)maxd;
    while (fv1 >= (MYFLT)maxd) fv1 -= (MYFLT)maxd;
	if (*p->interp) { // no interpolation
		*p->kr = buf[(long) fv1];
	}
	else {
		if (fv1 < maxd - 1) fv2 = fv1 + 1;
		else                fv2 = 0.0f;
		v1 = (long)fv1;
		v2 = (long)fv2;
		*p->kr = buf[v1] + (fv1 - v1) * (buf[v2]-buf[v1]);
	}
    if (++(p->left) == maxd) p->left = 0;

}


//--------------------------

void timeseq_set(TIMEDSEQ *p)
{
	FUNC *ftp;
	MYFLT *table;
	int j;
	if ((ftp = ftfind(p->ifn)) == NULL)  return;
	table = p->table = ftp->ftable;
	p->numParm = p->INOCOUNT-2; // ?
	for (j = 0; j < ftp->flen; j+= p->numParm) {
		if (table[j] < 0) { 
			p->endSeq = table[j+1];
			p->endIndex = j/p->numParm;
			break;
		}
	}
	p->initFlag = 1;
}


void timeseq(TIMEDSEQ *p)
{
	MYFLT *table = p->table, minDist = onedkr;
	MYFLT phs = *p->kphs, endseq = p->endSeq;
	int  j,k, numParm = p->numParm, endIndex = p->endIndex;
	while (phs > endseq) 
		phs -=endseq;
	while (phs < 0 ) 
		phs +=endseq;
	
	if (p->initFlag) {
	prev:
		for (j=0,k=endIndex; j < endIndex; j++, k--) {
			if (table[j*numParm + 1] > phs ) {
				p->nextActime = table[j*numParm + 1]; 
				p->nextIndex = j;
				p->prevActime = table[(j-1)*numParm + 1]; 
				p->prevIndex = j-1;
				break;
			}
			if (table[k*numParm + 1] < phs ) {
				p->nextActime = table[(k+1)*numParm + 1]; 
				p->nextIndex = k+1;
				p->prevActime = table[k*numParm + 1]; 
				p->prevIndex = k;
				break;
			}
		}
		if (phs == p->prevActime&& p->prevIndex != -1 )  {
			*p->ktrig = 1;
			for (j=0; j < numParm; j++) {
				*p->args[j]=table[p->prevIndex*numParm + j];
			}
		}
		else if (phs == p->nextActime && p->nextIndex != -1 )  {
			*p->ktrig = 1;
			for (j=0; j < numParm; j++) {
				*p->args[j]=table[p->nextIndex*numParm + j];
			}
		}
		//p->oldPhs = phs;
		p->initFlag=0;
	}
	else {
		if (phs > p->nextActime || phs < p->prevActime) {			
			for (j=0; j < numParm; j++) {
				*p->args[j]=table[p->nextIndex*numParm + j];
			}
			if (table[p->nextIndex*numParm] != -1) // if it is not end locator
				//*p->ktrig = 1;
				*p->ktrig = table[p->nextIndex*numParm + 3];
			if (phs > p->nextActime) {
				if (p->prevIndex > p->nextIndex && p->oldPhs < phs) { // there is a phase jump
					*p->ktrig = 0;
					goto fine;
				} 
				if (fabs(phs-p->nextActime) > minDist) 
					goto prev;

				p->prevActime = table[p->nextIndex*numParm + 1];
				p->prevIndex = p->nextIndex;
				p->nextIndex = (p->nextIndex + 1) % endIndex;
				p->nextActime = table[p->nextIndex*numParm + 1];
			}
			else {
				if (fabs(phs-p->nextActime) > minDist) 
					goto prev;

				p->nextActime = table[p->prevIndex*numParm + 1]; //p->nextActime+1;
				p->nextIndex = p->prevIndex;
				p->prevIndex = (p->prevIndex - 1);
				if (p->prevIndex < 0) {
					p->prevIndex += p->endIndex;
				}
				p->prevActime = table[p->prevIndex*numParm + 1]; //p->nextActime+1;
			}
		}
		else 
			*p->ktrig = 0;
		fine:
		p->oldPhs = phs;
	}

	
}

/*
extern "C" void timeseq_set(TIMEDSEQ *p)
{
	FUNC *ftp;
	MYFLT *table;
	if ((ftp = ftfind(p->ifn)) != NULL) {
      ftp = ftp;
    }
	else return;
	table = p->table = ftp->ftable;
	p->numParm = p->INOCOUNT-3; // ?
	for (int j = 0; j < ftp->flen; j+= p->numParm) {
		if (table[j] < 0) { // if insnum  < 0
			p->endSeq = table[j+1];
			p->endIndex = j/p->numParm;
			break;
		}
	}
	p->prevActime = p->nextActime = 0;
	p->lastIndex=-1;
	p->oldPhs =0;
	p->nextIndex=0;

}


extern "C" void timeseq(TIMEDSEQ *p)
{
	MYFLT minDist = *p->iMinDist, *table = p->table;
	MYFLT phs = *p->kphs;
	int  j, index  = p->currIndex, numParm = p->numParm, endIndex = p->endIndex;

	if (p->lastIndex > p->nextIndex) {
		if (p->oldPhs < phs) {
			*p->ktrig = 0;
			goto fine;
		}
	}
	if (phs > p->nextActime) {
			*p->ktrig = 1;
			for (j=0; j < p->numParm; j++) {
				*p->args[j]=table[p->nextIndex * p->numParm+j];
			}
			p->lastIndex = p->nextIndex;
			p->nextIndex = (p->nextIndex + 1) % p->endIndex;
			p->nextActime = table[p->nextIndex * p->numParm+1]; //p->nextActime+1;
		}
	else *p->ktrig = 0;
fine:
	p->oldPhs = phs;
}

*/
/*

typedef struct	{
	OPDS	h;
	MYFLT	*ktrig, *kphs, *iMinDist, *ifn, *args[PMAX];
	MYFLT endSeq, *table, oldPhs;
	int numParm, currIndex, endIndex, prevIndex, nextIndex, lastIndex;
	MYFLT prevActime, nextActime, lastActime;

} TIMEDSEQ;

*/

//---===---===---===---===---===---===---===---===---===---===---===---===

extern int maxfnum;
extern FUNC	**flist;


void tabrec_set(TABREC *p) 
{
    //FUNC *ftp;
    //if ((ftp = ftfind(p->ifn)) == NULL) {
    //  initerror(Str(X_1535,"tabrec: incorrect table number"));
    //  return;
    //}
    //p->table = ftp->ftable;
	//p->tablen = ftp->flen;
	p->recording = 0;
	p->currtic = 0;
	p->ndx = 0;
	p->numins = p->INOCOUNT-4;
}

void tabrec_k(TABREC *p) 
{
	if (*p->ktrig_start) {
		if (*p->kfn != p->old_fn) {
			FUNC *ftp;
			int fno;
			if ((fno = (int)*p->kfn) <= 0 || fno > maxfnum || (ftp = flist[fno]) == NULL) {
				sprintf(errmsg, Str(X_315,"Invalid ftable no. %f"),*p->kfn);
				perferror(errmsg);
				return;
			}
			else {
				p->tablen = ftp->flen;
				p->table = &ftp->ftable[1];
				p->currtic = 0;
				p->ndx = 0;
				ftp->ftable[0] = *p->numtics;
			}
		}
		
		p->recording = 1;
		p->ndx = 0;
		p->currtic = 0;
	}
	if (*p->ktrig_stop) {
		
		if (p->currtic >= *p->numtics) {
			p->recording = 0;
			return;
		}
		p->currtic++;
	}
	if (p->recording) {
		int j, curr_frame = p->ndx * p->numins;
		
		MYFLT *table = p->table;
		MYFLT **inargs = p->inargs;
		if (curr_frame + p->numins < p->tablen) { /* record only if table is not full */
			for (j = 0; j < p->numins; j++)
				table[curr_frame + j] = *inargs[j];
		}
		(p->ndx)++;
	}
}
/*-------------------------*/
void tabplay_set(TABPLAY *p) 
{
 //   FUNC *ftp;
   // if ((ftp = ftfind(p->ifn)) == NULL) {
   //   initerror(Str(X_1535,"tabplay: incorrect table number"));
   //   return;
   // }
  //  p->table = ftp->ftable;
//	p->tablen = ftp->flen;
	p->playing = 0;
	p->currtic = 0;
	p->ndx = 0;
	p->numouts = p->INOCOUNT-3;
}

void tabplay_k(TABPLAY *p) 
{
	if (*p->ktrig) {
		if (*p->kfn != p->old_fn) {
			FUNC *ftp;
			int fno;
			if ((fno = (int)*p->kfn) <= 0 || fno > maxfnum || (ftp = flist[fno]) == NULL) {
				sprintf(errmsg, Str(X_315,"Invalid ftable no. %f"),*p->kfn);
				perferror(errmsg);
				return;
			}
			else {
				p->tablen = ftp->flen;
				p->table = &ftp->ftable[1];
				p->currtic = 0;
				p->ndx = 0;
				ftp->ftable[0] = *p->numtics;
				p->old_fn = *p->kfn;
			}
		}

		p->playing = 1;
		if (p->currtic == 0)
			p->ndx = 0;
		if (p->currtic >= *p->numtics) {
			p->playing = 0;
			return;
		}
		p->currtic++;
		p->currtic %= (long) *p->numtics;

	}
	if (p->playing) {
		int j, curr_frame = p->ndx * p->numouts;
		MYFLT *table = p->table;
		MYFLT **outargs = p->outargs;
		if (curr_frame + p->numouts < p->tablen) { /* play only if ndx is inside table */
			//for (j = p->ndx* p->numouts; j < end; j++)
			//	*outargs[j] = table[j];

			for (j = 0; j < p->numouts; j++)
				*outargs[j] = table[curr_frame+j];
		}
		(p->ndx)++;
	}
}

/*-------------------------*/

void isChanged_set(ISCHANGED *p) 
{
	p->numargs = p->INOCOUNT;
}

void isChanged(ISCHANGED *p) 
{
	MYFLT **inargs = p->inargs;	
	MYFLT *old_inargs = p->old_inargs;
	int numargs = p->numargs, ktrig = 0, j;
	
	for (j =0; j< numargs; j++) {
		if (*inargs[j] != old_inargs[j]) {
			ktrig = 1;
			break;
		}
	}

	if (ktrig) {
		for (j =0; j< numargs; j++) {
			old_inargs[j] = *inargs[j];
		}
	}
	*p->ktrig = (MYFLT) ktrig;
}
/*-------------------------*/

#include "oload.h" /* for strset */

void CSsystem(CSSYSTEM *p) 
{
	long filno;
	char comLine[512];
	int ret;

	if (*p->commandLine == sstrcod) { /* if char string name given */
      extern EVTBLK *currevent;
      if (p->STRARG == NULL) strcpy(comLine,unquote(currevent->strarg));
      else strcpy(comLine,unquote(p->STRARG));    /* unquote it,  else use */
    }
    else if ((filno=(long)*p->commandLine) <= strsmax && strsets != NULL &&
	     strsets[filno])
      strcpy(comLine, strsets[filno]);
    else sprintf(comLine,"soundin.%ld",filno);  /* soundin.filno */
	ret = system(NULL);
	if (ret)
		ret = system( comLine );
}

/*-------------------------*/

void partial_maximum_set(P_MAXIMUM *p) 
{
	p->max = 0;
	p->counter = 0;
}

void partial_maximum(P_MAXIMUM *p) 
{

	int	n = ksmps, flag = (int) *p->imaxflag;
	MYFLT *a = p->asig;
	MYFLT max = p->max;
	switch(flag) {
		case 0: /* absolute maximum */
			do 	{
				MYFLT temp;
				if ((temp= (MYFLT) fabs(*a++)) > max) max = temp;
			} while (--n);
			if (max > p->max) p->max = max;
			break;
		case 1: /* actual maximum */
				do 	{
					if (*a > max) max = *a;
					++a;
				} while (--n);
				if (max > p->max) p->max = max;
				break;
		case 2: /* actual minimum */
				do 	{
					if (*a < max) max = *a;
					++a;
				} while (--n);
				if (max < p->max) p->max = max;
				break;
		case 3: { /* average */
				MYFLT temp=0;
				do 	temp += *a++;
				while (--n);
				++(p->counter);
				p->max += temp;
				}
				break;
		default:
			perferror("max_k: invalid imaxflag value");
			return;
	}
	if (*p->ktrig) {
		if (flag == 3) { 
			*p->kout = p->max / p->counter;
			p->counter = 0;
		}
		else *p->kout = p->max;
		p->max = 0;
	}
}

