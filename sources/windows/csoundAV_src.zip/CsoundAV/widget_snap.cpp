#include "widg.h"

vector<ADDR_SET_VALUE> AddrSetValue; //addresses of valuators 
vector<SNAPSHOT> snapshots; 
extern vector<char*> allocatedStrings;


extern "C" void set_snap(FLSETSNAP *p)
{
	SNAPSHOT snap(AddrSetValue);
	int numfields = snap.fields.size();
	int index = (int) *p->index;
	*p->inum_snap = snapshots.size();
	*p->inum_val = numfields; // number of snapshots
	
	if (*p->ifn >= 1) { // if the table number is valid
		FUNC	*ftp;   // store the snapshot into the table
		if ((ftp = ftfind(p->ifn)) != NULL) {
			MYFLT * table = ftp->ftable;
			for( int j=0; j < numfields; j++) {
				table[index*numfields+j] = snap.fields[j].value;
			}
		}
		else initerror("FLsetsnap: invalid table");
	}
	else { // else store it into snapshot bank
		if (snapshots.size() < index+1)
			snapshots.resize(index+1);
		snapshots[index]=snap;
	}
}	


extern "C" void get_snap(FLGETSNAP *p)
{
	int index = *p->index;
	if (!snapshots.empty()) {
		if (index >= snapshots.size()) index = snapshots.size()-1;
		else if (index < 0 ) index=0;
		snapshots[index].get(AddrSetValue);
	}
	*p->inum_el = snapshots.size();
}	


extern "C" char *snapdir_path;


extern "C" void save_snap(FLSAVESNAPS* p)
{
#ifdef WIN32
	int id = MessageBox( NULL,	
				"Saving could overwrite the old file.\nAre you sure to save?",
                "Warning",	
                MB_TASKMODAL|MB_ICONWARNING |MB_OKCANCEL 
				);
	if (id != IDOK ) return;
#elif defined(LINUX)
	// put here some warning message!!
#endif
	char     s[MAXNAME];
	string  filename;
	if (*p->filename == sstrcod) { // if char string name given 
		if (p->STRARG == NULL) strcpy(s,unquote(currevent->strarg));
		else strcpy(s, unquote(p->STRARG));
	} 
	else if ((long)*p->filename <= strsmax && strsets != NULL && strsets[(long)*p->filename])
		strcpy(s, strsets[(long)*p->filename]);
	else sprintf(s,"snap.%d", (int)*p->filename); 
		
	if (isfullpath(s) || snapdir_path == NULL)  
		filename = s;
	else 
		filename = catpath(snapdir_path, s);

	//char* s[MAXNAME] = GetString(*p->filename,p->STRARG);

	fstream file(filename.c_str(), ios::out);
	for (int j =0; j < snapshots.size(); j++) {
		file << "----------- "<< j << " -----------\n";
		for ( int k =0; k < snapshots[j].fields.size(); k++) {
			VALUATOR_FIELD& f = snapshots[j].fields[k];
			if (f.opcode_name == "FLjoy") {
				file <<f.opcode_name<<" "<< f.value <<" "<< f.value2
					<<" "<< f.min <<" "<< f.max <<" "<< f.min2 <<" "<< f.max2<<" "<<f.exp<<" "<<f.exp2<<" \"" <<f.widg_name<<"\"\n";
			}
			else if (f.opcode_name == "FLslidBnk") {
				file << f.opcode_name << " " << f.exp << " "; // EXCEPTIONAL CASE! fld.exp contains the number of sliders and not the exponential flag
				for (int i=0; i < f.exp; i++) {
					file << f.sldbnkValues[i] << " ";
				}
				file << " \"" << f.widg_name << "\"\n";
			}
			else {
				file <<f.opcode_name<<" "<< f.value 
					<<" "<< f.min <<" "<< f.max <<" "<<f.exp<<" \"" <<f.widg_name<<"\"\n";
			}
		}
	}
	file << "---------------------------";
	file.close();
}


	
extern "C" void load_snap(FLLOADSNAPS* p)
{
	char     s[MAXNAME];
	string  filename;
	if (*p->filename == sstrcod) { // if char string name given 
		if (p->STRARG == NULL) strcpy(s,unquote(currevent->strarg));
		else strcpy(s, unquote(p->STRARG));
	} 
	else if ((long)*p->filename <= strsmax && strsets != NULL && strsets[(long)*p->filename])
		strcpy(s, strsets[(long)*p->filename]);
	else sprintf(s,"snap.%d", (int)*p->filename); 
		
	if (isfullpath(s) || snapdir_path == NULL)  
		filename = s;
	else 
		filename = catpath(snapdir_path, s);

	//char* s[MAXNAME] = GetString(*p->filename,p->STRARG);
	
	fstream file(filename.c_str(), ios::in);
	
	int j=0,k=-1;
	while (!(file.eof())) {
		char buf[MAXNAME];
		file.getline(buf,MAXNAME);
		
		strstream sbuf;
		sbuf << buf;
		
		string opc, opc_orig;
		getline(sbuf, opc, ' ');
		const char *ss = opc.c_str();
		if (*ss == '-') { // if it is a separation line
			k++; j=0; 
			if (snapshots.size() < k+1)
			snapshots.resize(k+1);
		}
		else if (*ss != '\0' && *ss != ' ' && *ss != '\n'){ //ignore blank lines
			ADDR_SET_VALUE& v = AddrSetValue[j];
			if (snapshots[k].fields.size() < j+1)
				snapshots[k].fields.resize(j+1);
			snapshots[k].is_empty = 0;
			VALUATOR_FIELD& fld = snapshots[k].fields[j];
			opc_orig = ((OPDS *) (v.opcode))->optext->t.opcod;

			if (!(opc_orig == opc)) {
				initerror("unmatched widget, probably due to a modified orchestra. Modifying an orchestra makes it incompatible with old snapshot files");
				return;
			}
			if (opc == "FLjoy") {
				fld.opcode_name = opc;
				string s;
				getline(sbuf,s, ' ');  fld.value = atof(s.c_str());
				getline(sbuf,s, ' ');  fld.value2 = atof(s.c_str());
				getline(sbuf,s, ' ');  fld.min = atof(s.c_str());
				getline(sbuf,s, ' ');  fld.max = atof(s.c_str());
				getline(sbuf,s, ' ');  fld.min2 = atof(s.c_str());
				getline(sbuf,s, ' ');  fld.max2 = atof(s.c_str());
				getline(sbuf,s, ' ');  fld.exp = atoi(s.c_str()); 
				getline(sbuf,s, ' ');  fld.exp2 = atoi(s.c_str());
				getline(sbuf,s, '\"'); 
				getline(sbuf,s, '\"');  fld.widg_name = s;
			}
			else if (opc == "FLslidBnk") {
				fld.opcode_name = opc;
				string s;
				getline(sbuf,s, ' ');  fld.exp = atoi(s.c_str()); // EXCEPTIONAL CASE! fld.exp contains the number of sliders and not the exponential flag
				fld.sldbnkValues = new MYFLT[fld.exp];
				allocatedStrings.push_back((char *) fld.sldbnkValues);

				for (int k =0; k < fld.exp; k++) {
					getline(sbuf,s, ' ');  fld.sldbnkValues[k] = atof(s.c_str());

				}
				getline(sbuf,s, '\"'); 
				getline(sbuf,s, '\"');  fld.widg_name = s;
			}
			else {
				fld.opcode_name = opc;
				string s;
				getline(sbuf,s, ' ');  fld.value = atof(s.c_str()); 
				getline(sbuf,s, ' ');  fld.min = atof(s.c_str()); 
				getline(sbuf,s, ' ');  fld.max = atof(s.c_str()); 
				getline(sbuf,s, ' ');  fld.exp = atoi(s.c_str());
				getline(sbuf,s, '\"'); 
				getline(sbuf,s, '\"');  fld.widg_name = s;
			}
			j++;
		}
	}
	
	file.close();

}

