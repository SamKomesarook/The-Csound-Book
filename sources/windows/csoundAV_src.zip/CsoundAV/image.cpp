#ifdef _WIN32
#pragma warning(disable:4786 4117)
#endif
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <map>
#include <string>
#include "stdpch.h"
#include "anydec.h"
#include "anybmp.h"
#include "GL/gl.h"

extern "C" {
	#undef __cplusplus
	#include "cs.h"
	#include "image.h"

	#include "oload.h"
	#define __cplusplus
    extern EVTBLK *currevent; 
	char *unquote(char *name);
}

#include "imagestruct.h"

#undef exit
using namespace std;

map<int,imageStruct> Bm_image; // map of pointers to CAnyBmp objects
map<int,imageStruct>::iterator Bm_image_iterator; // iterator of the map

#define ONEup255 0.00392156862745098f


#ifdef RESET
extern "C" void pictureRESET() {
	for(Bm_image_iterator=Bm_image.begin(); Bm_image_iterator != Bm_image.end(); Bm_image_iterator++) {
		if ((*Bm_image_iterator).second.data   != NULL) {
			delete [] (*Bm_image_iterator).second.data;
			(*Bm_image_iterator).second.data = NULL;
		}
		if ((*Bm_image_iterator).second.bmpObj != NULL) {
			delete (*Bm_image_iterator).second.bmpObj;
			(*Bm_image_iterator).second.bmpObj=NULL;
		}
	}
	Bm_image.clear();
}
#endif


extern "C" void bmcreate(BMCREATE *p)
{
	int ihandle = (int) *p->ihandle; 
	int width = *p->iwidth, height = *p->iheight, bpp = *p->ibpp;
	Bm_image_iterator = Bm_image.find(ihandle);
	if(Bm_image_iterator != Bm_image.end()) {  // if a previous instance of ihandle already exists
		if ((*Bm_image_iterator).second.data != NULL) {
			delete (*Bm_image_iterator).second.data; 
			(*Bm_image_iterator).second.data = NULL; 
		}
		if ((*Bm_image_iterator).second.bmpObj != NULL) {
			delete (*Bm_image_iterator).second.bmpObj; 
			(*Bm_image_iterator).second.bmpObj = NULL; 
		}
		//delete Bm_image[ihandle];			// erase it
		Bm_image.erase(Bm_image_iterator);
	}
	int csize;
	Bm_image[ihandle].xsize = *p->iwidth;
	Bm_image[ihandle].ysize = *p->iheight;
	Bm_image[ihandle].csize = csize = *p->ibpp/8;
	Bm_image[ihandle].type = GL_UNSIGNED_BYTE;
	int size = Bm_image[ihandle].xsize 
				* Bm_image[ihandle].ysize 
				* Bm_image[ihandle].csize;
	BYTE *im;
	Bm_image[ihandle].data = im = new BYTE[size];
	BYTE 	r =  CLAMP(*p->r), g =  CLAMP(*p->g), b =  CLAMP(*p->b), a =  CLAMP(*p->a);

	if (r !=0 || g !=0 || b !=0  || a !=0) {
		int j;
		switch (csize) {
			case 1:
				Bm_image[ihandle].format = GL_RED; 
				for ( j = 0; j < size; j++) {
					im[j] = r;
				}
				break;
			case 3:
				Bm_image[ihandle].format = GL_RGB;
				for ( j = 0; j < size; j+=3) {
					im[j+RED] = r;
					im[j+GREEN] = g;
					im[j+BLUE] = b;
				}
				break;
			case 4:
				Bm_image[ihandle].format = GL_RGBA;
				for ( j = 0; j < size; j+=4) {
					im[j+RED] = r;
					im[j+GREEN] = g;
					im[j+BLUE] = b;
					im[j+ALPHA] = a;
				}
				break;
			default:
				initerror ("bmcreate: invalid bpp");

		}
	}
}


extern "C" char *imgdir_path;

extern "C" void bmopen(BMOPEN *p)
{
	char     bmfilnam[MAXNAME];
	string  filename;
	if (*p->ifilno == sstrcod) { /* if char string name given */
		if (p->STRARG == NULL) strcpy(bmfilnam,unquote(currevent->strarg));
		else strcpy(bmfilnam, unquote(p->STRARG));
	} 
	else if ((long)*p->ifilno <= strsmax && strsets != NULL &&
	     strsets[(long)*p->ifilno])
      strcpy(bmfilnam, strsets[(long)*p->ifilno]);
    else sprintf(bmfilnam,"img.%d", (int)*p->ifilno); 
	
		
	if (isfullpath(bmfilnam) || imgdir_path == NULL)  filename = bmfilnam;
	else filename = catpath(imgdir_path, bmfilnam);


	int ihandle = (int) *p->ihandle;  
	Bm_image_iterator = Bm_image.find(ihandle);
	if(Bm_image_iterator != Bm_image.end()) {  // if a previous instance of ihandle already exists
		if ((*Bm_image_iterator).second.data != NULL) {
			delete (*Bm_image_iterator).second.data; 
			(*Bm_image_iterator).second.data = NULL; 
		}
		if ((*Bm_image_iterator).second.bmpObj != NULL) {
			delete (*Bm_image_iterator).second.bmpObj; 
			(*Bm_image_iterator).second.bmpObj = NULL; 
		}
		//delete Bm_image[ihandle];			// erase it
		Bm_image.erase(Bm_image_iterator);
	}
	//int bpp = 32; //default format in memory is 32 bit (Red Green Blue Alpha i.e. 4 bytes per pixel)
	//if (*p->iflag==1) // if == 1 format is set to 24 bit (RGB i.e. 3 bytes per pixel)
	//	bpp =  24;
	
	CAnyBmp * bmp = new(CAnyBmp); 
	CAnyPicDecoder dec;
	try {
		dec.MakeBmpFromFile(filename.c_str(), bmp,0); // fill the element with a bitmap from a file
	}
	catch(CTextException) {
		initerror("bmopen: unable to load bitmap file");
		return;
	}
	int width, height;
	

	*p->iwidth =  Bm_image[ihandle].xsize = width = bmp->GetWidth();
	*p->iheight=  Bm_image[ihandle].ysize = height = bmp->GetHeight();
	int bpp = bmp->GetBitsPerPixel();
	*p->ibpp = bpp;
	
	Bm_image[ihandle].csize = bpp/8;  /* color (LUMINANCE = 1, RGBA = 4) */
	switch  (Bm_image[ihandle].csize)
	{
		case 1: Bm_image[ihandle].format = GL_LUMINANCE; break;
		case 3: Bm_image[ihandle].format = GL_RGB; break;
		case 4: Bm_image[ihandle].format = GL_RGBA; break;
		default: initerror("invalid image format"); return;
	}
	Bm_image[ihandle].format = bpp/8;  /* color (LUMINANCE = 1, RGBA = 4) */
	switch (bpp) {
		case 8:	Bm_image[ihandle].format = GL_LUMINANCE; break;
		case 24: Bm_image[ihandle].format = GL_RGB; break;
		case 32: Bm_image[ihandle].format = GL_RGBA; break;
		default: initerror ("invalid image color depth (only 8, 24 and 32 bpp allowed)"); return;
	}
	Bm_image[ihandle].type = GL_UNSIGNED_BYTE;
	printf("bmopen ---> Bitmap image %s loaded\n",bmfilnam);
	printf("       ---> Width: %d,  Height: %d,  Bpp: %d\n", 
			(int)*p->iwidth,(int)*p->iheight ,(int) *p->ibpp);
	BYTE *im;
	BYTE **LineArray = bmp->GetLineArray();
	int j,k;
	switch ((int) *p->iflag) {
		case 0: // only *bmpObj
			Bm_image[ihandle].bmpObj = bmp; 
			break;
		case 1:	// only *data;
			Bm_image[ihandle].data = im =
				new BYTE[ Bm_image[ihandle].xsize 
							* Bm_image[ihandle].ysize 
							* (bpp/8)
						];
			switch (bpp) {
				case 8:
					for (j=0; j<height; j++) {
						BYTE *line = LineArray[j];
						for (k=0; k<width; k+=1) {
							*im++ = line[k];
						}
					}
					break;
				case 24:
					for (j=0; j<height; j++) {
						BYTE *line = LineArray[j];
						for (k=0; k<width*3; k+=3) {
							*im++ = line[k+2];
							*im++ = line[k+1];
							*im++ = line[k];
						}
					}
					break;
				case 32:
					for (j=0; j<height; j++) {
						BYTE *line = LineArray[j];
						for (k=0; k<width*4; k+=4) {
							*im++ = line[k+2];
							*im++ = line[k+1];
							*im++ = line[k];
							*im++ = line[k+3];
						}
					}
					break;
				default: 
					initerror ("invalid image color depth (only 8, 24 and 32 bpp allowed)"); 
					return;
			}
			delete bmp;
			break;
		case 2: // both
			Bm_image[ihandle].data = im =
				new BYTE[ Bm_image[ihandle].xsize * Bm_image[ihandle].ysize * (bpp/8)]; 
			switch (bpp) {
				case 8:
					for (j=0; j<height; j++) {
						BYTE *line = LineArray[j];
						for (k=0; k<width; k+=1) {
							*im++ = line[k];
						}
					}
					break;
				case 24:
					for (j=0; j<height; j++) {
						BYTE *line = LineArray[j];
						for (k=0; k<width*3; k+=3) {
							*im++ = line[k+2];
							*im++ = line[k+1];
							*im++ = line[k];
						}
					}
					break;
				case 32:
					for (j=0; j<height; j++) {
						BYTE *line = LineArray[j];
						for (k=0; k<width*4; k+=4) {
							*im++ = line[k+2];
							*im++ = line[k+1];
							*im++ = line[k];
							*im++ = line[k+3];
						}
					}
					break;
				default: 
					initerror ("invalid image color depth (only 8, 24 and 32 bpp allowed)"); 
					return;
			}
			Bm_image[ihandle].bmpObj = bmp; 
			break;
		default: // only *bmpObj
			Bm_image[ihandle].bmpObj = bmp; 
			break;

	}
	//CAnyBmp * bmp = (CAnyBmp *) Bm_image[ihandle].bmpObj;				// to speed-up operations
}

extern "C" void bmtable_set(BMTABLE *p)
{
	int ihandle = (int) *p->ihandle;
	Bm_image_iterator = Bm_image.find(ihandle);
	if(Bm_image_iterator == Bm_image.end()) {  // ihandle does't exist
		initerror("bmtable:invalid picture number");
		return;
	}
	p->LineArray = ((CAnyBmp*) Bm_image[ihandle].bmpObj)->GetLineArray();
}
	

extern "C" void bmtable(BMTABLE *p)
{
	int x= ((int) *p->kx) * 4;
	BYTE *line = p->LineArray[(int) *p->ky];
	*p->kr = line[x+RGBA_RED];
	*p->kg = line[x+RGBA_GREEN];
	*p->kb = line[x+RGBA_BLUE];
	*p->ka = line[x+RGBA_ALPHA];
}

extern "C" void bmtablei(BMTABLE *p)
{
	int   x= (int) *p->kx ,     y= (int) *p->ky;
	MYFLT fractx = *p->kx - x, fracty = *p->ky - y;
	MYFLT result1, result2, result11, result12, left, right;
	BYTE *line0 = p->LineArray[y];
	BYTE *line1 = p->LineArray[y+1];
	int x1=(x+1)*4;
	x*=4;
	
	result1 = line0[x+RGBA_RED];
	result2 = line1[x+RGBA_RED];
	result11 = line0[x1+RGBA_RED];
	result12 = line1[x1+RGBA_RED];
	left  = result1  + (result2 -result1 )*fracty;
	right = result11 + (result12-result11)*fracty;
	*p->kr = left + (right-left)*fractx;

	result1 = line0[x+RGBA_GREEN];
	result2 = line1[x+RGBA_GREEN];
	result11 = line0[x1+RGBA_GREEN];
	result12 = line1[x1+RGBA_GREEN];
	left  = result1  + (result2 -result1 )*fracty;
	right = result11 + (result12-result11)*fracty;
	*p->kg = left + (right-left)*fractx;

	result1 = line0[x+RGBA_BLUE];
	result2 = line1[x+RGBA_BLUE];
	result11 = line0[x1+RGBA_BLUE];
	result12 = line1[x1+RGBA_BLUE];
	left  = result1  + (result2 -result1 )*fracty;
	right = result11 + (result12-result11)*fracty;
	*p->kb = left + (right-left)*fractx;

	result1 = line0[x+RGBA_BLUE];
	result2 = line1[x+RGBA_BLUE];
	result11 = line0[x1+RGBA_BLUE];
	result12 = line1[x1+RGBA_BLUE];
	left  = result1  + (result2 -result1 )*fracty;
	right = result11 + (result12-result11)*fracty;
	*p->ka = left + (right-left)*fractx;
}


extern "C" void bmoscil_set(BMOSCIL *p)
{
	int ihandle = (int) *p->ihandle;
	Bm_image_iterator = Bm_image.find(ihandle);
	if(Bm_image_iterator == Bm_image.end()) {  // ihandle does't exist
		initerror("bmoscil:invalid picture number");
		return;
	}
	CAnyBmp * bmp = (CAnyBmp*) Bm_image[ihandle].bmpObj;
	p->LineArray = bmp->GetLineArray();
	p->width = bmp->GetWidth();
	p->height = bmp->GetHeight();
	p->Xphase = *p->kxphs;
	p->Yphase = *p->kyphs;
	p->flag=1;
}
	

extern "C" void bmoscil(BMOSCIL *p)
{
	int x;
	MYFLT Xphase = p->Xphase, Yphase = p->Yphase;
	int ktrig_xphreset = *p->ktrig_xphreset;
	int ktrig_yphreset = *p->ktrig_yphreset;
	if (p->flag) {
		p->flag = 0;
		goto firstime;
	}
	if (*p->ktrig) {
		Xphase += *p->kxinc;
		while(Xphase >= p->width) Xphase -= p->width;
		while(Xphase < 0.0f )	  Xphase += p->width;	
		
		Yphase += *p->kyinc;
		while(Yphase >= p->height) Yphase -= p->height;
		while(Yphase < 0.0f )	   Yphase += p->height;
	}
	if (ktrig_xphreset) Xphase =  *p->kxphs;
	if (ktrig_yphreset) Yphase =  *p->kyphs;
firstime:
	x= ((int) Xphase) * 4;
	BYTE *line = p->LineArray[(int) Yphase];
	*p->kr = line[x+RGBA_RED];
	*p->kg = line[x+RGBA_GREEN];
	*p->kb = line[x+RGBA_BLUE];
	*p->ka = line[x+RGBA_ALPHA];
	p->Xphase = Xphase; 
	p->Yphase = Yphase;
}

extern "C" void bmoscili(BMOSCIL *p)
{
	int x;
	MYFLT Xphase = p->Xphase, Yphase = p->Yphase;
	int ktrig_xphreset = *p->ktrig_xphreset;
	int ktrig_yphreset = *p->ktrig_yphreset;
	if (p->flag) {
		p->flag = 0;
		goto firstime;
	}
	if (*p->ktrig) {
		Xphase += *p->kxinc;
		while(Xphase >= p->width) Xphase -= p->width;
		while(Xphase < 0.0f )	  Xphase += p->width;	

		Yphase += *p->kyinc;
		while(Yphase >= p->height) Yphase -= p->height;
		while(Yphase < 0.0f )	   Yphase += p->height;
	}
	if (ktrig_xphreset) Xphase =  *p->kxphs;
	if (ktrig_yphreset) Yphase =  *p->kyphs;
firstime:

	x= (int) Xphase;
	int y= (int) Yphase;
	MYFLT fractx = Xphase - x, fracty = Yphase - y;
	MYFLT result1, result2, result11, result12, left, right;
	BYTE *line0 = p->LineArray[y];
	BYTE *line1 = p->LineArray[y+1];
	int x1=(x+1)*4;
	x*=4;

	result1 = line0[x+RGBA_RED];
	result2 = line1[x+RGBA_RED];
	result11 = line0[x1+RGBA_RED];
	result12 = line1[x1+RGBA_RED];
	left  = result1  + (result2 -result1 )*fracty;
	right = result11 + (result12-result11)*fracty;
	*p->kr = left + (right-left)*fractx;

	result1 = line0[x+RGBA_GREEN];
	result2 = line1[x+RGBA_GREEN];
	result11 = line0[x1+RGBA_GREEN];
	result12 = line1[x1+RGBA_GREEN];
	left  = result1  + (result2 -result1 )*fracty;
	right = result11 + (result12-result11)*fracty;
	*p->kg = left + (right-left)*fractx;

	result1 = line0[x+RGBA_BLUE];
	result2 = line1[x+RGBA_BLUE];
	result11 = line0[x1+RGBA_BLUE];
	result12 = line1[x1+RGBA_BLUE];
	left  = result1  + (result2 -result1 )*fracty;
	right = result11 + (result12-result11)*fracty;
	*p->kb = left + (right-left)*fractx;

	result1 = line0[x+RGBA_BLUE];
	result2 = line1[x+RGBA_BLUE];
	result11 = line0[x1+RGBA_BLUE];
	result12 = line1[x1+RGBA_BLUE];
	left  = result1  + (result2 -result1 )*fracty;
	right = result11 + (result12-result11)*fracty;
	*p->ka = left + (right-left)*fractx;


	p->Xphase = Xphase; 
	p->Yphase = Yphase;
}

static inline MYFLT MAX(MYFLT v1, MYFLT v2, MYFLT v3)
{ 
	if (v1 > v2 && v1 > v3) return(v1);
	if (v2 > v3) return(v2);
	return(v3);
}

static inline MYFLT MIN(MYFLT v1, MYFLT v2, MYFLT v3)
{ 
	if (v1 < v2 && v1 < v3) return(v1);
	if (v2 < v3) return(v2);
	return(v3);
}

//inspired from rgb2hsv of mark danks' GEM
extern "C" void rgb2hsvl(RGB2HSVL *p)
{
	MYFLT h, s, v;
	MYFLT r= *p->r * ONEup255, g= *p->g * ONEup255, b= *p->b * ONEup255;

	MYFLT max = MAX(r, g, b);
	MYFLT min = MIN(r, g, b);
	v = max;		// the value
	if (max != 0.0f) s = (max - min) / max; // calculate saturation
	else			 s = 0.0f;

	if (s == 0.0f)	 h = 0.0f; // hue is undefined if no saturation	
	else		
	{		// chromatic case - calculate hue
		MYFLT delta = max - min;
		if (r == max) h = (g - b) / delta;	// between magenta and cyan
		else if (g == max)	h = 2.0f + (b - r) / delta;			// between yellow and magenta
		else if (b == max)	h = 4.0f + (r - g) / delta;					// between cyan and yellow
		h *= 60.0f; // convert hue to degrees
		if (h < 0.0) h += 360.f; // make sure hue is nonnegative
		h /= 360.f;		// normalize hue
	}
	*p->hue=h;
	*p->sat=s;
	*p->val=v;
	*p->lum=(r+g+b) * .333333333333333f; //normalize luminance 0 to 1
}


extern "C" void bmscan_set(BMSCAN *p)
{
	int ihandle = (int) *p->ihandle;
	FUNC *ftp;
	Bm_image_iterator = Bm_image.find(ihandle);
	if(Bm_image_iterator == Bm_image.end()) {  // ihandle does't exist
		initerror("bmoscil:invalid picture number");
		return;
	}
	CAnyBmp * bmp = (CAnyBmp*) Bm_image[ihandle].bmpObj;
	p->LineArray = bmp->GetLineArray();
	p->width = bmp->GetWidth();
	p->height = bmp->GetHeight();

	if (*p->ihorLines >0)
		p->flag=1;
	else {
		p->flag=0;
		if ((ftp = ftfind(p->ihorLines)) != NULL) 
			p->ftpLines = ftp->ftable;
	}
	if ((ftp = ftfind(p->ifnR)) != NULL)
		p->ftpR = ftp->ftable;
	if ((ftp = ftfind(p->ifnG)) != NULL)
		p->ftpG = ftp->ftable;
	if ((ftp = ftfind(p->ifnB)) != NULL) 
		p->ftpB = ftp->ftable;
}

extern "C" void bmscan(BMSCAN *p)
{
	int j,k;
	int height = (int) p->height, width = (int) p->width;
	BYTE ** LineArray = p->LineArray;
	int x = (int) *p->kphs;
	MYFLT *ftpR = p->ftpR, *ftpG= p->ftpG,*ftpB = p->ftpB;
	while (x  >= width) x  -= width;
	x *=4;

	if(p->flag) {
		int horLines = (int) *p->ihorLines;
		horLines = (horLines > 0) ? horLines : 1;
		for (j = (int) *p->istartLine, k=0 ; j <height; j+= horLines, k++) {
			BYTE *line = LineArray[height-j-1];
			ftpR[k] = line[x+RGBA_RED]; 
			ftpG[k] = line[x+RGBA_GREEN];
			ftpB[k] = line[x+RGBA_BLUE]; 
		}
	}
	else {
		MYFLT *ftpLines =p->ftpLines;
		k=0;
		do {
			j = (int) ftpLines[k];
			BYTE *line = LineArray[height-j-1];
			ftpR[k] = line[x+RGBA_RED]; 
			ftpG[k] = line[x+RGBA_GREEN];
			ftpB[k] = line[x+RGBA_BLUE];
			k++;
		} while (j <height) ;
	}
}


extern "C" void bmscani(BMSCAN *p)
{
	int j,k;
	int height = (int) p->height, width = (int) p->width;
	BYTE ** LineArray = p->LineArray;
	int x= (int) *p->kphs;
	int x1=x+1;
	MYFLT fract = *p->kphs -x;
	//int x = ((int) *p->kphs) * 4;
	MYFLT *ftpR = p->ftpR, *ftpG= p->ftpG,*ftpB = p->ftpB;
	MYFLT result1,result2;
	while (x  >= width) 
		x  -= width;
	while (x1 >= width) 
		x1 -= width;
	x *= 4;
	x1*= 4;
	if(p->flag) {
		int horLines = (int) *p->ihorLines;
		horLines = (horLines > 0) ? horLines : 1;
		for (j = (int) *p->istartLine, k=0 ; j <height; j+= horLines, k++) {
			BYTE *line = LineArray[height-j-1];

			result1 = line[x+RGBA_RED]; 
			result2 = line[x1+RGBA_RED]; 
			ftpR[k] = result1 + (result2 - result1 )*fract;

			result1 = line[x+RGBA_GREEN];
			result2 = line[x1+RGBA_GREEN]; 
			ftpG[k] = result1 + (result2 - result1 )*fract;

			result1 = line[x+RGBA_BLUE]; 
			result2 = line[x1+RGBA_BLUE]; 
			ftpB[k] = result1 + (result2 - result1 )*fract;
		}
	}
	else {
		MYFLT *ftpLines =p->ftpLines;
		k=0;
		do {
			j = (int) ftpLines[k];
			BYTE *line = LineArray[height-j-1];

			result1 = line[x+RGBA_RED]; 
			result2 = line[x1+RGBA_RED]; 
			ftpR[k] = result1 + (result2 - result1 )*fract;

			result1 = line[x+RGBA_GREEN];
			result2 = line[x1+RGBA_GREEN]; 
			ftpG[k] = result1 + (result2 - result1 )*fract;

			result1 = line[x+RGBA_BLUE]; 
			result2 = line[x1+RGBA_BLUE]; 
			ftpB[k] = result1 + (result2 - result1 )*fract;
			k++;
		} while (j <height) ;
	}
}


