
typedef struct	{
	OPDS	h;
	MYFLT	*out1, *out2, *amp, *freq, *kloop, *kend, *ift, *iphs;
	//FUNC	*ftp;
	long	tablen;
	MYFLT	fsr;
	short *ft; //table
	double	phs, fsrUPsr /* , looplength */;
	long	phs_int;
} LPOSC_ST;

