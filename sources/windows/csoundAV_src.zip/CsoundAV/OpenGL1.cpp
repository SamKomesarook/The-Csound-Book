#include "widg.h"


#include <GL/gl.h>
#include <GL/glu.h>

extern "C" {
	#undef __cplusplus
	#include "cs.h"
	#include "OpenGL1.h"
	#define __cplusplus
}

using namespace std;

template <class T, class A = alloc> class list2 : public list<T,A> {
public:
	typedef list <T,A>::iterator iterator ;

	reference operator[](size_type n) { // returns value of nth element 
		iterator it = begin();
		if (n >= size()) return back();
		while (n--) it++;
		return *it;
	}
	iterator end_1() { // returns last valid iterator
		iterator it = end();
		return --it;
	}
};

extern "C"  int isFLTKenabled;
			int update_interval=40;
			int update_interval_resolution =10;

			double	GLperiod;
extern "C"	long	kcounter;
			double	FrameCounter;
			long	FrameDiff;

#ifdef WIN32
	extern HWND callback_target;
#endif

static long mapIndex=0;
typedef vector<OPDS*> OPDSvectType;
OPDSvectType currVect;  // current main flow OPDS structure vector containing OpenGL function addresses

GLfloat	fAspect;

static MYFLT currPosLevel;

struct OPDSvectPosType {
	list<OPDSvectType>::iterator it;
	int level;
};

static inline bool posPredicate(vector<OPDS*>& curr) {
	return curr[0]->GLposLevel > currPosLevel;
}

inline void wait_semaphore(bool& red) {
	while(red) {
		#ifdef WIN32
			Sleep(0);
		#elif defined(LINUX) or defined(SOMEOTHERUNIX)
			....insert some code for idle waiting here...
		#endif
	}
}

static map<long, OPDSvectPosType> vposMap;
static list2<OPDSvectType> VectList_1, VectList_0, VectList;
static bool host_semaphore, callback_semaphore;

bool OpenGL_enabled=false;
bool OpenGL_init_stage = true;

static MYFLT GLratio=1;

class FL_GL_WINDOW: public Fl_Gl_Window 
{
public:
	void draw()
	{
		static long ActualFrameCount;
		wait_semaphore(host_semaphore);
		callback_semaphore = true;
		list2<OPDSvectType>::iterator j;

		if (OpenGL_init_stage) {
			FrameCounter = 0;

			#ifdef WIN32
			{
				BOOL nRet;
				nRet = SetThreadPriority( GetCurrentThread(), THREAD_PRIORITY_NORMAL - 1 );
			}	
			#endif
			glPushAttrib(GL_ALL_ATTRIB_BITS);
			mode(FL_DEPTH|FL_RGB|FL_DOUBLE);
			bool test =  VectList_1.begin() == VectList_1.end()	;
			for(j=VectList_1.begin(); j !=  VectList_1.end(); j++) {
				OPDSvectType& v =  *j;
				for (int k = 0; k< (const int) v.size(); k++) {
					 OPDS *pds = v[k];
					 (*pds->GLadr)(pds);
				}
			}
			invalidate();
			OpenGL_init_stage = false;
		}
		
		//FrameDiff = FrameCounter - ActualFrameCount;
		
		if (!valid()) {

			glViewport(0, 0, w(), h());
			fAspect = GLratio * (GLfloat)w()/(GLfloat)h();

			for(j=VectList_0.begin(); j != VectList_0.end(); j++) {
				OPDSvectType& v =  *j;
				for (int k = 0; k< (const int) v.size(); k++) {
					 OPDS *pds = v[k];
					 (*pds->GLadr)(pds);
				}
			}
		}
		
		for(j=VectList.begin(); j != VectList.end(); j++) {
			OPDSvectType& v =  *j;
			for (int k = 0; k< (const int) v.size(); k++) {
				 OPDS *pds = v[k];
				 (*pds->GLadr)(pds);
			}
		}
		
		if (FrameDiff) {
			FrameDiff = 0;
			ActualFrameCount = FrameCounter;
		}
		//++ActualFrameCount;
		callback_semaphore = false;
	}

	FL_GL_WINDOW(int W, int H, const char *l=0) : Fl_Gl_Window(W,H,l) {}
	FL_GL_WINDOW(int X, int Y, int W, int H, const char *l=0) : Fl_Gl_Window(X,Y,W,H,l) {}

};

FL_GL_WINDOW  *GLwindow;

MMRESULT FL_TimId=NULL;

int Frame_thread_exit=1;


#ifdef RESET

void OpenGL_RESET2 () {
	OpenGL_enabled=false;
	
	#ifdef WIN32
	Sleep(100);
	#endif
	host_semaphore=true;
	callback_semaphore= false;
	timeKillEvent( FL_TimId );
	FL_TimId = NULL;
	mapIndex=0;
	update_interval=40;
	update_interval_resolution =10;
	vposMap.clear();
	VectList_1.clear();
	VectList_0.clear();
	VectList.clear();
	FrameCounter = 0;
	GLratio = 1;
	#ifdef WIN32
	Sleep(100);
//	Frame_threadHandle = 0;
	Frame_thread_exit =1;
	#endif
}
#endif



//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

#ifdef WIN32
#include "soundio.h"
#include <time.h>

extern unsigned long initial_CS_time;



extern double frame_millisec;
extern void frame_timer_init(void);
extern void do_frames_timing(void);

static void __cdecl frame_loop(void *s)
{
	frame_timer_init();
	do {
		if (OpenGL_enabled && !callback_semaphore) 
			GLwindow->redraw();
		if (callback_target) 
			PostMessage(callback_target,0,0,0); //bogus message to make thread to react
		do_frames_timing();
		//FrameCounter = (timeGetTime() - initial_CS_time) / frame_millisec;
		++FrameCounter;
		if(Frame_thread_exit) return;
	} while (1);
}

extern "C" {
	extern int sleep_flag;
	extern void PlayDsoundSleep(char *outbuf, int nbytes);
	extern void set_current_process_priority_critical(void);
	extern void    (*audtran)(char *, int);
}
#ifdef GAB_WIN
extern "C" void  checkSleepBox(void);
#endif
extern "C" void GLfps(GLPERIOD *p)
{	

	if (O.informat != AE_NO_AUDIO) {
		sleep_flag=TRUE;
		audtran =  PlayDsoundSleep;
		set_current_process_priority_critical();
#ifdef GAB_WIN
		checkSleepBox();
#endif
	}

	GLperiod = ekr / *p->ifps;
	frame_millisec = 1000.0 / *p->ifps;
    _beginthread(frame_loop, 0, NULL);
	Frame_thread_exit = 0;
}


#elif defined(LINUX) || defined(someOtherUnix)
	...add code for TimerProc here...
	...add code for GLfps here...
#endif

extern "C" void GLredraw(GL_ONEARG *p)
{	
	if (*p->arg && OpenGL_enabled) {
			FLlock();
			GLwindow->redraw();
			FLunlock();


#ifdef WIN32
		if (callback_target) {
			PostMessage(callback_target,0,0,0); //bogus message to make thread to react
		}
#endif

	}
//	++FrameCounter;
}



//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@


extern int FLstack_count;
extern vector<PANELS> fl_windows; // all panels
extern vector<ADDR_STACK> AddrStack; //addresses of containers 
extern void widget_attributes(Fl_Widget *o);

extern "C" void GLpanel(GL_PANEL *p)
{   
	isFLTKenabled = 1;
	char* panelName = GetString(*p->name,p->STRARG);
	
	int x = *p->ix, y =*p->iy, width = *p->iwidth, height=*p->iheight;
	if(width <0) width = 400; //default
	if(height <0) height = 300;

	int borderType;
	switch( (int) *p->border ) {
		case 0: borderType = FL_FLAT_BOX; break;
		case 1: borderType = FL_DOWN_BOX; break;
		case 2: borderType = FL_UP_BOX; break;
		case 3:	borderType = FL_ENGRAVED_BOX; break;
		case 4:	borderType = FL_EMBOSSED_BOX; break;
		case 5:	borderType = FL_BORDER_BOX; break;
		case 6:	borderType = FL_THIN_DOWN_BOX; break;
		case 7:	borderType = FL_THIN_UP_BOX; break;
		default: borderType = FL_FLAT_BOX;
	}
	
	Fl_Window *o;
	if(x < 0) o = GLwindow = new FL_GL_WINDOW(width,height, panelName);
	else 	o = GLwindow = new FL_GL_WINDOW(x,y,width,height, panelName);

	o->box((Fl_Boxtype) borderType);
	o->resizable(o);

 	widget_attributes(o);
#ifdef GAB_WIN //sets the OpenGL window icon
	o->icon((char *)LoadIcon(hProcessInstance, MAKEINTRESOURCE(IDI_GL_ICON)));
#endif
	ADDR_STACK adrstk(&p->h, (void *) o, FLstack_count);
	AddrStack.push_back(adrstk);
	PANELS panel(o, (FLstack_count>0) ? 1 : 0);
	fl_windows.push_back(panel);
	FLstack_count++;
}

extern "C" void EndGLpanel(GL_NOARG *p)
{
	FLstack_count--;
	ADDR_STACK adrstk = AddrStack.back();
	if (strcmp( adrstk.h->optext->t.opcod, "GLpanel")) {
		initerror("FLpanel_end: invalid stack pointer: verify its placement"); 
		return;
	}
	if(adrstk.count != FLstack_count) {
		initerror("FLpanel_end: invalid stack count: verify GLpanel/GLpanel_end count and placement");
		return;
	}
	((Fl_Window*) adrstk.WidgAddress)->end();
	AddrStack.pop_back();
}


extern "C" void GLinsert_i(GL_INSERT *p) {
	
	MYFLT p3 = p->h.insdshead->p3;
	//currVect.clear();
	if (p3 <=0) {
		p->p3type=1; //midi activated
		p->relesing_flag=0;
		short *xtra;
		if (*(xtra = &(p->h.insdshead->xtratim)) < 4 )  // is 2 sufficient?
			*xtra = 4;
		p->kcounterEnd = LONG_MAX;
	}
	else {
		p->p3type=0;
		p->kcounterEnd = kcounter + p3 * ekr - 2; // is 2 sufficient?
	}
	list2<OPDSvectType>::iterator it;
	if (currVect.size() > 0)
		currVect[0]->GLposLevel= currPosLevel= *p->pos_level;

	switch((int) *p->pos_level) {
		case -1:
			wait_semaphore(callback_semaphore); //wait for any operation in OpenGL thread ends
			host_semaphore=true; // avoid any OpenGL operation to begin at this moment
			VectList_1.push_back(currVect);
			it = VectList_1.end_1();
			host_semaphore=false;
			OpenGL_init_stage = true;

			break;
		case 0:
			wait_semaphore(callback_semaphore); //wait for any operation in OpenGL thread ends
			host_semaphore=true; // avoid  any OpenGL operation to begin at this moment
			VectList_0.push_back(currVect);
			host_semaphore=false;
			it = VectList_0.end_1();
			break;
		default:
			list2<OPDSvectType>::iterator it2;
			it2 = find_if(VectList.begin(), VectList.end(), posPredicate);
			wait_semaphore(callback_semaphore); //wait for any operation in OpenGL thread ends
			host_semaphore=true; // avoid any OpenGL operation to begin at this moment
			it = VectList.insert(it2, currVect);
			host_semaphore=false;
			
			break;
	}

	OPDSvectPosType vpos;
	vpos.it = it;
	vpos.level = (int) *p->pos_level;

	vposMap[mapIndex] = vpos;
	p->vectorID = mapIndex;
	mapIndex++;
	OpenGL_enabled=true;
	currVect.clear();
	p->done_flag=1;
}

extern "C" void GLinsert(GL_INSERT *p) {
	if (p->p3type) { 
		if (p->h.insdshead->relesing && !(p->relesing_flag)) {//midi activated
			p->relesing_flag=1;
			p->kcounterEnd = kcounter + p->h.insdshead->xtratim - 2;
		}
	}
	if (kcounter >= p->kcounterEnd && p->done_flag) {
		switch((int) *p->pos_level) {
		case -1:
			wait_semaphore(callback_semaphore); //wait for any operation in OpenGL thread ends
			host_semaphore=true; // avoid  any OpenGL operation to begin at this moment
			VectList_1.erase(vposMap[p->vectorID].it);
			host_semaphore=false;
			break;
		case 0:
			wait_semaphore(callback_semaphore); //wait for any operation in OpenGL thread ends
			host_semaphore=true; // avoid  any OpenGL operation to begin at this moment
			VectList_0.erase(vposMap[p->vectorID].it);
			host_semaphore=false;
			
			break;
		default:
			wait_semaphore(callback_semaphore); //wait for any operation in OpenGL thread ends
			host_semaphore=true; // avoid  any OpenGL operation to begin at this moment
			VectList.erase(vposMap[p->vectorID].it);
			host_semaphore=false;
			break;
		}
		p->done_flag=0;
	}
}


//-----------------------
//void glfullscreen(GL_FULLSCREEN *p) {
extern "C" void GLfullscreen(GL_FULLSCREEN *p) {
	FLlock();
	if (*p->flag) {
		p->px=	GLwindow->x();
		p->py=	GLwindow->y();
		p->pw=	GLwindow->w();
		p->ph=	GLwindow->h();

		GLwindow->fullscreen();
	}
	else 
	  GLwindow->fullscreen_off(p->px,p->py,p->pw,p->ph);
	
	GLwindow->valid(0);
	//GLwindow->valid(0);
	FLunlock();
#ifdef WIN32
		//Sleep(100);
	if (callback_target) {
			PostMessage(callback_target,0,0,0); //bogus message to make thread to react
	}
#endif
}
//extern "C" void GLfullscreen(GL_FULLSCREEN *p) {	INIT_F(glfullscreen) }


extern "C" void wait_GL_INIT(GL_NOARG *p) {
	while (OpenGL_init_stage) 
		Sleep(20);
}

extern "C" void set_GLratio(GL_TWOARGS *p) {
	GLratio = *p->arg1; 
	if(*p->arg2){
		FLunlock();
		GLwindow->valid(0);
		FLunlock();
	}
}


