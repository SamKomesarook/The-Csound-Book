typedef	struct {
  OPDS	h;
  MYFLT	*r1, *ifilno;
} SNDINFO;

typedef	struct {
  OPDS	h;
  MYFLT	*r1, *ifilno, *channel;
} SNDINFOPEAK;
