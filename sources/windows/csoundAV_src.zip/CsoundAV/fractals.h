typedef struct	{
	OPDS	h;
	MYFLT	*kr, *koutrig,  *ktrig, *kx, *ky, *kmaxIter;
	MYFLT oldx, oldy;
	int oldCount;
} MANDEL;


typedef struct {
	OPDS    h;
	MYFLT   *ktrig, *kreinit, *ioutFunc, *initStateFunc, *iRuleFunc, *ielements, *irulelen, *iradius;
	MYFLT	*currLine, *outVec, *initVec, *ruleVec;
	int	elements, NewOld, ruleLen;
	AUXCH   auxch;
} CELLA; 




