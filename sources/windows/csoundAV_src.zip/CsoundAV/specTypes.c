#include "cs.h"         /*                                      SPECTRA.C       */
#include <math.h>
#include "cwindow.h"
#include "spectra.h"
#include "specTypes.h"

/*
typedef struct {
	MYFLT   *begp, *curp, *endp, feedback[6];
	long    scount;
} OCTDAT;

#define MAXOCTS 8

typedef struct {
	long	npts, nocts, nsamps;
	MYFLT   lofrq, hifrq, looct, srate;
	OCTDAT  octdata[MAXOCTS];
	AUXCH	auxch;
} DOWNDAT;

typedef struct {
	long	ktimstamp, ktimprd;
	long	npts, nfreqs, dbout;
	DOWNDAT *downsrcp;
	AUXCH	auxch;
} SPECDAT;

typedef struct {
	long	windid;			// set by MakeGraph() 
	MYFLT   *fdata;			// data passed to DrawGraph 
	long    npts;			// size of above array 
	char    caption[CAPSIZE];	// caption string for graph 
	short   waitflg;		// set =1 to wait for ms after Draw 
	short	polarity;		// controls positioning of X axis 
	MYFLT   max, min;		// workspace .. extrema this frame 
	MYFLT	absmax;			// workspace .. largest of above 
	MYFLT   oabsmax;		// Y axis scaling factor 
	int	danflag;		// set to 1 for extra Yaxis mid span 
} WINDAT;

typedef struct {
	OPDS	h;
	SPECDAT *wsig;
	MYFLT	*iprd, *iwtflg;
	int     countdown, timcount;
	WINDAT  dwindow;
} SPECDISP;

*/

static char *getstrdbout(int dbcode)
{
    static char *outstring[] = {"mag", "db", "mag sqrd", "root mag"};
    switch (dbcode) {
    case 0:
    case 1:
    case 2:
    case 3:
		return(outstring[dbcode]);
    default:
		return(Str(X_1331,"unknown dbcode"));
    }
}


void specinfo(SPECINFO *p) {
	SPECDAT *specp;
	DOWNDAT *downp;
    if (p->wsig->auxch.auxp==NULL) {
		initerror(Str(X_1219,"specdisp: not initialized"));
		return;
    }
	specp = p->wsig;
	downp = specp->downsrcp;
	if (downp->lofrq > 5.) {
		printf(	"instr %d %s, dft (%s), %ld octaves (%d - %d Hz)  %ld points\n",
			p->h.insdshead->insno, p->STRARG, getstrdbout(specp->dbout),
			downp->nocts, (int)downp->lofrq, (int)downp->hifrq, specp->npts);
		
	}
	else {                      /* more detail if low frequency  */
		printf(	"instr %d %s, dft (%s), %ld octaves (%3.1f - %3.1f Hz) %ld points\n",
			p->h.insdshead->insno, p->STRARG, getstrdbout(specp->dbout),
			downp->nocts, downp->lofrq, downp->hifrq, specp->npts);
	}
	*p->ipoints  = (MYFLT) specp->npts;
	*p->iminfreq = downp->lofrq;
	*p->imaxfreq = downp->hifrq;
}





void spec2table_set(SPEC2TABLE *p)
{
	FUNC *ftp;
    if ((ftp = ftfind(p->ifnout)) == NULL) {
		  initerror("sdispdata: incorrect table number");
          return;
	}
	p->table = ftp->ftable;
    if (p->wsig->auxch.auxp==NULL) {
		initerror(Str(X_1219,"sdispdata: w var not initialized"));
		return;
    }
	p->sourcedata = (MYFLT *) p->wsig->auxch.auxp;
	if (*p->inumelem <= 0) p->count =  p->wsig->npts;
	else                   p->count =  (long) *p->inumelem;

	if (*p->kfilter >= 0) { 
		auxalloc (p->count * sizeof(MYFLT) , &p->filterStuff);
		p->yt1 = (MYFLT *) p->filterStuff.auxp;
	}
}

void spec2table(SPEC2TABLE *p)
{
		long j,	count = p->count;
		MYFLT *out = p->table, *source = p->sourcedata;
		if (*p->kfilter >=0) {
			MYFLT  *yt1= p->yt1, c1, c2;
			if (*p->kfilter != p->prvhp) {
				double b;
				p->prvhp = *p->kfilter;
				b = 2.0 - cos((double)(*p->kfilter * tpidsr * ksmps));
				c2 = p->c2 = (MYFLT) ( b - sqrt(b * b - 1.0) );
				c1 = p->c1 = FL(1.0) - c2;
			}
			else {
				c1 = p->c1;
				c2 = p->c2;
			}
			for(j = (int) *p->istartoffset; j< count; j++) {
				*out++ = *yt1++ = c1 * *source++ + c2 * *yt1;
			}
		}
		else {
			for(j = (int) *p->istartoffset; j< count; j++) {
				*out++ = *source++;
			}
		}
}
