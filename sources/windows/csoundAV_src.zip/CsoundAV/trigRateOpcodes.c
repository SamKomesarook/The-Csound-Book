#include "cs.h"
#include <math.h>
#include "trigRateOpcodes.h"
#include "uggab.h"
#include "newopcodes.h"


void trRangeRand(TRANGERAND *p) { /* gab d5*/
	if(*p->ktrig)
		*p->out = randGab * (*p->max - *p->min) + *p->min;
}
