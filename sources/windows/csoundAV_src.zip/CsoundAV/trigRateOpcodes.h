typedef struct	{	/* gab d5*/
	OPDS	h;
	MYFLT	*out, *ktrig, *min, *max;
} TRANGERAND;
