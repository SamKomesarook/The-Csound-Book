#include <windows.h>
#include<mmsystem.h>
#include "cs.h"

static double millisec;
static double ktime;
extern "C" MYFLT ekr;
static double frame_time;
double frame_millisec;

extern "C" void do_events_timing(void) 
{
	ktime += millisec;
	while (timeGetTime() < ktime ) {
		Sleep(1);
  }
}

extern "C" void do_events_timing_zero(long kcnt) 
{
	ktime += millisec*kcnt;
	while (timeGetTime() < ktime ) {
		Sleep(1);
  }
}

extern "C" void timer_init(void)
{
	millisec = 1000/ekr;
	ktime = timeGetTime();
}


void frame_timer_init(void)
{
	//millisec = 1000/ekr;
	frame_time = timeGetTime();
}

void do_frames_timing(void) 
{
	frame_time += frame_millisec;
	while (timeGetTime() < frame_time ) {
		Sleep(1);
  }
}



