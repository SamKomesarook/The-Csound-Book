#include <windows.h>
#include <string.h>
#include "resource.h" 
#include "cs.h"
int flStartStop;
extern void gab_printf(char *s,...);
void (*cwin_printf)(char *s,...);
int  (*cwin_putchar)(int c);
HINSTANCE hProcessInstance;


#ifdef VST
long VSTblock_size;
float VSTsampleRate;
int VSTblockRatio, CheckVstBuffer, ndxVstBuffer;
float *spoutVST, *spinVST;
#endif


void null_printf(char *s,...)
{
}

int null_putchar(int c)
{
	return c;
}

extern int sleep_flag;
extern int  segamps, sormsg;
extern short rngflg;
HWND MainDialogHandle;
void (*err_printf)(char *s,...);
void setBufScroll(int value);
int xCurrentScroll;   // current horizontal scroll value 
int gab_putch(int c); 

void EnableDisplay(){
	cwin_printf = gab_printf;
	cwin_putchar = gab_putch;
	err_printf = gab_printf;
	O.msglevel = 0x7f;
	segamps = 1;
	sormsg =1;
	rngflg=1;
}

void DisableDisplay(){
	cwin_printf= null_printf;
	cwin_putchar = null_putchar;
	err_printf = null_printf;
	O.msglevel = 0;
	segamps = 0;
	sormsg =0;
	rngflg=0;
}

void SetConWinParms()
{
	SCROLLINFO scroll;
	char stringa[MAXNAME];
	scroll.cbSize=sizeof(SCROLLINFO); 
	scroll.fMask=SIF_ALL; 
	scroll.nMin=2; 
	scroll.nMax=1500; 
	scroll.nPage=10; 
	xCurrentScroll=scroll.nPos=O.outbufsamps; 
	SetDlgItemText(MainDialogHandle,idcBufferLabel,itoa(scroll.nPos,stringa,10));
	SendDlgItemMessage(MainDialogHandle, idcBufferScrollBar, 	 
	SBM_SETSCROLLINFO  , 
	(WPARAM) TRUE, (LPARAM) &scroll);
	if (sleep_flag)
		CheckDlgButton( MainDialogHandle,idcSleep, BST_CHECKED);
	else
		CheckDlgButton( MainDialogHandle,idcSleep, BST_UNCHECKED);
				
}


char * BakArguments[MAXCMDLINE];
char *OrcFile;
char *ScoFile;
char *WavFile;
//char *OrcPath;
//char *ScoPath;
//char *WavPath;
char *LastFlags;

extern char *SFdir;
char *SAdir;
char *SSdir;
char *INCdir;
char *IMGdir;
char *SNAPdir;
char *EDITpath;

int	maxCurrArgs; 


void RegistrySet() 
{
	LONG nRet;
	nRet=RegSetValue(HKEY_CURRENT_USER, "Software\\CsoundAV\\LastFlags", REG_SZ, LastFlags, strlen(LastFlags));
	nRet=RegSetValue(HKEY_CURRENT_USER, "Software\\CsoundAV\\OrcFile", REG_SZ, unquote(OrcFile), strlen(OrcFile));
	nRet=RegSetValue(HKEY_CURRENT_USER, "Software\\CsoundAV\\ScoFile", REG_SZ, unquote(ScoFile), strlen(ScoFile));
	nRet=RegSetValue(HKEY_CURRENT_USER, "Software\\CsoundAV\\WavFile", REG_SZ, unquote(WavFile), strlen(WavFile));

	nRet=RegSetValue(HKEY_CURRENT_USER, "Software\\CsoundAV\\SFdir", REG_SZ, unquote(SFdir), strlen(SFdir));
	nRet=RegSetValue(HKEY_CURRENT_USER, "Software\\CsoundAV\\SAdir", REG_SZ, unquote(SAdir), strlen(SAdir));
	nRet=RegSetValue(HKEY_CURRENT_USER, "Software\\CsoundAV\\SSdir", REG_SZ, unquote(SSdir), strlen(SSdir));
	nRet=RegSetValue(HKEY_CURRENT_USER, "Software\\CsoundAV\\INCdir", REG_SZ, unquote(INCdir), strlen(INCdir));
	nRet=RegSetValue(HKEY_CURRENT_USER, "Software\\CsoundAV\\IMGdir", REG_SZ, unquote(IMGdir), strlen(IMGdir));
	nRet=RegSetValue(HKEY_CURRENT_USER, "Software\\CsoundAV\\SNAPdir", REG_SZ, unquote(SNAPdir), strlen(SNAPdir));
	nRet=RegSetValue(HKEY_CURRENT_USER, "Software\\CsoundAV\\EDITpath", REG_SZ, unquote(EDITpath), strlen(EDITpath));

}																					  

void RegistryGet() 
{
	LONG nRet, size=MAXNAME;
	char buf[MAXNAME];	  
	nRet=RegQueryValue(HKEY_CURRENT_USER, "Software\\CsoundAV\\LastFlags", LastFlags, &size); size=MAXNAME;
	nRet=RegQueryValue(HKEY_CURRENT_USER, "Software\\CsoundAV\\OrcFile", OrcFile, &size); size=MAXNAME;
	nRet=RegQueryValue(HKEY_CURRENT_USER, "Software\\CsoundAV\\ScoFile", ScoFile, &size); size=MAXNAME;
	nRet=RegQueryValue(HKEY_CURRENT_USER, "Software\\CsoundAV\\WavFile", WavFile, &size); size=MAXNAME;
	nRet=RegQueryValue(HKEY_CURRENT_USER, "Software\\CsoundAV\\SFdir", SFdir, &size); size=MAXNAME;
	nRet=RegQueryValue(HKEY_CURRENT_USER, "Software\\CsoundAV\\SAdir", SAdir, &size); size=MAXNAME;
	nRet=RegQueryValue(HKEY_CURRENT_USER, "Software\\CsoundAV\\SSdir", SSdir, &size); size=MAXNAME;
	nRet=RegQueryValue(HKEY_CURRENT_USER, "Software\\CsoundAV\\INCdir", INCdir, &size); size=MAXNAME;
	nRet=RegQueryValue(HKEY_CURRENT_USER, "Software\\CsoundAV\\IMGdir", IMGdir, &size); size=MAXNAME;
	nRet=RegQueryValue(HKEY_CURRENT_USER, "Software\\CsoundAV\\SNAPdir", SNAPdir, &size); size=MAXNAME;
	nRet=RegQueryValue(HKEY_CURRENT_USER, "Software\\CsoundAV\\EDITpath", EDITpath, &size);
	sprintf(buf,"SFDIR=%s", SFdir);	putenv(buf);
	sprintf(buf,"SADIR=%s", SAdir);	putenv(buf);
	sprintf(buf,"SSDIR=%s", SSdir);	putenv(buf);
	sprintf(buf,"INCDIR=%s", INCdir);	putenv(buf);
	sprintf(buf,"IMGDIR=%s", IMGdir);	putenv(buf);
	sprintf(buf,"SNAPDIR=%s", SNAPdir);	putenv(buf);
	sprintf(buf,"CSEDITOR=%s", EDITpath);	putenv(buf);
}

void reset_all()
{
	extern void gab_midi_exit();
	extern void gab_midi_out_exit();
	extern void cscoreRESET(void);
	extern void expRESET(void);
	extern void ftRESET(void);
	extern void insertRESET(void);
	extern void memRESET(void);
	extern void musRESET(void);
	extern void oloadRESET(void);
	extern void tranRESET(void);
	extern void orchRESET(void);
	extern void soundinRESET(void);
	extern void adsynRESET(void);
	extern void lpcRESET(void);
	extern void stringRESET(void);
	extern void DirectSound_exit();
	extern char *orchname;
	extern char *scorename;
	extern void setport_num(int num);
	extern void set_out_port_num(int num);
	extern void SfReset();
	extern void playReset();
	extern void recReset();
	extern void zakRESET();
	extern void hetro_reset();
	extern void argdecReset();
	extern void widgetRESET();
	extern void tempnameRESET();
	extern void foutRESET();
	extern void pictureRESET();
	extern void OpenGL_RESET();


	extern int argc_err;
	extern long nrecs;

	argc_err = 0;
	nrecs = 0;
	sleep_flag=FALSE;
	set_out_port_num(-1);
	setport_num(-1);
	orchname=NULL;
	scorename=NULL;
	DirectSound_exit();
	gab_midi_out_exit();
	gab_midi_exit();
	zakRESET();
	cscoreRESET();
	expRESET();
	ftRESET();
	SfReset();
	insertRESET();
	memRESET();
	musRESET();
	oloadRESET();
	tranRESET();
	orchRESET();
	soundinRESET();
	adsynRESET();
	lpcRESET();
	playReset();
	recReset();
	hetro_reset();
	argdecReset();
	stringRESET();
	tempnameRESET();
	foutRESET();
	OpenGL_RESET();
	widgetRESET();
	pictureRESET();
	fcloseall();
}


char terminato[] = "\nCurrent Csound session terminated... \nClick \"Start\" to restart a new session with the same command-line arguments\n--------------------------------------------\n\0";

#undef exit

unsigned long exitWinGab(unsigned long cod)
{ 
	extern int exit_soon_flag;
	flStartStop=FALSE;
	SetDlgItemText(MainDialogHandle,idcStartStop,"Start");
	if (exit_soon_flag)	{
       RegistrySet();
	   exit(cod);
	}
	else
		flStartStop = FALSE;
		reset_all();
		gab_printf(terminato);
		ExitThread(cod);
	return cod;
	
} 

void callShowWindow() 
{
	ShowWindow(MainDialogHandle, SW_MINIMIZE );
}