
typedef	struct {
	OPDS	h;
	MYFLT	*ar, *asig, *kcf, *kbw, *ord, *iscl, *istor;
	int     scale, loop;
	MYFLT	c1, c2, c3, *yt1, *yt2, cosf, prvcf, prvbw;
	AUXCH	aux;
} KRESONX;


typedef struct {
	OPDS	h;
	MYFLT	*xndx, *xfn, *kinterp, *ixmode, *outargs[VARGMAX];
} MTABLEI;

typedef struct {
	OPDS	h;
	MYFLT	*xndx, *xfn, *kinterp, *ixmode, *outargs[VARGMAX];
	int nargs;
	MYFLT  	xbmul;
	long  pfn, len;
	MYFLT	*ftable;
} MTABLE;

typedef struct {
	OPDS	h;
	MYFLT	*xndx, *xfn, *ixmode, *inargs[VARGMAX];
} MTABLEIW;

typedef struct {
	OPDS	h;
	MYFLT	*xndx, *xfn, *ixmode, *inargs[VARGMAX];
	int nargs;
	MYFLT  	xbmul;
	long  pfn, len;
	MYFLT	*ftable;
} MTABLEW;

typedef struct {
	OPDS	h;
	MYFLT	*xndx, *xfn, *inargs[VARGMAX];
} MTABIW;

typedef struct {
	OPDS	h;
	MYFLT	*xndx, *xfn, *inargs[VARGMAX];
	int nargs;
	//MYFLT  	xbmul;
	long  pfn, len;
	MYFLT	*ftable;
} MTABW;

typedef struct {
	OPDS	h;
	MYFLT	*xndx, *xfn, *outargs[VARGMAX];
} MTABI;

typedef struct {
	OPDS	h;
	MYFLT	*xndx, *xfn, *outargs[VARGMAX];
	int nargs;
	//MYFLT  	xbmul;
	long  pfn, len;
	MYFLT	*ftable;
} MTAB;

typedef struct {
	OPDS	h;
	MYFLT	*rslt, *xndx, *xfn, *ixmode;
	MYFLT   *table;
	MYFLT  	xbmul;
	int		xmode;
	//FUNC	*ftp;
} FASTAB;

typedef struct {
	OPDS	h;
	MYFLT	*r, *ndx;
} FASTB;

typedef struct {
	OPDS	h;
	MYFLT	*ifn;
} TB_INIT;


typedef struct {
	OPDS	h;
	MYFLT	*sr, *xcps, *iphs;
	double	curphs;
	int flag;
} METRO;



typedef struct {
    OPDS    h;
    MYFLT   *sr, *kamp, *kcps, *ifn, *ifreqtbl, *iamptbl, *icnt, *iphs;
    FUNC    *ftp;
    FUNC    *freqtp;
    FUNC    *amptp;
    int     count;
    int     inerr;
    AUXCH   lphs;
	MYFLT	*previousAmp;
} ADSYNT2;

typedef struct {
    OPDS    h;
} EXITNOW;


typedef struct {
    OPDS    h;
	MYFLT *ktrig;
} TURNOFFK;

typedef struct {
	OPDS	h;
	MYFLT	*kr, *kin, *kdel, *imaxd, *istod, *interp;
	AUXCH	aux;
	long	left, maxd;
} KDEL;


typedef struct	{
	OPDS	h;
	MYFLT	*trig, *ndx, *maxtics, *ifn, *outargs[VARGMAX];
	int		numouts, currtic, old_ndx;
	MYFLT *table;
} SPLIT_TRIG;

typedef struct	{
	OPDS	h;
	MYFLT	*ktrig, *kphs, *ifn, *args[VARGMAX];
	MYFLT endSeq, *table, oldPhs;
	int numParm, /*currIndex,*/ endIndex, prevIndex, nextIndex /*, lastIndex */;
	MYFLT prevActime, nextActime/*, lastActime*/;
	int initFlag/*,jump*/;

} TIMEDSEQ;


typedef struct	{
	OPDS	h;
	MYFLT	*ktrig_start, *ktrig_stop, *numtics, *kfn, *inargs[VARGMAX];
	int	    recording, numins; 
	long	currtic, ndx, tablen;
	MYFLT	*table, old_fn;
	
} TABREC;

typedef struct	{
	OPDS	h;
	MYFLT	*ktrig, *numtics, *kfn, *outargs[VARGMAX];
	int	    playing, numouts; 
	long	currtic, ndx, tablen;
	MYFLT	*table, old_fn;
} TABPLAY;

typedef struct	{
	OPDS	h;
	MYFLT	*ktrig, *inargs[VARGMAX];
	MYFLT	old_inargs[VARGMAX];
	int numargs;
} ISCHANGED;

typedef struct	{
	OPDS	h;
	MYFLT	*commandLine;
} CSSYSTEM;

typedef struct	{
	OPDS	h;
	MYFLT	*kout, *asig, *ktrig, *imaxflag;
	MYFLT	max;
	int		counter;
} P_MAXIMUM;


/*====================
opcodes from Jens Groh
======================*/

typedef struct {
    OPDS    h;
    MYFLT   *ifilcod;
} PRINTI; 

typedef struct { /* for nlalp opcode */
   OPDS h; /* header */
   MYFLT *aresult; /* resulting signal */
   MYFLT *ainsig; /* input signal */
   MYFLT *klfact; /* linear factor */
   MYFLT *knfact; /* nonlinear factor */
   MYFLT *istor; /* initial storage disposition */
   double m0; /* energy storage */
   double m1; /* energy storage */
} NLALP; 
