#include "cs.h"
/*------- GAB INCLUDE -------------*/
#include "ugens3.h"
#include "ugens6.h"
#include "aops.h"
#include "vdelay.h"
#include "lowpassr.h"
#include "ugrw1.h"
#include "fof3.h"	
#include "gab_osc.h"
#include "uggab.h"
#include "foscili2.h"	
#include "InstrCall.h"
#ifdef WIN32
	#include "win_specific/out3D.h"  
#endif
#include "newopcodes.h"
#include "dashow.h"
#include "generative.h"
#include "image.h"
#include "vpvoc.h"
#include "fractals.h"
#include "schedule.h"
#include "flanger.h"
#include "widgets.h"
#include "OpenGL1.h"
#include "specTypes.h"
#include "vectorial.h"
#include "imageProc.h"
#include "trigRateOpcodes.h"


void	nreverb_set(void*),nreverb(void*);
void	zread(void*), zaset(void*), zar(void*), assign(void*), interp(void*);

/*---------- GAB OPCODES ----------*/
void    ipowoftwo(void *), ilogbasetwo(void *);
void    powoftwo_set(void *), logbasetwo_set(void *), powoftwoa(void *);
void    powoftwo(void *), powoftwoa(void *);
void	logbasetwo(void *), logbasetwoa(void *);
void	flanger_set(void*), flanger(void*), wguide1set(void*), wguide1(void*);
void    wguide2set(void*), wguide2(void*);
void    lowpr(void *), lowpr_set(void *), lowpr_setx(void *), lowprx(void *);
void    lowpr_w_sep_set(void *), lowpr_w_sep(void *);
void posc_set(void *), poscaa(void *), poscak(void *), poscka(void *), posckk(void *), kposc(void *);
void    lposc_set(void*), lposc(void*), lposc3(void*);
void    nlalp_set(void*), nlalp(void*);
void lposcint(void *);
void lsgset_old(void *), klnseg_old(void *), linseg_old(void *);
void  ftlen2(void*);
void  loscil2(void*), losset2(void*);
void  fofset3(void*), fof3(void*), numsamp(void*),ftsr(void*);
void  printk2(void*), printk2set(void*);
void foscset2(void *),foscili2(void *);
void icall(void *),dicall_set(void *),dicall(void *),micall_set(void *);
void micall(void *), dmicall_set(void *),dmicall(void *);
void kargc_set(void *), kargc(void *), kargt_set(void *), kargt(void *);
void argc_set(void *), argc(void *), argt_set(void *), argt(void *);
void artrnc_set(void *), artrnc(void *), artrnt_set(void *), artrnt(void *);
void krtrnc_set(void *), krtrnc(void *), krtrnt_set(void *), krtrnt(void *);
void fastab_set(void *), fastabi(void *), fastabk(void *), fastab(void *);
void fastabiw(void *), fastabkw(void *), fastabw(void *);
void out3d(void*), init3d(void*), o3dpos(void*), out3d_set(void*);
void o3dmindist(void*), o3dmaxdist(void*), o3dconeang(void*);
void o3dconeorient(void*), o3dconevolume(void*), o3dmode(void*);
void list_pos(void*), list_or(void*), list_rolloff(void*), list_distance(void*);
void dsSetDeferredFlag(void*), dsCommitDeferred(void*), eaxListEnvir(void*);
void eaxListEnvirSize(void*),eaxListEnvirDiffusion(void*),eaxListRoom(void*);
void eaxListRoomHF(void*),eaxListDecayTime(void*);
void eaxListDecayTimeHF(void*),eaxListReflec(void*),eaxListReflecDel(void*);
void eaxListReverb(void*),eaxListReverbDel(void*);
void eaxListRoomRolloff(void*),eaxListAirAbsHF(void*), eaxListAll(void*),eaxListFlags(void*);
void o3dsetAll(void*),list_setAll(void*);
void eaxSoDirect(void*), eaxSoDirectHF(void*), eaxSoRoom(void*),eaxSoRoomHF(void*);
void eaxSoObstruct(void*),eaxSoObstructRatio(void*);
void eaxSoOccl(void*),eaxSoOcclRatio(void*),eaxSoOcclRoom(void*);
void eaxSoRolloff(void*),eaxSoAirAbs(void*), init_eax(void*);
void eaxSoOutVol(void*),eaxSoAll(void*),eaxSoFlags(void*);
void loopseg_set(void*),	loopseg(void*), lpshold(void*);
void ikRangeRand(void*), aRangeRand(void*);
void randomi_set(void*), krandomi(void*), randomi(void*);
void randomh_set(void*), krandomh(void*), randomh(void*);
void random3_set(void*), random3(void*),random3a(void*);
void semitone(void*), isemitone(void*), semitone_a(void*), cent(void*), icent(void*),cent_a(void*),db(void*),idb(void*),db_a(void*);
void jitter2_set(void*), jitter2(void*),jitter_set(void*), jitter(void*),jitters_set(void*), jitters(void*), jittersa(void*);
void vibrato_set(void*), vibrato(void*),vibr_set(void*), vibr(void*);
void  krsnsetx(void*), kresonx(void*);
void ikDiscreteUserRand(void*), aDiscreteUserRand(void*);
void ikContinuousUserRand(void*), aContinuousUserRand(void*);
void mtable_set(void*),  mtable_k(void*),mtable_a(void*), mtable_i(void*); 
void mtablew_set(void*), mtablew_k(void*), mtablew_i(void*),  mtablew_a(void*);


void mtab_set(void*), mtab_k(void*), mtab_set(void*),  mtab_a(void*),  mtabw_i(void*);
void mtab_i (void*), mtabw_set(void*), mtabw_k(void*),  mtabw_a(void*),trigcall(void*) ;

void dashow (void*);

void test_set(void*), test(void*);
void schedk(void*), schedk_i(void*);
void lineto_set(void*), lineto(void*), tlineto_set(void*),tlineto(void*);
void bmopen(void*), bmcreate(void*), bmtable_set(void*), bmtable(void*), bmtablei(void*);
void bmoscil_set(void*), bmoscil(void*), bmoscili(void*), rgb2hsvl(void*); 
void metro_set(void*), metro(void*),  bmscan_set(void*),   bmscan(void*), bmscani(void*) ;
void mandel_set(void*), mandel(void*);
void vectorOp_set(void*), vadd(void*), vmult(void*), vpow(void*), vexp(void*);
void vectorOp_set(void*),vadd(void*),vmult(void*),vpow(void*),vexp(void*);
void vectorsOp_set(void*),vcopy(void*),vaddv(void*),vsubv(void*),vmultv(void*),vdivv(void*),vpowv(void*),vexpv(void*);
void vlimit_set(void*),vlimit(void*),vwrap(void*),vmirror(void*);
void vseg_set(void*), vlinseg(void*), vexpseg(void*); 
void vrandh_set(void*), vrandh(void*), vrandi_set(void*), vrandi(void*);
void ca_set(void*),  ca(void*), vport_set(void*),  vport(void*) ;
void kdel_set(void*),  kdelay(void*),vecdly_set(void*),  vecdly(void*), vmap(void*);
void seqtim2_set(void*), seqtim2(void*), adsynt2_set(void*), adsynt2(void*) ; 

void fl_slider(void*), StartPanel(void*), EndPanel(void*), FL_run(void*);
void fl_widget_color(void*), fl_knob(void*),fl_roller(void*), fl_text(void*);
void fl_value(void*), StartScroll(void*), EndScroll(void*);
void StartPack(void*), EndPack(void*), fl_widget_label(void*),fl_setWidgetValuei(void*),fl_setWidgetValue(void*), fl_setWidgetValue_set(void*);
void fl_update(void*), StartGroup(void*), EndGroup(void*), StartTabs(void*), EndTabs(void*);
void fl_joystick(void*),fl_button(void*),FLkeyb(void*),fl_counter(void*);
void set_snap(void*),get_snap(void*);
void fl_setColor1(void*), fl_setColor2(void*), fl_setTextSize(void*),  fl_setTextColor(void*);
void fl_setFont(void*), fl_setText(void*), fl_setSize(void*),fl_setTextType(void*),fl_setBox(void*);
void fl_setPosition(void*), fl_hide(void*), fl_show(void*), fl_box(void*), fl_align(void*);
void save_snap(void*),  load_snap(void*), fl_button_bank(void*),timeseq_set(void*),timeseq(void*) ;
void lposcinta(void*),FLprintkset(void*),FLprintk(void*),FLprintk2(void*),fl_bitmap(void*);
void fl_setOverlay(void*), exitnow(void*), turnoffk(void*),fl_widget_color2(void*);
void fl_text_size(void*), GLfps(void*) /* , showMacroDef(void*) */;

void GLpanel(void*), EndGLpanel(void*), GLinsert_i(void*), GLinsert(void*) ; 
void GLUTsphere(void*),  GLUTtorus(void*);
void GLperspective(void*),  GLmatrixMode(void*), GLclear(void*), GLloadIdentity(void*);
void GLpushMatrix(void*), GLpopMatr(void*),	GLtranslate(void*),	GLrotate(void*), GLscale(void*);
void GLenable(void*), GLdisable(void*),	GLclearcolor(void*), GLcolor(void*);
void GLlinewidth(void*), GLblendfunc(void*), GLcolor3(void*), glmaterial(void*);	
void glshininess(void*), GLshademodel(void*), GLloadTexture(void*), GLbindtexture(void*);
void GLbegin(void*), GLend(void*), GLtexcoord2(void*), GLvertex3(void*) , GLnormal3(void*);
void GLreadObject(void*),	GLnewList(void*), GLendList(void*), GLcallList(void*);
void GLfullscreen(void*), GLUnewquadric(void*), GLUsphere(void*), GLtexCircle(void*);
void GLUquadricDrawStyle(void*), GLUquadricNormals(void*), GLUcylinder(void*);
void GLtexEnvi(void*), GLtexEnvfv(void*),  GLtexGeni(void*),	GLtexGenfv(void*);
void GLenableClientState(void*),  GLdisableClientState(void*),	GLvertexPointer(void*);
void GLnormalPointer(void*), GLcolorPointer(void*),	 GLindexPointer(void*);
void GLtexCoordPointer(void*),	 GLedgeFlagPointer(void*), GLUquadricTexture(void*);
void GLarrayElement(void*),  GLdrawElements(void*),  GLdrawArrays(void*);
void GLpixelTransfer(void*), GLpixelMap(void*), GLdrawBuffer(void*), set_GLratio(void*);

void GLUTcube(void*), GLcullFace(void*), GLfrontFace(void*);
void GLUTdodecahedron(void*), GLUToctahedron(void*), GLUTtetrahedron(void*), GLUTicosahedron(void*);

void GLUlookAt(void*), GLloadMatrixv(void*), GLmultMatrixv(void*), GLloadMatrix(void*),  GLmultMatrix(void*);
void GLfrustum(void*), GLclipPlane(void*);
void GLfor(void*), GLfor_end(void*), GLtab(void*), GLtabw(void*), GLvtab(void*), GLvtabw(void*);
void GLif(void*), GLelse(void*), GLend_if(void*);
void GLsum(void*), GLsub(void*), GLmul(void*), GLdiv(void*), GLmod(void*); 
void GLint1(void*), GLfrac(void*), GLrnd(void*), GLbirnd(void*);
void GLabs(void*), GLexp(void*), GLlog(void*), GLsqr(void*), GLsin(void*), GLcos(void*), GLtan(void*); 
void GLatan(void*), GLsinh(void*), GLcosh(void*), GLtanh(void*), GLlog10(void*), GLasin(void*), GLacos(void*);
void GLredraw(void*), GLclearWhen(void*),GLUdisk(void*);
void GLhint(void*), GLlight(void*), GLlightv(void*), GLlightModel(void*), GLlightModelv(void*);
void GLphasor(void*),GLoscil(void*), GLoscili(void*), GLload_picasso(void*), GLrender_picasso(void*);


void GLopenVideoCam(void*), GLcamDialog(void*), GLmetro(void*), GLortho(void*);
void GLpix2tex_set(void*), GLpix2tex(void*), GLopenVideoFile(void*), GLvideo2tex(void*);
void imgGain_set(void*), imgGain(void*), imgConvolve_set(void*), imgConvolve(void*), imgSetPixel_set(void*), imgSetPixel(void*);

void GLevalCoord1(void*), GLevalCoord2(void*), GLevalMesh1(void*), GLevalMesh2(void*), GLmap1(void*), GLmap2(void*);
void GLmapGrid1(void*), GLmapGrid2(void*), GLUnewNurbsRenderer(void*), GLUbeginCurve(void*);
void GLUbeginSurface(void*), GLUendSurface(void*), GLUbeginTrim(void*), GLUendTrim(void*);
void GLUnurbsCurve(void*), GLUnurbsSurface(void*), GLUpwlCurve(void*), GLUendCurve(void*);
void GLUnurbsProperty(void*), GLtext3d(void*), GL3Dfont(void*), GLtexCube(void*),GLtexSquare(void*);
void fl_slider_bank(void*), tab0(void*), tab1(void*), tab2(void*), tab3(void*), tab4(void*), tab5(void*), tab6(void*), tab7(void*), tab8(void*), tab9(void*), tab10(void*), tab11(void*), tab12(void*), tab13(void*), tab14(void*), tab15(void*);
void tab0_init(void*), tab1_init(void*), tab2_init(void*), tab3_init(void*), tab4_init(void*), tab5_init(void*), tab6_init(void*), tab7_init(void*), tab8_init(void*), tab9_init(void*), tab10_init(void*), tab11_init(void*), tab12_init(void*), tab13_init(void*), tab14_init(void*), tab15_init(void*);
void a_k_set(void*), wait_GL_INIT(void*);
void specinfo(void*), spec2table_set(void*),spec2table(void*);
void split_trig_set(void*),split_trig(void*),tabrec_set(void*), tabrec_k(void*), tabplay_set(void*), tabplay_k(void*);
void GLUtessBeginPolygon(void*), GLUtessEndPolygon(void*), GLUtessBeginContour(void*);
void GLUtessEndContour(void*), GLUtessVertexv(void*), GLUtessVertex(void*);
void vphaseseg_set(void*), vphaseseg(void*), GLsetFrameDelay(void*);

void GLvadd(void*), GLvmult(void*), GLvpow(void*), GLvexp(void*), GLvsubv(void*), GLvmultv(void*), GLvdivv(void*);
void GLvpowv(void*), GLvexpv(void*), GLvcopy(void*), GLvmap(void*), GLvlimit(void*), GLvwrap(void*);
void GLvmirror(void*), GLvphaseseg(void*), GLvaddv(void*), GLgk_set(void*), GLgk(void*);
void tab2grate_set(void*), GLtab2grate(void*), isChanged_set(void*), isChanged(void*) ;

void trRangeRand(void*), lposcinta_stereo(void*), lposc_stereo_set(void*), lposcinta_stereo_no_trasp(void*);

void CSsystem(void*),ftlen(void*), partial_maximum_set(void*),partial_maximum(void*);


#define S	sizeof  
  /* thread vals, where isub=1, ksub=2, asub=4:
  		0 =	1  OR	2  (B out only)

/* thread vals, where isub=1, ksub=2, asub=4:
		0 =	1  OR	2  (B out only)
		1 =	1
		2 =	2
		3 =	1  AND	2
		4 =	4
		5 =	1  AND		4
		7 =	1  AND (2  OR	4)			*/

/* inarg types include the following:
		m	begins an indef list of iargs (any count)
		n	begins an indef list of iargs (nargs odd)
		o	optional, defaulting to 0
		p	   "		"	1
		q	   "		"	10
		v	   "		"	.5
		j	   "		"	-1
		h	   "		"	127
                y       begins indef list of aargs (any count)
                z       begins indef list of kargs (any count)
                Z       begins alternating kakaka...list (any count)
   outarg types include:
		m	multiple outargs (1 to 4 allowed)
   (these types must agree with rdorch.c)			*/

/* If dsblksize is 0xffff then translate */
/*                 0xfffe then translate two (oscil) */
/*                 0xfffd then translate two (peak) */
/*                 0xfffc then translate two (divz) */


OENTRY opcodlst_gab[] = {

{ "poscil", 0xfffe							}, 
{ "dashow", 0xffff,							},

{ "nlalp", S(NLALP),     5,     "a",    "akkoo", nlalp_set, NULL, nlalp     }, 
{ "reverb2",  S(NREV),	  5,	"a",	"akko",	nreverb_set, NULL,nreverb}, 

/*-------------------- GAB OPCODES ----------------------------------*/
/* deprecated */
{ "lpres",   S(LOWPR),    5,    "a",    "akko",  lowpr_set, NULL,   lowpr    },
{ "lpresx",  S(LOWPRX),    5,    "a",    "akkoo",  lowpr_setx, NULL,   lowprx    },
{ "posc",   S(POSC),     7,      "s",    "kkio", posc_set, kposc,   posckk   },
{ "lposc",  S(LPOSC),    5,      "a",    "kkkkio", lposc_set, NULL,   lposc   },
{ "physic1", S(WGUIDE1), 5,     "a",    "axkk",  wguide1set, NULL, wguide1  },
{ "physic2", S(WGUIDE2), 5,     "a",    "axxkkkk", wguide2set, NULL, wguide2 },
{ "vlpres",  S(LOWPR_SEP),    5,    "a",    "akkik",  lowpr_w_sep_set, NULL,   lowpr_w_sep    },
/* end */
{ "lposcint",   S(LPOSC),5,      "a",   "kkkkio", lposc_set, NULL,   lposcint   },
{ "ftlen2_i", S(EVAL),    1,     "i",    "i",    ftlen2                   },
{ "loscil2", S(LOSC),    5,     "mm","xkiojoojoo",losset2,NULL, loscil2   },
{ "fof3",   S(FOFS3),    5,     "a","xxxkkkkkiiiikk",fofset3,NULL,fof3   },
{ "foscili2",S(FOSC2),	5,	"a",  "xkkkkiio",foscset2,NULL,	foscili2 },

{ "call", S(ICALL),  1,  "",	"iiim",	icall			},
{ "callm", S(MICALL),  3,  "",	"iiim",	micall_set,	micall			},
{ "calld",S(DICALL), 3,  "",	"iiim",	dicall_set, dicall	},
{ "callmd",S(DMICALL), 3,  "",	"iiim",	dmicall_set, dmicall	},
{ "parmck",S(KARGC), 3,  "",	"z",	kargc_set, kargc	},
{ "parmtk",S(KARGT), 1,  "",	"z",	kargt_set	},
{ "parmca",S(KARGC), 5,  "",	"y",	argc_set, NULL, argc	},
{ "parmta",S(KARGT), 1,  "",	"y",	argt_set	},
{ "rtrnca",S(KARGC), 5,  "",	"y",	artrnc_set, NULL, artrnc	},
{ "rtrnta",S(KARGT), 1,  "",	"y",	artrnt_set  },
{ "rtrnck",S(KARGC), 3,  "",	"z",	krtrnc_set,  krtrnc	},
{ "rtrntk",S(KARGT), 1,  "",	"z",	krtrnt_set  	},

{ "tab_i",S(FASTAB),  1,   "i",    "iio", fastabi               },
{ "tab",S(FASTAB),  7,   "s",    "xio", fastab_set, fastabk,   fastab },
{ "tabw_i",S(FASTAB),  1,   "",    "iiio", fastabiw               },
{ "tabw",S(FASTAB),  7,   "",    "xxio", fastab_set, fastabkw,   fastabw },

/*--------- DirectSound 3D API -------------------*/
{ "Init3dAudio",S(INIT3D),  1,   "",    "i", init3d              },

{ "Out3d",S(OUT3D), 5,  "",	"ak",	out3d_set,   NULL,   out3d	},

{ "DsMode_i",S(OUT3DMODE),  1,   "",    "ii", o3dmode      },
{ "DsMode",  S(OUT3DMODE), 	2,     "",	"ki",	NULL, o3dmode, NULL},

{ "DsPosition_i",S(OUT3DPOS),  1,   "",    "iiii", o3dpos      },
{ "DsPosition",  S(OUT3DPOS), 	2,     "",	"kkki",	NULL, 	 o3dpos,	NULL},

{ "DsMinDistance_i",S(OUT3DPOS),  1,   "",    "ii", o3dmindist      },
{ "DsMinDistance",  S(OUT3DPOS), 	2,     "",	"ki",	NULL, 	 o3dmindist,	NULL},

{ "DsMaxDistance_i",S(OUT3DPOS),  1,   "",    "ii", o3dmaxdist      },
{ "DsMaxDistance",  S(OUT3DPOS), 	2,     "",	"ki",	NULL, 	 o3dmaxdist,	NULL},

{ "DsConeAngles_i",S(OUT3DCONEANG),  1,   "",    "iii", o3dconeang      },
{ "DsConeAngles",  S(OUT3DCONEANG), 	2,     "",	"kki",	NULL, 	 o3dconeang,	NULL},

{ "DsConeOrientation_i",S(OUT3DPOS),  1,   "",    "iiii", o3dconeorient      },
{ "DsConeOrientation",  S(OUT3DPOS), 	2,     "",	"kkki",	NULL,  o3dconeorient,	NULL},

{ "DsConeOutsideVolume_i",S(OUT3DCONEVOL),  1,   "",    "ii", o3dconevolume      },
{ "DsConeOutsideVolume",  S(OUT3DCONEVOL), 	2,     "",	"ki",	NULL, o3dconevolume, NULL},

{ "DsSetAll_i",S(OUT3DSETALL),  1,   "",       "iiiiiiiiiiiii", o3dsetAll      },
{ "DsSetAll",  S(OUT3DSETALL), 	2,     "",	"kkkkkkkkkkkki",	NULL, o3dsetAll, NULL},


{ "DsListenerPosition_i",S(LISTPOS),  1,   "",    "iii", list_pos      },
{ "DsListenerPosition",  S(LISTPOS), 	2,     "",	"kkk",	NULL, 	 list_pos,	NULL},

{ "DsListenerOrientation_i",S(LISTOR),  1,   "",    "iiiiii", list_or      },
{ "DsListenerOrientation",  S(LISTOR), 	2,     "",	"kkkkkk",	NULL, 	 list_or,	NULL},

{ "DsListenerRolloffFactor_i",S(LISTROLL),  1,   "",    "i", list_rolloff      },
{ "DsListenerRolloffFactor",  S(LISTROLL), 	2,     "",	"k",	NULL, 	 list_rolloff,	NULL},

{ "DsListenerDistanceFactor_i",S(LISTDIST),  1,   "",    "i", list_distance      },
{ "DsListenerDistanceFactor",  S(LISTDIST), 	2,     "",	"k",	NULL, 	 list_distance,	NULL},

{ "DsListenerSetAll_i",S(LISTSETALL),  1,   "",     "iiiiiiiiiii", o3dsetAll      },
{ "DsListenerSetAll",  S(LISTSETALL), 	2,     "",	"kkkkkkkkkkk",	NULL, o3dsetAll, NULL},


/*----- EAX 2.0 API ----------*/
#ifdef GAB_EAX

{ "InitEAX",S(COMMIT_DEFERRED),  1,   "",    "", init_eax        },

{ "EaxListenerEnvironment_i",S(EAX_PARM),  1,   "",    "i", eaxListEnvir      },
{ "EaxListenerEnvironment",  S(EAX_PARM), 	2,     "",	"k",	NULL, eaxListEnvir, NULL},

{ "EaxListenerEnvSize_i",S(EAX_PARM),  1,   "",    "i", eaxListEnvirSize      },
{ "EaxListenerEnvSize",  S(EAX_PARM), 	2,     "",	"k",	NULL, eaxListEnvirSize, NULL},

{ "EaxListenerEnvDiffusion_i",S(EAX_PARM),  1,   "",    "i", eaxListEnvirDiffusion      },
{ "EaxListenerEnvDiffusion",  S(EAX_PARM), 	2,     "",	"k",	NULL, eaxListEnvirDiffusion, NULL},

{ "EaxListenerRoom_i",S(EAX_PARM),  1,   "",    "i", eaxListRoom      },
{ "EaxListenerRoom",  S(EAX_PARM), 	2,     "",	"k",	NULL, eaxListRoom, NULL},

{ "EaxListenerRoomHF_i",S(EAX_PARM),  1,   "",    "i", eaxListRoomHF      },
{ "EaxListenerRoomHF",  S(EAX_PARM), 	2,     "",	"k",	NULL, eaxListRoomHF, NULL},

{ "EaxListenerDecayTime_i",S(EAX_PARM),  1,   "",    "i", eaxListDecayTime      },
{ "EaxListenerDecayTime",  S(EAX_PARM), 	2,     "",	"k",	NULL, eaxListDecayTime, NULL},

{ "EaxListenerDecayTimeHfRatio_i",S(EAX_PARM),  1,   "",    "i", eaxListDecayTimeHF      },
{ "EaxListenerDecayTimeHfRatio",  S(EAX_PARM), 	2,     "",	"k",	NULL, eaxListDecayTimeHF, NULL},

{ "EaxListenerReflections_i",S(EAX_PARM),  1,   "",    "i", eaxListReflec      },
{ "EaxListenerReflections",  S(EAX_PARM), 	2,     "",	"k",	NULL, eaxListReflec, NULL},

{ "EaxListenerReflectionsDelay_i",S(EAX_PARM),  1,   "",    "i", eaxListReflecDel      },
{ "EaxListenerReflectionsDelay",  S(EAX_PARM), 	2,     "",	"k",	NULL, eaxListReflecDel, NULL},

{ "EaxListenerReverb_i",S(EAX_PARM),  1,   "",    "i", eaxListReverb      },
{ "EaxListenerReverb",  S(EAX_PARM), 	2,     "",	"k",	NULL, eaxListReverb, NULL},

{ "EaxListenerReverbDelay_i",S(EAX_PARM),  1,   "",    "i", eaxListReverbDel      },
{ "EaxListenerReverbDelay",  S(EAX_PARM), 	2,     "",	"k",	NULL, eaxListReverbDel, NULL},

{ "EaxListenerRoomRolloff_i",S(EAX_PARM),  1,   "",    "i", eaxListRoomRolloff      },
{ "EaxListenerRoomRolloff",  S(EAX_PARM), 	2,     "",	"k",	NULL, eaxListRoomRolloff, NULL},

{ "EaxListenerAirAbsorption_i",S(EAX_PARM),  1,   "",    "i", eaxListAirAbsHF      },
{ "EaxListenerAirAbsorption",  S(EAX_PARM), 	2,     "",	"k",	NULL, eaxListAirAbsHF, NULL},

{ "EaxListenerFlags_i",S(EAX_LISTFLAGS),1,"","iiiiii", eaxListFlags      },
{ "EaxListenerFlags",  S(EAX_LISTFLAGS),2,"","kkkkkk", NULL, eaxListFlags, NULL},

{ "EaxListenerAll_i",S(EAX_LISTALL),1,"","iiiiiiiiiiiii", eaxListAll      },
{ "EaxListenerAll",  S(EAX_LISTALL),2,"","kkkkkkkkkkkkk", NULL, eaxListAll, NULL},

{ "EaxSourceDirect_i",S(EAX_SOURCEPARM),  1,   "",    "ii", eaxSoDirect      },
{ "EaxSourceDirect",  S(EAX_SOURCEPARM), 	2,     "",	"ki",	NULL, eaxSoDirect, NULL},

{ "EaxSourceDirectHF_i",S(EAX_SOURCEPARM),  1,   "",    "ii", eaxSoDirectHF      },
{ "EaxSourceDirectHF",  S(EAX_SOURCEPARM), 	2,     "",	"ki",	NULL, eaxSoDirectHF, NULL},

{ "EaxSourceRoom_i",S(EAX_SOURCEPARM),  1,   "",    "ii", eaxSoRoom      },
{ "EaxSourceRoom",  S(EAX_SOURCEPARM), 	2,     "",	"ki",	NULL, eaxSoRoom, NULL},

{ "EaxSourceRoomHF_i",S(EAX_SOURCEPARM),  1,   "",    "ii", eaxSoRoomHF      },
{ "EaxSourceRoomHF",  S(EAX_SOURCEPARM), 	2,     "",	"ki",	NULL, eaxSoRoomHF, NULL},

{ "EaxSourceObstruction_i",S(EAX_SOURCEPARM),  1,   "",    "ii", eaxSoObstruct      },
{ "EaxSourceObstruction",  S(EAX_SOURCEPARM), 	2,     "",	"ki",	NULL, eaxSoObstruct, NULL},

{ "EaxSourceObstructionRatio_i",S(EAX_SOURCEPARM),  1,   "",    "ii", eaxSoObstructRatio      },
{ "EaxSourceObstructionRatio",  S(EAX_PARM), 	2,     "",	"ki",	NULL, eaxSoObstructRatio, NULL},

{ "EaxSourceOcclusion_i",S(EAX_SOURCEPARM),  1,   "",    "ii", eaxSoOccl      },
{ "EaxSourceOcclusion",  S(EAX_SOURCEPARM), 	2,     "",	"ki",	NULL, eaxSoOccl, NULL},

{ "EaxSourceOcclusionRatio_i",S(EAX_SOURCEPARM),  1,   "",    "ii", eaxSoOcclRatio      },
{ "EaxSourceOcclusionRatio",  S(EAX_SOURCEPARM), 	2,     "",	"ki",	NULL, eaxSoOcclRatio, NULL},

{ "EaxSourceOcclusionRoomRatio_i",S(EAX_SOURCEPARM),  1,   "",    "ii", eaxSoOcclRoom      },
{ "EaxSourceOcclusionRoomRatio",  S(EAX_SOURCEPARM), 	2,     "",	"ki",	NULL, eaxSoOcclRoom, NULL},

{ "EaxSourceRoomRolloff_i",S(EAX_SOURCEPARM),  1,   "",    "ii", eaxSoRolloff      },
{ "EaxSourceRoomRolloff",  S(EAX_SOURCEPARM), 	2,     "",	"ki",	NULL, eaxSoRolloff, NULL},

{ "EaxSourceAirAbsorption_i",S(EAX_SOURCEPARM),  1,   "",    "ii", eaxSoAirAbs      },
{ "EaxSourceAirAbsorption",  S(EAX_SOURCEPARM), 	2,     "",	"ki",	NULL, eaxSoAirAbs, NULL},

{ "EaxSourceOutsideVolumeHF_i",S(EAX_SOURCEPARM),  1,   "",    "ii", eaxSoOutVol      },
{ "EaxSourceOutsideVolumeHF",  S(EAX_SOURCEPARM), 	2,     "",	"ki",	NULL, eaxSoOutVol, NULL},

{ "EaxSourceAll_i",S(EAX_SOURCEALL),  1,"", "iiiiiiiiiiiii", eaxSoAll      },
{ "EaxSourceAll",  S(EAX_SOURCEALL), 2, "",	"kkkkkkkkkkkki", NULL, eaxSoAll, NULL},

{ "EaxSourceFlags_i",S(EAX_SOURCEFLAGS),1,"","iiii", eaxSoFlags      },
{ "EaxSourceFlags",  S(EAX_SOURCEFLAGS),2,"","kkki", NULL, eaxSoFlags, NULL},

#endif /* GAB_EAX */
/*-------------- DirectSound 3D and EAX common --------------*/
{ "DsEaxSetDeferredFlag",S(SET_DEFERRED),  1,   "",    "i", dsSetDeferredFlag      },
{ "DsCommitDeferredSettings_i",S(COMMIT_DEFERRED),  1,   "",   "", dsCommitDeferred      },
{ "DsCommitDeferredSettings",  S(COMMIT_DEFERRED),  2,   "",	"",	NULL, dsCommitDeferred, NULL},

{ "resonxk", S(KRESONX),   3,      "k",    "kkkooo", krsnsetx, kresonx,   NULL   },

{ "vtablei", S(MTABLEI),   1,     "",   "iiiim", mtable_i,   NULL   },
{ "vtablek", S(MTABLE),   3,      "",   "kkkiz", mtable_set, mtable_k,   NULL   },
{ "vtablea", S(MTABLE),   5,      "",   "akkiy", mtable_set, NULL, mtable_a    },

{ "vtablewi", S(MTABLEIW),  1,    "",   "iiim", mtablew_i,   NULL   },
{ "vtablewk", S(MTABLEW),   3,    "",   "kkiz", mtablew_set, mtablew_k,   NULL   },
{ "vtablewa", S(MTABLEW),   5,    "",   "akiy", mtablew_set, NULL, mtablew_a    },

{ "vtabi", S(MTABI),   1,     "",   "iim", mtab_i,   NULL   },
{ "vtabk", S(MTAB),   3,      "",   "kiz", mtab_set, mtab_k,   NULL   },
{ "vtaba", S(MTAB),   5,      "",   "aiy", mtab_set, NULL, mtab_a    },

{ "vtabwi", S(MTABIW),  1,    "",   "iim", mtabw_i,   NULL   },
{ "vtabwk", S(MTABW),   3,    "",   "kiz", mtabw_set, mtabw_k,   NULL   },
{ "vtabwa", S(MTABW),   5,    "",   "aiy", mtabw_set, NULL, mtabw_a    },

{ "schedk", S(SCHEDK2),3,  "",     "kkz",schedk_i, schedk, NULL },

{ "dashow_i",S(DSH),    1,      "ii",    "iiii",    dashow               },
{ "dashow_k",S(DSH),    2,      "kk",    "kkkk",    NULL,   dashow      },


{ "bmopen",S(BMOPEN), 1,  "iii",	"Sio",bmopen	 	},
{ "bmtable",S(BMTABLE),    3,      "kkkk",    "kki",   bmtable_set,   bmtable      },
{ "bmtablei",S(BMTABLE),   3,      "kkkk",    "kki",   bmtable_set,   bmtablei      },
{ "bmoscil",S(BMOSCIL),    3,      "kkkk",    "kkkkkkki",   bmoscil_set,   bmoscil      },
{ "bmoscili",S(BMOSCIL),    3,      "kkkk",    "kkkkkkki",   bmoscil_set,   bmoscili      },
{ "rgb2hsvl",S(RGB2HSVL),   2,      "kkkk",    "kkk",   NULL,   rgb2hsvl      },
{ "rgb2hsvl_i",S(RGB2HSVL), 1,      "iiii",    "iii",  rgb2hsvl,         },
{ "bmscan",S(BMSCAN),	  3,      "",    "kiiiiii",   bmscan_set,   bmscan      },
{ "bmscani",S(BMSCAN),    3,      "",    "kiiiiii",   bmscan_set,   bmscani      },
{ "metro",  S(METRO),	  3,      "k",   "ko",	metro_set,	metro		},
{ "mandel",S(MANDEL),     3,      "kk",    "kkkk",   mandel_set,   mandel      },

{ "vadd",S(VECTOROP),    3,        "",    "iki",   vectorOp_set,   vadd      },
{ "vmult",S(VECTOROP),   3,        "",    "iki",   vectorOp_set,   vmult     },
{ "vpow",S(VECTOROP),    3,        "",    "iki",   vectorOp_set,   vpow      },
{ "vexp",S(VECTOROP),    3,        "",    "iki",   vectorOp_set,   vexp      },
{ "vaddv",S(VECTORSOP),  3,        "",    "iii",   vectorsOp_set,   vaddv      },
{ "vsubv",S(VECTORSOP),  3,        "",    "iii",   vectorsOp_set,   vsubv      },
{ "vmultv",S(VECTORSOP), 3,        "",    "iii",   vectorsOp_set,   vmultv      },
{ "vdivv",S(VECTORSOP),  3,        "",    "iii",   vectorsOp_set,   vdivv      },
{ "vpowv",S(VECTORSOP),  3,        "",    "iii",   vectorsOp_set,   vpowv      },
{ "vexpv",S(VECTORSOP),  3,        "",    "iii",   vectorsOp_set,   vexpv      },
{ "vcopy",S(VECTORSOP),  3,        "",    "iii",   vectorsOp_set,   vcopy      },
{ "vmap",S(VECTORSOP),   3,        "",    "iii",   vectorsOp_set,   vmap },
{ "vlimit",S(VLIMIT),    3,        "",    "ikki",   vlimit_set,   vlimit      },
{ "vwrap",S(VLIMIT),     3,        "",    "ikki",   vlimit_set,   vwrap      },
{ "vmirror",S(VLIMIT),   3,        "",    "ikki",   vlimit_set,   vmirror      },
{ "vlinseg",S(VSEG),    3,        "",    "iin",   vseg_set,   vlinseg      },
{ "vexpseg",S(VSEG),    3,        "",    "iin",   vseg_set,   vexpseg      },
{ "vrandh",S(VRANDH),   3,        "",    "ikki",  vrandh_set,   vrandh      },
{ "vrandi",S(VRANDI),   3,        "",    "ikki",  vrandi_set,   vrandi      },
{ "vport",S(VPORT),    3,        "",    "ikio",  vport_set,  vport    },
{ "vecdelay",S(VECDEL), 3,        "",    "iiiiio",vecdly_set,  vecdly    },
{ "vdelayk",S(KDEL),   3,        "k",   "kkioo",  kdel_set,  kdelay    },

{ "vcella",S(CELLA),   3,        "",    "kkiiiiip",  ca_set,  ca    },
{ "seqtime2", S(SEQTIM2),   3,      "k",    "kkkkkk", seqtim2_set, seqtim2, NULL},
{ "adsynt2",S(ADSYNT2),    5,     "a",  "kkiiiio", adsynt2_set,  NULL,  adsynt2  },

/*----- GUI OPCODES ----------*/
{ "FLslider",S(FLSLIDER),    1,     "ki",  "Siijjjjjjj", fl_slider  },
{ "FLknob",S(FLKNOB),		1,     "ki",  "Siijjjjjjo", fl_knob  },
{ "FLroller",S(FLROLLER),   1,     "ki",  "Siijjjjjjjj", fl_roller  },
{ "FLtext",S(FLTEXT),		1,     "ki",  "Siijjjjjj", fl_text  },
{ "FLjoy",S(FLJOYSTICK),    1,     "kkii",  "Siiiijjjjjjjj", fl_joystick  },
{ "FLcount",S(FLCOUNTER),   1,     "ki", "Siiiiiiiiiiz", fl_counter  },
{ "FLbutton",S(FLBUTTON),   1,     "ki",  "Siiiiiiiz", fl_button  },

{ "FLbutBank",S(FLBUTTONBANK),   1,     "ki",  "iiiiiiiiz", fl_button_bank  },
{ "FLbox",S(FL_BOX), 1,  "i",  "Siiiiiii", fl_box  },


//{ "FLkeyb",S(FLKEYB),		1,     "k",  "z", FLkeyb  },


{ "FLcolor",S(FLWIDGCOL),    1,     "",  "jjjjjj", fl_widget_color  },


{ "FLlabel",S(FLWIDGLABEL),    1,     "",  "ojojjj", fl_widget_label  },

{ "FLsetVal_i",S(FL_SET_WIDGET_VALUE_I), 1,  "",  "ii", fl_setWidgetValuei  },
{ "FLsetVal",S(FL_SET_WIDGET_VALUE), 3,  "",  "kki", fl_setWidgetValue_set, fl_setWidgetValue  },

{ "FLsetColor",S(FL_SET_COLOR), 1,  "",  "iiii", fl_setColor1  },
{ "FLsetColor2",S(FL_SET_COLOR), 1,  "",  "iiii", fl_setColor2  },
{ "FLsetTextSize",S(FL_SET_TEXTSIZE), 1,  "",  "ii", fl_setTextSize  },
{ "FLsetTextColor",S(FL_SET_COLOR), 1,  "",  "iiii", fl_setTextColor  },
{ "FLsetFont",S(FL_SET_FONT), 1,  "",  "ii", fl_setFont  },
{ "FLsetTextType",S(FL_SET_FONT), 1,  "",  "ii", fl_setTextType  },
{ "FLsetText",S(FL_SET_TEXT), 1,  "",  "Si", fl_setText  },
{ "FLsetSize",S(FL_SET_SIZE), 1,  "",  "iii", fl_setSize  },




{ "FLsetPosition",S(FL_SET_POSITION), 1,  "",  "iii", fl_setPosition  },

{ "FLhide",S(FL_WIDHIDE), 1,  "",  "i", fl_hide  },
{ "FLshow",S(FL_WIDSHOW), 1,  "",  "i", fl_show  },
{ "FLsetBox",S(FL_SETBOX), 1,  "",  "ii", fl_setBox  },
{ "FLsetAlign",S(FL_TALIGN), 1,  "",  "ii", fl_align  },

	/*------*/

{ "FLvalue",S(FLVALUE),		1,     "i",  "Sjjjj", fl_value  },

{ "FLpanel",S(FLPANEL),    1,     "",  "Sjjoooj", StartPanel  },
{ "FLpanel_end",S(FLPANELEND),    1,     "",  "", EndPanel  },
{ "FLscroll",S(FLSCROLL),	1,     "",  "iiooj", StartScroll  },
{ "FLscroll_end",S(FLSCROLLEND),1, "",  "", EndScroll  },
{ "FLpack",S(FLPACK),		1,     "",  "iiiiiiij", StartPack  },
{ "FLpack_end",S(FLPACKEND),1,     "",  "", EndPack  },
{ "FLtabs",S(FLTABS),		1,     "",  "iiiij", StartTabs  },
{ "FLtabs_end",S(FLTABSEND),1,     "",  "", EndTabs  },
{ "FLgroup",S(FLGROUP),		1,     "",  "Siiiioj", StartGroup  },
{ "FLgroup_end",S(FLGROUPEND),1,   "",  "", EndGroup  },


{ "FLsetsnap",S(FLSETSNAP), 1,     "ii", "io", set_snap  },
{ "FLgetsnap",S(FLGETSNAP), 1,     "i", "i", get_snap  },
{ "FLsavesnap",S(FLSAVESNAPS), 1,     "", "S", save_snap  },
{ "FLloadsnap",S(FLLOADSNAPS), 1,     "", "S", load_snap  },

{ "FLrun",S(FLRUN),			1,     "",  "", FL_run  },
{ "FLupdate",S(FLRUN),		1,     "",  "", fl_update  },
{ "FLprintk",S(FLPRINTK),	3,     "",  "iki", FLprintkset,FLprintk  },
{ "FLprintk2",S(FLPRINTK2),	2,     "",  "ki", NULL,FLprintk2  },


{ "FLcolor2",S(FLWIDGCOL2),    1,     "",  "jjj", fl_widget_color2  },
{ "FLsetImage",S(FL_SETBITMAP), 1,  "",  "iio", fl_bitmap  },
{ "FLsetOverlay",S(FL_OVERLAY), 2,  "",  "kkkkki", NULL,fl_setOverlay  },
{ "FLtextSize",S(FL_TEXTSIZE),    1,     "",  "i", fl_text_size  },

{ "FLslidBnk",S(FLSLIDERBANK),    1,     "",  "Siooooooooo", fl_slider_bank  },

//-------- OPENGL-RELATED ----------

/// Graphic engine setup-related opcodes
{ "GLfps",S(GLPERIOD),    1,     "",  "io", GLfps },
{ "GLpanel",S(GL_PANEL),    1,     "",  "Sjjooo", GLpanel  },
{ "GLpanel_end",S(GL_NOARG),    1,     "",  "", EndGLpanel  },
{ "GLinsert",S(GL_INSERT),    3,     "",  "i", GLinsert_i, GLinsert  },
{ "GLinsert_i",S(GL_INSERT),    1,     "",  "i", GLinsert_i },
{ "GLfullscreen",S(GL_FULLSCREEN), 1,     "",  "i", GLfullscreen  },
{ "GLredraw", S(GL_ONEARG), 2,    "",   "k",  NULL, GLredraw  },
{ "GLclearwhen", S(GL_TWOARGS), 1,    "",   "ki",   GLclearWhen  },
{ "GLwaitInitStage",S(GL_NOARG),  1,   "",    "", wait_GL_INIT },
{ "GLratio",S(GL_TWOARGS),  1,   "",    "io", set_GLratio },

/// Low-level OpenGL API-wrapping opcodes
{ "glVertex3",S(GL_AXIS), 1,     "",  "kkk", GLvertex3  },
{ "glClearColor",S(GL_COLOR4),     1,     "",  "kkkk", GLclearcolor  },
{ "glColor",S(GL_COLOR4),     1,     "",  "kkkk", GLcolor  },
{ "glColor3",S(GL_COLOR3),     1,     "",  "kkk", GLcolor3  },
{ "glNormal3",S(GL_AXIS), 1,     "",  "kkk", GLnormal3  },
{ "glOrtho",S(GL_ORTHO),     1,     "",  "kkkkkk", GLortho  },
{ "glClear",S(GL_MODE),     1,     "",  "i", GLclear  },
{ "glBegin",S(GL_ONEARG), 1,     "",  "k", GLbegin  },
{ "glEnd",S(GL_NOARG), 1,     "",  "", GLend  },

{ "glMatrixMode",S(GL_MODE),1,     "",  "i", GLmatrixMode  },
{ "glLoadIdentity",S(GL_NOARG),     1,     "",  "", GLloadIdentity  },
{ "glPushMatrix",S(GL_NOARG),     1,     "",  "", GLpushMatrix  },
{ "glPopMatrix",S(GL_NOARG),     1,     "",  "", GLpopMatr  },
{ "glTranslate",S(GL_AXIS),     1,     "",  "kkk", GLtranslate  },
{ "glRotate",S(GL_ROTATE),     1,     "",  "kkkk", GLrotate  },
{ "glScale",S(GL_AXIS),     1,     "",  "kkk", GLscale  },
{ "glEnable",S(GL_ENABLE),     1,     "",  "i", GLenable  },	
{ "glDisable",S(GL_ENABLE),     1,     "",  "i", GLdisable  },
{ "glHint",S(GL_TWOARGS),     1,     "",  "ii", GLhint  },
{ "glLight",S(GL_LIGHT),     1,     "",  "iik", GLlight  },
{ "glLightv",S(GL_LIGHTV),     1,     "",  "iikkkk", GLlightv  },
{ "glLightModel",S(GL_LIGHT_MODEL),     1,     "",  "ik", GLlightModel  },
{ "glLightModelv",S(GL_LIGHT_MODELV),     1,     "",  "iikkkk", GLlightModelv  },
{ "glLineWidth",S(GL_ONEARG),     1,     "",  "k", GLlinewidth  },
{ "glBlendFunc",S(GL_BLENDFUNC),     1,     "",  "ii", GLblendfunc  },
{ "glMaterial",S(GL_MATERIAL),     1,     "",  "kkkkk", glmaterial  },
{ "GLshininess",S(GL_ONEARG),     1,     "",  "k", glshininess  },
{ "glShadeModel",S(GL_ONEARG),     1,     "",  "k", GLshademodel  },
{ "glBindTexture",S(GL_ONEARG), 1,     "",  "k", GLbindtexture  },
{ "glTexCoord2",S(GL_TWOARGS), 1,     "",  "kk", GLtexcoord2  },

{ "glCullFace",S(GL_ONEARG),     1,     "",  "i", GLcullFace  },
{ "glFrontFace",S(GL_ONEARG),    1,     "",  "i", GLfrontFace  },

{ "glPixelTransfer",S(GL_TWOARGS),    1,     "",  "ik", GLpixelTransfer  },
{ "glPixelMap",S(GL_PIXEL_MAP),    1,     "",  "iii", GLpixelMap  },

{ "glDrawBuffer",S(GL_ONEARG),    1,     "",  "k", GLdrawBuffer  },
{ "glNewList",S(GL_ONEARG), 1,     "",  "i", GLnewList  },
{ "glEndList",S(GL_NOARG), 1,     "",  "", GLendList  },
{ "glCallList",S(GL_ONEARG), 1,     "",  "i", GLcallList  },

{ "glTexEnvi",S(GL_ONEARG), 1,     "",  "k", GLtexEnvi  },
{ "glTexEnvfv",S(GL_COLOR4), 1,     "",  "kkkk", GLtexEnvfv  },
{ "glTexGeni",S(GL_TWOARGS), 1,     "",  "ik", GLtexGeni  },
{ "glTexGenfv",S(GL_TEXGENFV), 1,     "",  "iikkkk", GLtexGenfv  },

{ "glEnableClientState",S(GL_ONEARG), 1,     "",  "i", GLenableClientState  },
{ "glDisableClientState",S(GL_ONEARG), 1,     "",  "i", GLdisableClientState  },
{ "glVertexPointer",S(GL_POINTER), 1,     "",  "iii", GLvertexPointer  },
{ "glNormalPointer",S(GL_POINTER), 1,     "",  "iii", GLnormalPointer  },
{ "glColorPointer",S(GL_POINTER), 1,     "",  "iii", GLcolorPointer  },
{ "glIndexPointer",S(GL_POINTER), 1,     "",  "iii", GLindexPointer  },
{ "glTexCoordPointer",S(GL_POINTER), 1,     "",  "iii", GLtexCoordPointer  },
{ "glEdgeFlagPointer",S(GL_POINTER), 1,     "",  "iii", GLedgeFlagPointer  },

{ "glArrayElement",S(GL_ONEARG), 1,     "",  "k", GLarrayElement  },
{ "glDrawElements",S(GL_DRAWELEMENTS), 1,   "",  "kii", GLdrawElements  },
{ "glDrawArrays",S(GL_DRAWARRAYS), 1,     "",  "kkk", GLdrawArrays  },

{ "glLoadMatrixv",S(GL_MATRIXV), 1,     "",  "i", GLloadMatrixv  },
{ "glMultMatrixv",S(GL_MATRIXV), 1,     "",  "i", GLmultMatrixv  },
{ "glLoadMatrix",S(GL_MATRIX), 1,     "",  "kkkkkkkkkkkkkkkk", GLloadMatrix  },
{ "glMultMatrix",S(GL_MATRIX), 1,     "",  "kkkkkkkkkkkkkkkk", GLmultMatrix  },

{ "glFrustum",S(GL_FRUSTUM), 1,     "",  "kkkkkk", GLfrustum  },
{ "glClipPlane",S(GL_CLIPLANE), 1,     "",  "ikkkk", GLclipPlane  },

{ "glEvalCoord1",S(GL_ONEARG), 1,     "",  "k", GLevalCoord1  },
{ "glEvalCoord2",S(GL_TWOARGS), 1,     "",  "kk", GLevalCoord2  },
{ "glEvalMesh1",S(GL_EVALMESH1), 1,     "",  "kkk", GLevalMesh1  },
{ "glEvalMesh2",S(GL_EVALMESH2), 1,     "",  "kkkkk", GLevalMesh2  },
{ "glMap1",S(GL_MAP1), 1,     "",  "iiiiii", GLmap1  },
{ "glMap2",S(GL_MAP2), 1,     "",  "iiiiiiiiii", GLmap2  },
{ "glMapGrid1",S(GL_MAPGRID1), 1,     "",  "kkk", GLmapGrid1  },
{ "glMapGrid2",S(GL_MAPGRID2), 1,     "",  "kkkkkk", GLmapGrid2  },

/// middle-level and glu-related opcodes
{ "gluPerspective",S(GL_PERSP),    1,     "",  "kkk", GLperspective  },
{ "gluLookAt",S(GLU_LOOKAT), 1,     "",  "kkkkkkkkk", GLUlookAt  },
{ "gluNewQuadric",S(GL_TWOARGS), 1,     "i",  "o", GLUnewquadric  },
{ "gluSphere",S(GLU_SPHERE), 1,     "",  "ikkk", GLUsphere  },
{ "gluCylinder",S(GLU_CYLINDER), 1,     "",  "ikkkkk", GLUcylinder  },
{ "gluDisk",S(GLU_DISK), 1,     "",  "ikkk", GLUdisk  },
{ "gluQuadricDrawStyle",S(GL_TWOARGS), 1,     "",  "ik", GLUquadricDrawStyle  },
{ "gluQuadricNormals",S(GL_TWOARGS), 1,     "",  "ik", GLUquadricNormals  },
{ "gluQuadricTexture",S(GL_TWOARGS), 1,     "",  "ik", GLUquadricTexture  },

{ "gluTessBeginPolygon",S(GL_NOARG), 1,   "",  "", GLUtessBeginPolygon  },
{ "gluTessEndPolygon",S(GL_NOARG),   1,   "",  "", GLUtessEndPolygon  },
{ "gluTessBeginContour",S(GL_NOARG), 1,   "",  "", GLUtessBeginContour  },
{ "gluTessEndContour",S(GL_NOARG),   1,   "",  "", GLUtessEndContour  },
{ "gluTessVertexv",S(GLU_TESS_VERTEXV),1, "",  "ik", GLUtessVertexv  },
{ "gluTessVertex",S(GLU_TES_VERTEX), 1,   "",  "kkk", GLUtessVertex  },

{ "gluNewNurbsRenderer",S(GL_ONEARG), 1,     "i",  "", GLUnewNurbsRenderer  },
{ "gluBeginCurve",S(GL_ONEARG), 1,     "",  "i", GLUbeginCurve  },
{ "gluEndCurve",S(GL_ONEARG), 1,     "",  "i", GLUendCurve  },
{ "gluBeginSurface",S(GL_ONEARG), 1,     "",  "i", GLUbeginSurface  },
{ "gluEndSurface",S(GL_ONEARG), 1,     "",  "i", GLUendSurface  },
{ "gluBeginTrim",S(GL_ONEARG), 1,     "",  "i", GLUbeginTrim  },
{ "gluEndTrim",S(GL_ONEARG), 1,     "",  "i", GLUendTrim  },
{ "gluNurbsCurve",S(GLU_NURBSCURVE), 1,     "",  "iiiiiii", GLUnurbsCurve  },
{ "gluNurbsSurface",S(GLU_NURBSSURFACE), 1, "",  "iiiiiiiiiii", GLUnurbsSurface  },
{ "gluNurbsProperty",S(GLU_NURBSPROPERTY), 1, "",  "iik", GLUnurbsProperty  },
{ "gluPwlCurve",S(GLU_PWLCURVE), 1,     "",  "iiiii", GLUpwlCurve  },

/// High-level OpenGL opcodes
{ "glutSphere",S(GLUTSPHERE),    1,     "",  "kkki", GLUTsphere  },
{ "glutTorus",S(GLUTORUS),    1,     "",  "kkkki", GLUTtorus  },
{ "glutCube",S(GL_TWOARGS), 1,     "",  "ki", GLUTcube  },
{ "glutDodecahedron",S(GL_ONEARG),    1,     "",  "i", GLUTdodecahedron  },
{ "glutOctahedron",S(GL_ONEARG),     1,     "",  "i", GLUToctahedron  },
{ "glutTetrahedron",S(GL_ONEARG),    1,     "",  "i", GLUTtetrahedron  },
{ "glutIcosahedron",S(GL_ONEARG),    1,     "",  "i", GLUTicosahedron  },

{ "GLloadTexture",S(GL_LOAD_TEXTURE), 1,     "i", "Sii", GLloadTexture  },
{ "GLwavefrontModel",S(GL_READ_OBJECT), 1,     "i",  "Siioo", GLreadObject  },

{ "GLtexCube", S(GL_TEXSQUARE), 1,    "",   "kkkkkkkkk",GLtexCube     },
{ "GLtexSquare", S(GL_TEXSQUARE), 1,    "",   "kkkkkkkkk",GLtexSquare     },
{ "GLtexCircle", S(GL_TEXCIRCLE), 1,    "",   "kikkkk",GLtexCircle     },

#ifdef WIN32 
{ "GLtext3d", S(GL_TEXT3D), 1,    "",   "Si",GLtext3d     },
{ "GLfont3d", S(GL_3D_FONT), 1,    "i",   "Siii",GL3Dfont     },
#endif /* WIN32 */

/// Flow of control for graphic engine
{ "GLfor",S(GL_FOR), 1,     "k",  "kkk", GLfor  },
{ "GLend_for",S(GL_FOR), 1,     "",  "", GLfor_end  },

{ "GLif",S(GL_IF), 1,     "",  "kik", GLif  },
{ "GLelse",S(GL_IF), 1,     "",  "", GLelse  },
{ "GLend_if",S(GL_IF), 1,     "",  "", GLend_if  },

/// Frame-rate math operators
{ "GLsum",S(AOP), 1,     "k",  "kk", GLsum  },
{ "GLsub",S(AOP), 1,     "k",  "kk", GLsub  },
{ "GLmul",S(AOP), 1,     "k",  "kk", GLmul  },
{ "GLdiv",S(AOP), 1,     "k",  "kk", GLdiv  },
{ "GLmod",S(AOP), 1,     "k",  "kk", GLmod  },

{ "GLint",S(EVAL), 1,     "k",  "k", GLint1  },
{ "GLfrac",S(EVAL), 1,     "k",  "k", GLfrac  },
{ "GLrnd",S(EVAL), 1,     "k",  "k", GLrnd  },
{ "GLbirnd",S(EVAL), 1,     "k",  "k", GLbirnd  },
{ "GLabs",S(EVAL), 1,     "k",  "k", GLabs  },
{ "GLexp",S(EVAL), 1,     "k",  "k", GLexp  },
{ "GLlog",S(EVAL), 1,     "k",  "k", GLlog  },
{ "GLsqr",S(EVAL), 1,     "k",  "k", GLsqr  },
{ "GLsin",S(EVAL), 1,     "k",  "k", GLsin  },
{ "GLcos",S(EVAL), 1,     "k",  "k", GLcos  },
{ "GLtan",S(EVAL), 1,     "k",  "k", GLtan  },
{ "GLasin",S(EVAL), 1,     "k",  "k", GLasin  },
{ "GLacos",S(EVAL), 1,     "k",  "k", GLacos  },
{ "GLatan",S(EVAL), 1,     "k",  "k", GLatan  },
{ "GLsinh",S(EVAL), 1,     "k",  "k", GLsinh  },
{ "GLcosh",S(EVAL), 1,     "k",  "k", GLcosh  },
{ "GLtanh",S(EVAL), 1,     "k",  "k", GLtanh  },
{ "GLlog10",S(EVAL), 1,     "k",  "k", GLlog10  },

/// Frame-rate vector operators
{ "GLvadd",S(VECTOROP),  1,   "",    "iki", GLvadd },
{ "GLvmult",S(VECTOROP),  1,   "",    "iki", GLvmult },
{ "GLvpow",S(VECTOROP),  1,   "",    "iki", GLvpow },
{ "GLvexp",S(VECTOROP),  1,   "",    "iki", GLvexp },

{ "GLvaddv",S(VECTORSOP),  1,   "",    "iii", GLvaddv },
{ "GLvsubv",S(VECTORSOP),  1,   "",    "iii", GLvsubv },
{ "GLvmultv",S(VECTORSOP),  1,   "",    "iii", GLvmultv },
{ "GLvdivv",S(VECTORSOP),  1,   "",    "iii", GLvdivv },
{ "GLvpowv",S(VECTORSOP),  1,   "",    "iii", GLvpowv },
{ "GLvexpv",S(VECTORSOP),  1,   "",    "iii", GLvexpv },
{ "GLvcopy",S(VECTORSOP),  1,   "",    "iii", GLvcopy },
{ "GLvmap",S(VECTORSOP),  1,   "",    "iii", GLvmap },

{ "GLvlimit",S(VLIMIT),  1,   "",    "ikki", GLvlimit },
{ "GLvwrap",S(VLIMIT),  1,   "",    "ikki", GLvwrap },
{ "GLvmirror",S(VLIMIT),  1,   "",    "ikki", GLvmirror },

/// Frame-rate signal generators
{ "GLtab",S(FASTAB),  1,   "k",    "kio", GLtab },
{ "GLtabw",S(FASTAB),  1,   "",    "kkio", GLtabw },

{ "GLvtab", S(MTAB),   1,    "",   "kiz", GLvtab    },
{ "GLvtabw", S(MTABW), 1,    "",   "kiz",  GLvtabw  },

{ "GLphasor", S(GL_PHASOR), 1,    "k",   "ko",  GLphasor  },
{ "GLoscil", S(GL_OSCIL), 1,    "k",   "kkio",  GLoscil  },
{ "GLoscili", S(GL_OSCIL), 1,    "k",   "kkio",  GLoscili  },
{ "GLmetro", S(GL_METRO), 1,    "k",   "ko",  GLmetro  },

{ "GLvphaseseg",S(VPSEG),  1,   "",    "kiim", GLvphaseseg },

/// Video-related
#ifdef WIN32

{ "GLopenVideoFile", S(GL_OPEN_VIDEO_FILE), 1,    "i",   "Si",GLopenVideoFile     },
{ "GLvideo2tex", S(GL_VIDEO2TEX), 1,    "k",   "kk",GLvideo2tex     },
{ "GLvideoCapture", S(GL_OPEN_VIDEO_CAM), 1,    "",   "iiiioooo",GLopenVideoCam     },

//{ "GLcamDialog", S(GL_CAM_DLG), 1,    "",   "i",GLcamDialog     },

#endif /* WIN32 */

/// Bitmap (pixmap) Image processing
{ "img2GLtex", S(GL_PIX2TEX), 3,    "i",   "kkkk",GLpix2tex_set, GLpix2tex    },
{ "imgGain", S(IMG_GAIN), 3,    "k",   "ikkkkkio",imgGain_set, imgGain    },
{ "imgConvolve", S(IMG_CONVOLVE), 3,    "",   "ikkki",imgConvolve_set, imgConvolve    },
{ "imgPoint", S(IMG_SETPIXEL), 3,    "",   "kkkkkkki",imgSetPixel_set, imgSetPixel    },
{ "imgCreate",  S(BMCREATE),1,      "",   "iiiioooo", bmcreate},


//-----------------------
{ "GLloadPicasso",S(LOAD_PICASSO),  1,   "ii",    "S", GLload_picasso },
{ "GLrenderPicasso",S(RENDER_PICASSO),  1,   "",    "kkz", GLrender_picasso },

//-----------------------

{ "zr_i",  S(ZKR),	1,     "i",	"i",	zread,	 NULL, 	NULL},
{ "zr_k",  S(ZKR),	2,     "k",	"k",	NULL,   zread,	NULL},
{ "zr_a",  S(ZAR),	5,     "a",	"a",	zaset,   NULL, 	zar},

// rate converters
{ "k_i",	   S(ZKR),	1,     "k",	"i",	assign},
{ "a_k",	  S(INDIFF),	5,	"a",	"k",	a_k_set,NULL,	interp	},
{ "g_k",	  S(G_RATE),	3,	"k",	"k",	GLgk_set, GLgk	},
{ "tabk2g",	  S(G_RATE_TAB),3,	"",	"iiio",	tab2grate_set, GLtab2grate	},
{ "set_g_del", S(GL_SET_FDELAY),	1,	"",	"i",	GLsetFrameDelay },

{ "tb0_init", S(TB_INIT),	1,     "",	"i",	tab0_init},
{ "tb1_init", S(TB_INIT),	1,     "",	"i",	tab1_init},
{ "tb2_init", S(TB_INIT),	1,     "",	"i",	tab2_init},
{ "tb3_init", S(TB_INIT),	1,     "",	"i",	tab3_init},
{ "tb4_init", S(TB_INIT),	1,     "",	"i",	tab4_init},
{ "tb5_init", S(TB_INIT),	1,     "",	"i",	tab5_init},
{ "tb6_init", S(TB_INIT),	1,     "",	"i",	tab6_init},
{ "tb7_init", S(TB_INIT),	1,     "",	"i",	tab7_init},
{ "tb8_init", S(TB_INIT),	1,     "",	"i",	tab8_init},
{ "tb9_init", S(TB_INIT),	1,     "",	"i",	tab9_init},
{ "tb10_init", S(TB_INIT),	1,     "",	"i",	tab10_init},
{ "tb11_init", S(TB_INIT),	1,     "",	"i",	tab11_init},
{ "tb12_init", S(TB_INIT),	1,     "",	"i",	tab12_init},
{ "tb13_init", S(TB_INIT),	1,     "",	"i",	tab13_init},
{ "tb14_init", S(TB_INIT),	1,     "",	"i",	tab14_init},
{ "tb15_init", S(TB_INIT),	1,     "",	"i",	tab15_init},

{ "tb0_k",	  S(FASTB),		2,     "k",	"k",	NULL,   tab0,	NULL},
{ "tb1_k",	  S(FASTB),		2,     "k",	"k",	NULL,   tab1,	NULL},
{ "tb2_k",	  S(FASTB),		2,     "k",	"k",	NULL,   tab2,	NULL},
{ "tb3_k",	  S(FASTB),		2,     "k",	"k",	NULL,   tab3,	NULL},
{ "tb4_k",	  S(FASTB),		2,     "k",	"k",	NULL,   tab4,	NULL},
{ "tb5_k",	  S(FASTB),		2,     "k",	"k",	NULL,   tab5,	NULL},
{ "tb6_k",	  S(FASTB),		2,     "k",	"k",	NULL,   tab6,	NULL},
{ "tb7_k",	  S(FASTB),		2,     "k",	"k",	NULL,   tab7,	NULL},
{ "tb8_k",	  S(FASTB),		2,     "k",	"k",	NULL,   tab8,	NULL},
{ "tb9_k",	  S(FASTB),		2,     "k",	"k",	NULL,   tab9,	NULL},
{ "tb10_k",	  S(FASTB),		2,     "k",	"k",	NULL,   tab10,	NULL},
{ "tb11_k",	  S(FASTB),		2,     "k",	"k",	NULL,   tab11,	NULL},
{ "tb12_k",	  S(FASTB),		2,     "k",	"k",	NULL,   tab12,	NULL},
{ "tb13_k",	  S(FASTB),		2,     "k",	"k",	NULL,   tab13,	NULL},
{ "tb14_k",	  S(FASTB),		2,     "k",	"k",	NULL,   tab14,	NULL},
{ "tb15_k",	  S(FASTB),		2,     "k",	"k",	NULL,   tab15,	NULL},

{ "tb0_i",	  S(FASTB),		1,     "i",	"i",	tab0	},
{ "tb1_i",	  S(FASTB),		1,     "i",	"i",	tab1	},
{ "tb2_i",	  S(FASTB),		1,     "i",	"i",	tab2	},
{ "tb3_i",	  S(FASTB),		1,     "i",	"i",	tab3	},
{ "tb4_i",	  S(FASTB),		1,     "i",	"i",	tab4	},
{ "tb5_i",	  S(FASTB),		1,     "i",	"i",	tab5	},
{ "tb6_i",	  S(FASTB),		1,     "i",	"i",	tab6	},
{ "tb7_i",	  S(FASTB),		1,     "i",	"i",	tab7	},
{ "tb8_i",	  S(FASTB),		1,     "i",	"i",	tab8	},
{ "tb9_i",	  S(FASTB),		1,     "i",	"i",	tab9	},
{ "tb10_i",	  S(FASTB),		1,     "i",	"i",	tab10	},
{ "tb11_i",	  S(FASTB),		1,     "i",	"i",	tab11	},
{ "tb12_i",	  S(FASTB),		1,     "i",	"i",	tab12	},
{ "tb13_i",	  S(FASTB),		1,     "i",	"i",	tab13	},
{ "tb14_i",	  S(FASTB),		1,     "i",	"i",	tab14	},
{ "tb15_i",	  S(FASTB),		1,     "i",	"i",	tab15	},

{ "specinfo",	  S(SPECINFO),		1,     "iii",	"w",	specinfo },
{ "spec2tab",	  S(SPEC2TABLE),	3,     "",	"wikoo",	spec2table_set, spec2table },

{ "timedseq",S(TIMEDSEQ),		3,     "k",  "kiz", timeseq_set,timeseq  },

{ "splitrig",	  S(SPLIT_TRIG),	3,     "",	"kkiiz",	split_trig_set, split_trig },

{ "tabrec",		  S(TABREC),		3,     "",	"kkkkz",	tabrec_set, tabrec_k },
{ "tabplay",	  S(TABPLAY),		3,     "",	"kkkz",		tabplay_set, tabplay_k },

{ "vphaseseg",    S(VPSEG),			3,     "",	"kiim",		vphaseseg_set, vphaseseg },


{ "lposcinta",   S(LPOSC),5,		  "a",   "akkkio", lposc_set, NULL,   lposcinta},
{ "lposcintsa",   S(LPOSC_ST),5,      "aa",   "akkkio", lposc_stereo_set, NULL,   lposcinta_stereo},
{ "lposcintsa2",  S(LPOSC_ST),5,      "aa",   "akkkio", lposc_stereo_set, NULL,   lposcinta_stereo_no_trasp},

{ "exitnow",S(EXITNOW),			1,     "",  "", exitnow  },
{ "turnoffk",S(TURNOFFK),		2,     "",  "k", NULL, turnoffk  },
{ "changed",    S(ISCHANGED),		3,     "k",	"z",		isChanged_set, isChanged },

{ "Trandom",    S(TRANGERAND),		2,     "k",	"kkk",		NULL, trRangeRand },
{ "system",  S(CSSYSTEM),1,      "",   "S", CSsystem},
{ "ftlen_k",S(EVAL),	2,	"k",	"k", NULL,	ftlen			},
{ "max_k",  S(P_MAXIMUM),	5,	"k",	"aki", 	partial_maximum_set,NULL,partial_maximum			},


};
	
/* CsoundAV External libraries:

	dsound.lib eaxguid.lib winmm.lib paintlib.lib libtiff.lib libjpeg.lib libpng.lib fltkd.lib opengl32.lib glut32.lib glu32.lib 
  
	- dsound.lib		Microsoft DirectX/DirectSound SDK
						search latest SDK on the internet
	- winmm.lib			Microsoft Multi Media extensions  
						included in Windows 95 SE/98/NT/2000
  
	- FLTK -->			http://www.fltk.org
  
	- Paintlib -->		http://www.paintlib.de/paintlib/
						see also libtiff, libpng, libjpeg and zlib
	- EAX 2.0 -->		http://developer.soundblaster.com/
	- OpenGL -->		included in Windows 95 SE/98/NT/2000  
						or you can download SGI distribution at: http://www.berkelium.com/OpenGL/sgi-opengl.html
	- GLUT	-->			http://www.xmission.com/~nate/opengl.html
	- Particle API-> 	http://www.cs.unc.edu/~davemc/Particle/
  	- GLpng -->			included in the sources
						http://www.wyatt100.freeserve.co.uk/download.htm
	- tdlib.lib	-->		Three-D Object Library by Nathan Drew Robins - http://www.cs.utah.edu/~narobins/opengl.html
*/	

long oplength_gab = sizeof(opcodlst_gab);
