#include "widg.h"

#if defined (_WIN32)
#	pragma warning(disable: 985 4786 4117 4804 )
#endif
//---------------
#define DEFAULT_WIDTH 400
#define DEFAULT_HEIGHT 400

extern "C" int isFLTKenabled;

static int curr_x = 0 , curr_y = 0;
int FLstack_count=0;

static int FLcontrol_iheight = 15;
static int FLroller_iheight = 18;
static int FLcontrol_iwidth = DEFAULT_WIDTH;
static int FLroller_iwidth = 150;
static int FLvalue_iwidth = 100;

static int FLcolor = -1;
static int FLcolor2 = -1;
static int FLtext_size = 0;
static int FLtext_color = -1;
static int FLtext_font = -1;
static int FLtext_align = 0;

static int FL_ix = 10;
static int FL_iy = 10;

vector<PANELS> fl_windows; // all panels
vector<ADDR_STACK> AddrStack; //addresses of containers 
extern vector<ADDR_SET_VALUE> AddrSetValue; //addresses of valuators 
vector<char*> allocatedStrings;
static unsigned long threadHandle;
extern vector<SNAPSHOT> snapshots; 
extern map<int,imageStruct> Bm_image; // map of pointers to CAnyBmp objects

static Fl_Window *oKeyb;
static int isActivatedKeyb=0;

int wait_run=0; // blocks Audio Thread until Widget Thread is running

static FLKEYB* keybp = NULL;
static int symbol_label_flag;
static int flruns=0;
extern int update_interval;
extern int update_interval_resolution;
#ifdef WIN32
HWND callback_target;
#endif



//-----------

char * GetString(MYFLT pname, char *t){
	char    *Name; //=  new char[MAXNAME];
	char s[MAXNAME];
	
	if (pname == sstrcod) { 
		if (t == NULL) strcpy(s,unquote(currevent->strarg));
		else strcpy(s, unquote(t));
		
	} 
	else if ((long)pname <= strsmax && strsets != NULL && strsets[(long)pname]) {
		strcpy(s, strsets[(long)pname]);
	}	
	Name =  new char[strlen(s)+2];
	strcpy(Name,s);
	if (*Name == '@') symbol_label_flag=1;
	else symbol_label_flag=0;
	allocatedStrings.push_back(Name);
	return Name;
}


#ifdef RESET
extern "C" void widgetRESET()
{
	int j;
	for (j = allocatedStrings.size()-1; j >=0; j--)  {
		delete [] allocatedStrings[j];
		allocatedStrings.pop_back();
	}
	for (j=fl_windows.size()-1; j >=0 ; j--) { //destroy all opened panels
		if  (fl_windows[j].is_subwindow == 0)	
			delete fl_windows[j].panel;
		fl_windows.pop_back();
	}
	//for (j = AddrValue.size()-1; j >=0; j--)  {
	//	AddrValue.pop_back();
	//}
	int ss = snapshots.size()-1;
	for (j=ss; j>=0; j--) {
		snapshots[j].fields.erase(snapshots[j].fields.begin(),snapshots[j].fields.end());
		snapshots.pop_back();
	}
	if (isActivatedKeyb) {
		delete oKeyb;
	}
	//keyb_out=0;
	isActivatedKeyb=0;
	keybp = NULL;
	
	AddrSetValue.clear();

	
	curr_x = 0 , curr_y = 0;
	FLstack_count=0;
	
	FLcontrol_iheight = 15;
	FLroller_iheight = 18;
	FLcontrol_iwidth = DEFAULT_WIDTH;
	FLroller_iwidth = 150;
	FLvalue_iwidth = 100;
	
	FLcolor = -1;
	FLcolor2 = -1;
	FLtext_size = 0;
	FLtext_color = -1;
	FLtext_font = -1;
	FLtext_align = 0;
//	keyb_out = 0;
	FL_ix = 10;
	FL_iy = 10;
	flruns =0;
	wait_run=0; // blocks Audio Thread until Widget Thread is running
#ifdef WIN32
	callback_target=0;
#endif
	isFLTKenabled = 0;
}

#endif

//----------------------------------------------
//----------------------------------------------
#include "widgets2.cpp"
//----------------------------------------------
//----------------------------------------------


void widget_attributes(Fl_Widget *o)
{
	if (FLtext_size == -2 ) {
		FLtext_size = -1;
		FLtext_color= -1;
		FLtext_font = -1;
		FLtext_align= -1;
		FLcolor = -1;
	}
	if (FLtext_size)  o->labelsize(FLtext_size); // if > 0 assign it, else skip, leaving default
	switch ((int) FLtext_color) {
		case -2: // random color  
			o->labelcolor(
				fl_color_cube( 
					(rand()*256. / RAND_MAX) * FL_NUM_RED/256, 
					(rand()*256. / RAND_MAX) * FL_NUM_GREEN/256, 
					(rand()*256. / RAND_MAX) * FL_NUM_BLUE/256 
				)  
			); 
			break;
		case -1:  // if FLtext_color is == -1, color assignment is skipped, leaving default color
			break;
		default:
			o->labelcolor(FLtext_color);
			break;
	}
	if (FLtext_font> 0) {
		Fl_Font font;
		switch (FLtext_font) {
			case 1: font = FL_HELVETICA; break;
			case 2: font = FL_HELVETICA_BOLD; break;
			case 3: font = FL_HELVETICA_ITALIC; break;
			case 4: font = FL_HELVETICA_BOLD_ITALIC; break;
			case 5: font = FL_COURIER; break;
			case 6: font = FL_COURIER_BOLD; break;
			case 7: font = FL_COURIER_ITALIC; break;
			case 8: font = FL_COURIER_BOLD_ITALIC; break;
			case 9: font = FL_TIMES; break;
			case 10: font = FL_TIMES_BOLD; break;
			case 11: font = FL_TIMES_ITALIC; break;
			case 12: font = FL_TIMES_BOLD_ITALIC; break;
			case 13: font = FL_SYMBOL; break;
			case 14: font = FL_SCREEN; break;
			case 15: font = FL_SCREEN_BOLD; break;
			case 16: font = FL_ZAPF_DINGBATS; break;
			default: font = FL_HELVETICA; break;
		}
		o->labelfont(font);
	}
	if (FLtext_align > 0) {
		Fl_Align type;
		switch (FLtext_align) {
			case -1: break;
			case 1: type = FL_ALIGN_CENTER; break;
			case 2: type = FL_ALIGN_TOP; break;
			case 3: type = FL_ALIGN_BOTTOM; break;
			case 4: type = FL_ALIGN_LEFT; break;
			case 5: type = FL_ALIGN_RIGHT; break;
			case 6: type = FL_ALIGN_TOP_LEFT; break;
			case 7: type = FL_ALIGN_TOP_RIGHT; break;
			case 8: type = FL_ALIGN_BOTTOM_LEFT; break;
			case 9: type = FL_ALIGN_BOTTOM_RIGHT; break;
			default: type = FL_ALIGN_BOTTOM; break;
		}
		o->align(type);
	}
	switch ((int) FLcolor) { 
		case -2:// light random color  
			o->color( 
				fl_color_cube( 
					(rand()*128. / RAND_MAX+128) * FL_NUM_RED/256, 
					(rand()*128. / RAND_MAX+128) * FL_NUM_GREEN/256, 
					(rand()*128. / RAND_MAX+128) * FL_NUM_BLUE/256 
				)  
			);
			break;
		case -3:// dark random color  
			o->color( 
				fl_color_cube( 
					(rand()*128. / RAND_MAX) * FL_NUM_RED/256, 
					(rand()*128. / RAND_MAX) * FL_NUM_GREEN/256, 
					(rand()*128. / RAND_MAX) * FL_NUM_BLUE/256 
				)  
			);
			break;
		case -1: // if FLcolor is == -1, color assignment is skipped, leaving widget default color
			break;
		default:
			o->color(FLcolor); 
			break;
	}
	switch ((int) FLcolor2) { 
		case -2:// light random color  
			o->selection_color( 
				fl_color_cube( 
					(rand()*128. / RAND_MAX+128) * FL_NUM_RED/256, 
					(rand()*128. / RAND_MAX+128) * FL_NUM_GREEN/256, 
					(rand()*128. / RAND_MAX+128) * FL_NUM_BLUE/256 
				)  
			);
			break;
		case -3:// dark random color  
			o->selection_color( 
				fl_color_cube( 
					(rand()*128. / RAND_MAX) * FL_NUM_RED/256, 
					(rand()*128. / RAND_MAX) * FL_NUM_GREEN/256, 
					(rand()*128. / RAND_MAX) * FL_NUM_BLUE/256 
				)  
			);
			break;
		case -1: // if FLcolor is == -1, color assignment is skipped, leaving widget default color
			break;
		default:
			o->selection_color(FLcolor2); 
			break;
	}
}


//-----------


extern "C" void FLkeyb(FLKEYB *p)
{
	isActivatedKeyb = 1;
	oKeyb = FLkeyboard_init();
	keybp = p; //output of the keyboard is stored into a global variable pointer
}


//-----------

void skin(Fl_Widget *o, int imgNum)
{
		imageStruct *bmp = &Bm_image[imgNum];
		FLlock();
		Fl_RGB_Image *img = new Fl_RGB_Image((BYTE*) (bmp->data),bmp->xsize,bmp->ysize,bmp->csize);
		Fl_Tiled_Image *t_img = new Fl_Tiled_Image(img);
		o->image(t_img);
		o->align(FL_ALIGN_INSIDE);
		FLunlock();
		allocatedStrings.push_back((char *) t_img);
		allocatedStrings.push_back((char *) img);
}


//-----------

extern "C" void StartPanel(FLPANEL *p)
{
	isFLTKenabled = 1;
	char* panelName = GetString(*p->name,p->STRARG);
	
	int x = *p->ix, y =*p->iy, width = *p->iwidth, height=*p->iheight;
	if(width <0) width = DEFAULT_WIDTH; //default
	if(height <0) height = DEFAULT_HEIGHT;

	int borderType;
	switch( (int) *p->border ) {
		case 0: borderType = FL_FLAT_BOX; break;
		case 1: borderType = FL_DOWN_BOX; break;
		case 2: borderType = FL_UP_BOX; break;
		case 3:	borderType = FL_ENGRAVED_BOX; break;
		case 4:	borderType = FL_EMBOSSED_BOX; break;
		case 5:	borderType = FL_BORDER_BOX; break;
		case 6:	borderType = FL_THIN_DOWN_BOX; break;
		case 7:	borderType = FL_THIN_UP_BOX; break;
		default: borderType = FL_FLAT_BOX;
	}
	
	Fl_Window *o;
	if(x < 0) o = new Fl_Double_Window(width,height, panelName);
	else 	o = new Fl_Double_Window(x,y,width,height, panelName);
	o->box((Fl_Boxtype) borderType);
	o->resizable(o);
	widget_attributes(o);
#ifdef GAB_WIN //sets the window icon
	o->icon((char *)LoadIcon(hProcessInstance, MAKEINTRESOURCE(IDI_ICON2)));
#endif
	if (*p->image >= 0) skin(o, (int) *p->image);
	ADDR_STACK adrstk(&p->h, (void *) o, FLstack_count);
	AddrStack.push_back(adrstk);
	PANELS panel(o, (FLstack_count>0) ? 1 : 0);
	fl_windows.push_back(panel);
	FLstack_count++;
}

extern "C" void EndPanel(FLPANELEND *p)
{
	FLstack_count--;
	ADDR_STACK adrstk = AddrStack.back();
	if (strcmp( adrstk.h->optext->t.opcod, "FLpanel"))
		initerror("FLpanel_end: invalid stack pointer: verify its placement");
	if(adrstk.count != FLstack_count)
		initerror("FLpanel_end: invalid stack count: verify FLpanel/FLpanel_end count and placement");
	((Fl_Window*) adrstk.WidgAddress)->end();
	AddrStack.pop_back();

}

//-----------
/*
typedef struct	{
	OPDS	h;
	MYFLT  *name, *iwidth, *iheight, *ix, *iy, *border;
} FL_TILE_GROUP;


extern "C" void FLtiledImage(FL_TILE_GROUP *p)
{
	char* Name = GetString(*p->name,p->STRARG);
	
	int x = *p->ix, y =*p->iy, width = *p->iwidth, height=*p->iheight;
	if(width <0) width = DEFAULT_WIDTH; //default
	if(height <0) height = DEFAULT_HEIGHT;

	int borderType;
	switch( (int) *p->border ) {
		case 0: borderType = FL_FLAT_BOX; break;
		case 1: borderType = FL_DOWN_BOX; break;
		case 2: borderType = FL_UP_BOX; break;
		case 3:	borderType = FL_ENGRAVED_BOX; break;
		case 4:	borderType = FL_EMBOSSED_BOX; break;
		case 5:	borderType = FL_BORDER_BOX; break;
		case 6:	borderType = FL_THIN_DOWN_BOX; break;
		case 7:	borderType = FL_THIN_UP_BOX; break;
		default: borderType = FL_FLAT_BOX;
	}
	Fl_Group *o = new Fl_Group(x,y,width,height);
	o->box((Fl_Boxtype) borderType);
	widget_attributes(o);
	group.image(new Fl_Tiled_Image(new Fl_Pixmap((const char * const *)tile_xpm)));
	group.align(FL_ALIGN_INSIDE);


}

CONTINUARE!!!!!!!!!!!!!!!!!


	char *Name = GetString(*p->name,p->STRARG);
    Fl_Group *o = new Fl_Group ((int) *p->ix, (int) *p->iy, (int) *p->iwidth, (int) *p->iheight,Name);
	widget_attributes(o);
	int borderType;
	switch((int)*p->border ) {
		case 0: borderType = FL_FLAT_BOX; break;
		case 1: borderType = FL_DOWN_BOX; break;
		case 2: borderType = FL_UP_BOX; break;
		case 3:	borderType = FL_ENGRAVED_BOX; break;
		case 4:	borderType = FL_EMBOSSED_BOX; break;
		case 5:	borderType = FL_BORDER_BOX; break;
		case 6:	borderType = FL_THIN_DOWN_BOX; break;
		case 7:	borderType = FL_THIN_UP_BOX; break;
		default: borderType = FL_FLAT_BOX;
	}
	o->box((Fl_Boxtype) borderType);
	widget_attributes(o);
	ADDR_STACK adrstk(&p->h,o,FLstack_count);
	AddrStack.push_back(adrstk);
	FLstack_count++;
}

extern "C" void EndGroup(FLGROUPEND *p)
{
	FLstack_count--;
	ADDR_STACK adrstk = AddrStack.back();
	if (strcmp( adrstk.h->optext->t.opcod, "FLgroup"))
		initerror("FLgroup_end: invalid stack pointer: verify its placement");
	if(adrstk.count != FLstack_count)
		initerror("FLgroup_end: invalid stack count: verify FLgroup/FLgroup_end count and placement");
	((Fl_Scroll*) adrstk.WidgAddress)->end();

	AddrStack.pop_back();
}



*/


//-----------
extern "C" void StartScroll(FLSCROLL *p)
{
    
	Fl_Scroll *o = new Fl_Scroll ((int) *p->ix, (int) *p->iy, (int) *p->iwidth, (int) *p->iheight);
	if (*p->image >= 0) skin(o, (int) *p->image);
	o->box(FL_FLAT_BOX);
	ADDR_STACK adrstk(&p->h,o,FLstack_count);
	AddrStack.push_back(adrstk);
	FLstack_count++;
}

extern "C" void EndScroll(FLSCROLLEND *p)
{
	FLstack_count--;
	ADDR_STACK adrstk = AddrStack.back();
	if (strcmp( adrstk.h->optext->t.opcod, "FLscroll"))
		initerror("FLscroll_end: invalid stack pointer: verify its placement");
	if(adrstk.count != FLstack_count)
		initerror("FLscroll_end: invalid stack count: verify FLscroll/FLscroll_end count and placement");
	((Fl_Scroll*) adrstk.WidgAddress)->end();

	AddrStack.pop_back();
}

//-----------
extern "C" void StartTabs(FLTABS *p)
{
    Fl_Tabs *o = new Fl_Tabs ((int) *p->ix, (int) *p->iy, (int) *p->iwidth, (int) *p->iheight);
	widget_attributes(o);
	if (*p->image >= 0) skin(o, (int) *p->image);
	ADDR_STACK adrstk(&p->h,o,FLstack_count);
	AddrStack.push_back(adrstk);
	FLstack_count++;
}

extern "C" void EndTabs(FLTABSEND *p)
{
	FLstack_count--;
	ADDR_STACK adrstk = AddrStack.back();
	if (strcmp( adrstk.h->optext->t.opcod, "FLtabs"))
		initerror("FLscroll_end: invalid stack pointer: verify its placement");
	if(adrstk.count != FLstack_count)
		initerror("FLtabs_end: invalid stack count: verify FLtabs/FLtabs_end count and placement");
	((Fl_Scroll*) adrstk.WidgAddress)->end();

	AddrStack.pop_back();
}

//-----------
extern "C" void StartGroup(FLGROUP *p)
{
	char *Name = GetString(*p->name,p->STRARG);
    Fl_Group *o = new Fl_Group ((int) *p->ix, (int) *p->iy, (int) *p->iwidth, (int) *p->iheight,Name);
	widget_attributes(o);
	if (*p->image >= 0) skin(o, (int) *p->image);
	if (*p->border != 0 ) {
	int borderType;
	switch((int)*p->border ) {
		case 0: borderType = FL_FLAT_BOX; break;
		case 1: borderType = FL_DOWN_BOX; break;
		case 2: borderType = FL_UP_BOX; break;
		case 3:	borderType = FL_ENGRAVED_BOX; break;
		case 4:	borderType = FL_EMBOSSED_BOX; break;
		case 5:	borderType = FL_BORDER_BOX; break;
		case 6:	borderType = FL_THIN_DOWN_BOX; break;
		case 7:	borderType = FL_THIN_UP_BOX; break;
		default: ;//borderType = FL_FLAT_BOX;
	}
	o->box((Fl_Boxtype) borderType);
	}
	widget_attributes(o);
	ADDR_STACK adrstk(&p->h,o,FLstack_count);
	AddrStack.push_back(adrstk);
	FLstack_count++;
}

extern "C" void EndGroup(FLGROUPEND *p)
{
	FLstack_count--;
	ADDR_STACK adrstk = AddrStack.back();
	if (strcmp( adrstk.h->optext->t.opcod, "FLgroup"))
		initerror("FLgroup_end: invalid stack pointer: verify its placement");
	if(adrstk.count != FLstack_count)
		initerror("FLgroup_end: invalid stack count: verify FLgroup/FLgroup_end count and placement");
	((Fl_Scroll*) adrstk.WidgAddress)->end();

	AddrStack.pop_back();
}

//-----------

extern "C" void StartPack(FLPACK *p)
{
    Fl_Pack *o = new Fl_Pack ((int) *p->ix, (int) *p->iy, (int) *p->iwidth, (int) *p->iheight);
	//fl_window->resizable(o);
	//o->box(FL_ENGRAVED_FRAME);
	o->spacing(*p->ispace);
	if (*p->itype == 0) 
		o->type(FL_VERTICAL);
	else
		o->type(FL_HORIZONTAL);
	int borderType;
	switch( (int) *p->border ) {
		case 0: borderType = FL_NO_BOX; break;
		case 1: borderType = FL_DOWN_FRAME; break;
		case 2: borderType = FL_UP_FRAME; break;
		case 3:	borderType = FL_ENGRAVED_FRAME; break;
		case 4:	borderType = FL_EMBOSSED_FRAME; break;
		case 5:	borderType = FL_BORDER_FRAME; break;
		case 6:	borderType = FL_THIN_DOWN_FRAME; break;
		case 7:	borderType = FL_THIN_UP_FRAME; break;
		default: borderType = FL_NO_BOX;
	}
	o->box((Fl_Boxtype) borderType);
	if (*p->image >= 0) skin(o, (int) *p->image);
	ADDR_STACK adrstk(&p->h,o,FLstack_count);;
	AddrStack.push_back(adrstk);
	FLstack_count++;
}

extern "C" void EndPack(FLPACKEND *p)
{
	FLstack_count--;
	ADDR_STACK adrstk = AddrStack.back();
	if (strcmp( adrstk.h->optext->t.opcod, "FLpack"))
		initerror("FLpack_end: invalid stack pointer: verify its placement");
	if(adrstk.count != FLstack_count)
		initerror("FLpack_end: invalid stack count: verify FLpack/FLpack_end count and placement");
	((Fl_Pack*) adrstk.WidgAddress)->end();

	AddrStack.pop_back();

}

//-----------

extern "C" void fl_widget_color(FLWIDGCOL *p)
{
	if (*p->red1 < 0) { // reset colors to default 
		FLcolor = (int) *p->red1; //when called without arguments
		//FLcolor2 =(int) *p->red1;
	}
	else {
		FLcolor = fl_color_cube(
			(int) *p->red1   * FL_NUM_RED  /256,
			(int) *p->green1 * FL_NUM_GREEN/256,
			(int) *p->blue1  * FL_NUM_BLUE /256
		);
	}
}
extern "C" void fl_widget_color2(FLWIDGCOL2 *p)
{
	if (*p->red < 0) { // reset colors to default 
		FLcolor2 =(int) *p->red;
	}
	else {
		FLcolor2 = fl_color_cube(
			(int) *p->red   * FL_NUM_RED  /256,
			(int) *p->green * FL_NUM_GREEN/256,
			(int) *p->blue  * FL_NUM_BLUE /256
		);
	}
}


extern "C" void fl_text_size(FL_TEXTSIZE *p)
{
	FLtext_size = *p->size;
}


extern "C" void fl_widget_label(FLWIDGLABEL *p)
{
	if (*p->size <= 0) { // reset settings to default  
		FLtext_size = 0; //when called without arguments
		FLtext_font = -1;
		FLtext_align = 0;
		FLtext_color = -1;
	}
	else {
		FLtext_size = (int) *p->size;
	
		if (*p->font > -1) FLtext_font = (int) *p->font;
		if (*p->align > 0)  FLtext_align =  (int) *p->align;
		if (*p->red > -1 && *p->green > -1 && *p->blue > -1) {
			FLtext_color = fl_color_cube(
				(int) *p->red   * FL_NUM_RED  /256,
				(int) *p->green * FL_NUM_GREEN/256,
				(int) *p->blue  * FL_NUM_BLUE /256
			);
		}
	}
}
//-----------

extern "C" void fl_setWidgetValuei(FL_SET_WIDGET_VALUE_I *p)
{
	ADDR_SET_VALUE v = AddrSetValue[(int) *p->ihandle];
	MYFLT val = *p->ivalue, range, base;
	switch (v.exponential) {
		case LIN_: //linear
			if (val > v.max) val = v.max;
			else if (val < v.min) val = v.min;
			break; 
		case EXP_: //exponential
			range = v.max-v.min; 
			base = pow(v.max / v.min, 1/range);
			val = (log(val/v.min) / log(base)) ;
			break; 
		default: 
			warning("not implemented yet");
	}
    

	Fl_Widget *o = (Fl_Widget *) v.WidgAddress;
	
	FLlock();
	if (!(strcmp(((OPDS *) v.opcode)->optext->t.opcod, "FLbutton"))) {
		((Fl_Button *)o)->value(val);
	} else if (!(strcmp(((OPDS *) v.opcode)->optext->t.opcod, "FLbutBank"))) {
		
		set_butbank_value((Fl_Group *)o, val);
	} else if (!(strcmp(((OPDS *) v.opcode)->optext->t.opcod, "FLjoy"))) {
		static int flag=1;
		if (flag) { //FLsetVal  always requires two adjacent calls when setting FLjoy
				((Fl_Positioner *)o)->xvalue(val);
				flag = 0;
		}
		else {
				((Fl_Positioner *)o)->yvalue(val);
				flag = 1;
		}
	}
	else
		((Fl_Valuator *)o)->value(val);
		
	o->do_callback(o, v.opcode);
	FLunlock();
}


extern "C" void fl_setWidgetValue_set(FL_SET_WIDGET_VALUE *p)
{
	ADDR_SET_VALUE v = AddrSetValue[(int) *p->ihandle];
	MYFLT  /* val = *p->ivalue, */ range, base;
	p->max = v.max;
	p->min = v.min;
	p->WidgAddress = v.WidgAddress;
	p->opcode = v.opcode;
	switch (v.exponential) {

		case LIN_: //linear
			p->exp = LIN_;
			break; 
		case EXP_: //exponential
			p->exp = EXP_;
			range = v.max-v.min; 
			base = pow(v.max / v.min, 1/range);
			//val = (log(val/v.min) / log(base)) ;
			p->log_base = log(base);
			break; 
		default: 
			warning("not implemented yet");
	}

}


extern "C" void fl_setWidgetValue(FL_SET_WIDGET_VALUE *p)
{
	if(*p->ktrig) {
		MYFLT  val = *p->kvalue;

		switch (p->exp) {
			case LIN_: //linear
				if (val > p->max) val = p->max;
				else if (val < p->min) val = p->min;
				break; 
			case EXP_: //exponential
				val = (log(val/p->min) / p->log_base) ;
				break; 
			default: 
				warning("not implemented yet");
		}
		FLlock();
		Fl_Widget *o = (Fl_Widget *) p->WidgAddress;
		((Fl_Valuator *)o)->value(val);
		o->do_callback(o, p->opcode);
		FLunlock();
		
	}
}


//-----------
//-----------

extern "C" void fl_setColor1(FL_SET_COLOR *p)
{
	ADDR_SET_VALUE v = AddrSetValue[(int) *p->ihandle];
	Fl_Widget *o = (Fl_Widget *) v.WidgAddress;
	int color = fl_color_cube(
			(int) *p->red   * FL_NUM_RED  /256,
			(int) *p->green * FL_NUM_GREEN/256,
			(int) *p->blue  * FL_NUM_BLUE /256
		);
	FLlock();
	o->color(color);
	FLunlock();
	
}

extern "C" void fl_setColor2(FL_SET_COLOR *p)
{
	ADDR_SET_VALUE v = AddrSetValue[(int) *p->ihandle];
	Fl_Widget *o = (Fl_Widget *) v.WidgAddress;
	int color = fl_color_cube(
			(int) *p->red   * FL_NUM_RED  /256,
			(int) *p->green * FL_NUM_GREEN/256,
			(int) *p->blue  * FL_NUM_BLUE /256
		);
	FLlock();
	o->selection_color(color);
	FLunlock();
	
}

extern "C" void fl_setTextColor(FL_SET_COLOR *p)
{
	ADDR_SET_VALUE v = AddrSetValue[(int) *p->ihandle];
	Fl_Widget *o = (Fl_Widget *) v.WidgAddress;
	int color = fl_color_cube(
			(int) *p->red   * FL_NUM_RED  /256,
			(int) *p->green * FL_NUM_GREEN/256,
			(int) *p->blue  * FL_NUM_BLUE /256
		);
	FLlock();
	o->labelcolor(color);
	FLunlock();
	

}

extern "C" void fl_setTextSize(FL_SET_TEXTSIZE *p)
{
	ADDR_SET_VALUE v = AddrSetValue[(int) *p->ihandle];
	Fl_Widget *o = (Fl_Widget *) v.WidgAddress;
	FLlock();
	o->labelsize((uchar) *p->ivalue );
	FLunlock();
	
}

extern "C" void fl_setFont(FL_SET_FONT *p)
{
	ADDR_SET_VALUE v = AddrSetValue[(int) *p->ihandle];
	Fl_Widget *o = (Fl_Widget *) v.WidgAddress;
	Fl_Font font;
	switch ((int) *p->itype) {
		case 1: font = FL_HELVETICA; break;
		case 2: font = FL_HELVETICA_BOLD; break;
		case 3: font = FL_HELVETICA_ITALIC; break;
		case 4: font = FL_HELVETICA_BOLD_ITALIC; break;
		case 5: font = FL_COURIER; break;
		case 6: font = FL_COURIER_BOLD; break;
		case 7: font = FL_COURIER_ITALIC; break;
		case 8: font = FL_COURIER_BOLD_ITALIC; break;
		case 9: font = FL_TIMES; break;
		case 10: font = FL_TIMES_BOLD; break;
		case 11: font = FL_TIMES_ITALIC; break;
		case 12: font = FL_TIMES_BOLD_ITALIC; break;
		case 13: font = FL_SYMBOL; break;
		case 14: font = FL_SCREEN; break;
		case 15: font = FL_SCREEN_BOLD; break;
		case 16: font = FL_ZAPF_DINGBATS; break;
		default: font = FL_SCREEN;
	}
	FLlock();
	o->labelfont(font);
	FLunlock();
	
}

extern "C" void fl_setTextType(FL_SET_FONT *p)
{
	ADDR_SET_VALUE v = AddrSetValue[(int) *p->ihandle];
	Fl_Widget *o = (Fl_Widget *) v.WidgAddress;
	Fl_Labeltype type;
	switch ((int) *p->itype) {
		case 0: type = FL_NORMAL_LABEL; break;
		case 1: type = FL_NO_LABEL; break;
		case 2: type = FL_SYMBOL_LABEL; break;
		case 3: type = FL_SHADOW_LABEL; break;
		case 4: type = FL_ENGRAVED_LABEL; break;
		case 5: type = FL_EMBOSSED_LABEL; break;
		//case 6: type = _FL_BITMAP_LABEL; break;
		//case 7: type = _FL_PIXMAP_LABEL; break;
		//case 8: type = _FL_IMAGE_LABEL; break;
		case 9: type = _FL_MULTI_LABEL; break;
		case 10: type = FL_FREE_LABELTYPE; break;
		default: type = FL_NORMAL_LABEL;
	}
	FLlock();
	o->labeltype(type);
	o->window()->redraw();
	FLunlock();
}



/*
FL_EXPORT void overlay_BOX::draw()
{
	Fl_Box::draw();
	//if (!rw) // iw width is different from 0
	//	fl_overlay_rect(rx,ry,rw,rh);
}
*/



extern "C" void fl_setOverlay(FL_OVERLAY *p)
{
	if(*p->ktrig) {
		ADDR_SET_VALUE v = AddrSetValue[(int) *p->ihandle];
		overlay_BOX *o = (overlay_BOX *) v.WidgAddress;
		FLlock();
		o->set_rect(*p->kx,*p->ky,*p->kwidth,*p->kheight);
		FLunlock();
	}
}


extern "C" void fl_box(FL_BOX *p)
{
	char *text = GetString(*p->itext,p->STRARG);
	Fl_Boxtype type;
	switch ((int) *p->itype) {
		case 1: type = FL_FLAT_BOX; break;
		case 2: type = FL_UP_BOX; break;
		case 3: type = FL_DOWN_BOX; break;
		case 4: type = FL_THIN_UP_BOX; break;
		case 5: type = FL_THIN_DOWN_BOX; break;
		case 6: type = FL_ENGRAVED_BOX; break;
		case 7: type = FL_EMBOSSED_BOX; break;
		case 8: type = FL_BORDER_BOX; break;
		case 9: type = _FL_SHADOW_BOX; break;
		case 10: type = _FL_ROUNDED_BOX; break;
		case 11: type = _FL_RSHADOW_BOX; break;
		case 12: type = _FL_RFLAT_BOX; break;
		case 13: type = _FL_ROUND_UP_BOX; break;
		case 14: type = _FL_ROUND_DOWN_BOX; break;
		case 15: type = _FL_DIAMOND_UP_BOX; break;
		case 16: type = _FL_DIAMOND_DOWN_BOX; break;
		case 17: type = _FL_OVAL_BOX; break;
		case 18: type = _FL_OSHADOW_BOX; break;
		case 19: type = _FL_OFLAT_BOX; break;
		default: type = FL_FLAT_BOX;
	}
	
	Fl_Font font;
	switch ((int) *p->ifont) {
		case 1: font = FL_HELVETICA; break;
		case 2: font = FL_HELVETICA_BOLD; break;
		case 3: font = FL_HELVETICA_ITALIC; break;
		case 4: font = FL_HELVETICA_BOLD_ITALIC; break;
		case 5: font = FL_COURIER; break;
		case 6: font = FL_COURIER_BOLD; break;
		case 7: font = FL_COURIER_ITALIC; break;
		case 8: font = FL_COURIER_BOLD_ITALIC; break;
		case 9: font = FL_TIMES; break;
		case 10: font = FL_TIMES_BOLD; break;
		case 11: font = FL_TIMES_ITALIC; break;
		case 12: font = FL_TIMES_BOLD_ITALIC; break;
		case 13: font = FL_SYMBOL; break;
		case 14: font = FL_SCREEN; break;
		case 15: font = FL_SCREEN_BOLD; break;
		case 16: font = FL_ZAPF_DINGBATS; break;
		default: font = FL_HELVETICA;
	}
	FLlock();
	if (!strcmp(text, " ")) {
		text=NULL;
	}
	Fl_Box *o =  new overlay_BOX(*p->ix, *p->iy, *p->iwidth, *p->iheight, text);
	widget_attributes(o);
	if (symbol_label_flag) o->labeltype(FL_SYMBOL_LABEL);
	o->box(type);
	o->labelfont(font);
	o->labelsize(*p->isize);
	o->align(FL_ALIGN_WRAP);
	FLunlock();
	//
	AddrSetValue.push_back(ADDR_SET_VALUE(0, 0, 0, (void *) o, (void *) p));
	*p->ihandle = AddrSetValue.size()-1; 

}


extern "C" void fl_setText(FL_SET_TEXT *p)
{
	char *text = GetString(*p->itext,p->STRARG);
	ADDR_SET_VALUE v = AddrSetValue[(int) *p->ihandle];
	Fl_Widget *o = (Fl_Widget *) v.WidgAddress;
	FLlock();
	o->label(text);
	FLunlock();
}

extern "C" void fl_setSize(FL_SET_SIZE *p)
{
	ADDR_SET_VALUE v = AddrSetValue[(int) *p->ihandle];
	Fl_Widget *o = (Fl_Widget *) v.WidgAddress;
	FLlock();
	o->size((short)  *p->iwidth, (short) *p->iheight);
	FLunlock();
	
}

extern "C" void fl_setPosition(FL_SET_POSITION *p)
{
	ADDR_SET_VALUE v = AddrSetValue[(int) *p->ihandle];
	Fl_Widget *o = (Fl_Widget *) v.WidgAddress;
	FLlock();
	o->position((short)  *p->ix, (short) *p->iy);
	FLunlock();
	
}

extern "C" void fl_hide(FL_WIDHIDE *p)
{
	ADDR_SET_VALUE v = AddrSetValue[(int) *p->ihandle];
	Fl_Widget *o = (Fl_Widget *) v.WidgAddress;
	FLlock();
	o->hide();
	FLunlock();
	
}

extern "C" void fl_show(FL_WIDSHOW *p)
{
	ADDR_SET_VALUE v = AddrSetValue[(int) *p->ihandle];
	Fl_Widget *o = (Fl_Widget *) v.WidgAddress;
	FLlock();
	o->show();
	FLunlock();
	
}

extern "C" void fl_setBox(FL_SETBOX *p)
{
	ADDR_SET_VALUE v = AddrSetValue[(int) *p->ihandle];
	Fl_Widget *o = (Fl_Widget *) v.WidgAddress;
	Fl_Boxtype type;
	switch ((int) *p->itype) {
		case 1: type = FL_FLAT_BOX; break;
		case 2: type = FL_UP_BOX; break;
		case 3: type = FL_DOWN_BOX; break;
		case 4: type = FL_THIN_UP_BOX; break;
		case 5: type = FL_THIN_DOWN_BOX; break;
		case 6: type = FL_ENGRAVED_BOX; break;
		case 7: type = FL_EMBOSSED_BOX; break;
		case 8: type = FL_BORDER_BOX; break;
		case 9: type = FL_SHADOW_BOX; break;
		case 10: type = FL_ROUNDED_BOX; break;
		case 11: type = FL_RSHADOW_BOX; break;
		case 12: type = FL_RFLAT_BOX; break;
		case 13: type = FL_ROUND_UP_BOX; break;
		case 14: type = FL_ROUND_DOWN_BOX; break;
		case 15: type = FL_DIAMOND_UP_BOX; break;
		case 16: type = FL_DIAMOND_DOWN_BOX; break;
		case 17: type = FL_OVAL_BOX; break;
		case 18: type = FL_OSHADOW_BOX; break;
		case 19: type = FL_OFLAT_BOX; break;
		default: type = FL_FLAT_BOX;
	}
	FLlock();
	o->box(type);
	FLunlock();
	
}

extern "C" void fl_align(FL_TALIGN *p)
{
	ADDR_SET_VALUE v = AddrSetValue[(int) *p->ihandle];
	Fl_Widget *o = (Fl_Widget *) v.WidgAddress;
	Fl_Align type;
	switch ((int) *p->itype) {
		case 1: type = FL_ALIGN_CENTER; break;
		case 2: type = FL_ALIGN_TOP; break;
		case 3: type = FL_ALIGN_BOTTOM; break;
		case 4: type = FL_ALIGN_LEFT; break;
		case 5: type = FL_ALIGN_RIGHT; break;
		case 6: type = FL_ALIGN_TOP_LEFT; break;
		case 7: type = FL_ALIGN_TOP_RIGHT; break;
		case 8: type = FL_ALIGN_BOTTOM_LEFT; break;
		case 9: type = FL_ALIGN_BOTTOM_RIGHT; break;
		default: type = FL_ALIGN_BOTTOM;
	}
	FLlock();
	o->align(type);
	FLunlock();
	
}



//-----------
//-----------


extern "C" void fl_value(FLVALUE *p)
{
	char *controlName = GetString(*p->name,p->STRARG);
	int ix, iy, iwidth, iheight;
	if (*p->ix<0) ix = FL_ix;	else  FL_ix = ix = *p->ix;
	if (*p->iy<0) iy = FL_iy;	else  FL_iy = iy = *p->iy;
	if (*p->iwidth<0) iwidth = FLvalue_iwidth; else FLvalue_iwidth = iwidth = *p->iwidth;
	if (*p->iheight<0) iheight = FLroller_iheight;	else FLroller_iheight = iheight = *p->iheight;

	Fl_Output *o = new Fl_Output(ix, iy, iwidth, iheight,controlName);
	o->align(FL_ALIGN_BOTTOM | FL_ALIGN_WRAP);
	if (FLcolor < 0 )
		o->color(FL_GRAY );
	else
		o->color(FLcolor, FLcolor2); 
	widget_attributes(o);
	//AddrValue.push_back((void *) o);
	AddrSetValue.push_back(ADDR_SET_VALUE(LIN_, 0, 0, (void *) o, (void *) p));
	//*p->ihandle = AddrValue.size()-1; 
	*p->ihandle = AddrSetValue.size()-1; 
	
}
/*
#define MAXSLIDERBANK 128

typedef struct {
	MYFLT min, max, *out;
	MYFLT base, *table;
	long tablen;
	int exp;
} SLDBK_ELEMENT;

typedef struct	{
	OPDS	h;
	MYFLT *ihandle, *names, *inumsliders, *ioutable, *ioutablestart_ndx, *iminmaxtable, *iexptable, *itypetable, *iwidth, *iheight, *ix, *iy;
	SLDBK_ELEMENT slider_data[MAXSLIDERBANK];
} FLSLIDERBANK;
*/

extern "C" void fl_slider_bank(FLSLIDERBANK *p)
{

	char s[MAXNAME];
	char *t = p->STRARG;
	if (*p->names == sstrcod) { 
		if (t == NULL) strcpy(s,unquote(currevent->strarg));
		else strcpy(s, unquote(t));

	} 
	else if ((long)*p->names <= strsmax && strsets != NULL && strsets[(long)*p->names]) {
		strcpy(s, strsets[(long)*p->names]);
	}
	string tempname(s);
	strstream sbuf;
	sbuf << tempname;

	int width = *p->iwidth;
	if (width <=0) width = 100;

	Fl_Group* w = new Fl_Group(*p->ix, *p->iy, width, *p->inumsliders*10);
	FUNC *ftp;
	MYFLT *minmaxtable, *typetable, *outable, *exptable;
	
	if (*p->ioutable  < 1) {
		extern	MYFLT *zkstart;
		extern long	zklast;
		if (zkstart != NULL && zklast > (long) (*p->inumsliders + *p->ioutablestart_ndx))
			outable = zkstart + (long) *p->ioutablestart_ndx;
		else {
			initerror("invalid ZAK space allocation");
			return;
		}
	}
	else {
		if((ftp = ftfind(p->ioutable)) != NULL) 
			outable = ftp->ftable + (long) *p->ioutablestart_ndx; 
		else 
			return;
	}
	if((int) *p->iminmaxtable > 0)
		if((ftp = ftfind(p->iminmaxtable)) != NULL) minmaxtable = ftp->ftable; else return;
	if ((int) *p->iexptable > 0)
		if((ftp = ftfind(p->iexptable)) != NULL) exptable = ftp->ftable; else return;
	if ((int) *p->itypetable >0)
		if((ftp = ftfind(p->itypetable)) != NULL) typetable = ftp->ftable; else return;

	for (int j =0; j< *p->inumsliders; j++) {
		string stemp;
		if (tempname == " ") {
			char s[10];
			stemp = itoa(j,s,10);
		}
		else
			getline(sbuf, stemp, '@');
		char *Name =  new char[stemp.size()+2];
		strcpy(Name,stemp.c_str());
		allocatedStrings.push_back(Name);
		int x = *p->ix,  y = *p->iy + j*10;
		Fl_Slider *o;
		int slider_type;
		if ((int) *p->itypetable <=0)  // no slider type table 
			if (*p->itypetable >= -7) //  all sliders are of the same type
				slider_type = - *p->itypetable;
			else { // random type
					//(rand()*128. / RAND_MAX) * FL_NUM_RED/256, 
				slider_type = rand()*7. / RAND_MAX;
				switch(slider_type) { 
					case 0: slider_type = 1; break;
					case 2: slider_type = 3; break;
					case 4: slider_type = 5; break;
					case 6: slider_type = 7; break;
					default: slider_type = 1;
				}
			}
		else
			slider_type = typetable[j];
		

		if (slider_type < 10)	
			o = new Fl_Slider(x, y, width, 10, Name);
		else { 
			o = new Fl_Value_Slider_Input(x, y, width, 10, Name);
			slider_type -=10;
			((Fl_Value_Slider_Input*) o)->textboxsize(50);
			((Fl_Value_Slider_Input*) o)->textsize(13);
		}
		switch((int) slider_type) { //type
			case 1: o->type(FL_HOR_FILL_SLIDER); break;
			case 3: o->type(FL_HOR_SLIDER); break;
			case 5: o->type(FL_HOR_NICE_SLIDER); o->box(FL_FLAT_BOX); break;
			case 7:  o->type(FL_HOR_NICE_SLIDER); o->box(FL_DOWN_BOX); break;
			default: o->type(FL_HOR_NICE_SLIDER); o->box(FL_FLAT_BOX); break;
		}
		o->align(FL_ALIGN_LEFT);
		widget_attributes(o);
		MYFLT min, max, range;
		if ((int) *p->iminmaxtable > 0) {
			min = minmaxtable[j*2];
			max = minmaxtable[j*2+1];
		}
		else {
			min = 0.;
			max = 1.;
		}			
		int iexp;
		
		p->slider_data[j].min=min; 
		p->slider_data[j].max=max; 
		p->slider_data[j].out=&outable[j]; 

		if ((int) *p->iexptable <=0)  // no table, all sliders have the same behaviour
			iexp = *p->iexptable;
		else	
			iexp = exptable[j];
		switch (iexp) {
			case -1: iexp = EXP_; break;
			case 0: iexp = LIN_; break; 
		}

		MYFLT val = 0;
		p->slider_data[j].exp = iexp;
		switch (iexp) {
			case LIN_: //linear
				o->range(min,max);
				o->callback((Fl_Callback*)fl_callbackLinearSliderBank,(void *) &(p->slider_data[j]));
				val = outable[j];
				if (val > max) val = max;
				else if (val < min) val = min;


				break;
			case EXP_ : //exponential
				if (min == 0 || max == 0)
					initerror("FLsliderBank: zero is illegal in exponential operations");
				range = max - min;
				o->range(0,range);
				p->slider_data[j].base = pow((max / min), 1/range);
				o->callback((Fl_Callback*)fl_callbackExponentialSliderBank,(void *) &(p->slider_data[j]));
				{
					val = outable[j];
					MYFLT range = max-min; 
					MYFLT base = pow(max / min, 1/range);
					val = (log(val/min) / log(base)) ;
				}
				break;
			default: 
			{
				FUNC *ftp;
				MYFLT fnum = abs(iexp);
				if((ftp = ftfind(&fnum)) != NULL) p->slider_data[j].table = ftp->ftable; else return;
				p->slider_data[j].tablen = ftp->flen;
				o->range(0,.99999999);
				if (iexp > 0) //interpolated
					o->callback((Fl_Callback*)fl_callbackInterpTableSliderBank,(void *)  &(p->slider_data[j]));
				else // non-interpolated
					o->callback((Fl_Callback*)fl_callbackTableSliderBank,(void *)  &(p->slider_data[j]));
			}
		}
		o->value(val);

	}
	w->resizable(w);
	if (*p->iwidth <=0 || *p->iheight <=0) {// default width and height
		int a,b;
		w->size( a= w->parent()->w() -50, b= w->parent()->h());
		w->position(50, 0);
	}
	else {
		w->size( *p->iwidth, *p->iheight);
		w->position(*p->ix, *p->iy);
	}
	w->end();
	AddrSetValue.push_back(ADDR_SET_VALUE(LIN_, 0, 0, (void *) w, (void *) p));
	//*p->ihandle = AddrSetValue.size()-1; 
}


extern "C" void fl_slider(FLSLIDER *p)
{
	char *controlName = GetString(*p->name,p->STRARG);
	int ix,iy,iwidth, iheight,itype, iexp;

	if (*p->iy < 0) {
		iy = FL_iy;
		FL_iy += FLcontrol_iheight + 5;
	} else {
		iy = *p->iy;
		FL_iy = iy + FLcontrol_iheight + 5;
	}
	if (*p->ix < 0)  ix = FL_ix; // omitted options: set default
	else  FL_ix = ix = *p->ix;
	if (*p->iwidth < 0) iwidth = FLcontrol_iwidth;
	else FLcontrol_iwidth = iwidth = *p->iwidth;
	if (*p->iheight < 0) iheight = FLcontrol_iheight;
	else FLcontrol_iheight = iheight = *p->iheight;
	if (*p->itype < 1) itype = 1;
	else  itype = (int) *p->itype;
	
	//if (*p->iexp == LIN_) iexp = LIN_;
	//else  iexp = (int) *p->iexp;
	switch((int) *p->iexp) {
		case -1: iexp = EXP_; break;
		case 0: iexp = LIN_; break; 
		default: iexp = *p->iexp;
	}

	
	if (itype > 10 && iexp == EXP_) {
		warning("FLslider exponential, using non-labeled slider");
		itype -= 10;
	}

	Fl_Slider *o;
	if (itype < 10)	o = new Fl_Slider(ix, iy, iwidth, iheight, controlName);
	else { 
		o = new Fl_Value_Slider_Input(ix, iy, iwidth, iheight, controlName);
		itype -=10;
		((Fl_Value_Slider_Input*) o)->textboxsize(50);
		((Fl_Value_Slider_Input*) o)->textsize(13);
		
	}
	switch (itype) {
		case 1:  o->type(FL_HOR_FILL_SLIDER); break;
		case 2:	 o->type(FL_VERT_FILL_SLIDER); break;
		case 3:	 o->type(FL_HOR_SLIDER); break;
		case 4:	 o->type(FL_VERT_SLIDER); break;
		case 5:  o->type(FL_HOR_NICE_SLIDER); o->box(FL_FLAT_BOX); break;
		case 6:	 o->type(FL_VERT_NICE_SLIDER); o->box(FL_FLAT_BOX); break;
		case 7:  o->type(FL_HOR_NICE_SLIDER); o->box(FL_FREE_BOXTYPE); break;
		case 8:	 o->type(FL_VERT_NICE_SLIDER); o->box(FL_FREE_BOXTYPE); break;
		default: initerror("FLslider: invalid slider type");
	}
	o->align(FL_ALIGN_BOTTOM | FL_ALIGN_WRAP);
	widget_attributes(o);
	MYFLT min = p->min = *p->imin, max = *p->imax, range;
	switch (iexp) {
		case LIN_: //linear
			o->range(min,max);
			o->callback((Fl_Callback*)fl_callbackLinearSlider,(void *) p);
			break;
		case EXP_ : //exponential
			if (min == 0 || max == 0)
				initerror("FLslider: zero is illegal in exponential operations");
			range = max - min;
			o->range(0,range);
			p->base = pow((max / min), 1/range);
			o->callback((Fl_Callback*)fl_callbackExponentialSlider,(void *) p);
			break;
		default: 
		{
			FUNC *ftp;
			MYFLT fnum = abs(iexp);
			if((ftp = ftfind(&fnum)) != NULL) {
				p->table = ftp->ftable;
				p->tablen = ftp->flen;
			}
			else return;
			o->range(0,.99999999);
			if (iexp > 0) //interpolated
				o->callback((Fl_Callback*)fl_callbackInterpTableSlider,(void *) p);
			else // non-interpolated
				o->callback((Fl_Callback*)fl_callbackTableSlider,(void *) p);
		}
	}
	AddrSetValue.push_back(ADDR_SET_VALUE(iexp, *p->imin, *p->imax, (void *) o, (void *) p));
	*p->ihandle = AddrSetValue.size()-1; 
}


extern "C" void fl_joystick(FLJOYSTICK *p)
{
	char *Name = GetString(*p->name,p->STRARG);
	int ix,iy,iwidth, iheight, iexpx, iexpy;

	if (*p->ix < 0)  ix = 10; // omitted options: set default
	else  FL_ix = ix = *p->ix;
	if (*p->iy < 0)  iy = 10; // omitted options: set default
	else  iy = *p->iy;
	if (*p->iwidth < 0) iwidth = 130;
	else iwidth = *p->iwidth;
	if (*p->iheight < 0) iheight = 130;
	else iheight = *p->iheight;


	switch((int) *p->iexpx) {
		case -1: iexpx = EXP_; break;
		case 0: iexpx = LIN_; break; 
		default: iexpx = *p->iexpx;
	}
	switch((int) *p->iexpy) {
		case -1: iexpy = EXP_; break;
		case 0: iexpy = LIN_; break; 
		default: iexpy = *p->iexpy;
	}
/*
	if (*p->iexpx == LIN_) iexpx = LIN_;
	else  iexpx = (int) *p->iexpx;
	if (*p->iexpy == LIN_) iexpy = LIN_;
	else  iexpy = (int) *p->iexpy;
*/	

	Fl_Positioner *o = new Fl_Positioner(ix, iy, iwidth, iheight, Name);
	widget_attributes(o);
	switch (iexpx) {
		case LIN_: //linear
			o->xbounds(*p->iminx,*p->imaxx); break;
		case EXP_: //exponential
			{ if (*p->iminx == 0 || *p->imaxx == 0)
				initerror("FLjoy X axe: zero is illegal in exponential operations");
			MYFLT range = *p->imaxx - *p->iminx;
			o->xbounds(0,range);
			p->basex = pow((*p->imaxx / *p->iminx), 1/range);
			} break;
		default:
		{
			FUNC *ftp;
			MYFLT fnum = abs(iexpx);
			if((ftp = ftfind(&fnum)) != NULL) {
				p->tablex = ftp->ftable;
				p->tablenx = ftp->flen;
			}
			else return;
			o->xbounds(0,.99999999);
			/*
			if (iexp > 0) //interpolated
				o->callback((Fl_Callback*)fl_callbackInterpTableSlider,(void *) p); 
			else // non-interpolated
				o->callback((Fl_Callback*)fl_callbackTableSlider,(void *) p);
			*/
		}
	}
   	switch (iexpy) {
		case LIN_: //linear
			o->ybounds(*p->iminy,*p->imaxy); break;
		case EXP_ : //exponential
			{ if (*p->iminy == 0 || *p->imaxy == 0)
				initerror("FLjoy X axe: zero is illegal in exponential operations");
			MYFLT range = *p->imaxy - *p->iminy;
			o->ybounds(0,range);
			p->basey = pow((*p->imaxy / *p->iminy), 1/range);
			} break;
		default:
		{
			FUNC *ftp;
			MYFLT fnum = abs(iexpy);
			if((ftp = ftfind(&fnum)) != NULL) {
				p->tabley = ftp->ftable;
				p->tableny = ftp->flen;
			}
			else return;
			o->ybounds(0,.99999999);
		/*	if (iexp > 0) //interpolated
				o->callback((Fl_Callback*)fl_callbackInterpTableSlider,(void *) p); 
			else // non-interpolated
				o->callback((Fl_Callback*)fl_callbackTableSlider,(void *) p);
		*/
		}
	}
	o->align(FL_ALIGN_BOTTOM | FL_ALIGN_WRAP);
	o->callback((Fl_Callback*)fl_callbackJoystick,(void *) p);
	AddrSetValue.push_back(ADDR_SET_VALUE(iexpx, *p->iminx, *p->imaxx, (void *) o, (void *) p));
	*p->ihandle1 = AddrSetValue.size()-1; 
	AddrSetValue.push_back(ADDR_SET_VALUE(iexpy, *p->iminy, *p->imaxy, (void *) o, (void *) p));
	*p->ihandle2 = AddrSetValue.size()-1; 

}


extern "C" void fl_knob(FLKNOB *p)
{
	char *controlName = GetString(*p->name,p->STRARG);
	int ix,iy,iwidth, itype, iexp;

	if (*p->iy < 0) iy = FL_iy;
	else  FL_iy = iy = *p->iy;
	if (*p->ix < 0)  ix = FL_ix;
	else  FL_ix = ix = *p->ix;
	if (*p->iwidth < 0) iwidth = FLcontrol_iwidth;
	else FLcontrol_iwidth = iwidth = *p->iwidth;
	if (*p->itype < 1) itype = 1;
	else  itype = (int) *p->itype;
	/*
	if (*p->iexp < LIN_) iexp = LIN_;
	else  iexp = (int) *p->iexp;
*/
	switch((int) *p->iexp) {
		case -1: iexp = EXP_; break;
		case 0: iexp = LIN_; break; 
		default: iexp = *p->iexp;
	}

	Fl_Valuator* o;
	switch (itype) {
		case 1:
			o = new Fl_Knob(ix, iy, iwidth, iwidth, controlName);
			o->box(FL_NO_BOX);
			if (*p->icursorsize != 0) ((Fl_Knob*) o)->cursor(*p->icursorsize);
			break;
		case 2:
			o = new Fl_Dial(ix, iy, iwidth, iwidth, controlName);
			o->type(FL_FILL_DIAL);
			o->box(_FL_OSHADOW_BOX);
			((Fl_Dial*) o)->angles(20,340);
			break;
		case 3:
			o = new Fl_Dial(ix, iy, iwidth, iwidth, controlName);
			o->type(FL_LINE_DIAL); 
			o->box(_FL_OSHADOW_BOX);
			break;
		case 4:
			o = new Fl_Dial(ix, iy, iwidth, iwidth, controlName);
			o->type(FL_NORMAL_DIAL); 
			o->box(_FL_OSHADOW_BOX);
			break;
		default:
			initerror("FLknob: invalid knob type");
	}
	widget_attributes(o);
	o->align(FL_ALIGN_BOTTOM | FL_ALIGN_WRAP);
    o->range(*p->imin,*p->imax);
	//o->box(FL_NO_BOX);
   	switch (iexp) {
		case LIN_: //linear
			o->range(*p->imin,*p->imax);
			o->callback((Fl_Callback*)fl_callbackLinearKnob,(void *) p);
			o->step(0.001);
			break;
		case EXP_ : //exponential
			{ MYFLT min = p->min = *p->imin, max = *p->imax;
			if (min == 0 || max == 0)
				initerror("FLknob: zero is illegal in exponential operations");
			MYFLT range = max - min;
			o->range(0,range);
			p->base = pow((max / min), 1/range);
			o->callback((Fl_Callback*)fl_callbackExponentialKnob,(void *) p);
			} break;
		default:
		{
			FUNC *ftp;
			p->min = *p->imin;
			MYFLT fnum = abs(iexp);
			if((ftp = ftfind(&fnum)) != NULL) {
				p->table = ftp->ftable;
				p->tablen = ftp->flen;
			}
			else return;
			o->range(0,.99999999);
			if (iexp > 0) //interpolated
				o->callback((Fl_Callback*)fl_callbackInterpTableKnob,(void *) p); 
			else // non-interpolated
				o->callback((Fl_Callback*)fl_callbackTableKnob,(void *) p);
		}
	}
	AddrSetValue.push_back(ADDR_SET_VALUE(iexp, *p->imin, *p->imax, (void *) o, (void *) p));
	*p->ihandle = AddrSetValue.size()-1; 
}




extern "C" void fl_text(FLTEXT *p)
{
	char *controlName = GetString(*p->name,p->STRARG);
	int ix,iy,iwidth,iheight,itype;
	MYFLT	istep;

	if (*p->iy < 0) iy = FL_iy;
	else  FL_iy = iy = *p->iy;
	if (*p->ix < 0)  ix = FL_ix;
	else  FL_ix = ix = *p->ix;
	if (*p->iwidth < 0) iwidth = FLcontrol_iwidth;
	else FLcontrol_iwidth = iwidth = *p->iwidth;
	if (*p->iheight < 0) iheight = FLcontrol_iheight;
	else FLcontrol_iheight = iheight = *p->iheight;
	if (*p->itype < 1) itype = 1;
	else  itype = (int) *p->itype;
	if (*p->istep < 0) istep = FL(.1);
	else  istep = *p->istep;

	Fl_Valuator* o;
	switch(itype) {
		case 1:	{
			o = new Fl_Value_Input(ix, iy, iwidth, iheight, controlName);
			((Fl_Value_Output *) o)->step(istep);
			((Fl_Value_Output *) o)->range(*p->imin,*p->imax);
		} break;
		case 2:	 {
			o = new Fl_Value_Input_Spin(ix, iy, iwidth, iheight, controlName);
			((Fl_Value_Input *) o)->step(istep);
			((Fl_Value_Input *) o)->range(*p->imin,*p->imax);
		} break; 
		case 3:
		{
			o = new Fl_Value_Output(ix, iy, iwidth, iheight, controlName);
			((Fl_Value_Output *) o)->step(istep);
			((Fl_Value_Output *) o)->range(*p->imin,*p->imax);
		} break;
	}
	o->align(FL_ALIGN_BOTTOM | FL_ALIGN_WRAP);
	widget_attributes(o);
	o->callback((Fl_Callback*)fl_callbackLinearValueInput,(void *) p);
	AddrSetValue.push_back(ADDR_SET_VALUE(LIN_, *p->imin, *p->imax, (void *) o, (void *) p));
	*p->ihandle = AddrSetValue.size()-1; 
}

extern "C" void fl_button(FLBUTTON *p)
{
	char *Name = GetString(*p->name,p->STRARG);
	int type = (int) *p->itype;
	if (type >9 ) { // ignored when getting snapshots
		char s[512];
		sprintf(s,"FLbutton \"%s\" ignoring snapshot capture retreive", Name);
		warning(s);
		type = type-10;
	}
	Fl_Button *w;
	
	switch (type) {
		case 1: w= new Fl_Button(*p->ix, *p->iy, *p->iwidth, *p->iheight, Name); w->box(FL_PLASTIC_UP_BOX);break;
		case 2: w= new Fl_Light_Button(*p->ix, *p->iy, *p->iwidth, *p->iheight, Name); w->box(FL_PLASTIC_UP_BOX);break;
		case 3: w= new Fl_Check_Button(*p->ix, *p->iy, *p->iwidth, *p->iheight, Name); break;
		case 4: w= new Fl_Round_Button(*p->ix, *p->iy, *p->iwidth, *p->iheight, Name); break;
		default: initerror("FLbutton: invalid button type");
	}
	Fl_Button *o = w;
	

	if (symbol_label_flag) o->labeltype(FL_SYMBOL_LABEL);
	o->align(FL_ALIGN_WRAP);
	widget_attributes(o);
	o->callback((Fl_Callback*)fl_callbackButton,(void *) p);
	AddrSetValue.push_back(ADDR_SET_VALUE(LIN_, 0, 0, (void *) o, (void *) p));
	*p->ihandle = AddrSetValue.size()-1; 
	O.RTevents = 1;     /* Make sure kperf() looks for RT events */
	O.ksensing = 1;
	O.OrcEvts  = 1;     /* - of the appropriate type */

}

extern "C" void fl_button_bank(FLBUTTONBANK *p)
{
	char *Name = "/0"; //GetString(*p->name,p->STRARG);
	int type = (int) *p->itype;
	if (type >=10 ) { // ignored when getting snapshots
		char s[512];
		sprintf(s,"FLbutton \"%s\" ignoring snapshot capture retreive", Name);
		warning(s);
		type = type-10;
	}
	Fl_Group* o = new Fl_Group(*p->ix, *p->iy, *p->inumx * 10, *p->inumy*10);
	int z = 0;
	for (int j =0; j<*p->inumx; j++) {
		for (int k=0; k< *p->inumy; k++) {
			int x = *p->ix + j*10, y = *p->iy + k*10;
			Fl_Button *w;
			char    *btName=  new char[30];
			allocatedStrings.push_back(btName);
			itoa( z, btName, 10); z++;
			switch (type) {
				case 1: w= new Fl_Button(x, y, 10, 10, btName); w->box(FL_PLASTIC_UP_BOX); break;
				case 2: w= new Fl_Light_Button(x, y, 10, 10, btName); w->box(FL_PLASTIC_UP_BOX); break;
				case 3: w= new Fl_Check_Button(x, y, 10, 10, btName); break;
				case 4: w= new Fl_Round_Button(x, y, 10, 10, btName); break;
				default: initerror("FLbuttonBank: invalid button type");
			}
			widget_attributes(w);
			w->type(FL_RADIO_BUTTON);
			w->callback((Fl_Callback*)fl_callbackButtonBank,(void *) p);
		}
	}
	o->resizable(o);
	o->size( *p->iwidth, *p->iheight);
	o->position(*p->ix, *p->iy);
	o->align(FL_ALIGN_BOTTOM | FL_ALIGN_WRAP);
	o->end();

	AddrSetValue.push_back(ADDR_SET_VALUE(LIN_, 0, 0, (void *) o, (void *) p));
	*p->ihandle = AddrSetValue.size()-1; 
	O.RTevents = 1;     /* Make sure kperf() looks for RT events */
	O.ksensing = 1;
	O.OrcEvts  = 1;     /* - of the appropriate type */
}


extern "C" void fl_counter(FLCOUNTER *p)
{
	char *controlName = GetString(*p->name,p->STRARG);
//	int ix,iy,iwidth,iheight,itype;
//	MYFLT	istep1, istep2;

	Fl_Counter* o = new Fl_Counter(*p->ix, *p->iy, *p->iwidth, *p->iheight, controlName);
	widget_attributes(o);
	int type = (int) *p->itype;
	if (type >9 ) { // ignored when getting snapshots
		char s[512];
		sprintf(s,"FLcount \"%s\" ignoring snapshot capture retreive", controlName);
		warning(s);
		type = type-10;
	}
	switch(type) {
		case 1: o->type(FL_NORMAL_COUNTER);  break;
		case 2:	o->type(FL_SIMPLE_COUNTER);  break; 
		default:o->type(FL_NORMAL_COUNTER);  break;
	}

	o->step(*p->istep1);
	o->lstep(*p->istep2);
	o->align(FL_ALIGN_BOTTOM | FL_ALIGN_WRAP);
	if (*p->imin != *p->imax) // range is accepted only if min and max are different
		o->range(*p->imin,*p->imax); //otherwise no-range
	widget_attributes(o);
	o->callback((Fl_Callback*)fl_callbackCounter,(void *) p);
	AddrSetValue.push_back(ADDR_SET_VALUE(LIN_, 0, 100000, (void *) o, (void *) p));
	*p->ihandle = AddrSetValue.size()-1; 
	O.RTevents = 1;     /* Make sure kperf() looks for RT events */
	O.ksensing = 1;
	O.OrcEvts  = 1;     /* - of the appropriate type */

}



extern "C" void fl_roller(FLROLLER *p)
{
	char *controlName = GetString(*p->name,p->STRARG);
	int ix,iy,iwidth, iheight,itype, iexp ;
	double istep;
	if (*p->iy < 0) {
		iy = FL_iy;
		FL_iy += FLroller_iheight + 15;
	} else {
		iy = *p->iy;
		FL_iy = iy + FLroller_iheight + 15;
	}
	// omitted options: set defaults
	if (*p->ix<0) ix = FL_ix;	else  FL_ix = ix = *p->ix;
	if (*p->iy<0) iy = FL_iy;	else  FL_iy = iy = *p->iy;
	if (*p->iwidth<0) iwidth = FLroller_iwidth; else FLroller_iwidth = iwidth = *p->iwidth;
	if (*p->iheight<0) iheight = FLroller_iheight;	else FLroller_iheight = iheight = *p->iheight;
	if (*p->itype<1) itype = 1; 	else  itype = (int) *p->itype;
	//if (*p->iexp<LIN_) iexp = LIN_;	else  iexp = (int) *p->iexp;
	switch((int) *p->iexp) {
		case -1: iexp = EXP_; break;
		case 0: iexp = LIN_; break; 
		default: iexp = *p->iexp;
	}

	if (*p->istep<0) istep = 1;	else  istep =  *p->istep;
	p->min = *p->imin;
	Fl_Roller *o;
	switch (itype) {
		case 1:
			o = new Fl_Roller(ix, iy, iwidth, iheight, controlName);
			o->type(FL_HORIZONTAL); 
			break;
		case 2:
			o = new Fl_Roller(ix, iy, iwidth, iheight, controlName);
			o->type(FL_VERTICAL); 
			break;
		default:
			initerror("FLroller: invalid roller type");
	}
	widget_attributes(o);
	o->step(istep);
	switch (iexp) {
		case LIN_: //linear
			o->range(*p->imin,*p->imax);
			o->callback((Fl_Callback*)fl_callbackLinearRoller,(void *) p);
			break;
		case EXP_ : //exponential
			{ MYFLT min = p->min, max = *p->imax;
			if (min == 0 || max == 0)
				initerror("FLslider: zero is illegal in exponential operations");
			MYFLT range = max - min;
			o->range(0,range);
			p->base = pow((max / min), 1/range);
			o->callback((Fl_Callback*)fl_callbackExponentialRoller,(void *) p);
			} break;
		default:
		{
			FUNC *ftp;
			MYFLT fnum = abs(iexp);
			if((ftp = ftfind(&fnum)) != NULL) {
				p->table = ftp->ftable;
				p->tablen = ftp->flen;
			}
			else return;
			o->range(0,.99999999);
			if (iexp > 0) //interpolated
				o->callback((Fl_Callback*)fl_callbackInterpTableRoller,(void *) p); 
			else // non-interpolated
				o->callback((Fl_Callback*)fl_callbackTableRoller,(void *) p);
		}
	}
	AddrSetValue.push_back(ADDR_SET_VALUE(iexp, *p->imin, *p->imax, (void *) o, (void *) p));
	*p->ihandle = AddrSetValue.size()-1; 
}


extern "C" long kcounter;

extern "C" void FLprintkset(FLPRINTK *p)
{
    if (*p->ptime < FL(1.0) / ekr)
      p->ctime = FL(1.0) / ekr;
    else	p->ctime = *p->ptime;
	
    p->initime = (MYFLT) kcounter * onedkr;
    p->cysofar = -1;
}

extern "C" void FLprintk(FLPRINTK *p)
{
	MYFLT	timel;
	long	cycles;

	timel =	((MYFLT) kcounter * onedkr) - p->initime;
	cycles = (long)(timel / p->ctime);
	if (p->cysofar < cycles) {
		p->cysofar = cycles;
		char valString[MAXNAME]; 
		FLlock();
		((Fl_Output*) (AddrSetValue[(long) *p->idisp]).WidgAddress)->value(gcvt( *p->val, 5, valString )); 
		FLunlock();
		
	}
}


extern "C" void FLprintk2(FLPRINTK2 *p)
{
	MYFLT	value = *p->val;	
	if (p->oldvalue != value) {
		char valString[MAXNAME]; 
		FLlock();
		((Fl_Output*) (AddrSetValue[(long) *p->idisp]).WidgAddress)->value(gcvt( *p->val, 5, valString )); 
		FLunlock();
		
		p->oldvalue = value;
	}
}


extern "C" void fl_bitmap(FL_SETBITMAP *p)
{
	//ADDR_SET_VALUE v = ;
	Fl_Widget *o = (Fl_Widget *) AddrSetValue[(int) *p->ihandle].WidgAddress;
	imageStruct *bmp = &Bm_image[(int) *p->ibitmapNum];

	BYTE    *image = (BYTE*) (bmp->data);

	Fl_RGB_Image *img = new Fl_RGB_Image(image,bmp->xsize,bmp->ysize,bmp->csize);
	Fl_Tiled_Image *t_img;
	FLlock();
	
	switch ((int) *p->iflag){
		case 1:
			o->image(img);
			o->size(bmp->xsize, bmp->ysize);
			break;
		case 2:
			t_img = new Fl_Tiled_Image(img);
			o->image(t_img);
			allocatedStrings.push_back((char *) t_img);
			break;
		default:
			o->image(img);
	}
	o->align(FL_ALIGN_INSIDE);
	Fl_Boxtype box = o->box();
	if (box != FL_NO_BOX && box != FL_FLAT_BOX)
		o->size(o->w()+4, o->h() +4);
	o->parent()->redraw();
	FLunlock();
	allocatedStrings.push_back((char *) img);
}
