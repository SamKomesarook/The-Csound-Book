/* oscillator opcodes by Gabriel Maldonado */
#include "cs.h"
//#include "Gab_osc.h"
#include "uggab.h"
#include "gab_osc.h"
extern   FUNC   *ftnp2find(MYFLT*);       /* permit non-power-of-2 ftable (no masks) */



void lposcint(LPOSC *p)
{
    
   	double	*phs= &p->phs;
   	double	si= *p->freq * (p->fsr/esr);
    MYFLT	*out = p->out;
	short	*ft = (short *) p->ftp->ftable, *curr_samp;
	MYFLT	fract; 
    long	n = ksmps;
    double	loop, end, looplength /* = p->looplength */ ; 

	if ((loop= *p->kloop) < 0) loop=0;
	if ((end= *p->kend) > p->tablen || end <=0) end = p->tablen;
	looplength = end - loop;
		
	do {
		curr_samp= ft + (long)*phs;
	    fract= (MYFLT)(*phs - (long)*phs);
	    *out++ = *p->amp * (*curr_samp +(*(curr_samp+1)-*curr_samp)*fract);
	    *phs += si;
	    while (*phs  >= end) *phs -= looplength;
	    while (*phs  < loop) *phs += looplength;
	}while (--n);
}


void lposcinta(LPOSC *p)
{
    
   	double	*phs= &p->phs;
   	double	si= *p->freq * (p->fsr/esr);
    MYFLT	*out = p->out,  *amp=p->amp;
	short	*ft = (short *) p->ftp->ftable, *curr_samp;
	MYFLT	fract; 
    long	n = ksmps;
    double	loop, end, looplength /* = p->looplength */ ; 

	if ((loop= *p->kloop) < 0) loop=0;
	if ((end= *p->kend) > p->tablen || end <=0) end = p->tablen;
	looplength = end - loop;
	do {
		curr_samp= ft + (long)*phs;
	    fract= (MYFLT)(*phs - (long)*phs);
	    *out++ = *amp++ * (*curr_samp +(*(curr_samp+1)-*curr_samp)*fract);
	    *phs += si;
	    while (*phs  >= end) *phs -= looplength;
	    while (*phs  < loop) *phs += looplength;
	}while (--n);
}

//-------------------------
void lposc_stereo_set(LPOSC_ST *p)
{
    FUNC *ftp;
    double  loop, end, looplength, fsr;
    if ((ftp = ftnp2find(p->ift)) == NULL) return;
    if (!(fsr = ftp->gen01args.sample_rate)){
      printf("lposcil: no sample rate stored in function assuming=sr\n");
      p->fsr=esr;
    }
	p->fsrUPsr = fsr/esr;
    p->ft    = (short *) ftp->ftable;
    p->tablen = ftp->flen/2;
    /* changed from
       p->phs    = *p->iphs * p->tablen;   */
    if ((loop = *p->kloop) < 0) loop=0;
    if ((end = *p->kend) > p->tablen || end <=0 ) end = p->tablen;
    looplength = end - loop;
	
	if (*p->iphs >= 0) 
        p->phs_int = (long) (p->phs = *p->iphs);

	while (p->phs >= end)
        p->phs_int = (long) (p->phs -= looplength);
}


void lposcinta_stereo(LPOSC_ST *p) // stereo lposcinta
{
   	double	*phs= &p->phs,   si= *p->freq * p->fsrUPsr;
    MYFLT	*out1 = p->out1, *out2 = p->out2, *amp=p->amp;
	short	*ft =  p->ft;
	long	n = ksmps;
    double	loop, end, looplength /* = p->looplength */ ; 
	if ((loop= *p->kloop) < 0) loop=0;
	if ((end= *p->kend) > p->tablen || end <=0) end = p->tablen;
	looplength = end - loop;
	do {
		double fract;
		short *curr_samp1 = ft + (long) *phs * 2;
		short *curr_samp2 = curr_samp1 +1;
	    fract= *phs - (long) *phs;
	    *out1++ = *amp   * (MYFLT) (*curr_samp1 +(*(curr_samp1+2)-*curr_samp1)*fract);
		*out2++ = *amp++ * (MYFLT) (*curr_samp2 +(*(curr_samp2+2)-*curr_samp2)*fract);
	    *phs += si;
	    while (*phs  >= end) *phs -= looplength;
	    while (*phs  < loop) *phs += looplength;
	} while (--n);
}

void lposcinta_stereo_no_trasp(LPOSC_ST *p) // trasposition is allowed only 
{											//in integer values (twice, three times etc.)
											// so it is faster
	long *phs = &p->phs_int, si = (long) *p->freq;
    MYFLT	*out1 = p->out1, *out2 = p->out2, *amp=p->amp;
	short	*ft =  p->ft;
	long	n = ksmps;
    long	loop, end, looplength /* = p->looplength */ ; 
	if ((loop= (long) *p->kloop) < 0) loop=0;
	if ((end= (long) *p->kend) > p->tablen || end <=0) end = p->tablen;
	looplength = end - loop;
	if (looplength == 0) looplength = end;
	do {
		short *curr_samp1 = ft + *phs * 2;
	    *out1++ = *amp   * (MYFLT) *curr_samp1 ;
		*out2++ = *amp++ * (MYFLT) *(curr_samp1+1) ;
	     *phs += si;
	    while (*phs  >= end) *phs -= looplength;
	    while (*phs  < loop) *phs += looplength;
	} while (--n);
}

