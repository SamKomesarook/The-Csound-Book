#ifdef _WIN32
#pragma warning(disable:4786 4117)
#endif

#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <map>
#include <string>
#include <process.h>

using namespace std;

#include "GL/gl.h"

extern "C" {
	#undef __cplusplus
	#include "cs.h"
	#include "imageProc.h"

	#include "oload.h"
	#define __cplusplus
    extern EVTBLK *currevent; 
	char *unquote(char *name);
}
#include "imagestruct.h"

extern map<int,imageStruct> Bm_image; // map of pointers to CAnyBmp objects
extern map<int,imageStruct>::iterator Bm_it; // iterator of the map

//----------------

extern "C" void imgGain_set(IMG_GAIN *p)
{
	imageStruct* out = &(Bm_image[(int) *p->ioutHandle]);	
	imageStruct* in = &(Bm_image[(int) *p->ihandle]);		
	if (in->data == NULL) {								
		initerror("invalid ihandle value");				
		return;											
	}													
	else if (in->csize != 1 && in->csize != 4 ) 	{		
		initerror("invalid color depth. Only 1 or 4 allowed"); 
		return;											
	}													
	if ( out->data == NULL								
		||	in->xsize != out->xsize						
		||	in->ysize != out->ysize						
		||	in->csize != out->csize) {					
		out->xsize = in->xsize;							
		out->ysize = in->ysize;							
		out->csize = in->csize;
		out->format = in->format;
		out->type = in->type;
		if (out->data != NULL) delete [] out->data;	
		if (out->csize == 1 ) // GREY
			out->data = new BYTE[ out->xsize * out->ysize]; 
		else				// RGBA
			out->data = new BYTE[ out->xsize * out->ysize * out->csize]; 
	}													
	p->width = out->xsize;								
	p->height = out->ysize;								
	p->depth = out->csize;								
	p->pixels_in = in->data;								
	p->pixels_out = out->data;
	
	p->datasize = p->width * p->height;
	p->pix_done = 0;
	p->isNotFinished = 1;
		
	if	(*p->iprocessing_time)
		p->pix_per_kcycle = p->datasize / (*p->iprocessing_time * ekr);
	else 
		p->pix_per_kcycle = p->datasize;
}


extern "C" void imgGain(IMG_GAIN *p)
{
	
	*p->outTrig = 0;
	if (*p->trig || p->isNotFinished){ 
		const long pix_done = p->pix_done;
		long end_point = pix_done + p->pix_per_kcycle;
		if (end_point >= p->datasize) {
			end_point= p->datasize;
			p->isNotFinished = 0;
		}
		else p->isNotFinished = 1;


		if (p->depth == 4) { //RGBA
			MYFLT red = *p->red, green = *p->green, blue = *p->blue, alpha =*p->alpha;
			BYTE *pixel_in  = (BYTE*) p->pixels_in  + pix_done * 4;
			BYTE *pixel_out = (BYTE*) p->pixels_out + pix_done * 4;
			int j = end_point - pix_done;
			do {
				int r = (int) (pixel_in[RED]   * red);
				int g = (int) (pixel_in[GREEN] * green);
				int b = (int) (pixel_in[BLUE]  * blue);
				int a = (int) (pixel_in[ALPHA] * alpha);
				pixel_out[RED]		= CLAMP(r);
				pixel_out[GREEN]	= CLAMP(g);
				pixel_out[BLUE]		= CLAMP(b);
				pixel_out[ALPHA]	= CLAMP(a);
				pixel_out+=4;
				pixel_in+=4;
			} while (--j);
		}
		else {			//GREY SCALE
			MYFLT red = *p->red;
			BYTE *pixel_in  = (BYTE*) p->pixels_in  + pix_done;
			BYTE *pixel_out = (BYTE*) p->pixels_out + pix_done;

			for (int j = pix_done; j < end_point; j++) 
				*pixel_out++ = CLAMP( (int) (*pixel_in++ * red));
		}
		if (p->isNotFinished) p->pix_done = end_point;
		else {
			p->pix_done = 0;
			*p->outTrig = 1;
		}
	}
}
//----------------
extern "C" void imgSetPixel_set(IMG_SETPIXEL *p)
{
	imageStruct *image = &(Bm_image[*p->imageHandle]);
	p->pixels = image->data;
	p->width = image->xsize;								
	p->height = image->ysize;								
	//p->depth = ;
	if (image->csize != 4) // only allows RGBA data
		initerror("imgSetPixel: only supports RGBA format!");
	p->totSize = p->width * p->height * 4;
	if ( image->data == NULL ) {								
		initerror("imgSetPixel: image does not exist!");
		//image->data = new BYTE[ out->xsize * out->ysize * out->csize]; 
	}
}

extern "C" void imgSetPixel(IMG_SETPIXEL *p)
{
	if (*p->trig) { 
		BYTE  *pix;
		pix = ((BYTE*) p->pixels) +	((((int) *p->x + (int) *p->y * p->width) * 4) % p->totSize);
		pix[RED] = CLAMP((int) *p->r);
		pix[GREEN] = CLAMP((int) *p->g);
		pix[BLUE] = CLAMP((int) *p->b);
		pix[ALPHA] = CLAMP((int) *p->a);
		//printf("x:%d   y:%d\n", (int) *p->x, (int) *p->y);
		;
	}
}

//----------------
extern "C" void imgConvolve_set(IMG_CONVOLVE *p)
{
	imageStruct* out = &(Bm_image[(int) *p->ioutHandle]);	
	imageStruct* in = &(Bm_image[(int) *p->ihandle]);		
	if (in->data == NULL) {								
		initerror("invalid ihandle value");				
		return;											
	}													
	else if (in->csize != 1 && in->csize != 4 ) 	{		
		initerror("invalid color depth. Only 1 or 4 allowed"); 
		return;											
	}													
	if ( out->data == NULL								
		||	in->xsize != out->xsize						
		||	in->ysize != out->ysize						
		||	in->csize != out->csize) {					
		out->xsize = in->xsize;							
		out->ysize = in->ysize;							
		out->csize = in->csize;
		out->format = in->format;
		out->type = in->type;
		if (out->data != NULL) delete out->data;	
		if (out->csize == 1 ) {// GREY
			//out->data = new BYTE[ out->xsize * out->ysize]; 
			initerror("imgConvolve: monochrome images not allowed");
			return;
		}
		else				// RGBA
			out->data = new BYTE[ out->xsize * out->ysize * out->csize]; 
	}													
	p->old_matrix_fn =0;

	p->width = out->xsize;								
	p->height = out->ysize;								
	p->depth = out->csize;								
	p->pixels_in = in->data;								
	p->pixels_out = out->data;
/*
	p->datasize = p->width * p->height;
	p->pix_done = 0;
	p->isNotFinished = 1;
		
	if	(*p->iprocessing_time)
		p->pix_per_kcycle = p->datasize / (*p->iprocessing_time * ekr);
	else 
		p->pix_per_kcycle = p->datasize;
		*/
}


extern "C" void imgConvolve(IMG_CONVOLVE *p)
{
	if (*p->trig ){

		if (p->old_matrix_fn != (int) *p->kmatrix_fn) {
			FUNC *ftp;
			if((ftp = ftfind(p->kmatrix_fn)) != NULL) {
				p->m_matrix = ftp->ftable+2;
				p->m_rows = (int) (ftp->ftable)[0];
				p->m_cols = (int) (ftp->ftable)[1];
				p->old_matrix_fn = (int) *p->kmatrix_fn;
			}
			else {
				perferror("imgConvolve: invalid matrix table");
				return;
			}
		}
		
		imageStruct tempImg, *image = &(Bm_image[*p->ihandle]);
		copy2Image(&tempImg,image);
		BYTE  *pixel_out = (BYTE*) p->pixels_out;
		
		int m_rows = p->m_rows;
		int m_cols = p->m_cols;
		MYFLT *m_matrix =  p->m_matrix;
		MYFLT m_range = *p->m_range;
		int initX = m_rows / 2;
		int initY = m_cols / 2;
		int maxX = tempImg.xsize - initX;
		int maxY = tempImg.ysize - initY;
		int xTimesc = tempImg.xsize * tempImg.csize;
		int initOffset = initY * xTimesc + initX * tempImg.csize;
		
		for (int y = initY; y < maxY; y++)
		{
			int realY = y * xTimesc;
			int offsetY = realY - initOffset;
			
			for (int x = initX; x < maxX; x++)
			{
				int realPos = x * tempImg.csize + realY;
				int offsetXY = x * tempImg.csize + offsetY;
				
				// skip the alpha value
				for (int c = 0; c < 3; c++) {
					MYFLT new_val = 0.0;
					int offsetXYC = offsetXY + c;
					
					for (int matY = 0; matY < m_cols; matY++) {
						int offsetXYCMat = matY * xTimesc + offsetXYC;
						int realMatY = matY * m_rows;
						
						for (int matX = 0; matX < m_rows; matX++) {
							new_val += ( (BYTE*) tempImg.data)[offsetXYCMat + matX * tempImg.csize] *
								m_matrix[realMatY + matX];
						}
					}
					//((BYTE*) image->data)[realPos + c] = CLAMP(new_val/m_range);
					pixel_out[realPos + c] = CLAMP(new_val/m_range);
				}
			}
		}
		delete [] tempImg.data;
	}
}



