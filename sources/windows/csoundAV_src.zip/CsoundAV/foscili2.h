typedef struct {
	OPDS	h;
	MYFLT	*rslt, *xamp, *kcps, *kcar, *kmod, *kndx, *ifn_car, *ifn_mod, *iphs;
	long	mphs, cphs;
	FUNC	*ftp_car, *ftp_mod;
} FOSC2;
