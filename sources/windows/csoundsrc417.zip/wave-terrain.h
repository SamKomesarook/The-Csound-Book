#include "cs.h"
typedef struct {

  OPDS h;

  MYFLT *aout;
  MYFLT *kamp;

  MYFLT *kpch;

  MYFLT *kcx, *kcy;
  MYFLT *krx, *kry;

  MYFLT *i_tabx, *i_taby;
/* Internals */

  MYFLT *xarr, *yarr;

  AUXCH aux_x, aux_y;
  
  MYFLT sizx, sizy;
  MYFLT theta;

} WAVETER;
