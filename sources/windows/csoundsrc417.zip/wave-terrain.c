#include "cs.h"
#include "wave-terrain.h"
#include <math.h>

/*  Wave-terrain synthesis opcode
 *
 *  author: m gilliard
 *          en6mjg@bath.ac.uk
 */


void wtinit(WAVETER *p){

    /* DECLARE */
    int i;
    FUNC *ftpx = ftfind(p->i_tabx);
    FUNC *ftpy = ftfind(p->i_taby);

    /* CHECK */
    if ((ftpx == NULL)||(ftpy == NULL)) {
      initerror("wter: ftable not found");
      return;
    }

/*
  printf("WAVE TERRAIN INIT v1.0 - terrain(%d,%d)\n", tabxlen, tabylen); 
*/

    /* ALLOCATE FOR COPIES OF FTABLES */
    auxalloc (ftpx->flen * sizeof(MYFLT), &p->aux_x);
    auxalloc (ftpy->flen * sizeof(MYFLT), &p->aux_y);

    /* POINT xarr AND yarr AT THE TABLES */
    p->xarr = (MYFLT*)p->aux_x.auxp;
    p->yarr = (MYFLT*)p->aux_y.auxp;

    /* COPY TABLES TO LOCAL */
    for (i=0; i != ftpx->flen; i++){
      p->xarr[i] = (ftpx->ftable[i]);
    }

    for (i=0; i != ftpy->flen; i++){
      p->yarr[i] = (ftpy->ftable[i]);
    }

    /* PUT SIZES INTO STRUCT FOR REFERENCE AT PERF TIME */
    p->sizx = (MYFLT)ftpx->flen;
    p->sizy = (MYFLT)ftpy->flen;
    p->theta = FL(0.0);
}

void wtPerf(WAVETER *p){
    int i;
    int xloc, yloc;
    MYFLT xc, yc;

    for (i=0; i<ksmps; i++) {

      /* COMPUTE LOCATION OF SCANNING POINT */
      xc = *(p->kcx) + *(p->krx) * (MYFLT)sin((double)p->theta);
      yc = *(p->kcy) + *(p->kry) * (MYFLT)cos((double)p->theta);

      /* MAP SCANNING POINT TO BE IN UNIT SQUARE */
      xc = xc-(MYFLT)floor(xc);
      yc = yc-(MYFLT)floor(yc);

      /* SCALE TO TABLE-SIZE SQUARE */
      xloc = (int)(xc * p->sizx);
      yloc = (int)(yc * p->sizy);

      /* OUTPUT AM OF TABLE VALUES * KAMP */
      p->aout[i] = p->xarr[xloc] * p->yarr[yloc] * *(p->kamp);

      /* MOVE SCANNING POINT ROUND THE ELLIPSE */
      p->theta += *(p->kpch) * (TWOPI_F / esr);
    }
}
