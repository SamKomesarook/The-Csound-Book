/****************** hrtferi.h *******************/
#include "3Dug.h"

typedef struct {
  OPDS 		h;
  MYFLT		*aLeft, *aRight, *aIn, *iAz, *iElev; /* outputs and inputs */
  MEMFIL	*mfp;		/* file pointer */
  long		incount, outfront, outend, outcount;
  AUXCH		auxch;		/* will point to allocated memory */
  HRTF_DATUM	hrtf_data;	/* matrix to store HRTF data */
  MYFLT		outl[256], outr[256];
  MYFLT		x[256], yl[256], yr[256], bl[127], br[256];
} HRTFERI;

				

