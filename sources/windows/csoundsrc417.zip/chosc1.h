typedef struct  {
        OPDS    h;
        MYFLT   *ar, *X0, *C;   /* The parameters */
        MYFLT   prev;
} SCHOSC;
