/* ***************************************************************** */
/* ******** Program to import lpanal files from tabular format. **** */
/* ***************************************************************** */

/* ***************************************************************** */
/* John ffitch 1998 Nov 15                                           */
/* ***************************************************************** */
     
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#ifndef FLOAT
#include "sysdep.h"
#endif
#include "lpc.h"

void usage(void);

long natlong(long lval)             /* coerce a bigendian long into a natural long */
{
    unsigned char benchar[4];
    unsigned char *p = benchar;
    long natlong;

    *(long *)benchar = lval;
    natlong = *p++;
    natlong <<= 8;
    natlong |= *p++;
    natlong <<= 8;
    natlong |= *p++;
    natlong <<= 8;
    natlong |= *p;
    return(natlong);
}

FILE *dribble = NULL;
void dribble_printf(char *fmt, ...)
{
    va_list a;
    va_start(a, fmt);
    vprintf(fmt, a);
    va_end(a);
    if (dribble != NULL) {
      va_start(a, fmt);
      vfprintf(dribble, fmt, a);
      va_end(a);
    }
}

void err_printf(char *fmt, ...)
{
    va_list a;
    va_start(a, fmt);
    vfprintf(stderr, fmt, a);
    va_end(a);
    if (dribble != NULL) {
      va_start(a, fmt); /* gab */
      vfprintf(dribble, fmt, a);
      va_end(a);
    }
}

extern void init_getstring(int, char**);
int main(int argc, char **argv)
{
    FILE *inf;
    FILE *outf;
    LPHEADER hdr;
    int i, j;
    char *str;
    float *coef;

    init_getstring(argc, argv);
    if (argc!= 3)
        usage();
    inf = fopen(argv[1], "rb");
    if (inf == NULL) {
        fprintf(stderr, "Cannot open input file %s\n", argv[1]);
        exit(1);
    }
    outf = fopen(argv[2], "w");
    if (inf == NULL) {
        fprintf(stderr, "Cannot open output file %s\n", argv[2]);
        exit(1);
    }
    if (fread(&hdr, sizeof(LPHEADER)-4, 1, inf) != 1 ||
        hdr.lpmagic != LP_MAGIC) {
        fprintf(stderr, "Failed to read LPC header\n");
        exit(1);
    }
    fscanf(inf, "%ld,%ld,%ld,%ld,%f,%f,%f",
            &hdr.headersize, &hdr.lpmagic, &hdr.npoles, &hdr.nvals,
            &hdr.framrate, &hdr.srate, &hdr.duration);
    if (fwrite(&hdr, sizeof(LPHEADER)-4, 1, outf) != 1 ||
        hdr.lpmagic != LP_MAGIC) {
        fprintf(stderr, "Failed to write LPC header\n");
        exit(1);
    }
    str = (char *)malloc(hdr.headersize-sizeof(LPHEADER)+4);
    for (i=0; i<hdr.headersize-sizeof(LPHEADER)+4; i++)
        str[i] = getc(inf);
    if (getc(inf)!='\n') {
      fprintf(stderr, "Failed to read string\n");
    }
    fwrite(&hdr, sizeof(char), hdr.headersize-sizeof(LPHEADER)+4, outf);
    coef = (float *)malloc((hdr.npoles+hdr.nvals)*sizeof(float));
    for (i = 0; i<hdr.nvals; i++) {
        char c;
        for (j=0; j<hdr.npoles; j++) 
            fscanf(inf, "%f%c", &coef[j], &c);
        fwrite(&coef[0], sizeof(float), hdr.npoles, outf);
    }
    fclose(outf);
    fclose(inf);
}

void usage(void)
{
    exit(1);
}
