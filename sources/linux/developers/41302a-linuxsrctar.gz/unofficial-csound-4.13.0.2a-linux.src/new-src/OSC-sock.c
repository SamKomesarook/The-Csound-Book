/* ===================================================================
 * File:	OSC-sock.c
 * Time-stamp:	<2000-12-13 05:37:26 steve>
 * Author:	Stefan Kersten <steve@k-hornz.de>
 * Contents:	Csound/OSC support
 * ===================================================================
 * $Id: OSC-sock.c,v 1.6 2001/01/13 11:22:54 nicb Exp $
 * ===================================================================
 */

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>

#include <OSC/OSC.h>
#include <OSC/OSC-internal-messages.h>

#include "OSC-sock.h"

#define MSlot_MaxNumBufs	100	/* Max number of incoming buffers */
#define MSlot_MaxNumInQueue	100	/* Max number of objects in the OSC queue */
#define MSlot_MaxNumCB		200	/* Max number of active callbacks in the scheduler */
#define MSlot_InitNumCont	50	/* Fallback value; give arguments to OSCinit */
#define MSlot_InitNumMeth	100
#define MSlot_MaxMethSize	32	/* Maximum length of the method string; 
					   this should be enough */
#define MSlot_InsTagWidth	3	/* How much digits will be taken from the instance
					   tag? Change it to allow for more than 999
					   separately controlable instances of one instrument. */
#define MSlot_InsContStr	"instruments"

#define MSend_MaxNumPeers	20	/* Max number of Peers OSCsend can address */
#define MSend_MaxHostLen	64

#define MMalloc(byteCount) 	malloc(byteCount)
#define MFree(object)		free(object); object = NULL
#define MAtexit(func)		atexit(func)
#define MPerror(text)		perror(text)
#define MInitError		initerror("")

#define MError_Memory		"no memory left"
#define MError_Initialized	"OSC has not been initialized"

#if defined(_DEBUG)
#  define MAssert(p) \
	if (!(p)) \
	{ \
		fprintf(stderr, \
		"Assertion failed in file %s, line %d\n", \
		__FILE__, __LINE__); \
		exit(1); \
	}

static void DEBUG(char *s, ...)
{
  va_list ap;
  fprintf(stderr, "==>  ");
  va_start(ap, s);
  vfprintf(stderr, s, ap);
  fprintf(stderr, "\n");
  va_end(ap);
}

#else /* !_DEBUG */

#  define MAssert(p)
static void DEBUG(char *s, ...) {};

#endif /* _DEBUG */


typedef struct MethodStruct*	 	Method;
typedef struct ContainerStruct*	 	Container;
typedef struct GlobalStateStruct* 	GlobalState;

static GlobalState globals = NULL;
#define MOscIsUp (globals != NULL)

static char *IntToString(int);
static char *ParseIntTag(int, int);
static void Warning(char *, ...);


/* ===================================================================
 * List, ListElt, ListIsEqualFunc
 * 
 * A singly linked list with an unspecified data portion.
 * For use with instrument numbers, integer tags and method names.
 * A function must be supplied upon list creation, which checks
 * for equality of two arguments.
 *
 * Note: This is used inconsistently: arguments are the container 
 * and the key, such that cont->key and key are compared.
 */
typedef struct ListEltStruct* ListElt;
typedef struct ListStruct* List;

typedef void (*ListEltDeleteFunc)(void *);
typedef int (*ListIsEqualFunc)(const void *, const void *);

struct ListEltStruct
{
  ListElt	next;
  void		*data;
};

struct ListStruct
{
  ListElt	  head;
  ListElt	  tail;
};

static ListElt ListElt_New(void *data)
{
  ListElt self;

  if ((self = (ListElt)MMalloc(sizeof(struct ListEltStruct))) == NULL)
  {
    return NULL;
  }
  
  self->next = NULL;
  self->data = data;

  return self;
}

#define List_IsEmpty(self) (self->head == NULL)

static void ListElt_Delete(ListElt self, ListEltDeleteFunc free)
{
  if (self != NULL)
  {
    (*free)(self->data);
    MFree(self);
  }
}

static List List_New()
{
  List self;

  if ((self = (List)MMalloc(sizeof(struct ListStruct))) == NULL)
  {
    return NULL;
  }

  self->head = NULL;
  self->tail = NULL;
  
  return self;
}

static ListElt List_PopFront(List self)
{
  ListElt retElt;

  MAssert(self != NULL);
  MAssert(!List_IsEmpty(self));

  if(List_IsEmpty(self))
  {
    return NULL;
  }
  else
  {
    retElt = self->head;
    self->head = self->head->next;
    return retElt;
  }
}

static void List_Delete(List self, ListEltDeleteFunc free)
{
  if (self != NULL)
  {
    while (!List_IsEmpty(self))
    {
      ListElt listElt = List_PopFront(self);
      ListElt_Delete(listElt, free);
    }
    MFree(self);
  }
}

static List List_PushBack(List self, ListElt elt)
{
  MAssert(self != NULL);
  MAssert(elt != NULL);

  elt->next = NULL;

  if (self->head == NULL)
  {
    self->head = self->tail = elt;
  }
  else
  {
    self->tail->next = elt;
    self->tail = elt;
  }
  
  return self;
}

static List List_PushBackNew(List self, void *data)
{
  ListElt listElt;
  
  if ((listElt = ListElt_New(data)) == NULL)
  {
    return NULL;
  }
  
  return List_PushBack(self, listElt);
}


/* ===================================================================
 * These containers are needed to set up the OSC address space.
 * The toplevel routine to be called is AddControlSlot()
 */
struct ControlContextStruct
{
  MYFLT			value;
  MYFLT			amp[2];
};

struct GlobalStateStruct
{
  OSC_UDPSocket		socket;
  OSC_UDPSocket		peers[MSend_MaxNumPeers];
  int			numPeers;
  OSCcontainer		oscRoot;
  List			controlContexts;
  List			memoryChunks;
};

static void MemoryChunk_Delete(void *chunk)
{
  MFree(chunk);
}

#define Context_MapValue(value, min1, min2, max1, max2) \
	((((value - min1) / (max1 - min1)) * (max2 - min2)) + min2)

static ControlContext ControlContext_New(MYFLT value, MYFLT amp1, MYFLT amp2)
{
  ControlContext self;

  if ((self = (ControlContext)MMalloc(sizeof(struct ControlContextStruct))) == NULL)
  {
    return NULL;
  }

  self->value = value;
  self->amp[0] = amp1;
  self->amp[1] = amp2;

  return self;
}

static void ControlContext_Delete(void *data)
{
  if (data != NULL)
  {
    MFree(data);
  }
}

static OSCcontainer AddControlSlot(OSCcontainer parent,
				   int ins, int numTags, Name name,
				   MYFLT init, MYFLT min, MYFLT max,
				   methodCallback callback)
{
  OSCcontainer
    insCont, 
    tagCont;
  OSCMethod
    method;
  ControlContext	
    context;
  struct OSCContainerQueryResponseInfoStruct 
    contInfo;
  struct OSCMethodQueryResponseInfoStruct 
    methodInfo;
  char
    *insStr, 
    *tagStr;
  int i;

  MAssert(parent != NULL);
  MAssert(MOscIsUp);

  OSCInitContainerQueryResponseInfo(&contInfo);
  OSCInitMethodQueryResponseInfo(&methodInfo);

  if ((insStr = IntToString(ins)) == NULL)
  {
    return NULL;
  }

  if ((insCont = OSCGetChildContainer(parent, insStr, 1)) == NULL)
  {
    insCont = OSCNewContainer(insStr, parent, &contInfo);
  }
  else
  {
    MFree(insStr);
  }

  for (i = 0; i < numTags; i++)
  {
    if ((tagStr = ParseIntTag(i, MSlot_InsTagWidth + 1)) == NULL)
    {
      return NULL;
    }
    
    if ((tagCont = OSCGetChildContainer(insCont, tagStr, 1)) == NULL)
    {
      tagCont = OSCNewContainer(tagStr, insCont, &contInfo);
    }
    else
    {
      MFree(tagStr);
    }

    if ((context = ControlContext_New(init, min, max)) == NULL)
    {
      return NULL;
    }

    if ((method = OSCGetMethod(tagCont, name, 1)) == NULL)
    {
      method = OSCNewMethod(name, tagCont, callback, context, &methodInfo);
    }
    else
    {
      ControlContext_Delete(context);
    }

    if (List_PushBackNew(globals->controlContexts, context) == NULL)
    {
      ControlContext_Delete(context);
      return NULL;
    }
  }

  return parent;
}

static ControlContext GetControlContext(OSCcontainer parent, 
					char *ins, char *tag, char *meth)
{
  OSCcontainer
    insCont, 
    tagCont;
  OSCMethod
    method;

  MAssert(parent != NULL);

  if ((insCont = OSCGetChildContainer(parent, ins, 1)) == NULL)
  {
    return NULL;
  }

  if ((tagCont = OSCGetChildContainer(insCont, tag, 1)) == NULL)
  {
    return NULL;
  }

  if ((method = OSCGetMethod(tagCont, meth, 1)) == NULL)
  {
    return NULL;
  }

  return (ControlContext)OSCGetMethodContext(method);
}

static void GlobalState_Delete(GlobalState self)
{
  int i;

  if (self != NULL)
  {
    OSC_UDPSocket_Delete(self->socket);

    List_Delete(self->controlContexts, ControlContext_Delete);
    List_Delete(self->memoryChunks, MemoryChunk_Delete);

    for (i = 0; i < self->numPeers; i++)
    {
      if (self->peers[i] != NULL)
      {
	OSC_UDPSocket_Delete(self->peers[i]);
      }
    }

    MFree(self);
  }
}

static GlobalState GlobalState_New(void)
{
  GlobalState self;
  int i;

  if ((self = (GlobalState)MMalloc(sizeof(struct GlobalStateStruct))) == NULL)
  {
    return NULL;
  }

  self->socket 	= NULL;
  self->oscRoot	= NULL;

  if ((self->controlContexts = List_New()) == NULL)
  {
    return NULL;
  }

  if ((self->memoryChunks = List_New()) == NULL)
  {
    MFree(self->controlContexts);
    return NULL;
  }

  self->numPeers = MSend_MaxNumPeers;
  for (i = 0; i < self->numPeers; i++)
  {
    self->peers[i] = NULL;
  }

  return self;
}

/* ===================================================================
 * OSC Methods
 */

/* Allocate new memory of size numBytes and append it to a global
   list for later cleanup. 
   Called by OSC. */
static void *InitTimeMalloc(int numBytes) 
{
  void *result = (void *)MMalloc(numBytes);

  if (List_PushBackNew(globals->memoryChunks, result) == NULL)
  {
    MFree(result);
    result = NULL;
  }

  return result;
}

static void *RealTimeMalloc(int numBytes) 
{
  return InitTimeMalloc(numBytes);
}

static OSCcontainer InitOSCAddressSpace(void)
{
  struct OSCAddressSpaceMemoryTuner t;

  t.initNumContainers 		= MSlot_InitNumCont;
  t.initNumMethods		= MSlot_InitNumMeth;
  t.InitTimeMemoryAllocator	= InitTimeMalloc;
  t.RealTimeMemoryAllocator	= RealTimeMalloc;

  return OSCInitAddressSpace(&t);
}

static int InitOSCReceive(void)
{
  struct OSCReceiveMemoryTuner rt;
  int result;
  
  rt.InitTimeMemoryAllocator	= InitTimeMalloc;
  rt.RealTimeMemoryAllocator	= RealTimeMalloc;
  rt.receiveBufferSize		= MSlot_MaxBufSize;
  rt.numReceiveBuffers		= MSlot_MaxNumBufs;
  rt.numQueuedObjects		= MSlot_MaxNumInQueue;
  rt.numCallbackListNodes	= MSlot_MaxNumCB;

  result = OSCInitReceive(&rt);

  if (!result)
    return -1;

  return result;
}

OSCTimeTag CurrentTime()
{
  extern long 	kcounter;
  extern MYFLT 	ekr;
  OSCTimeTag 	now = OSCTT_Immediately();

  return OSCTT_PlusSeconds(now, ((float)kcounter / ekr));
}

/* ===================================================================
 * DoOSC()
 *
 * This function is called every k-cycle in kperf() to process any 
 * OSC events that have come over the socket and dispatches the
 * corresponding callbacks.
 */
void DoOSC()
{
  OSCTimeTag
    now;
  int
    n = 0;
  OSC_UDPSocket	
    socket;

  if (!MOscIsUp)
  {
    return;
  }
  
  now = CurrentTime();

  socket = globals->socket;
  MAssert(socket != NULL);

  while (1)
  {
    n = OSC_UDPSocket_Receive(socket, NULL);
    if (n == 0)
    {
      break;
    }
    if (n < 0)
    {
      Warning("DoOSC: error during recv on socket %d", OSC_UDPSocket_GetSocketFD(socket));
      return;
    }
  }

  OSCInvokeAllMessagesThatAreReady(now);
}

static void OscControlSlotCB(void *data, int arglen, const void *vargs,
			     OSCTimeTag when, NetworkReturnAddressPtr ra)
{
  ControlContext
    context = (ControlContext)data;
  int
    byteCount;
  void
    *args;
  MYFLT
    locMin, 
    locMax, 
    remMin, 
    remMax, 
    arg, 
    value;

  if ((arglen/4) != 3)
  {
    /* Warning("ControlCB: wrong # args: %d", argc); */
    return;
  }

  args   = (void *)vargs;
  locMin = context->amp[0];
  locMax = context->amp[1];

  /* Decode arguments */
  if ((byteCount = OSC_ReadFloatFromBuffer(args, arglen, &remMin)) == 0)
  {
    return;
  }
  args += byteCount; arglen -= byteCount;

  if ((byteCount = OSC_ReadFloatFromBuffer(args, arglen, &remMax)) == 0)
  {
    return;
  }
  args += byteCount; arglen -= byteCount;

  if ((byteCount = OSC_ReadFloatFromBuffer(args, arglen, &arg)) == 0)
  {
    return;
  }
  args += byteCount; arglen -= byteCount;
  
  /* Compute value */
  if ((locMin == 0) && (locMax == 0))
  {
    value = arg;
  }
  else
  {
    if ((remMin == 0) && (remMax == 0))
    {
      remMin = locMin;
      remMax = locMax;
    }
    
    if (arg <= remMin)
    {
      value = locMin;
    }
    else if (arg >= remMax)
    {
      value = locMax;
    }
    else
    {
      value = Context_MapValue(arg, remMin, locMin, remMax, locMax);
    }
  }

  context->value = value;
}

static void OscNoteOnCB(void *data, int arglen, const void *vargs,
			OSCTimeTag when, NetworkReturnAddressPtr ra)
{
  /* note-on <instag> <args> */
}

static void OscNoteOffCB(void *data, int arglen, const void *vargs,
			 OSCTimeTag when, NetworkReturnAddressPtr ra)
{
  /* note-off <instag> */
}

static void OscPlayNoteCB(void *data, int arglen, const void *vargs,
			  OSCTimeTag when, NetworkReturnAddressPtr ra)
{
  /* play-note <instag> <dur> <args> */
}

static void OscTimeCB(void *data, int arglen, const void *vargs,
		      OSCTimeTag when, NetworkReturnAddressPtr ra)
{
  /* send current k-time to ra */
}

static void OscStopCB(void *data, int arglen, const void *vargs,
		      OSCTimeTag when, NetworkReturnAddressPtr ra)
{
  /* emit an 'e' score event */
}

static void OscVolumeCB(void *data, int arglen, const void *vargs,
			OSCTimeTag when, NetworkReturnAddressPtr ra)
{
  /* volume <channel> <value> */
}


/* ===================================================================
 * Utility
 */
static char *IntToString(int i)
{
  char *buf;

  if ((buf = (char *)MMalloc(((sizeof(int) * CHAR_BIT + 2) / 3 + 1))) == NULL)
  {
    return NULL;
  }

  sprintf(buf, "%d", i);

  return buf;
}

static char *GetStrarg(MYFLT *arg, int size, char *strarg)
{
  char *str;
  int strNdx;

  extern char **strsets;
  extern int strsmax;
  
  if ((str = (char *)MMalloc(size)) == NULL)
  {
    return NULL;
  }
  if (*arg == sstrcod)
  {
    extern EVTBLK *currevent; 
    if (strarg == NULL)
    {
      strcpy(str, unquote(currevent->strarg));
    }
    else 
    {
      strcpy(str, unquote(strarg));
    }
  }
  else if (((strNdx = (long)*arg) < strsmax) && 
	   (strsets != NULL) &&
	   strsets[strNdx])
  {
    strcpy(str, strsets[strNdx]);
  }
  else
  {
    MFree(str);
    str = IntToString((long)str);
  }

  return str;
}

static char *ParseIntTag(int i, int bufLen)
{
  char *self;

  if ((self = (char *)MMalloc(bufLen)) == NULL)
  {
    return NULL;
  }

  sprintf(self, "%.*d", bufLen-1, i);
  
  return self;
}

static char *ParseFloatTag(MYFLT f, int bufLen)
{
  char *self;
  char tmpBuf[bufLen+8];
  int i, k;

  if ((self = (char *)MMalloc(bufLen)) == NULL)
  {
    return NULL;
  }

  sprintf(tmpBuf, "%.*f", bufLen-1, f);

  /* Look for first char after '.' */
  i = 0;
  while (1)
  {
    i++;
    if (tmpBuf[i-1] == '.')
    {
      break;
    }
  }

  /* now copy insTagWidth chars */
  for (k = 0; k < bufLen-1; k++)
    self[k] = tmpBuf[k+i];
  self[k++] = '\0';

  return self;
}

static void Warning(char *what, ...)
{
  va_list ap;
  va_start(ap, what);
  vfprintf(stderr, what, ap);
  fprintf(stderr, "\n");
  va_end(ap);
}

/* ===================================================================
 * OSCinit
 */
static void osc_shutdown()
{
  GlobalState_Delete(globals);
}

void osc_init(void *entry)
{
  OSCINIT
    *p = (OSCINIT *)entry;
  unsigned short
    port = (unsigned short)*(p->_port);
  OSCcontainer		
    oscScoreCont, 
    oscSysCont;
  struct OSCContainerQueryResponseInfoStruct 
    cqInfo;
  struct OSCMethodQueryResponseInfoStruct    
    mqInfo;

  if (MOscIsUp)
  {
    initerror("OSCinit: you should only call this opcode once, globally");
    return;
  }
  
  if ((globals = GlobalState_New()) == NULL)
  {
    initerror("OSCinit: OSC opcode initialization failed");
    return;
  }

  if (OSC_UDP_Startup() == SOCKET_ERROR)
  {
    GlobalState_Delete(globals);
    globals = NULL;
    MPerror("OSCinit: could not initialize network");
    MInitError;
    return;
  }

  if ((globals->socket = OSC_UDPSocket_ServerNew(port)) == NULL)
  {
    GlobalState_Delete(globals);
    globals = NULL;
    MPerror("OSCinit: could not create socket");
    MInitError;
    return;
  }
  OSC_UDPSocket_SetNonBlocking(globals->socket, TRUE);

  /* Initialize OSC containers */
  OSCInitContainerQueryResponseInfo(&cqInfo);
  OSCInitMethodQueryResponseInfo(&mqInfo);

  globals->oscRoot = InitOSCAddressSpace();

  OSCNewContainer(MSlot_InsContStr, globals->oscRoot, &cqInfo);

  oscScoreCont = OSCNewContainer("score", globals->oscRoot, &cqInfo);
  OSCNewMethod("note-on", oscScoreCont, OscNoteOnCB, NULL, &mqInfo);
  OSCNewMethod("note-off", oscScoreCont, OscNoteOffCB, NULL, &mqInfo);
  OSCNewMethod("play-note", oscScoreCont, OscPlayNoteCB, NULL, &mqInfo);
  
  oscSysCont = OSCNewContainer("system", globals->oscRoot, &cqInfo);

  OSCNewMethod("volume", oscSysCont, OscVolumeCB, NULL, &mqInfo);
  OSCNewMethod("time", oscSysCont, OscTimeCB, NULL, &mqInfo);
  OSCNewMethod("stop", oscSysCont, OscStopCB, NULL, &mqInfo);
  
  if (InitOSCReceive() == -1)
  {
    GlobalState_Delete(globals);
    globals = NULL;
    initerror("OSCinit: OSC library initialization failed");
    return;
  }

  /* Register function called at program termination */
  MAtexit(osc_shutdown);

  /* Ensure that DoOSC() will run in kperf() */
  O.RTevents = 1;
}

/* ===================================================================
 * OSCslot
 */
void osc_slot(void *entry)
{
  OSCSLOT
    *p = (OSCSLOT *)entry;
  OSCcontainer
    insCont;
  int
    ins, 
    numTags, 
    maxNumTags;
  MYFLT
    init, 
    min, 
    max;
  char
    *methStr;

  ins 		= abs(*p->_ins);
  numTags 	= abs(*p->_numtags);

  if (!MOscIsUp ||
      ((insCont = OSCGetChildContainer(globals->oscRoot, MSlot_InsContStr, 1)) == NULL))
  {
    initerror("OSCslot: OSC has not been initialized");
    return;
  }

  if (numTags > (maxNumTags = (pow(10, MSlot_InsTagWidth) - 1)))
  {
    Warning("OSCslot: too many tags requested (max: %d); "
	    "increase MSlot_InsTagWidth in OSC-sock.c and recompile.");
    MInitError;
    return;
  }
  
  if ((methStr = GetStrarg(p->_meth, MSlot_MaxMethSize, p->STRARG)) == NULL)
  {
    Warning("OSCslot: %s", MError_Memory);
    MInitError;
    return;
  }
  
  if ((AddControlSlot(insCont,
		      ins, numTags, methStr,
		      *p->_init, *p->_min, *p->_max,
		      OscControlSlotCB)) == NULL)
  {
    MFree(methStr);
    Warning("OSCslot: %s", MError_Memory);
    MInitError;
    return;
  }
}

/* ===================================================================
 * OSCslotr
 */
void osc_slotr_set(void *entry)
{
  OSCSLOTR
    *p = (OSCSLOTR *)entry;
  OSCcontainer
    insCont;
  char
    *insStr, 
    *tagStr, 
    *methStr;
  MYFLT
    insTag = *p->_instag;
  
  if (!MOscIsUp ||
      ((insCont = OSCGetChildContainer(globals->oscRoot, MSlot_InsContStr, 1)) == NULL))
  {
    initerror("OSCslotr: OSC has not been initialized");
    goto error;
  }
    
  if ((methStr = GetStrarg(p->_meth, MSlot_MaxMethSize, p->STRARG)) == NULL)
  {
    Warning("OSCslotr: %s", MError_Memory);
    MInitError;
    goto error;
  }

  if (insTag <= 0)
  {
    insTag = p->h.insdshead->p1;
  }
    
  if ((insStr = IntToString(abs(insTag))) == NULL)
  {
    Warning("OSCslotr: %s", MError_Memory);
    MInitError;
    goto error;
  }

  if ((tagStr = ParseFloatTag(insTag, MSlot_InsTagWidth + 1)) == NULL)
  {
    Warning("OSCslotr: %s", MError_Memory); 
    MInitError;
    goto error;
  }

  p->context = GetControlContext(insCont, insStr, tagStr, methStr);

  if (p->context == NULL)
  {
    Warning("OSCslotr: no such address: /instruments/%s/%s/%s",
	    insStr, tagStr, methStr);
    MInitError;
    goto error;
  }

  *p->_result = p->context->value;

 error:
  MFree(methStr);
  MFree(insStr);
  MFree(tagStr);
}

void osc_slotr(void *entry)
{
  OSCSLOTR *p = (OSCSLOTR *)entry;

  MAssert(p->context != NULL);

  *p->_result = p->context->value;
}

/* ===================================================================
 * OSCslotw
 */
void osc_slotw_set(void *entry)
{
  OSCSLOTW
    *p = (OSCSLOTW *)entry;
  char
    *insStr, 
    *tagStr, 
    *methStr;
  MYFLT
    insTag = *p->_instag;

  if (!MOscIsUp)
  {
    initerror("OSCslotw: OSC has not been initialized");
    goto error;
  }

  if ((methStr = GetStrarg(p->_meth, MSlot_MaxMethSize, p->STRARG)) == NULL)
  {
    Warning("OSCslotw: %s", MError_Memory);
    MInitError;
    goto error;
  }

  if ((insStr = IntToString(abs((int)insTag))) == NULL)
  {
    Warning("OSCslotw: %s", MError_Memory);
    MInitError;
    goto error;
  }

  if (insTag <= 0)
  {
    /* negative instag: address all instances */
    if ((tagStr = (char *)MMalloc(2)) == NULL)
    {
      Warning("OSCslotw: %s", MError_Memory);
      MInitError;
      goto error;
    } 
    strcpy(tagStr, "*");
  }
  else
  {
    if ((tagStr = ParseFloatTag(insTag, MSlot_InsTagWidth + 1)) == NULL)
    {
      Warning("OSCslotw: %s", MError_Memory);
      MInitError;
      goto error;
    }
  }

  sprintf(p->address, "/instruments/%s/%s/%s", insStr, tagStr, methStr);
  OSC_initBuffer(&p->buf, MSlot_MaxBufSize, p->byteArr);

 error:
  MFree(insStr);
  MFree(tagStr);
  MFree(methStr);
}

void osc_slotw(void *entry)
{
  OSCSLOTW
    *p = (OSCSLOTW *)entry;
  OSCPacketBuffer 
    pBuf;
  OSCbuf	
    *buf = &p->buf;
  int
    bufLen,
    *sizep;
    
  /* OSCSendInternalMessage does not do any byte conversions! */

  /*    float		argv[3]; */
  /*    argv[0] = *p->_min; */
  /*    argv[1] = *p->_max; */
  /*    argv[2] = *p->_arg; */
  /*    if (!OSCSendInternalMessage(p->address, sizeof(float)*3, argv)) */
  /*    { */
  /*      Warning("OSCslotw: no such address: %s", p->address); */
  /*      MInitError; */
  /*      return; */
  /*    } */

  if (!(pBuf = OSCAllocPacketBuffer()))
  {
    Warning("OSCslotw: Out of memory for packet buffers - had to drop a packet!");
    return;
  }

  OSC_resetBuffer(buf);
  OSC_writeAddress(buf, p->address);
  OSC_writeFloatArg(buf, (float)*p->_min);
  OSC_writeFloatArg(buf, (float)*p->_max);
  OSC_writeFloatArg(buf, (float)*p->_arg);

  if ((bufLen = OSC_packetSize(buf)) > OSCGetReceiveBufferSize())
  {
    Warning("OSCslotw: shouldn't happen: packet size > receive buffer size");
    OSCFreePacket(pBuf);
    return;
  }

  memcpy(OSCPacketBufferGetBuffer(pBuf), OSC_getPacket(buf), bufLen);

  sizep = OSCPacketBufferGetSize(pBuf);
  *sizep = bufLen;
  OSCAcceptPacket(pBuf);
}


/* ===================================================================
 * OSCpeer
 */
void osc_peer(void *entry)
{
  OSCPEER
    *p = (OSCPEER *)entry;
  char
    *hostName;
  int
    port = abs(*p->_port),
    id = abs(*p->_id), 
    maxId = MSend_MaxNumPeers;

  OSC_UDPSocket sock;
  OSC_UDPAddress addr;
  
  if (!MOscIsUp)
  {
    initerror("OSCpeer: OSC has not been initialized");
    return;
  }

  if ((id < 0) || (id > maxId))
  {
    Warning("OSCpeer: id requested is invalid, can only address [1,%d]", maxId);
    MInitError;
    return;
  }

  if ((hostName = GetStrarg(p->_host, MSend_MaxHostLen, p->STRARG)) == NULL)
  {
    Warning("OSCpeer: %s", MError_Memory);
    MInitError;
    goto error;
  }

  if ((addr = OSC_UDPAddress_New(hostName, port)) == NULL)
  {
    Warning("OSCpeer: %s, or socket error:", MError_Memory);
    MPerror("OSCpeer");
    MInitError;
    goto error;
  }

  if ((sock = OSC_UDPSocket_ClientNew(FALSE)) == NULL)
  {
    Warning("OSCpeer: %s", MError_Memory);
    MInitError;
    goto error;
  }
  
  if (OSC_UDPSocket_Connect(sock, addr) == SOCKET_ERROR)
  {
    OSC_UDPSocket_Delete(sock);
    MPerror("OSCpeer");
    MInitError;
    goto error;
  }

  if (globals->peers[id-1] != NULL)
  {
    OSC_UDPSocket_Delete(globals->peers[id]);
  }

  globals->peers[id-1] = sock;

 error:
  MFree(hostName);
  OSC_UDPAddress_Delete(addr);
}

/* ===================================================================
 * OSCsend
 */
void osc_send_set(void *entry)
{
  OSCSEND
    *p = (OSCSEND *)entry;
  int
    id = abs(*p->_id), 
    maxId = MSend_MaxNumPeers;
  char
    *addr;

  if (!MOscIsUp)
  {
    Warning("OSCsend: %s", MError_Initialized);
    MInitError;
    return;
  }

  if ((id < 1) || (id > maxId))
  {
    Warning("OSCsend: id requested is invalid, can only address [1,%d]", maxId);
    MInitError;
    return;
  }

  if (globals->peers[id-1] == NULL)
  {
    Warning("OSCsend: no peer with id %d", id);
    MInitError;
    return;
  }
  
  if ((addr = GetStrarg(p->_addr, MSend_MaxAddrLen, p->STRARG)) == NULL)
  {
    Warning("OSCsend: %s", MError_Memory);
    MInitError;
    return;
  }

  strcpy(p->address, addr);
  MFree(addr);
  OSC_initBuffer(&p->buf, MSend_MaxBufSize, p->byteArr);
  p->sock = globals->peers[id-1];
}

void osc_send(void *entry)
{
  OSCSEND
    *p = (OSCSEND *)entry;
  OSCbuf
    *buf = &p->buf;

  OSC_resetBuffer(buf);
  OSC_openBundle(buf, CurrentTime());
  OSC_writeAddress(buf, p->address);
  OSC_writeFloatArg(buf, (float)*p->_arg);
  OSC_closeBundle(buf);

  /* Socket is connected, so we can omit the address */
  OSC_UDPSocket_Send(p->sock, NULL, buf);
}

/* EOF */
