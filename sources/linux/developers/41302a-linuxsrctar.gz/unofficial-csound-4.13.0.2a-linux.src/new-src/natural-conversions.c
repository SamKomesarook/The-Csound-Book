/*
 * $Id: natural-conversions.c,v 1.1 1999/06/23 11:53:17 nicb Exp $
 *
 * In the canonical code, these functions are repeated over and over
 * all over the place; this created linking conflicts in the dynamic
 * version, so we place them in a single place and call them from here
 * [nicb@axnet.it, 22/06/1999]
 */

short natshort(short sval)/* coerce a bigendian short into a natural short */
{
    unsigned char benchar[2];
    short natshort;

    *(short *)benchar = sval;
    natshort = benchar[0];
    natshort <<= 8;
    natshort |= benchar[1];
    return(natshort);
}

long natlong(long lval) /* coerce a bigendian long into a natural long */
{
    unsigned char benchar[4];
    unsigned char *p = benchar;
    long natlong;

    *(long *)benchar = lval;
    natlong = *p++;
    natlong <<= 8;
    natlong |= *p++;
    natlong <<= 8;
    natlong |= *p++;
    natlong <<= 8;
    natlong |= *p;
    return(natlong);
}
