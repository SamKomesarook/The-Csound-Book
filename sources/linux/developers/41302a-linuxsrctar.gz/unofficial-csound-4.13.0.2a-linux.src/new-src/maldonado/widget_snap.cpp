#include "widg.h"

vector<ADDR_SET_VALUE> AddrSetValue; //addresses of valuators 
vector<SNAPSHOT> snapshots; 

extern "C" void set_snap(FLSETSNAP *p)
{
	SNAPSHOT snap(AddrSetValue);
	int numfields = snap.fields.size();
	int index = (int) *p->index;
	*p->inum_snap = snapshots.size();
	*p->inum_val = numfields; // number of snapshots
	
	if (*p->ifn >= 1) { // if the table number is valid
		FUNC	*ftp;   // store the snapshot into the table
		if ((ftp = ftfind(p->ifn)) != NULL) {
			MYFLT * table = ftp->ftable;
			for( int j=0; j < numfields; j++) {
				table[index*numfields+j] = snap.fields[j].value;
			}
		}
		else initerror("FLsetsnap: invalid table");
	}
	else { // else store it into snapshot bank
		if (snapshots.size() < index+1)
			snapshots.resize(index+1);
		snapshots[index]=snap;
	}
}	



extern "C" void get_snap(FLGETSNAP *p)
{
	int index = *p->index;
	if (!snapshots.empty()) {
		if (index > snapshots.size()) index = snapshots.size();
		else if (index < 0 ) index=0;
		snapshots[index].get(AddrSetValue);
	}
	*p->inum_el = snapshots.size();
}	




extern "C" void save_snap(FLSAVESNAPS* p)
{
	char* filename = GetString(*p->filename,p->STRARG);
	fstream file(filename, ios::out);
	for (int j =0; j < snapshots.size(); j++) {
		file << "----------- "<< j << " -----------\n";
		for ( int k =0; k < snapshots[j].fields.size(); k++) {
			VALUATOR_FIELD& f = snapshots[j].fields[k];
			if (f.opcode_name == "FLjoy") {
				file <<f.opcode_name<<" "<< f.value <<" "<< f.value2
					<<" "<< f.min <<" "<< f.max <<" "<< f.min2 <<" "<< f.max2<<" "<<f.exp<<" "<<f.exp2<<" \"" <<f.widg_name<<"\"\n";
			}
			else {
				file <<f.opcode_name<<" "<< f.value 
					<<" "<< f.min <<" "<< f.max <<" "<<f.exp<<" \"" <<f.widg_name<<"\"\n";
			}
		}
	}
	file << "---------------------------";
	file.close();
}

	
extern "C" void load_snap(FLLOADSNAPS* p)
{
	char* filename = GetString(*p->filename,p->STRARG);
	fstream file(filename, ios::in);
	int j=0,k=-1;
	char s[500];
	while (!(file.eof())) {
		//; 
		file.getline(s,500);
		string opc, opc_orig;
		char *ss = s, *opc_temp,/* *opc_orig,  */ *val, *val2, *min, *max, *min2, *max2, *exp, *exp2, *widg_name;
		if (*ss == '-'){ // if it is a separation line
			k++; j=0; 
			if (snapshots.size() < k+1)
			snapshots.resize(k+1);
		
		}
		else if (*ss != '\0' && *ss != ' ') { //ignore blank lines
			ADDR_SET_VALUE& v = AddrSetValue[j];
			if (snapshots[k].fields.size() < j+1)
				snapshots[k].fields.resize(j+1);
			snapshots[k].is_empty = 0;
			VALUATOR_FIELD& fld = snapshots[k].fields[j];
			opc_temp = ss; while(*ss != ' ') ss++; *ss++ = '\0';
			opc = opc_temp;
			opc_orig = ((OPDS *) (v.opcode))->optext->t.opcod;
			if (!(opc_orig == opc))
				initerror("unmatched widget, probably due to a modified orchestra");

			val = ss; while(*ss != ' ') ss++; *ss++ = '\0';
		
			if(opc == "FLjoy") {
				val2=ss; while(*ss != ' ') ss++; *ss++ = '\0';
				fld.value2 = atof(val2);

			}
			min = ss; while(*ss != ' ') ss++;	*ss++ = '\0';
			max = ss; while(*ss != ' ') ss++;	*ss++ = '\0';

			if(opc == "FLjoy") {
				min2 = ss; while(*ss != ' ') ss++;	*ss++ = '\0';
				max2 = ss; while(*ss != ' ') ss++;	*ss++ = '\0';
				fld.min2 = atof(min2);
				fld.max2 = atof(max2);
			}
			exp = ss; while(*ss != ' ') ss++;	*ss++ = '\0';

			if(opc == "FLjoy") {
				exp2 = ss; while(*ss != ' ') ss++;	*ss++ = '\0';
				fld.exp2 = atoi(exp2);
			}
			widg_name = ++ss; 
				while(*ss != '\"') 
					ss++;	
				*ss++ = '\0';
			
			fld.exp = atoi(exp);
			fld.value = atof(val);
			fld.min = atof(min);
			fld.max = atof(max);
			fld.exp = atoi(exp);
			fld.widg_name= widg_name;
			fld.opcode_name= opc;
			j++;
		}
		
	}
	file.close();

}


