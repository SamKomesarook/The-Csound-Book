#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#if defined (_WIN32)
#	pragma warning(disable:4786 4117 4804)
#	include <process.h>
#endif /* defined(_WIN32) */

#if defined(LINUX)
#	include <pthread.h>
#	include "../config.h"
#endif /* defined(LINUX) */

#include <FL/Fl.H>
#include <FL/Fl_Window.H>
#include <FL/Fl_Box.H>
#include <FL/Fl_Slider.H>
#include <FL/Fl_Value_Slider.H>
#include <FL/Fl_Adjuster.H>
#include <FL/Fl_Counter.H>
#include <FL/Fl_Dial.H>
#include <FL/Fl_Roller.H>
#include <FL/Fl_Value_Input.H>
#include <FL/Fl_Value_Output.H>
#include <FL/Fl_Scrollbar.H>
#include <FL/Fl_Scrollbar.H>
#include <FL/fl_draw.H>
#include <FL/Fl_Output.H>
#include <FL/Fl_Scroll.H>
#include <FL/Fl_Pack.H>
#include <FL/Fl_Tabs.H>
#include <FL/Fl_Positioner.H>
#include <FL/Fl_Button.H>
#include <FL/Fl_Light_Button.H>
#include <FL/Fl_Check_Button.H>
#include <FL/Fl_Round_Button.H>
#include <FL/Fl_Image.H>
#include "FL/Fl_Knob.H"
#include "FL/Fl_flews.H"

#include <vector>
#include <map>
#include <string>
#include <fstream.h>

#if defined(HAVE_PAINTLIB)
#include "stdpch.h"
#include "anydec.h"
#include "anybmp.h"
#endif /* defined(HAVE_PAINTLIB) */
using namespace std ;

#define LIN_ 0
#define EXP_ -1
#undef min
#undef max


extern "C" {
	#undef __cplusplus
	#include "cs.h"
	#include "widgets.h"
	#include "oload.h"
	#define __cplusplus
    extern EVTBLK *currevent; 
	extern char *unquote(char *name);
}
#undef exit

struct PANELS {
	Fl_Window *panel;
	int	is_subwindow;
	PANELS(Fl_Window *new_panel, int flag) : panel(new_panel), is_subwindow(flag){}
	PANELS() {panel = NULL; is_subwindow=0;	}
};

struct ADDR {
	void *opcode;
	void *WidgAddress;
};

struct ADDR_STACK /*: ADDR*/{
	OPDS *h;
	void *WidgAddress;
	int	count;
	ADDR_STACK(OPDS *new_h,void *new_address,  int new_count) : h(new_h),WidgAddress(new_address), count(new_count) {}
	ADDR_STACK() { h=NULL; WidgAddress = NULL;	count=0; }
};

struct ADDR_SET_VALUE /*: ADDR*/{
	int exponential;
	MYFLT min,max;
	void  *WidgAddress,  *opcode;
	ADDR_SET_VALUE(int new_exponential,MYFLT new_min, MYFLT new_max, void *new_WidgAddress, void *new_opcode) :
		exponential(new_exponential),min(new_min), max(new_max),WidgAddress(new_WidgAddress),opcode(new_opcode)	{}
	ADDR_SET_VALUE() { exponential=LIN_; min=0; max=0; WidgAddress=NULL; opcode=NULL; }
};

struct VALUATOR_FIELD {
	MYFLT value, value2;
	MYFLT min,max, min2,max2;
	int	exp, exp2;
	string widg_name;
	string opcode_name;
	VALUATOR_FIELD() {  value = 0; value2 =0; widg_name= ""; opcode_name =""; 
		min = 0; max =1; min2=0; max2=1; exp=LIN_; exp2=LIN_;}
};



struct SNAPSHOT {
	int is_empty;
	vector<VALUATOR_FIELD> fields;
	SNAPSHOT(vector<ADDR_SET_VALUE>& valuators);
	SNAPSHOT() { is_empty = 1; }
	void get(vector<ADDR_SET_VALUE>& valuators);
};


class overlay_BOX : public Fl_Box{
//	int /* rx,ry,rw,rh, */ oldx,oldy;
public:
	//FL_EXPORT void draw(); 
	FL_EXPORT overlay_BOX(int x, int y, int w, int h, const char *l=0) : Fl_Box(x,y,w,h,l) 
	{
		fl_overlay_rect(0,0,0,0);
//		oldx=0;
//		oldy=0;
	}
	FL_EXPORT ~overlay_BOX() 
	{
		fl_overlay_rect(0,0,0,0);	
	}

	FL_EXPORT void	set_rect(int newrx, int newry, int newrw, int newrh) {
		fl_overlay_rect(newrx+x(),newry+y(),newrw,newrh);
		
	}
};

char * GetString(MYFLT pname, char *t);
Fl_Window * FLkeyboard_init();
int FLkeyboard_sensing();

extern "C" void ButtonSched(MYFLT  *args[], int numargs);
extern "C" void deact(INSDS *ip);
