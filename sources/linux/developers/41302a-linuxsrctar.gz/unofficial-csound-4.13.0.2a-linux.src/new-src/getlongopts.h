#include <getopt.h>

void    aiff_opt(char *arg);
void    alaw_opt(char *arg);
void    ascii_opt(char *arg);
void    bogus_opt(char *arg);
void    chars_opt(char *arg);
void    cscoresco_opt(char *arg);
void    defergen01_opt(char *arg);
#if defined(ESDRTAUDIO)
void	esd_host_opt(char *arg);
#endif /* defined(ESDRTAUDIO) */
void    extract_opt(char *arg);
void    floats_opt(char *arg);
void    hardbuffer_opt(char *arg);
void    heartbeat_opt(char *arg);
void    help_opt(char *arg);
void    incard_opt(char *arg);
void    infile_opt(char *arg);
void    ircam_opt(char *arg);
void    itimerun_opt(char *arg);
void    krate_opt(char *arg);
void    lineeventdev_opt(char *arg);
void    longs_opt(char *arg);
void    message_opt(char *arg);
void    midieventdev_opt(char *arg);
void    midifile_opt(char *arg);
void    midihardware_opt(char *arg);
void    midiport_opt(char *arg);
void    midisustain_opt(char *arg);
void    nodiskoutput_opt(char *arg);
void    nodisplay_opt(char *arg);
void    postscript_opt(char *arg);
void    noheader_opt(char *arg);
void    notify_opt(char *arg);
void    opcodes_opt(char *arg);
#ifdef OSSRTAUDIO
void    oss_in_opt (char *arg);
void    oss_out_opt(char *arg);
#endif
void    outcard_opt(char *arg);
void    outfile_opt(char *arg);
void    rewrite_opt(char *arg);
void    sched_opt(char *arg);
void    shorts_opt(char *arg);
void    softbuffer_opt(char *arg);
void    srate_opt(char *arg);
void    tempo_opt(char *arg);
void    terminate_opt(char *arg);
void    uchars_opt(char *arg);
void    ulaw_opt(char *arg);
void    utility_opt(char *arg);
void    verbose_opt(char *arg);
void    volume_opt(char *arg);
void    wav_opt(char *arg);
void    dither_opt(char *arg);

void	do_opts_help(const char *exit_string, ...);

typedef struct Csound_Options {
        struct option opt;      /* See getopt.h */
        char *arg;              /* Example argument "<num>", "<filename>", etc. */
        char *help;             /* Option description */
	void (*func)(char *);	/* Function to act on option */
} Csound_Options;
