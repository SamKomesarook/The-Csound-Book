#include "cs.h"			/*			ENTRY.C		*/
#include "insert.h"
#include "clarinet.h"
#include "flute.h"
#include "bowed.h"
#include "bowedbar.h"
#include "marimba.h"
#include "brass.h"
#include "vibraphn.h"
#include "shaker.h"
#include "phisem.h"
#include "fm4op.h"
#include "moog1.h"
#include "singwave.h"
#include "mandolin.h"

#include "dcblockr.h"
#include "flanger.h"
#include "lowpassr.h"
#if defined(CWIN) || defined(TCLTK)
#include "control.h"
#endif
#include "schedule.h"
#include "cwindow.h"
#include "spectra.h"
#include "pitch.h"
#include "scansyn.h"
#include "vbap.h"
#include "uggab.h"
#include "repluck.h"
#include "aops.h"
#include "ugens1.h"
#include "nlfilt.h"
#include "fhtfun.h"
#include "vdelay.h"
#include "ugens2.h"

#if defined(GAB_RT)
#include "ugens3.h"
#include "fof3.h"	/* Gabriel Maldonado (gab-A1)*/
#include "physGab.h"	/* Gabriel Maldonado (gab-A1)*/
#include "foscili2.h"	/* Gabriel Maldonado (gab-A3)*/
#include "InstrCall.h"	/* Gabriel Maldonado (gab-A5)*/
#include "fractals.h"
#include "vibrato.h"
#endif /* defined(GAB_RT) */

#include "babo.h"
#include "ugmoss.h"
/* __OSC__ */
#if defined(ENABLE_OSC)
#	include "new-src/OSC-sock.h"   /* Steve Kersten */
#endif /* defined(ENABLE_OSC) */
  
#define S	sizeof

#if defined(CWIN) || defined(TCLTK)
void	cntrl_set(void*), control(void*), ocontrol(void*);
void	button_set(void*), button(void*), check_set(void*), check(void*);
void	textflash(void*);
#endif
void	varicolset(void*), varicol(void*);
void	pinkset(void*), pinkish(void*), inh(void*), ino(void*), in16(void*);
void	in32(void*), inall(void*), zaset(void*), inz(void*), outh(void*);
void	outo(void*), outx(void*), outX(void*), outch(void*), outall(void*);
void	zaset(void*), outz(void*), cpsxpch(void*), cps2pch(void*);
void	nlfiltset(void*), nlfilt(void*), Xsynthset(void*), Xsynth(void*);
void	wgpsetin(void*), wgpluck(void*), wgpset(void*), wgpluck(void*);
void	clarinset(void*), clarin(void*), fluteset(void*), flute(void*);
void	bowedset(void*), bowed(void*), bowedbarset(void*), bowedbar(void*);
void	brassset(void*), brass(void*), marimbaset(void*), marimba(void*);
void	vibraphnset(void*), vibraphn(void*), agogobelset(void*), agogobel(void*);
void	shakerset(void*), shaker(void*), cabasaset(void*), cabasa(void*);
void	crunchset(void*), cabasa(void*), sekereset(void*), sekere(void*);
void	sandset(void*), sekere(void*), stixset(void*), sekere(void*);
void	guiroset(void*), guiro(void*), tambourset(void*), tambourine(void*);
void	bambooset(void*), bamboo(void*), wuterset(void*), wuter(void*);
void	sleighset(void*), sleighbells(void*), tubebellset(void*), tubebell(void*);
void	rhodeset(void*), tubebell(void*), wurleyset(void*), wurley(void*);
void	heavymetset(void*), heavymet(void*), b3set(void*), hammondB3(void*);
void	FMVoiceset(void*), FMVoice(void*), percfluteset(void*), percflute(void*);
void	Moog1set(void*), Moog1(void*), voicformset(void*), voicform(void*);
void	mandolinset(void*), mandolin(void*), dcblockrset(void*), dcblockr(void*);
void	flanger_set(void*), flanger(void*), sum(void*), product(void*);
void	macset(void*), maca(void*), macset(void*), mac(void*), instcount(void*);
void	adsrset(void*), klnseg(void*), linseg(void*), madsrset(void*);
void	klnsegr(void*), linsegr(void*), xdsrset(void*), kxpseg(void*);
void	expseg(void*), mxdsrset(void*), kxpsegr(void*), expsegr(void*);
void	schedule(void*), schedwatch(void*), ifschedule(void*), kschedule(void*);
void	triginset(void*), ktriginstr(void*), trigseq_set(void*), trigseq(void*);
void	seqtim_set(void*), seqtim(void*), lfoset(void*), lfok(void*);
void	lfoa(void*), stresonset(void*), streson(void*), pitchset(void*);
void	pitch(void*), clockset(void*), clockon(void*), clockset(void*);
void	clockoff(void*), clockread(void*), impulse_set(void*), impulse(void*);
void	pitchamdfset(void*), pitchamdf(void*), scsnu_init(void*);
void	scsnu_play(void*);
void	scsns_init(void*), scsns_play(void*), clip_set(void*), clip(void*);
void	vbap_FOUR_init(void*), vbap_FOUR (void*), vbap_EIGHT_init(void*);
void	vbap_EIGHT(void*), vbap_SIXTEEN_init(void*), vbap_SIXTEEN(void*);
void	vbap_zak_init(void*), vbap_zak(void*), vbap_ls_init(void*);
void	vbap_FOUR_moving_init(void*), vbap_FOUR_moving(void*);
void	vbap_EIGHT_moving_init(void*), vbap_EIGHT_moving(void*);
void	vbap_SIXTEEN_moving_init(void*), vbap_SIXTEEN_moving(void*);
void	vbap_zak_moving_init(void*), vbap_zak_moving(void*), ksense(void*);
void	reverbx_set(void*), reverbx(void*);
void	Foscset(void*), Fosckk(void*);
void	trnset(void*), ktrnseg(void*), trnseg(void*);
void	lpf18set(void*), lpf18db(void*);
void	wavesetset(void*), waveset(void*);
void    dconvset(void *), dconv(void *);
void	pfun(void*);

#if defined(GAB_RT)
void ftlen2(void*);
void icall(void *),dicall_set(void *),dicall(void *),micall_set(void *);
void micall(void *), dmicall_set(void *),dmicall(void *);
void fofset3(void*), fof3(void*);
void foscset2(void *),foscili2(void *);
void loscil2(void*), losset2(void*);
void posc_set(void *), posc(void *), kposc(void *);
void lposc_set(void *), lposc(void *), lposcint(void *);
void lowpr(void *), lowpr_set(void *), lowpr_setx(void *), lowprx(void *);
void lowpr_w_sep_set(void *), lowpr_w_sep(void *);
void phys1(void *), phys1set(void *),phys2(void *), phys2set(void *);
void    ipowoftwo(void *), ilogbasetwo(void *);
void    powoftwo_set(void *), logbasetwo_set(void *), powoftwoa(void *);
void    powoftwo(void *), powoftwoa(void *);
void	logbasetwo(void *), logbasetwoa(void *);

void mtab_set(void*), mtab_k(void*), mtab_set(void*),  mtab_a(void*),  mtabw_i(void*);
void mtab_i (void*), mtabw_set(void*), mtabw_k(void*),  mtabw_a(void*),trigcall(void*) ;
void dashow (void*);
void poscils_set(void*), kposcils(void*), poscilsa(void*);
void test_set(void*), test(void*);
void schedk(void*);
void lineto_set(void*), lineto(void*), tlineto_set(void*),tlineto(void*);
void bmopen(void*), bmtable_set(void*), bmtable(void*), bmtablei(void*);
void bmoscil_set(void*), bmoscil(void*), bmoscili(void*), rgb2hsvl(void*);
void metro_set(void*), metro(void*),  bmscan_set(void*),   bmscan(void*), bmscani(void*) ;
void mandel_set(void*), mandel(void*),cpstun(void*),cpstun_i(void*);
void vectorOp_set(void*), vadd(void*), vmult(void*), vpow(void*), vexp(void*);
void vectorOp_set(void*),vadd(void*),vmult(void*),vpow(void*),vexp(void*);
void vectorsOp_set(void*),vcopy(void*),vaddv(void*),vsubv(void*),vmultv(void*),vdivv(void*),vpowv(void*),vexpv(void*);
void vlimit_set(void*),vlimit(void*),vwrap(void*),vmirror(void*);
void vseg_set(void*), vlinseg(void*), vexpseg(void*); 
void vrandh_set(void*), vrandh(void*), vrandi_set(void*), vrandi(void*);
void ca_set(void*),  ca(void*), vport_set(void*),  vport(void*) ;
void kdel_set(void*),  kdelay(void*),vecdly_set(void*),  vecdly(void*), vmap(void*);
void seqtim2_set(void*), seqtim2(void*), adsynt2_set(void*), adsynt2(void*) ;
#endif /* defined(GAB_RT) */

/* thread vals, where isub=1, ksub=2, asub=4:
		0 =	1  OR	2  (B out only)
		1 =	1
		2 =		2
		3 =	1  AND	2
		4 =			4
		5 =	1  AND		4
		7 =	1  AND (2  OR	4)			*/

/* inarg types include the following:
		m	begins an indef list of iargs (any count)
		n	begins an indef list of iargs (nargs odd)
		o	optional, defaulting to 0
		p	   "		"	1
		q	   "		"	10
		v	   "		"	.5
		j	   "		"	-1
		h	   "		"	127
                y       begins indef list of aargs (any count)
                z       begins indef list of kargs (any count)
                Z       begins alternating kakaka...list (any count)
   outarg types include:
		m	multiple outargs (1 to 4 allowed)
   (these types must agree with rdorch.c)			*/

/* If dsblksize is 0xffff then translate */
/*                 0xfffe then translate two (oscil) */
/*                 0xfffd then translate two (peak) */
/*                 0xfffc then translate two (divz) */

OENTRY opcodlst_2[] = {
/* opcode   dspace	thread	outarg	inargs	isub	ksub	asub	*/
{ "pinkish", S(PINKISH),  5,    "a",    "xoooo", pinkset, NULL, pinkish },
{ "noise",  S(VARI),   5,	"a",	"xk",	varicolset, NULL, varicol },
{ "inh",    S(INQ),	4,	"aaaaaa","",	NULL,	NULL,	inh	},
{ "ino",    S(INQ),	4,	"aaaaaaaa","",	NULL,	NULL,	ino	},
{ "inx",    S(INALL),	4,	"aaaaaaaaaaaaaaaa","",	NULL,	NULL,	in16 },
{ "in32",   S(INALL),	4,	"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
					"",	NULL,	NULL,	in32 },
{ "inch",   S(INALL),	4,	"a",	"k",	NULL,	NULL,	inall	},
{ "inz",    S(IOZ),	4,	"",	"k",	zaset,	NULL,	inz	},
  /* Note that there is code in rdorch.c that assumes that opcodes starting
     with the charcters out followed by a s, q, h, o or x are in this group
     ***BEWARE***
   */
{ "outh",   S(OUTH),	4,	"",	"aaaaaa",NULL,	NULL,	outh	},
{ "outo",   S(OUTO),	4,	"",	"aaaaaaaa",NULL,NULL,	outo	},
{ "outx",   S(OUTX),	4,	"",	"aaaaaaaaaaaaaaaa",NULL,NULL, outx },
{ "out32",  S(OUTX),	4,	"",	"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
    						NULL,	NULL,	outX	},
{ "outch",  S(OUTCH),	4,	"",	"Z",	NULL,	NULL,	outch	},
{ "outc",   S(OUTX),	4,	"",	"y",	NULL,	NULL,	outall	},
{ "outz",   S(IOZ),	4,	"",	"k",	zaset,	NULL,	outz	},
{ "cpsxpch",  S(XENH),  1,      "i",    "iiii",	cpsxpch, NULL,  NULL },
{ "cps2pch",  S(XENH),  1,      "i",    "ii",	cps2pch, NULL,  NULL },
{ "nlfilt",   S(NLFILT),5,     "a",	"akkkkk",nlfiltset, NULL, nlfilt},
{ "cross2",   S(CON),	5,     "a",	"aaiiik",Xsynthset, NULL, Xsynth},
{ "repluck", S(WGPLUCK2), 5,    "a",    "ikikka",wgpsetin,   NULL,     wgpluck},
{ "wgpluck2",S(WGPLUCK2), 5,    "a",    "ikikk", wgpset,     NULL,     wgpluck},
{ "wgclar",  S(CLARIN),  5,     "a",    "kkkiikkkio",clarinset,NULL,   clarin},
{ "wgflute", S(FLUTE),   5,     "a",    "kkkiikkkiovv",fluteset,NULL,  flute },
{ "wgbow",   S(BOWED),   5,     "a",    "kkkkkkio", bowedset, NULL,    bowed },
{ "wgbowedbar", S(BOWEDBAR), 5, "a",    "kkkkkoooo", bowedbarset, NULL, bowedbar },
{ "wgbrass", S(BRASS),   5,     "a",    "kkkikkio", brassset, NULL,     brass},
{ "marimba", S(MARIMBA), 5,     "a",    "kkiiikkiioo", marimbaset, NULL, marimba},
{ "vibes", S(VIBRAPHN),  5,     "a",    "kkiiikkii", vibraphnset,NULL,vibraphn},
{ "gogobel",S(VIBRAPHN), 5,     "a",    "kkiiikki", agogobelset,NULL, agogobel},
{ "shaker",  S(SHAKER),  5,     "a",    "kkkkko",  shakerset, NULL,   shaker},
{ "cabasa",  S(CABASA),  5,     "a",    "iiooo",    cabasaset, NULL,   cabasa},
{ "crunch",  S(CABASA),  5,     "a",    "iiooo",    crunchset, NULL,   cabasa},
{ "sekere",  S(SEKERE),  5,     "a",    "iiooo",    sekereset, NULL,   sekere},
{ "sandpaper", S(SEKERE),5,     "a",    "iiooo",    sandset, NULL,   sekere},
{ "stix", S(SEKERE),     5,     "a",    "iiooo",    stixset, NULL,   sekere},
{ "guiro", S(GUIRO),     5,     "a",    "kiooooo",   guiroset, NULL, guiro},
{ "tambourine", S(TAMBOURINE),5,"a",    "kioooooo", tambourset, NULL, tambourine},
{ "bamboo", S(BAMBOO),   5,     "a",    "kioooooo", bambooset, NULL, bamboo },
{ "dripwater", S(WUTER), 5,     "a",    "kioooooo", wuterset, NULL, wuter },
{ "sleighbells", S(SLEIGHBELLS), 5, "a","kioooooo", sleighset, NULL, sleighbells },
{ "fmbell",  S(FM4OP),   5,     "a",    "kkkkkkiiiii",tubebellset,NULL,tubebell},
{ "fmrhode", S(FM4OP),   5,     "a",    "kkkkkkiiiii",rhodeset,NULL,  tubebell},
{ "fmwurlie", S(FM4OP),  5,     "a",    "kkkkkkiiiii",wurleyset, NULL, wurley},
{ "fmmetal", S(FM4OP),   5,     "a",    "kkkkkkiiiii",heavymetset, NULL, heavymet},
{ "fmb3", S(FM4OP),      5,     "a",    "kkkkkkiiiii", b3set, NULL, hammondB3},
{ "fmvoice", S(FM4OPV),  5,     "a",    "kkkkkkiiiii",FMVoiceset, NULL, FMVoice},
{ "fmpercfl", S(FM4OP),  5,     "a",    "kkkkkkiiiii",percfluteset, NULL, percflute},
{ "moog", S(MOOG1),      5,     "a",    "kkkkkkiii", Moog1set, NULL, Moog1  },
{ "voice", S(VOICF),	 5,     "a",    "kkkkkkii", voicformset, NULL, voicform},
{ "mandol", S(MANDOL),	 5,     "a",    "kkkkkkio", mandolinset, NULL, mandolin},
{ "dcblock", S(DCBlocker),5,    "a",    "ao",   dcblockrset, NULL, dcblockr},
{ "flanger", S(FLANGER), 5,     "a",    "aakv", flanger_set, NULL, flanger },
{ "sum", S(SUM),         4,     "a",    "y",    NULL, NULL, sum            },
{ "product", S(SUM),     4,     "a",    "y",    NULL, NULL, product        },
{ "maca", S(SUM),        5,     "a",    "y",	macset,      NULL, maca    },
{ "mac", S(SUM),         5,     "a",    "Z",	macset,      NULL, mac     },
{ "active", S(INSTCNT),  1,     "i",    "i",    instcount, NULL, NULL      },
#if defined(CWIN) || defined(TCLTK)
{ "control", S(CNTRL),   3,     "k",    "k",    cntrl_set, control, NULL   },
{ "setctrl", S(SCNTRL),  1,     "",     "iSi",  ocontrol, NULL, NULL   },
{ "button", S(CNTRL),    3,     "k",    "k",    button_set, button, NULL   },
{ "checkbox", S(CNTRL),  3,     "k",    "k",    check_set, check,   NULL   },
{ "flashtxt", S(TXTWIN), 1,     "",     "iS",   textflash, NULL,    NULL   },
#endif
{ "adsr", S(LINSEG),     7,	"s",	"iiiio",adsrset,klnseg, linseg     },
{ "madsr", S(LINSEG),    7,	"s",	"iiiioj", madsrset,klnsegr, linsegr },
{ "xadsr", S(EXXPSEG),   7,	"s",	"iiiio", xdsrset, kxpseg, expseg    },
{ "mxadsr", S(EXPSEG),   7,	"s",	"iiiioj", mxdsrset, kxpsegr, expsegr },
{ "transeg", S(TRANSEG), 7,	"s",	"iiim", trnset, ktrnseg,    trnseg },
{ "schedule", S(SCHED),  1,     "",     "iiim", schedule, schedwatch, NULL },
{ "schedwhen", S(WSCHED),3,     "",     "kkkkm",ifschedule, kschedule, NULL },
{ "schedkwhen", S(TRIGINSTR), 3,"",     "kkkkkz",triginset, ktriginstr, NULL },
{ "trigseq", S(TRIGSEQ), 3,     "",     "kkkkkz", trigseq_set, trigseq, NULL },
{ "seqtime", S(SEQTIM),  3,     "k",    "kkkkk", seqtim_set, seqtim, NULL   },
{ "lfo", S(LFO),         7,     "s",    "kko",	lfoset,   lfok,   lfoa     },
{ "streson", S(STRES),   5,     "a",    "aki",  stresonset, NULL, streson  },
{ "pitch", S(PITCH),     5,    "kk", "aiiiiqooooojo", pitchset, NULL, pitch },
{ "clockon", S(CLOCK),   3,     "",     "i",    clockset, clockon, NULL    },
{ "clockoff", S(CLOCK),  3,     "",     "i",    clockset, clockoff, NULL   },
{ "readclock", S(CLKRD), 1,     "i",    "i",    clockread, NULL, NULL      },
{ "mpulse", S(IMPULSE),  5,     "a",    "kko",  impulse_set, NULL, impulse },
{ "pitchamdf",S(PITCHAMDF), 5,  "kk","aiioppoo", pitchamdfset, NULL, pitchamdf },
{ "scanu", S(PSCSNU),5, "", "iiiiiiikkkkiikkaii", scsnu_init, NULL, scsnu_play },
{ "scans", S(PSCSNS),    5,     "a",    "kkiio", scsns_init, NULL, scsns_play},
{ "clip", S(CLIP),       5,	"a",	"aiiv",	clip_set, NULL, clip        },
{ "vbap4",  S(VBAP_FOUR), 5, "aaaa","aioo", vbap_FOUR_init, NULL, vbap_FOUR },
{ "vbap8",  S(VBAP_EIGHT), 5, "aaaaaaaa","aioo", vbap_EIGHT_init, NULL, vbap_EIGHT },
{ "vbap16", S(VBAP_SIXTEEN), 5, "aaaaaaaaaaaaaaaa","aioo", vbap_SIXTEEN_init, NULL, vbap_SIXTEEN },
{ "vbapz",  S(VBAP_ZAK), 5,     "",    "iiaioo", vbap_zak_init, NULL, vbap_zak },
{ "vbaplsinit",  S(VBAP_LS_INIT), 1, "","iioooooooooooooooooooooooooooooooo", vbap_ls_init},
{ "vbap4move",  S(VBAP_FOUR_MOVING), 5, "aaaa","aiiim", vbap_FOUR_moving_init, NULL, vbap_FOUR_moving },
{ "vbap8move",  S(VBAP_EIGHT_MOVING), 5, "aaaaaaaa","aiiim", vbap_EIGHT_moving_init, NULL, vbap_EIGHT_moving },
{ "vbap16move",  S(VBAP_SIXTEEN_MOVING), 5, "aaaaaaaaaaaaaaaa","aiiim", vbap_SIXTEEN_moving_init, NULL, vbap_SIXTEEN_moving },
{ "vbapzmove",  S(VBAP_ZAK_MOVING), 5, "","iiaiiim", vbap_zak_moving_init, NULL, vbap_zak_moving },
{ "sense", S(KSENSE),    2,     "k",    "",      NULL, ksense, NULL },
{ "sensekey", S(KSENSE), 2,     "k",    "",      NULL, ksense, NULL },
{ "xxx", S(XOSC),	 5,	"a",	"kkio",	    Foscset, NULL, Fosckk },
{ "reverb2",  S(NREV2),	 5,	"a",	"akkoojoj", reverbx_set,NULL,reverbx},
{ "nreverb",  S(NREV2),	 5,	"a",	"akkoojoj", reverbx_set,NULL,reverbx},
#if defined(GAB_RT)
{ "iftlen2", S(EVAL),    1,     "i",    "i",    ftlen2                   },
{ "icall", S(ICALL),  1,  "",	"iiim",	icall			},
{ "micall", S(MICALL),  3,  "",	"iiim",	micall_set,	micall			},
{ "dicall",S(DICALL), 3,  "",	"iiim",	dicall_set, dicall	},
{ "dmicall",S(DMICALL), 3,  "",	"iiim",	dmicall_set, dmicall	},
{ "loscil2", S(LOSC),    5,     "mm","xkiojoojoo",losset2,NULL, loscil2   },
{ "fof3",   S(FOFS3),    5,     "a","xxxkkkkkiiiikk",fofset3,NULL,fof3   },
{ "foscili2",S(FOSC2),	5,	"a",  "xkkkkiio",foscset2,NULL,	foscili2	},
{ "lpres",   S(LOWPR),    5,    "a",    "akk",  lowpr_set, NULL,   lowpr    },
{ "lpresx",  S(LOWPRX),    5,    "a",    "akko",  lowpr_setx, NULL,   lowprx    },
{ "posc",   S(POSC),     7,      "s",    "kkio", posc_set, kposc,   posc   },
{ "lposc",  S(LPOSC),    5,      "a",    "kkkkio", lposc_set, NULL,   lposc   },
{ "lposcint",   S(LPOSC),5,      "a",   "kkkkio", lposc_set, NULL,   lposcint   },
{ "physic1", S(PHIS1),   5,      "a",   "akkk", phys1set, NULL,   phys1   },
{ "physic2",S(PHIS2),    5,      "a",   "akkkkkk", phys2set, NULL,   phys2   },
{ "vlpres",  S(LOWPR_SEP),    5,    "a",    "akkik",  lowpr_w_sep_set, NULL,   lowpr_w_sep    },
{ "adsynt2",S(ADSYNT2),    5,     "a",  "kkiiiio", adsynt2_set,  NULL,  adsynt2  },
{ "cpstun",S(CPSTUN),    2,      "k",    "kkk",   NULL,   cpstun      },
{ "cpstuni",S(CPSTUNI),    1,      "i",    "ii",   cpstun_i,        },
{ "lineto",S(LINETO),    3,      "k",    "kk",   lineto_set,   lineto      },
{ "logbtwo_a",S(EVAL),   4,     "a",    "a", logbasetwo_set, NULL, logbasetwoa },
{ "logbtwo_i",S(EVAL),   1,     "i",    "i",    ilogbasetwo                },
{ "logbtwo_k",S(EVAL),   2,     "k",    "k",    logbasetwo_set, logbasetwo },
{ "mandel",S(MANDEL),    3,      "kk",    "kkkk",   mandel_set,   mandel      },
{ "metro",  S(METRO),	   3,		"k",	"ko",	metro_set,	metro		},
{ "powoftwo_a",S(EVAL),  4,     "a",    "a",  powoftwo_set, NULL, powoftwoa },
{ "powoftwo_i",S(EVAL),  1,     "i",    "i",    ipowoftwo                  },
{ "powoftwo_k",S(EVAL),  2,     "k",    "k",    powoftwo_set, powoftwo     },
{ "tlineto",S(LINETO2),    3,      "k",    "kkk",   tlineto_set,   tlineto      },
{ "vadd",S(VECTOROP),    3,        "",    "iki",   vectorOp_set,   vadd      },
{ "vaddv",S(VECTORSOP),    3,        "",    "iii",   vectorsOp_set,   vaddv      },
{ "vcella",S(CELLA),   3,        "",    "kkiiiiip",  ca_set,  ca    },
{ "vcopy",S(VECTORSOP),    3,        "",    "iii",   vectorsOp_set,   vcopy      },
{ "vdelayk",S(KDEL),   3,        "k",   "kkio",  kdel_set,  kdelay    },
{ "vdivv",S(VECTORSOP),    3,        "",    "iii",   vectorsOp_set,   vdivv      },
{ "vecdelay",S(VECDEL), 3,        "",    "iiiiio",vecdly_set,  vecdly    },
{ "vexp",S(VECTOROP),    3,        "",    "iki",   vectorOp_set,   vexp      },
{ "vexpseg",S(VSEG),    3,        "",    "iin",   vseg_set,   vexpseg      },
{ "vexpv",S(VECTORSOP),    3,        "",    "iii",   vectorsOp_set,   vexpv      },
{ "vlimit",S(VLIMIT),    3,        "",    "ikki",   vlimit_set,   vlimit      },
{ "vlinseg",S(VSEG),    3,        "",    "iin",   vseg_set,   vlinseg      },
{ "vmap",S(VECTORSOP),    3,        "",    "iii",   vectorsOp_set,   vmap },
{ "vmirror",S(VLIMIT),   3,        "",    "ikki",   vlimit_set,   vmirror      },
{ "vmult",S(VECTOROP),   3,        "",    "iki",   vectorOp_set,   vmult     },
{ "vmultv",S(VECTORSOP),   3,        "",    "iii",   vectorsOp_set,   vmultv      },
{ "vport",S(VPORT),    3,        "",    "ikio",  vport_set,  vport    },
{ "vpow",S(VECTOROP),    3,        "",    "iki",   vectorOp_set,   vpow      },
{ "vpowv",S(VECTORSOP),    3,        "",    "iii",   vectorsOp_set,   vpowv      },
{ "vrandh",S(VRANDH),   3,        "",    "ikki",  vrandh_set,   vrandh      },
{ "vrandi",S(VRANDI),   3,        "",    "ikki",  vrandi_set,   vrandi      },
{ "vsubv",S(VECTORSOP),    3,        "",    "iii",   vectorsOp_set,   vsubv      },
{ "vwrap",S(VLIMIT),    3,        "",    "ikki",   vlimit_set,   vwrap      },
#endif /* defined(GAB_RT) */

#if defined(ENABLE_OSC)
{ "OSCinit",    S(OSCINIT),  1, "",  "i",      osc_init,        NULL,         NULL         },
{ "OSCslot",    S(OSCSLOT),  1, "",  "iiSooo", osc_slot,        NULL,         NULL         },
{ "OSCslotr",   S(OSCSLOTR), 3, "k", "So",     osc_slotr_set,   osc_slotr,    NULL         },
{ "OSCslotw",   S(OSCSLOTW), 3, "",  "kSioo",  osc_slotw_set,   osc_slotw,    NULL         },
{ "OSCpeer",	S(OSCPEER),  1, "",  "Sii",    osc_peer,	NULL,	      NULL         },
{ "OSCsend",	S(OSCSEND),  3, "",  "kSio",   osc_send_set,    osc_send,     NULL         },
#endif /* defined(ENABLE_OSC) */

{ "babo",   S(BABO),     5,     "aa",   "akkkiiijj", baboset, NULL, babo },
{ "lpf18", S(LPF18),     5,     "a",    "akkk",  lpf18set, NULL, lpf18db },
{ "waveset", S(BARRI),   5,	"a",	"ako",   wavesetset,  NULL, waveset },
{ "dconv",  S(DCONV),    5,     "a",    "aii",    dconvset, NULL, dconv },
{ "p_i", S(PFUN),        1,	"i",	"i",	pfun, NULL, NULL },
{ "p_k", S(PFUN),        2,	"k",	"k",	NULL, pfun, NULL }
};

long oplength_2 = sizeof(opcodlst_2);
