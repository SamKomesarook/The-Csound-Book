#!/bin/sh
#
# $Id: OSC-example.sh,v 1.1 2000/08/12 02:03:41 nicb Exp $
#
# simple slider driver
#

OSC_EXAMPLE_DIR=${OSC_EXAMPLE_DIR:-doc/examples}
OSC_TCL=$OSC_EXAMPLE_DIR/OSC-sliders-example.tcl
PORTNO=2222

wish $OSC_TCL localhost $PORTNO car 0 10 &
wish $OSC_TCL localhost $PORTNO mod 0 10 &
wish $OSC_TCL localhost $PORTNO ndx 0 10 &

echo "You'll have to kill the sliders by hand :)..."

exit 0
