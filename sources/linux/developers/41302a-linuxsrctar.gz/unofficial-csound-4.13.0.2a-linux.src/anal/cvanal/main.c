/*
 * $Id: main.c,v 1.2 1999/06/23 11:53:02 nicb Exp $
 */
#include "execute.h"
#include "../../cs.h"

int main(int argc, char *argv[])
{
	return execute(cvanal, argc, argv, "cvanal", "cvanal");
}
