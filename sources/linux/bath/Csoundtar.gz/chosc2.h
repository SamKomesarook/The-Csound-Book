
typedef struct  {
        OPDS    h;
        MYFLT   *ar, *X0, *X1, *a, *b, *d, *C, *L;      /* The parameters */
        AUXCH   delay;          /* Buffer for old values */
        int     point;          /* Pointer to old values */
} CHOSC;

