                                                /*  USTUB.H  */

/* header and dummy global references for main.c stub in  */
/* standalone versions of hetro, lpanal, pvanal, sndinfo  */

OPARMS O;                              /* dummy global resolving */
GLOBALS glob;                     /*  for references unused */

void fdrecord(FDCH *fdchp) {}
void initerror(char *s) {}
void sndwrterr(int n, int nput) {}

