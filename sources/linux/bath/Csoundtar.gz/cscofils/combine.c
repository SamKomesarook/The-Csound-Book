#include "cscore.h"                              /*   CSCORE_SWITCH.C  */

                     /* cscore control test: switch betw two 2-sect scores */
                     /* the warped/un-warped quality should be preserved   */

cscore()             /* program callable from either Csound or Cscore_main */
{
	EVLIST *a, *b;
	FILE   *fp1, *fp2;

	fp1 = getcurfp();
	fp2 = filopen("score2.srt");

	a = lgetuntil(1.0);	/* read sect from score 1 */
	lput(a);		/* write it out as is */
	putstr("s");
	setcurfp(fp2);
	b = lgetuntil(1.0);      /* read sect from score 2 */
	lput(b);		/* write it out as is */
	putstr("s");
	setcurfp(fp1);
	a = lget();		/* read next sect from score 1 */
	lput(a);		/* write it out */
	putstr("s");
	setcurfp(fp2);
	b = lget();             /* read next sect from score 2 */
	lput(b);		/* write it out */
	putstr("s");

	lrelev(a);              /* optional to reclaim space */
	lrelev(b);

	setcurfp(fp1);
	a = lgetnext(1.0);	/* read next sect from score 1 */
	lput(a);		/* write it out */
	putstr("s");
	setcurfp(fp2);
	b = lgetnext(1.0);             /* read next sect from score 2 */
	lput(b);		/* write it out */
	putstr("s");
	setcurfp(fp1);
	a = lgetnext(1.0);	/* read next sect from score 1 */
	lput(a);		/* write it out */
	putstr("s");
	setcurfp(fp2);
	b = lgetnext(1.0);             /* read next sect from score 2 */
	lput(b);		/* write it out */
	putstr("e");
}


