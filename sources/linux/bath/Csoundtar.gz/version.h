# define VERSION (4)
# define SUBVER  (19)
#ifdef BETA
# define VERSIONSTRING  " v4.19beta"
# define PVERSION "\p                                               Csound 4.19betsa"
#else
# define VERSIONSTRING  " v4.19"
# define PVERSION "\p                                               Csound 4.19"
#endif
