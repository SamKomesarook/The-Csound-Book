typedef struct {
  OPDS  h;
  float *ktrig, *kstart, *kloop, *initndx, *kfn, *outargs[VARGMAX];
  long ndx;
  int nargs, done;
  long  pfn;
  float *table;
} TRIGSEQ;

typedef struct {
  OPDS  h;
  float *ktrig, *unit_time, *kstart, *kloop, *initndx, *kfn;
  long ndx;
  int done;
  double start, newtime;
  long  pfn;
  float *table;
} SEQTIM;
