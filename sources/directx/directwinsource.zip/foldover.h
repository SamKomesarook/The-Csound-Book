typedef struct {
	OPDS	h;
	float	*ar, *asig, *kincr ;
	double index;
	long sample_index;
	float value;
} FOLD;