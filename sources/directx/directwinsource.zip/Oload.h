#define	NCONSTS	400    /* gbl */		/*	OLOAD.H		*/
#define	LNAMES	2000 //400    /* lcl */ /* gab d4*/
#define	GNAMES	400  //100    /* gbl */	/* gab d4*/
#define	NLABELS	 100 //20    /* lcl */	/* gab d4 */
#define NGOTOS   400 //40				/* gab d4 */

#ifndef MINSHORT
#define MINSHORT (-32768)
#endif
extern  short nlabels;
#define LABELIM  (MINSHORT + nlabels)
#define CHKING   0
#define CBAS    32250
#define VBAS    32400
#define GVBAS   32550           /* VBAS + PMAX */
#define VMAGIC  0x56444154L     /* "VDAT" */

#define STRSMAX 8
extern  int     strsmax;
extern  char ** strsets;

typedef struct	{
	char	*namep;
	short	type, count;
} NAME;

typedef	struct	{
	char	*lbltxt;
	short	*ndxp;
} LBLARG;

typedef	struct	{
	short	lblno;
	float	**argpp;
} LARGNO;

typedef struct  {
	float   *ndx, *string;
} STRNG;

typedef struct  {
	float   *sets[PMAX];
} PVSET;

typedef struct  {
	float   *dimen;
} VDIMEN;

typedef struct  {
	float   *progs[32];
} VPRGS;

typedef struct  {
	OPDS    h;                   
	float   *pgm, *vals[32];
} PGM_INIT;

typedef struct {
        OPDS    h;
        float   *pgm, *vals[64];
} PCTL_INIT;

typedef struct {
	float	*ictlno, *insnos[16];
} INXCL;

typedef struct inx {
	struct inx *nxtinx;
	int ctrlno;
        int inscnt;
	int inslst[1];
} INX;

typedef struct {
	int	insno;
	long	ktime;
} TRNON;

typedef struct {
    	OPDS   h;
    	float  *insno, *itime;
} TURNON;

typedef struct  pgmbnk {
	struct  pgmbnk *nxtbnk;
	long    bankno;
	float   *vpgdat; 
	float   *spldat;
} PGMBNK;

typedef struct  {
	INSTRTXT *instxt;
	PGMBNK  *banks;
} VPGLST;

extern  char    **strsets;
PGMBNK *getchnbnk(MCHNBLK*);
float *getkeyparms(MCHNBLK*,int);
