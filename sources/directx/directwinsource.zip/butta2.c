static void gen23(void)         /* ASCII file table read Gab 17-feb-98*/
/* Modified after Paris Smaragdis by JPff */
{				
    int  	c = 0, j = 0;
    char 	buf[512], *p;
    FLOAT 	*fp;
    FILE	*infile;
	
    if (!(infile=fopen(e->strarg,"r"))) 
		FTERR (Str(X_725,"error opening ASCII file"));
    fp = ftp->ftable;
    p = buf;
    if (fp==NULL) {
		/* Start counting elements */
		flen = 0;
		while ((c= getc(infile)) != EOF) {
			if (!isspace(c)) {
				if (c == ';') {
					while ((c= getc(infile)) != '\n') ;
				}
				else *p++ = c;
			}
			else {
				char pp;
				*p = '\0';
				for (p = buf; (pp = *p) != '\0'; p++) {
					if (!isdigit(pp) && pp != '-' && pp != '.' && pp != '\0')
						goto nxt;
				}
				flen++;
nxt: 
				while (isspace(c=getc(infile))) ;
				ungetc(c,infile);				  
				p = buf;
			}
		}
		printf("%d elements in %s\n", c, e->strarg);
		rewind(infile);
		/* Allocate memory and read them in now */
		flen    = c;
		flen    = flen+2;
		lenmask = flen;
		flenp1  = flen+2;
		ftp = (FUNC *) mcalloc((long)sizeof(FUNC) + flen*sizeof(FLOAT));
		flist[fno]   = ftp;
		ftp->flen    = flen;
		ftp->lenmask = flen;
    }
    p = buf;
    while ((c= getc(infile)) != EOF && j < flen) {
		if (!isspace(c)) {
			if (c == ';') {
				while ((c= getc(infile)) != '\n') ;
			}
			else *p++ = c;
		}
		else {
			char pp;		/* To save value */
			*p = '\0';
			for (p = buf; (pp = *p) != '\0'; p++) {
				if (!isdigit(pp) && pp != '-' && pp != '.' && pp != '\0')
					goto next ;
			}
			*fp++ = (FLOAT) atof (buf);
			j++;
next: 
			while (isspace(c=getc(infile))) ;
			ungetc(c,infile);				  
			p = buf;
		}
    }
    fclose(infile);
}