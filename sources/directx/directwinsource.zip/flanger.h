/*
typedef struct {
	OPDS	h;
	float	*sr, *ain, *adel, *imaxd, *istod;
	AUXCH	aux;
	long	left;
} VDEL;

typedef struct {
	OPDS	h;
	float	*ar, *asig, *khp, *istor;
	float	c1, c2, yt1, prvhp;
} TONE;
*/

typedef struct {
	OPDS	h;
	float *ar, *asig, *xdel, *filt_khp, *kfeedback;
	float c1,c2,yt1,prvhp; /* filter instance variables */
	AUXCH	aux;  /* delay instance variables */
	long	left;
    short   xdelcod;
} WGUIDE1;

typedef struct {
	OPDS	h;
	float *ar, *asig, *xdel1, *xdel2, *filt_khp1, *filt_khp2, *kfeedback1, *kfeedback2;
	float c1_1,c2_1,yt1_1,prvhp1; /* filter1 instance variables */
	float c1_2,c2_2,yt1_2,prvhp2; /* filter1 instance variables */
	AUXCH	aux1;  /* delay1 instance variables */
	long	left1;
	AUXCH	aux2;  /* delay1 instance variables */
	long	left2;

	float	old_out;
    short   xdel1cod, xdel2cod;
} WGUIDE2;

/*------------------*/

typedef struct {
	OPDS	h;
	float	*ar, *asig, *xdel, *kfeedback, *maxd;
	float	yt1; /* filter instance variables */
	AUXCH	aux;  /* delay instance variables */
	long	left;
	unsigned long maxdelay;
	float	fmaxd;
} FLANGER;



