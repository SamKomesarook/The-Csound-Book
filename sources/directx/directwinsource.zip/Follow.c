	/*	Envelope follower by Paris Smaragdis	*/
	/*	Berklee College of Music Csound development team */
	/*	Copyright (c) August 1994.  All rights reserve */
	/*	Improvements 1999 John ffitch */

#include "cs.h"
#include <math.h>
#include "follow.h"

void flwset(FOL *p)
{
    p->wgh = p->max = 0.0f;
    p->length = (long)(*p->len * esr);
    if (p->length<=0L) {           /* RWD's suggestion */
      initerror(Str(X_549,"\nError: follow - zero length!\n"));
      p->length = (long)esr;
    }
    p->count = p->length;
}

                                /* Use absolute value rather than max/min */
void follow(FOL *p)
{
    long	n = ksmps;
    FLOAT	*in = p->in, *out = p->out;
    FLOAT	max = p->max;
    long        count = p->count;
    do {
      FLOAT sig = *in++;
      if (sig > max) max = sig;
      else if (sig < -max) max = -sig;
      if (--count == 0L) {
	p->wgh = max;
	max = 0.0f;
	count = p->length;
      }
      *out++ = p->wgh;
    } while (--n);
    p->max = max;
    p->count = count;
}

/* The Jean-Marc Jot (IRCAM) envelope follower, from code by
   Bram.DeJong@rug.ac.be and James Maccartney posted on music-dsp;
   Transferred to csound by JPff, 2000 feb 12
*/
void envset(ENV *p)
{
                                /* Note - 6.90775527898 -- log(0.001) */
    p->lastatt = *p->attack;
    if (p->lastatt<=0.0f)
      p->ga = (FLOAT) exp(- 69.0775527898/esr);
    else 
      p->ga = (FLOAT) exp(- 6.90775527898/(esr* p->lastatt));
    p->lastrel = *p->release;
    if (p->lastrel<=0.0f)
      p->gr = (FLOAT) exp(- 69.0775527898/esr);
    else
      p->gr = (FLOAT) exp(- 6.90775527898/(esr* p->lastrel));
    p->envelope = 0.0f;
}

void envext(ENV *p)
{
    int nsmps = ksmps;
    FLOAT	envelope = p->envelope;
    FLOAT 	ga, gr;
    FLOAT	*in = p->in, *out = p->out;
    if (p->lastrel!=*p->attack) {
      p->lastatt = *p->attack;
      if (p->lastatt<=0.0f)
        ga = p->ga = (FLOAT) exp(-10000.0/esr);
      else 
        ga = p->ga = (FLOAT) exp(-1.0/(esr* p->lastatt));
    }
    else ga = p->ga;
    if (p->lastrel!=*p->release) {
      p->lastrel = *p->release;
      if (p->lastrel<=0.0f)
        gr = p->gr = (FLOAT) exp(-100.0/esr);
      else
        gr = p->gr = (float) exp(-1.0/(esr* p->lastrel));
    }
    else gr = p->gr;
    do {
      FLOAT inp = *in++;
      if (inp<0.0f) inp = -inp; /* Absolute value */
      if (envelope < inp) {
        envelope = inp + ga*(envelope-inp);
      }
      else {
        envelope = inp + gr*(envelope-inp);
      }
      *out++ = envelope;
    } while (nsmps--);
    p->envelope = envelope;
}
