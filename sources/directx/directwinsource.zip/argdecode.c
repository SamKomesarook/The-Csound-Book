#include "cs.h"                 /*                              ARG_DECODE.C */
#include "soundio.h"
#include <ctype.h>
#include <string.h>

#ifdef LINUX
int midi_out;
extern void openMIDIout(void);
#endif

extern  OPARMS  O;
extern char    *orchname;  /* used by rdorch */
int     stdinassgn = 0;
extern char    *scorename;
extern char    *xfilename;
#define FIND(MSG)   if (*s == '\0')  \
                        if (!(--argc) || ((s = *++argv) != NULL) && *s == '-') \
                            dieu(MSG);

#ifdef GAB_RT	/* gab-A1 */
extern int     ScotScore;
void dieu_gab(char *s, char *title);
int flprintf =0, flprintfbis =0;  	
extern int rt_output_flag; 
extern int o_flag;
extern void setindev_num(int);
#ifndef GAB_WIN 
extern void set_rows(int);
extern void set_columns( int);
#endif	 //GAB_WIN 
extern void setoutdev_num(int);
extern void setno_check(void);
extern void setflag_graphic(void);
extern void exit_soon(void);
#ifndef GAB_WIN
extern void console_rows();
#endif
extern	void setport_num(int num);
extern	void setbuf_num(int	num);
void midi_out_enable(int midi_out);

// void set_realtime_sleep(void);
//extern void set_DirectSound_flag(void); /* gab-A2 */
//void set_rtplay_Dsound(void);  /* gab-A2 */
extern void set_secondary_flag();	/* gab-A2 */
extern void SetDsoundDevNum(int);	   /* gab-A2 */
extern void SetDsoundCapDevNum(int);
void set_sleep_flag(void); /*gab-A6*/
int argc_err; 				/*gab-A6*/
char **argv_err;			/*gab-A6*/
char *clbuf;
OPARMS  Obak = {0,0, 0,1,1,0, 0,0, 0,0, 0,0, 1,0,0,7, 0,0,0, 0,0,0,0, 0,0 }; /* gab e4*/

char *argv_gab[40]; /* allows 40 arguments (!) */


#endif 	/* gab-A1 */

extern int directSound_flag;
extern int directSoundCapture_flag;

#ifdef RESET
void argdecReset(){
	 directSound_flag=0;
	 rt_output_flag=0;
	 directSoundCapture_flag=0;
	 //memcpy (O, Obak, sizeof(OPARMS));
	 O = Obak;
	 //void *memcpy( void *dest, const void *src, size_t count );


	 
}

#endif



/* alphabetically, so i dont have to hunt for a letter next time...
**********************************************************************
-a alaw sound samples
-A create an AIFF format output soundfile
-b N sample frames (or -kprds) per software sound I/O buffer
-B N samples per hardware sound I/O buffer
-c 8-bit signed_char sound samples
-C use Cscore processing of scorefile
-d suppress all displays
-D defer GEN01 soundfile loads until performance time
-e Rescale floats as shorts to max amplitude
-E (was -G) N  Number of tables in graphics window
-f float sound samples
-F fnam read MIDIfile event stream from file 'fnam'
-g suppress graphics, use ascii displays
-G suppress graphics, use Postscript displays
-h no header on output soundfile
-H N print a heartbeat style 1, 2 or 3 at each soundfile write
-i fnam sound input filename
-I I-time only orch run
-j
-J create an IRCAM format output soundfile
-k N orchestra krate override
-K
-l long_int sound samples
-L dnam read Line-oriented realtime score events from device 'dnam'
-m N tty message level. Sum of: 1=note amps, 2=out-of-range msg, 4=warnings
-M dnam read MIDI realtime events from device 'dnam'
-n no sound onto disk
-N notify (ring the bell) when score or miditrack is done
-o fnam sound output filename
-O
-p Play after rendering
-P
-q fnam  Sound Sample-In Directory
-Q fnam  Analysis Directory
-r N orchestra srate override
-R continually rewrite header while writing soundfile (WAV/AIFF)
-s short_int sound samples
-S score is in Scot format
-t N use uninterpreted beats of the score, initially at tempo N
-T terminate the performance when miditrack is done
-u ulaw sound samples
-U unam run utility program unam
-v verbose orch translation
-V N  Number of chars in screen buffer for output window
-w   Record and Save MIDI input to a file
-W create a WAV format output soundfile
-x fnam extract from score.srt using extract file 'fnam'
-X fnam  Sound File Directory
-y N  Enables Profile Display at rate N in seconds,
   or for negative N, at -N kperiods
-Y N  Enables Progress Display at rate N seconds,
   or for negative N, at -N kperiods
-z List opcodes in this version
-Z
-- fnam log output to file (was -y fnam  Redirect output to listing file 'fnam')
-8 8-bit unsigned_char sound samples  J. Mohr 1995 Oct 17 
*/

static void usage(void)
{
#ifdef M_I286
err_printf( "See usage.txt\n");
#else
err_printf("Usage:\tcsound [-flags] orchfile scorefile\n");
err_printf( "Legal flags are:\n");
err_printf("-U unam\trun utility program unam\n");
err_printf("-C\tuse Cscore processing of scorefile\n");
err_printf("-I\tI-time only orch run\n");
err_printf("-n\tno sound onto disk\n");
err_printf("-i fnam\tsound input filename\n");
err_printf("-o fnam\tsound output filename\n");
err_printf("-b N\tsample frames (or -kprds) per software sound I/O buffer\n");
err_printf("-B N\tsamples per hardware sound I/O buffer\n");
err_printf("-A\tcreate an AIFF format output soundfile\n");
err_printf("-W\tcreate a WAV format output soundfile\n");
err_printf("-J\tcreate an IRCAM format output soundfile\n");
err_printf("-h\tno header on output soundfile\n");
err_printf("-c\t8-bit signed_char sound samples\n");
err_printf("-a\talaw sound samples\n");
err_printf("-8\t8-bit unsigned_char sound samples\n"); /* J. Mohr 1995 Oct 17 */
err_printf("-u\tulaw sound samples\n");
err_printf("-s\tshort_int sound samples\n");
err_printf("-l\tlong_int sound samples\n");
err_printf("-f\tfloat sound samples\n");
err_printf("-r N\torchestra srate override\n");
err_printf("-k N\torchestra krate override\n");
err_printf("-v\tverbose orch translation\n");
err_printf("-m N\ttty message level. Sum of: 1=note amps, 2=out-of-range msg, 4=warnings\n");
err_printf("-d\tsuppress all displays\n");
err_printf("-g\tsuppress graphics, use ascii displays\n");
err_printf("-G\tsuppress graphics, use Postscript displays\n");
err_printf("-S\tscore is in Scot format\n");
err_printf("-x fnam\textract from score.srt using extract file 'fnam'\n");
err_printf("-t N\tuse uninterpreted beats of the score, initially at tempo N\n");
err_printf("-L dnam\tread Line-oriented realtime score events from device 'dnam'\n");
err_printf("-M dnam\tread MIDI realtime events from device 'dnam'\n");
err_printf("-F fnam\tread MIDIfile event stream from file 'fnam'\n");
err_printf("-P N\tMIDI sustain pedal threshold (0 - 128)\n");
err_printf("-R\tcontinually rewrite header while writing soundfile (WAV/AIFF)\n");
err_printf("-H#\tprint a heartbeat style 1, 2 or 3 at each soundfile write\n");
err_printf("-N\tnotify (ring the bell) when score or miditrack is done\n");
err_printf("-T\tterminate the performance when miditrack is done\n");
err_printf("-D\tdefer GEN01 soundfile loads until performance time\n");
#ifdef LINUX                    /* Jonathan Mohr  1995 Oct 17 */
#ifdef RTAUDIO
err_printf("-V N\tset real-time audio output volume to N (1 to 100)\n");
#endif
#endif
err_printf("-z\tList opcodes in this version\n");
err_printf("-- fnam\tlog output to file\n");
#ifdef GAB_RT	   /* gab-A1 */
	err_printf("-+j num\tconsole number of text rows (default 25)\n");
	err_printf("-+J num\tconsole number of text columns (default 80)\n");
	err_printf("-+K num\tenable MIDI IN. 'num' (optional) = MIDI IN port device id number \n");
	err_printf("-+q num\tWAVE OUT device id number (use only if more WAVE devices are installed)\n");
	err_printf("-+p num\tnumber of WAVE OUT buffers (default 4; max. 40)\n");
	err_printf("-+O    \tsuppress all console text output for better realtime performance\n");
	err_printf("-+e    \tallow any sample rate (warn: not all sndcards support non-standard sr)\n");
	err_printf("-+y    \tdon't wait for keypress on exit\n");
	//err_printf("-+E    \tallow graphic display for WCSHELL by Riccardo Bianchini\n");
	err_printf("-+Q num\tenable MIDI OUT. 'num' (optional) = MIDI OUT port device id number\n");
	err_printf("-+Y    \tsuppress realtime WAVE OUT for better MIDI OUT timing performance\n");
	err_printf("-+*    \tyield control to system for better multitasking\n");
	err_printf("-+/    \tenable script file command line\n");
    err_printf("-+X num\tenable DirectSound primary buffer audio out (num is optional)\n");
	err_printf("-+C num\tenable DirectSoundCapture audio input\n");
    err_printf("-+S num\tenable DirectSound secondary buffer audio out (num is optional)\n");

#endif			/* GAB_RT */
err_printf("flag defaults: csound -s -otest -b%d -B%d -m7 -P128\n",
    IOBUFSAMPS, IODACSAMPS);
#endif
#ifndef GAB_RT	   /* gab-A1 */
        exit(1);
#endif
}


void dieu(char *s)
{
#ifdef GAB_RT	  /* gab-A1 */
	char sgab[256] ;
	int j;
#ifndef GAB_WIN
	set_rows(67);
    console_rows();
#endif 
  	usage();
	sprintf(sgab,"Csound Command ERROR: %s",s); 	/* gab-A1 */
	
	for (j=0; j< argc_err; j++) {
		err_printf("%s ",argv_err[j]);
	}
	
	err_printf("\n\nCsound Command ERROR:\t%s\n",s);
	dieu_gab(sgab,"Csound error!");  /* gab-A1 */
#ifndef CWIN
    exit(1);
#endif /* CWIN */
#else /* GAB_RT */  
    err_printf("Csound Command ERROR:\t%s\n",s);
    usage();
    if (!POLL_EVENTS()) exit(1);
#endif /* GAB_RT */
}

int remap_argv(char *fname) /* gab-A1 */
{
	FILE * fil;
	char * pt;
	int j=0;
	clbuf = (char *) malloc(2048);
	pt = clbuf;
	if ( !(fil=fopen(fname, "rt"))) die("bad command-line script file\n");
	printf("USING file '%s' as command line\n", fname);
	while (fscanf(fil, "%s", pt) != EOF){
		argv_gab[j++] = pt;
		pt+= strlen(pt)+1;
	}	
	fclose(fil);
	/*if (access(fname, 6))  chmod( fname, S_IREAD | S_IWRITE );  removes read-only flag*/
	return j;	
}


int platform (char flag, char **s, int *argc, char ***argv) /*gab */
{
	#define FIND2(MSG)   if (**s == '\0')  \
			if (!(--(*argc)) || ((*s = *(*++argv)) != NULL) && **s == '-') \
			    dieu(MSG);

	int num,n,gflag=0;
	switch (flag)	{
					case 'j':  FIND2("no rows number")  /* GAB */
						sscanf(*s,"%d%n",&num, &n);
						#ifndef GAB_WIN
						set_rows(num);
						console_rows();
						#endif
						(*s) += n;
						break;
					case 'J':  FIND2("no columns number")  /* GAB */
						sscanf(*s,"%d%n",&num, &n);
						#ifndef GAB_WIN
						set_columns(num);
						#endif //GAB_WIN
						(*s) += n;
						break;
					case 'K': if (**s != '\0' && **s >='0' && **s <= '9') { /* optional midi port number */
							sscanf(*s,"%d%n",&num, &n);  /* GAB midi port number */
							setport_num(num);
							(*s) +=n;
						}
						O.Midiname = "sbmidi";
						O.Midiin = 1; 
						break;
					case 'p': 	FIND2("no audio buffers number")  /* Audio buffers number */
						sscanf(*s,"%d%n",&num, &n); 
						setbuf_num(num);
						(*s) +=n;
						break;
					case 'q': 	if (**s != '\0'&& **s >='0' && **s <= '9') { /* Wave OUT device Number */
						sscanf(*s,"%d%n",&num, &n);
						setoutdev_num(num);
						(*s) +=n;
						}
						rt_output_flag=1;
						O.sfheader=0;
						if (O.filetyp == TYP_WAV  || 
							O.filetyp == TYP_AIFF || 
							O.filetyp == TYP_AIFC) {
							warning("realtime session - suppressing any WAV or AIFF header!");
							O.filetyp = 0;
						}

						break;
					case 'X': 	if (**s != '\0'&& **s >='0' && **s <= '9') { /* gab-A2 DirectSound device Number */
						sscanf(*s,"%d%n",&num, &n);
						SetDsoundDevNum(num);
						(*s) +=n;
						}
						{
							directSound_flag = 1;
							rt_output_flag=1;
							O.sfheader=0;
						if (O.filetyp == TYP_WAV  || 
							O.filetyp == TYP_AIFF || 
							O.filetyp == TYP_AIFC) {
							warning("realtime session - suppressing any WAV or AIFF header!");
							O.filetyp = 0;
						}

						}
						break;
					case 'C': if (**s != '\0'&& **s >='0' && **s <= '9') { 	/* gab c3 DirectSoundCapture device Number */
						sscanf(*s,"%d%n",&num, &n);
						SetDsoundCapDevNum(num);
						(*s) +=n;
						}
						{
							directSoundCapture_flag = 1;
							rt_output_flag=1;
							O.sfread = 1;
						}
						break;
					case 'S': 	if (**s != '\0'&& **s >='0' && **s <= '9') { /* gab-A2 DirectSound device Number */
						sscanf(*s,"%d%n",&num, &n);
						SetDsoundDevNum(num);
						(*s) +=n;
						}
						{
							extern int directSound_flag;
							directSound_flag = 1;
							set_secondary_flag();
							rt_output_flag=1;
							O.sfheader=0;
							if (O.filetyp == TYP_WAV  || 
							O.filetyp == TYP_AIFF || 
							O.filetyp == TYP_AIFC) {
							warning("realtime session - suppressing any WAV or AIFF header!");
							O.filetyp = 0;
						}

						}
						break;
					case 'O': 	flprintfbis=1;	/* no text print */
						break;
					case 'e': 	setno_check();	 /* allows arbitrary output sample rate */
						break;
			/*		case 'E': 	setflag_graphic();	// allows graphic display for WCSHELL by Riccardo Bianchini	
						break; */
					case 'y': 	exit_soon(); /* doesn't wait for keypress on exit */
						break;
					case 'Q':{ 	int midi_out=-1;
						if (**s != '\0' && **s >='0' && **s <= '9') {  /* midi out */
							sscanf(*s,"%d%n",&midi_out, &n); 
							(*s) +=n;
						}
						midi_out_enable(midi_out);	}
						break;
					case 'Y': 	O.outformat = AE_NO_AUDIO; /* disables any realtime Wave OUT */
						printf("--->no audio output: only MIDI OUT ENABLED\n");
						O.sfwrite = 0;
						break;
					case '*':  set_sleep_flag();	 /* enables WIN95 YELDING */
						printf("---> WIN95 YIELDING ENABLED!!\n");
						break;
					case '/': FIND2("no command FILE");  /* scan command line into a file */
						*argc = remap_argv(*s);
						*argv =  argv_gab;
						(*s) = (*argv)[0];
						gflag=1;
						/*goto prossimo; */
						break;
					default:
						die("'-+' flag must be followed by a valid platform specific flag letter!");
	}
	return gflag;
}


void gab_putchar(char c)	/* gab-A1 */
{
	 if (!flprintf) putchar(c);
}

void cleanstr(char *s) /* gab A8 */
{
	while(*s) {
		if (*s == 10 || *s == 13) {
			*s = '\0';
			break;
		}
		s++;
	}
}


int argdecode(int argc, char **argv, char **pfilnamp, char *envoutyp)
{
    char *s;
    char c;
    int n;
    char outformch;
    char *filnamp = *pfilnamp;
	int num; /* gab */
	argc_err = argc; argv_err = argv+1; /*gab A1*/
        do {
            if (!POLL_EVENTS()) exit(1);
            s = *++argv;
prossimo:  /* gab-A1 */
			cleanstr(s);  /* gab A8 */
            if (*s++ == '-') {                        /* read all flags:  */
                while ((c = *s++) != '\0') {
                    switch(c) {
                    case 'U': FIND("no utility name")
                              if (strcmp(s,"hetro") == 0) {
                                  printf("util HETRO:\n");
                                  hetro(argc,argv);
								  exit(0);
                              }
                              else if (strcmp(s,"lpanal") == 0) {
                                  printf("util LPANAL:\n");
                                  lpanal(argc,argv);
								  exit(0);
                              }
                              else if (strcmp(s,"pvanal") == 0) {
                                  printf("util PVANAL:\n");
                                  pvanal(argc,argv);
								  exit(0);
                              }
                              else if (strcmp(s,"sndinfo") == 0) {
                                  printf("util SNDINFO:\n");
                                  sndinfo(argc,argv);
								  exit(0);
                              }
                              else if (strcmp(s,"cvanal") == 0) {
                                  printf("util CVANAL:\n");
                                  cvanal(argc,argv);
                                  exit(0);
                              }
                              else if (strcmp(s,"pvlook") == 0) {
                                  printf("util PVLOOK:\n");
                                  pvlook(argc,argv);
                                  exit(0);
                              }
                              else dies("-U %s not a valid UTIL name",s);
                    case 'C': O.usingcscore = 1;     /* use cscore processing  */
                              break;
                    case 'I': O.initonly = 1;           /* I-only implies */
                    case 'n': O.sfwrite = 0;            /* nosound        */
                              break;
                    case 'i': 
#ifndef GAB_RT  /* gab-A1 */
                              FIND("no infilename")
#else           /* GAB_RT */
                        if (*s != '\0'&& *s >='0' && *s <= '9') {  /* (gab-A1)  Wave IN device Number */
                            sscanf(s,"%d%n",&num, &n); 
                            setindev_num(num);
                            s +=n;
                            O.infilename = "adc\0";							
                        } 
                        else if (*s == '\0') O.infilename = "adc\0";  /* gab-A1 */
                        else {
#endif          /* GAB_RT */                     
                              O.infilename = filnamp;   /* soundin name */
                              while ((*filnamp++ = *s++));  s--;
                              if (!POLL_EVENTS()) exit(1);
                              if (strcmp(O.infilename,"stdout") == 0)
                                  dieu("-i cannot be stdout");
                              if (strcmp(O.infilename,"stdin") == 0)
#ifdef SYMANTEC
                                  dieu("stdin audio not supported");
#else
                              {
                                  if (stdinassgn)
                                      dieu("-i: stdin previously assigned");
                                  stdinassgn = 1;
                              }
#endif
						#ifdef GAB_RT   /* gab-A1 */
                        } 
						#endif         /* GAB_RT */
                        O.sfread = 1;
                        break;
                    case 'o': FIND("no outfilename")
							#ifdef GAB_RT   /* gab-A1 */
                               o_flag=1;
							#endif/*GAB_RT*/
                              O.outfilename = filnamp;          /* soundout name */
                              while ((*filnamp++ = *s++)); s--;
							  if (strcmp(O.outfilename,"stdin") == 0)
                                  dieu("-o cannot be stdin");
                              if (strcmp(O.outfilename,"stdout") == 0) 
								#if defined SYMANTEC || defined BCC || defined __WATCOMC__ || defined __unix || defined WIN32
                                  dieu("stdout audio not supported");
								#else
                                  if ((O.stdoutfd = dup(1)) < 0) /* redefine stdout */
                                      die("too many open files");
                                  dup2(2,1);                /* & send 1's to stderr */
								#endif
                              break;
                    case 'b': FIND("no iobufsamps")
                              sscanf(s,"%d%n",&O.outbufsamps, &n);
							#ifdef GAB_WIN
							  {
								  extern void setBufScroll(int);
								  setBufScroll(O.outbufsamps);
							  }
							#endif
                    /* defaults in musmon.c */
                              O.inbufsamps = O.outbufsamps;
                              s += n;
                              break;
                    case 'B': FIND("no hardware bufsamps")
                              sscanf(s,"%ld%n",&O.oMaxLag, &n);
                    /* defaults in rtaudio.c */
                              s += n;
                              break;
                    case 'A': if (O.filetyp == TYP_WAV) {
                                  if (envoutyp == NULL) goto outtyp;
                                  warning("-A overriding local default WAV out");
                              }
                              O.filetyp = TYP_AIFF;     /* AIFF output request*/
                              break;
	          case 'J':
        	    	if (O.filetyp == TYP_AIFF ||
                		O.filetyp == TYP_WAV) {
	            	if (envoutyp == NULL) goto outtyp;
        	 	     warning("-J overriding local default AIFF/WAV out");
	            		}
        		    O.filetyp = TYP_IRCAM;      /* IRCAM output request */
		            break;
                    case 'W': if (O.filetyp == TYP_AIFF) {
                                if (envoutyp == NULL) goto outtyp;
                                warning("-W overriding local default AIFF out");
                              }
                              if (!POLL_EVENTS()) exit(1);
                              O.filetyp = TYP_WAV;      /* WAV output request */
                              break;
                    case 'h': O.sfheader = 0;           /* skip sfheader  */
                              break;
                    case 'c': if (O.outformat) goto outform;
                              outformch = c;
                              O.outformat = AE_CHAR;    /* signed 8-bit char soundfile */
                              break;
                    case 'a': if (O.outformat) goto outform;
                              outformch = c;
                              O.outformat = AE_ALAW;    /* a-law soundfile */
                              break;
                    case 'u': if (O.outformat) goto outform;
                              outformch = c;
                              O.outformat = AE_ULAW;    /* mu-law soundfile */
                              break;
                    case '8': if (O.outformat) goto outform;
                              outformch = c;
                              O.outformat = AE_UNCH;    /* unsigned 8-bit soundfile */
                              break;
                    case 's': if (O.outformat) goto outform;
                              outformch = c;
                              O.outformat = AE_SHORT;   /* short_int soundfile*/
                              break;
                    case 'l': if (O.outformat) goto outform;
                              outformch = c;
                              O.outformat = AE_LONG;    /* long_int soundfile */
                              break;
                    case 'f': if (O.outformat) goto outform;
                              outformch = c;
                              O.outformat = AE_FLOAT;   /* float soundfile */
		              if (O.filetyp == TYP_AIFF) {
              			warning("Overriding File Type to AIFF-C for float output");
		                O.filetyp = TYP_AIFC;
		              }
                              break;
                    case 'r': FIND("no sample rate")
                              sscanf(s,"%ld",&O.sr_override);
                              while (*++s);
                              break;
                    case 'k': FIND("no control rate")
                              sscanf(s,"%ld",&O.kr_override);
                              while (*++s);
                              break;
                    case 'v': O.odebug = odebug = 1;    /* verbose otran  */
                              break;
                    case 'm': FIND("no message level")
                              sscanf(s,"%d%n",&O.msglevel, &n);
                              s += n;
                              break;
                    case 'd': O.displays = 0;           /* no func displays */
                              break;
                    case 'g': O.graphsoff = 1;          /* don't use graphics */
                              break;
                    case 'G': O.postscript = 1;         /* Postscript graphics*/
                              break;
                    case 'S': ScotScore++;
                              break;
                    case 'x': FIND("no xfilename")
                              xfilename = s;            /* extractfile name */
                              while (*++s);
                              break;
                    case 't': FIND("no tempo value")
                              sscanf(s,"%d%n",&O.cmdTempo, &n);/* use this tempo .. */
                              s += n;
                              if (O.cmdTempo <= 0) dieu("illegal tempo");
                              O.Beatmode = 1;       /* on uninterpreted Beats */
                              break;
                    case 'L': FIND("no Linein score device_name")
                              O.Linename = filnamp;     /* Linein device name */
                              while ((*filnamp++ = *s++));  s--;
                              if (!strcmp(O.Linename,"stdin")) {
                                  if (stdinassgn)
                                      dieu("-L: stdin previously assigned");
                                  stdinassgn = 1;
                              }
                              O.Linein = 1;
                              break;
                    case 'M': FIND("no midi device_name")
                              O.Midiname = filnamp;     /* Midi device name */
                              while ((*filnamp++ = *s++));  s--;
                              if (!strcmp(O.Midiname,"stdin")) {
                                  if (stdinassgn)
                                      dieu("-M: stdin previously assigned");
                                  stdinassgn = 1;
                                }
                              O.Midiin = 1;
                              break;
                    case 'F': FIND("no midifile name")
                              O.FMidiname = filnamp;    /* Midifile name */
                              while ((*filnamp++ = *s++));  s--;
                              if (!strcmp(O.FMidiname,"stdin")) {
                                  if (stdinassgn)
                                      dieu("-F: stdin previously assigned");
                                  stdinassgn = 1;
                                }
                              O.FMidiin = 1;          /***************/
                              break;
                    case 'P': FIND("no pedal threshold")
                              sscanf(s,"%d%n",&O.SusPThresh, &n);
                              s += n;
                              break;
#ifdef LINUX
                    case 'Q': FIND("no MIDI output device")
                              midi_out = -1;
                              if (isdigit(*s)) {
                                sscanf(s,"%d%n",&midi_out,&n);
                                s += n;
                                openMIDIout();
                              }
                              break;
#endif
                    case 'R': O.rewrt_hdr = 1;
                              break;
                    case 'H': if (isdigit(*s)) {
				sscanf(s, "%d%n", &O.heartbeat, &n);
				s += n;
			      }
		              else O.heartbeat = 1;
		              break;
                    case 'N': O.ringbell = 1;        /* notify on completion */
                              break;
                    case 'T': O.termifend = 1;       /* terminate on midifile end */
                              break;
                    case 'D': O.gen01defer = 1;  /* defer GEN01 sample loads 
                                                    until performance time */
                              break;
#ifdef LINUX
#ifdef RTAUDIO
                    /* Add option to set soundcard output volume for real-
                       time audio output under Linux. -- J. Mohr 95 Oct 17 */
                    case 'V': FIND("no volume level")
                              sscanf(s,"%d%n",&O.Volume, &n);
                              s += n;
                              break;
#endif
#endif
                    case 'z': {
                                int full = 0;
                                extern int ug_flag; /* gab A9 */
								if (*s != '\0') {
                                  if (isdigit(*s)) ug_flag = full = *s++ - '0'; /* gab A9 */
                                }
								 /* list_opcodes(full); */
								 
                              }
                              /*return (0);*/
							break; /* gab A9 */
                    case '-': FIND("no log file");
                              dribble = fopen(s, "w");
                              while (*s++); s--;
                              break;
#ifdef	GAB_RT		 /* gab-A1 */
					case '+': {	 /* platform dependent flags */
						char flag = *s++;
						int gflag;
						gflag = platform(flag, &s, &argc, &argv);
						if (gflag) goto  prossimo;
						}
						break;
#endif /* GAB_RT */
                    default:  sprintf(errmsg,"unknown flag -%c", c);
		     dieu(errmsg);
                    }
                    if (!POLL_EVENTS()) exit(1);
                }
            }
            else {
                if (orchname == NULL)
                    orchname = --s;
                else if (scorename == NULL)
                    scorename = --s;
                else dieu("too many arguments");
            }
            if (!POLL_EVENTS()) exit(1);
        } while (--argc);
		*pfilnamp = filnamp;
		return 0;
outtyp: dieu("output soundfile cannot be both AIFF and WAV");

outform: sprintf(errmsg,"sound output format cannot be both -%c and -%c",
                outformch, c);
        dieu(errmsg);
}
