#include <stdio.h>              /*                      WINCWIN.C        */
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include "cwin.h"
#include "cs.h"
#define CAPSIZE 60

typedef struct {
        long    windid;                 /* set by MakeGraph() */
        float   *fdata;                 /* data passed to DrawGraph */
        long    npts;                   /* size of above array */
        char    caption[CAPSIZE];       /* caption string for graph */
        short   waitflg;                /* set =1 to wait for ms after Draw */
        short   polarity;               /* controls positioning of X axis */
        float   max, min;               /* workspace .. extrema this frame */
        float   absmax;                 /* workspace .. largest of above */
        float   oabsmax;                /* Y axis scaling factor */
        int     danflag;                /* set to 1 for extra Yaxis mid span */
} WINDAT;

enum {        /* symbols for WINDAT.polarity field */
        NOPOL,
        NEGPOL,
        POSPOL,
        BIPOL
};

typedef struct {        /* for 'joystick' input window */
        long     windid;        /* xwindow handle */
        int      m_x,m_y;       /* current crosshair pixel adr */
        float    x,y;           /* current proportions of fsd */
        int      down;
} XYINDAT;

void dispset(WINDAT *, float *, long, char *, int, char *), display(WINDAT *);
WINDAT *NewWin(char *, int);
void   DoDisp(WINDAT *,float *,int);

int  Graphable(void);           /* initialise windows.  Returns 1 if X ok */
void MakeGraph(WINDAT *, char *);       /* create wdw for a graph */
void MakeXYin(XYINDAT *, double, double);
                                /* create a mouse input window; init scale */
void DrawGraph(WINDAT *);       /* update graph in existing window */
void ReadXYin(XYINDAT *);       /* fetch latest value from ms input wdw */
void KillGraph(WINDAT *);       /* remove a graph window */
void KillXYin(XYINDAT *);       /* remove a ms input window */
        double x0 = 0.0, y0 = 0.0, y_off = 0.005, x_off = 0.005;
int  ExitGraph(void); /* print click-Exit message in most recently active window */

int Graphable(void)     /* called during program initialisation */
{
        return 1;
} 

void MakeGraph(WINDAT *wdptr, char *name) 
        /* called from window.c to open a graphics window */
{
    IGNORE(wdptr);
/*     cwin_caption(name); */
/*     cwin_show(); */
}

				/* Next line must be in line with cwin.cpp */
#define PICTURE_SIZE (32768)
void DrawGraph(WINDAT *wdptr)    /* called from window.c to graph an array */
{ 
    float       *fdata = wdptr->fdata;
    long        npts   = wdptr->npts;
    char        *msg   = wdptr->caption;
    int         lsegs, pol;
    char        string[100];
    int scale = 1;

    pol  = wdptr->polarity;
    cwin_clear();

    sprintf(string,"%s  %ld points, max %5.3f %s",
	    msg,npts,wdptr->oabsmax, (wdptr->waitflg?"(wait)":""));
    cwin_caption(string);
    lsegs = npts;                       /* one lineseg per datum */
    while (lsegs>PICTURE_SIZE) lsegs /=2, scale *= 2; /* Rescale */
    {       /* take scale factors out of for-loop for faster run-time */
        float x0 = 0.0f, y0 = 0.0f, y_off = 0.005f, x_off = 0.005f;
        float x_scale = (2.0f-2.0f*x_off)/ (float)(lsegs-1);
        float y_scale = (2.0f-2.0f*y_off)/ wdptr->oabsmax;
        float  f,*fdptr = fdata;
        int i = 0, j = lsegs;
        if (pol == (short)BIPOL) {
            y_off += 0.0f;
            y_scale /= 2.0f;             /* max data scales to h/2 */
        }
        else y_off += 1.0f;
        cwin_line_dash(0x0000ff, 0.0f+x_off, y_off-0.0f, 2.0f+x_off, y_off-0.0f);
        x0 = 0.0f; y0 = y_off - (*fdptr * y_scale); j--;
	fdptr += scale;
        while (j--) {
          float x, y;
          f = *fdptr;
	  fdptr += scale;
          cwin_line(0xff0000, x0, y0,
                    x=x_off+ i++ * x_scale, y=y_off - (f * y_scale));
          x0 = x; y0 = y;
        }
    }
/*     cwin_paint(); */
    cwin_show();
    if (wdptr->waitflg) {
        cwin_getchar();
        sprintf(string,"%s  %ld points, max %5.3f",msg,npts,wdptr->oabsmax);
        cwin_caption(string);
    }
    POLL_EVENTS();       
 }

void KillGraph(WINDAT *wdptr)
{
    IGNORE(wdptr);
    cwin_clear();
    POLL_EVENTS();
}
    
   
int ExitGraph(void)
{
    cwin_clear();
    POLL_EVENTS();
    return 0;
}

float mouse_x = 0.0f, mouse_y = 0.0f;

void MakeXYin(XYINDAT *wdptr, double x, double y)
{
    wdptr->x = (float)x;
    wdptr->y = (float)y;
    return;
}

extern void cwin_report_right(char*);
void ReadXYin(XYINDAT *wdptr)
{
/*  char buff[20]; */
    wdptr->x  = mouse_x;
    wdptr->y  = mouse_y;
/*    printf("[%.2f,%.2f]\n", mouse_x, mouse_y); */
/*     sprintf(buff, "[%.2f,%.2f]", mouse_x, mouse_y); */
/*     cwin_report_right(buff); */
    return;
}
