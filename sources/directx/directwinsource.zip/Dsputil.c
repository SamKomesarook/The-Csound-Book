/******************************************************************/
/*  dsputil.c                                                     */
/* DSP utility functions for Csound - dispfft, pvoc, and convolve */
/* 20apr90 dpwe                                                   */
/******************************************************************/

#include "dpwelib.h"
#include "fft.h"
#include "dsputil.h"
#include <math.h>
#ifdef MSVC                   /* Thanks to Richard Dobson */
# define hypot _hypot
#endif
#if defined(__ZPC__) || defined(__WATCOMC__) || defined(__ncc)
extern double hypot(double,double);
#endif
#ifdef LATTICE
/* xmath.c - extensions to maths library. */
/* Copyright (C) Codemist Ltd, 1988 */

double hypot(double x, double y)
{
    double scale;
    int n1, n2;
    if (x==0.0) return fabs(y);
    else if (y==0.0) return fabs(x);
    (void) frexp(x, &n1);
    (void) frexp(y, &n2);
    if (n2>n1) n1 = n2;
/* n1 is now the exponent of the larger (in absolute value) of x, y      */
    scale = ldexp(1.0, n1);     /* can not be 0.0                        */
    x /= scale;
    y /= scale;
/* The above scaling operation introduces no rounding error (since the   */
/* scale factor is exactly a power of 2). It reduces the larger of x, y  */
/* to be somewhere near 1.0 so overflow in x*x+y*y is impossible. It is  */
/* still possible that one of x*x and y*y will underflow (but not both)  */
/* but this is harmless.                                                 */
    return scale * sqrt(x*x + y*y);
}
/* End of Codemist Ltd Copyright component */

#endif

/* Do we do the whole buffer, or just indep vals? */
#define someof(s)       (s)
    /* (1L+s/2L) is the indep vals in an FFT frame of length (s).. well */
    /* (change to just (s) to work on whole buffer) */
#define actual(s)       ((s-1L)*2L)
    /* if callers are passing whole frame size, make this (s) */
    /* where callers pass s/2+1, this recreates the parent fft frame size */

void CopySamps( /* just move samples */
    FLOAT       *sce,
    FLOAT       *dst,
    long        size)
{
    ++size;
    while (--size)
        *dst++ = *sce++;
}

/* Allocate a cleared buffer */
FLOAT *MakeBuf(long size)
{
    FLOAT *res,*p;
    long          i;
    
    res = (FLOAT *) malloc((long)size * sizeof(FLOAT));
    p = res;
    for (i=0; i<size; ++i)
        *p++ = 0.0f;
    return(res);
}

/* Write window coefs into buffer, don't malloc */
void FillHalfWin(FLOAT *wBuf, long size, FLOAT max, int hannq)
    /* 1 => hanning window else hamming */
{
    FLOAT       a,b;
    long        i;

    if (hannq)
        {       a = 0.50f;        b = 0.50f;        }
    else
        {       a = 0.54f;        b = 0.46f;        }
                
    if (wBuf!= NULL)
        {                       /* NB: size/2 + 1 long - just indep terms */
        size /= 2;              /* to fix scaling */
        for (i=0; i<=size;++i)
            wBuf[i] = max * (a-b*(FLOAT)cos(PI*(FLOAT)i/(FLOAT)size ) );
        }
    return;
}
    
/* Make 1st half of hamming window for those as desire */
FLOAT *MakeHalfWin(long size, FLOAT max, int hannq)
                /* Effective window size (altho only s/2+1 alloc'd */
                /* 1 => hanning window else hamming */
{
    FLOAT       *wBuf;

    wBuf = (FLOAT *) malloc((long)(size/2+1) * sizeof(FLOAT));
                                /* NB: size/2 + 1 long - just indep terms */
    FillHalfWin(wBuf,size,max,hannq);
    return(wBuf);
}
    
void UnpackReals(FLOAT *dst, long size) /* expand out size to re,0,re,0 etc */
{
    FLOAT       *d2;

    d2 = dst + 2*size - 1;      /* start at ends .. */
    dst += size - 1;
    ++size;
    while (--size)              /* .. & copy backwards */
        {
            *d2-- = 0.0f;
            *d2-- = *dst--;
        }
}

void PackReals(FLOAT *buffer, long size) /* pack re,im,re,im into re,re */
{
    FLOAT       *b2 = buffer;

    ++size;
    while (--size)
        {
            *b2++ = *buffer++;
            ++buffer;
        }
}

/* Convert Real & Imaginary spectra into Amplitude & Phase */
void Rect2Polar(FLOAT *buffer, long size)
{
    long        i;
    FLOAT       *real,*imag;
    double      re,im;
    FLOAT       mag;

    real = buffer;      imag = buffer+1;
    for (i = 0; i< someof(size); ++i)
        {
            re = (double)real[2L*i];
            im = (double)imag[2L*i];
            real[2L*i] = mag = (FLOAT)hypot(re,im);
            if (mag == 0.0f)
                imag[2L*i] = 0.0f;
            else
                imag[2L*i] = (FLOAT)atan2(im,re);
        } 
}


void Polar2Rect(FLOAT *buffer, long size) /* reverse above */
{
    long            i;
    FLOAT   *magn,*phas;
    FLOAT   mag;
    double  pha;

    magn = buffer;  phas = buffer+1;
    for (i = 0; i< someof(size); ++i)
        {
            mag =         magn[2L*i];
            pha = (double)phas[2L*i];
            magn[2L*i] = mag*(FLOAT)cos(pha);
            phas[2L*i] = mag*(FLOAT)sin(pha);
        }
}

void Lin2DB(FLOAT *buffer, long size)   /* packed buffer i.e. reals, not complex */
{
    while (size--) {
        *buffer = /* 20.0f*log10 */ 8.68589f*(FLOAT)log(*buffer);
        buffer++;
    }
}

void DB2Lin(FLOAT *buffer, long size)   /* packed buffer i.e. reals, not complex */
{
    while (size--) {
        *buffer = (FLOAT)exp( /* 1/20.0f*log10 */ .1151292*(*buffer) );
        buffer++;
    }
}

FLOAT maskPhs(FLOAT phs)        /* do it inline instead! */
{
    while (phs > PI_F) {
/*      putchar('-'); fflush(stdout);   */
            phs -= 2.0f*PI_F;
    }
    while (phs < -PI_F) {
/*      putchar('+'); fflush(stdout);   */
            phs += 2.0f*PI_F;
    }
    return(phs);
}

#define MmaskPhs(phs)   /* macro version of phase masking */ \
    while (phs > PI_F)    \
        phs -= 2.0f*PI_F; \
    while (phs < -PI_F)   \
        phs += 2.0f*PI_F; \

#define MMmaskPhs(p,q,s) /* p is pha, q is as int, s is 1/PI */ \
    q = (int)(s*p);     \
    p -= PI_F*(FLOAT)((int)((q+((q>=0)?(q&1):-(q&1) )))); \


void UnwrapPhase(FLOAT *buf, long size, FLOAT *oldPh)
{
    long    i;
    FLOAT   *pha;
    FLOAT   p, oneOnPi;
    int     z;

    pha = buf + 1;
    oneOnPi = 1.0f/PI_F;
    for (i=0; i<someof(size); ++i)
        {
            p = pha[2L*i];
            p -= oldPh[i];              /* find change since last frame */
            MMmaskPhs(p,z,oneOnPi);
            /* MmaskPhs(p); */
            oldPh[i] = pha[2L*i];       /* hold actual phase for next diffce */
            pha[2L*i] = p;              /* .. but write back phase change */
        }
}

void RewrapPhase(FLOAT *buf, long size, FLOAT *oldPh)
{
    long    i;
    FLOAT   *pha;
    FLOAT   p,oneOnPi;
    int     z;

    /* Phase angle was properly scaled when it came out of frqspace */
    /* .. so just add it */
    pha = buf + 1;
    oneOnPi = 1.0f/PI_F;
    for (i=0; i<someof(size); ++i)
        {
            p = (pha[2L*i]+oldPh[i]);
            MMmaskPhs(p,z,oneOnPi);
            /* MmaskPhs(p);     */
            oldPh[i] = pha[2L*i] = p;
        }
}

/* Convert a batch of phase differences to actual target freqs */
void PhaseToFrq(FLOAT *buf, long size, FLOAT incr, FLOAT sampRate)
{
    long    i;
    FLOAT   *pha,p,q,oneOnPi;
    int     z;
    FLOAT   srOn2pi, binMidFrq, frqPerBin;
    FLOAT   expectedDphas,eDphIncr;

    pha = buf + 1;
    srOn2pi = sampRate/(2.0f*PI_F*incr);
    frqPerBin = sampRate/((FLOAT)actual(size));
    binMidFrq = 0.0f;
    /* Of course, you get some phase shift with spot-on frq coz time shift */
    expectedDphas = 0.0f;
    eDphIncr = 2.0f*PI_F*incr/((FLOAT)actual(size));
    oneOnPi = 1.0f/PI_F;
    for (i=0; i<someof(size); ++i)
        {
            q = p = pha[2L*i]-expectedDphas;
            MMmaskPhs(p,z,oneOnPi);
/*      MmaskPhs(q);    */
            pha[2L*i] = p;
            pha[2L*i] *= srOn2pi;
            pha[2L*i] += binMidFrq;

            expectedDphas += eDphIncr;
            expectedDphas -= TWOPI_F*(FLOAT)((int)(expectedDphas*oneOnPi)); 
            binMidFrq += frqPerBin;
        }
    /* Doesn't deal with 'phases' of DC & fs/2 any different */
}

/* Undo a pile of frequencies back into phase differences */
void FrqToPhase(
    FLOAT *buf, long size, FLOAT incr, FLOAT sampRate, FLOAT fixUp)
    /* the fixup phase shift ... ? */
{
    FLOAT   *pha;
    FLOAT   twoPiOnSr, binMidFrq, frqPerBin;
    FLOAT   expectedDphas,eDphIncr;
    FLOAT   p;
    long    i;
    int     j;
    FLOAT   oneOnPi;

    oneOnPi = 1.0f/PI_F;
    pha = buf + 1;
    twoPiOnSr = 2.0f*PI_F*((FLOAT)incr)/sampRate;
    frqPerBin = sampRate/((FLOAT)actual(size));
    binMidFrq = 0.0f;
    /* Of course, you get some phase shift with spot-on frq coz time shift */
    expectedDphas = 0.0f;
    eDphIncr = 2.0f*PI_F*((incr)/((FLOAT)actual(size)) + fixUp);
    for (i=0; i<someof(size); ++i)
        {
            p = pha[2L*i];
            p -= binMidFrq;
            p *= twoPiOnSr;
            p += expectedDphas;
            MMmaskPhs(p,j,oneOnPi);
            /* MmaskPhs(p);     */
            pha[2L*i] = p;
            expectedDphas += eDphIncr;
            expectedDphas -= TWOPI_F*(FLOAT)((int)(expectedDphas*oneOnPi)); 
            binMidFrq += frqPerBin;
        }
        /* Doesn't deal with 'phases' of DC & fs/2 any different */
}

/* Unpack stored mag/pha data into buffer */
void FetchIn(
    FLOAT   *inp,       /* pointer to input data */
    FLOAT   *buf,       /* where to put our nice mag/pha pairs */
    long    fsize,      /* frame size we're working with */
    FLOAT   pos)        /* fractional frame we want */
{
    long    j;
    FLOAT   *frm0, *frm1;
    long    base;
    FLOAT   frac;

    /***** WITHOUT INFO ON WHERE LAST FRAME IS, MAY 'INTERP' BEYOND IT ****/
    base = (long)pos;               /* index of basis frame of interpolation */
    frac = ((FLOAT)(pos - (FLOAT)base));
    /* & how close to get to next */
    frm0 = inp + ((long)fsize+2L)*base;
    frm1 = frm0 + ((long)fsize+2L);         /* addresses of both frames */
    if (frac != 0.0f)           /* must have 2 cases to avoid poss seg vlns */
        {               /* and failed computes, else may interp   */
                                /* bd valid data */
            for (j=0; j<(fsize/2L + 1L); ++j)  /* mag/pha for just over 1/2 */
                {               /* Interpolate both mag and phase */
                    buf[2L*j] = frm0[2L*j] + frac*(frm1[2L*j]-frm0[2L*j]);
                    buf[2L*j+1L] = frm0[2L*j+1L] 
                        + frac*(frm1[2L*j+1L]-frm0[2L*j+1L]);
                }
        }
    else
        {       /* frac is 0.0 i.e. just copy the source frame */
            for (j=0; j<(fsize/2L + 1L); ++j)
                {               /* no need to interpolate */
                    buf[2L*j] = frm0[2L*j];
                    buf[2L*j+1] = frm0[2L*j+1L];
                }
        }
}

/* Fill out the dependent 2nd half of iFFT data; scale down & opt conjgt */
void FillFFTnConj(
    FLOAT   *buf,
    long     size,              /* full length of FFT ie 2^n */
    FLOAT   scale,              /* can apply a scale factor.. */
    int     conj)               /* flag to conjugate at same time */
{
    FLOAT   miscale;            /* scaling for poss. conj part */
    FLOAT   *mag,*pha;
    long    j;
    long    hasiz = 1L + size/2L; /* the indep values */

    if (scale == 0.0f)   scale = 1.0f;
    if (conj)
        miscale = -scale;
    else
        miscale = scale;
    mag = buf;      pha = buf+1;
    for (j=0; j<hasiz; ++j)         /* i.e. mag/pha for just over 1/2 */
        {
            mag[2L*j] *= scale;
            pha[2L*j] *= miscale;
        }
    for (j=hasiz; j<size; ++j)          /* .. the rest is mirrored .. */
        {
            mag[2L*j] = mag[2L*(size-j)];     /* For the symmetry extension, */
            pha[2L*j] = -pha[2L*(size-j)];    /*  conjugate of 1st 1/2 rgdls */
        }
}

void ApplyHalfWin(FLOAT *buf, FLOAT *win, long len)
    /* Window only store 1st half, is symmetric */
{
    long j;
    long    lenOn2 = (len/2L);

    for (j = lenOn2 + 1; j--; )
        *buf++ *= *win++;
    for (j = len - lenOn2 - 1, win--; j--; )
        *buf++ *= *--win;
}       

/* Overlap (some of) new data window with stored previous data in circular buffer */
void addToCircBuf(
    FLOAT   *sce, FLOAT *dst, /* linear source and circular destination */
    long    dstStart,         /* Current starting point index in circular dst */
    long    numToDo,          /* how many points to add ( <= circBufSize ) */
    long    circBufSize)      /* Size of circ buf i.e. dst[0..circBufSize-1] */
    {
    long    i;
    long    breakPoint;     /* how many points to add before having to wrap */

    breakPoint = circBufSize-dstStart;/* i.e. if we start at (dIndx = lim -2) */
    if (numToDo > breakPoint)   /*   we will do 2 in 1st loop, rest in 2nd. */
        {
        for (i=0; i<breakPoint; ++i)
            dst[dstStart+i] += sce[i];
        dstStart -= circBufSize;
        for (i=breakPoint; i<numToDo; ++i)
            dst[dstStart+i] += sce[i];
        }
    else                                /* All fits without wraparound */
        for (i=0; i<numToDo; ++i)
            dst[dstStart+i] += sce[i];
    return;
    }

/* Write from a circular buffer into a linear output buffer without 
   clearing data 
   UPDATES SOURCE & DESTINATION POINTERS TO REFLECT NEW POSITIONS */
void writeFromCircBuf(
    FLOAT   **sce,
    FLOAT   **dst,              /* Circular source and linear destination */
    FLOAT   *sceStart,
    FLOAT   *sceEnd,            /* Address of start & end of source buffer */
    long    numToDo)            /* How many points to write (<= circBufSize) */
{
    FLOAT   *srcindex = *sce;
    FLOAT   *dstindex = *dst;
    long    breakPoint;     /* how many points to add before having to wrap */

    breakPoint = sceEnd - srcindex + 1;
    if (numToDo >= breakPoint)  /*  we will do 2 in 1st loop, rest in 2nd. */
        {
            numToDo -= breakPoint;
            for (; breakPoint > 0; --breakPoint) {
/*                printf("Input audio l1 = %f\n",*srcindex);  */
                *dstindex++ = *srcindex++;                
            }
            srcindex = sceStart;
        }
    for (; numToDo > 0; --numToDo) {
/*        printf("Input audio l2 = %f\n",*srcindex);  */
        *dstindex++ = *srcindex++;                
    }
    *sce = srcindex;
    *dst = dstindex;
    return;
}

/* Write from a circular buffer into a linear output buffer CLEARING DATA */
void writeClrFromCircBuf(
    FLOAT   *sce, FLOAT *dst, /* Circular source and linear destination */
    long    sceStart,         /* Current starting point index in circular sce */
    long    numToDo,          /* How many points to write ( <= circBufSize ) */
    long    circBufSize)      /* Size of circ buf i.e. sce[0..circBufSize-1] */
{
    long    i;
    long    breakPoint;     /* how many points to add before having to wrap */

    breakPoint = circBufSize-sceStart; /* i.e. if we start at (Indx = lim -2) */
    if (numToDo > breakPoint)   /*  we will do 2 in 1st loop, rest in 2nd. */
        {
            for (i=0; i<breakPoint; ++i)
                {
                    dst[i] = sce[sceStart+i];
                    sce[sceStart+i] = 0.0f;
                }
            sceStart -= circBufSize;
            for (i=breakPoint; i<numToDo; ++i)
                {
                    dst[i] = sce[sceStart+i];
                    sce[sceStart+i] = 0.0f;
                }
        }
    else                                /* All fits without wraparound */
        for (i=0; i<numToDo; ++i)
            {
                dst[i] = sce[sceStart+i];
                sce[sceStart+i] = 0.0f;
            }
    return;
}

/* Add source array to dest array, results in dest */
void    FixAndAdd(FLOAT *samplSce, short *shortDest, long size)
{
    long i;
    for (i = 0; i < size; i++)
        shortDest[i] += (short)samplSce[i];
}

/* Rules to convert between samples and frames, given frSiz & frIncr */
long NumFrames(long dataSmps, long frSiz, long frInc)
{
    return( 1L + (dataSmps - (long)frSiz)/(long)frInc );
}

long NumSampls(long frames, long frSiz, long frIncr)
{
    return(((long)frSiz)+((long)frIncr)*(frames-1L));
}

/********************************************************************/
/*  udsample.c      -       from dsampip.c                          */
/*  Performs sample rate conversion by interpolated FIR LPF approx  */
/*  VAX, CSOUND VERSION                                             */
/*  1700 07feb90 taken from rational-only version                   */
/*  1620 06dec89 started dpwe                                       */
/********************************************************************/

/* (ugens7.h) #define   SPDS (8) */    /* How many sinc lobes to go out */
/* Static function prototypes - moved to top of file */
static FLOAT *sncTab = NULL;    /* point to our sin(x)/x lookup table */

void UDSample(
    FLOAT   *inSnd,
    FLOAT   stindex,
    FLOAT   *outSnd,
    long     inLen,
    long     outLen,
    FLOAT   fex)
/*  Perform the sample rate conversion:
    inSnd   is the existing sample to be converted
    outSnd  is a pointer to the (pre-allocated) new soundspace
    inLen   is the number of points in the input sequence
    outLen  is the number of output sample points.  e.g inLen/fex
    fex is the factor by which frequencies are increased
    1/fex = lex, the factor by which the output will be longer
    i.e. if the input sample is at 12kHz and we want to produce an
    8kHz sample, we will want it to be 8/12ths as many samples, so
    lex will be 0.75
 */
{
    int     in2out;
    long    i,j,x;
    FLOAT   a;
    FLOAT   phasePerInStep, fracInStep;
    FLOAT   realInStep, stepInStep;
    long    nrstInStep;
    FLOAT   posPhase, negPhase;
    FLOAT   lex = 1.0f/fex;
    int     nrst;
    FLOAT   frac;

    phasePerInStep = ((lex>1)? 1.0f : lex)* (FLOAT)SPTS;
    /* If we are upsampling, LPF is at input frq => sinc pd matches */
    /*  downsamp => lpf at output rate; input steps at some fraction */
    in2out = (int)( ((FLOAT)SPDS) * ( (fex<1)? 1.0 : fex ) );
    /* number of input points contributing to each op: depends on LPF */
    realInStep = stindex;           stepInStep = fex;
    for (i = 0; i<outLen; ++i)              /* output sample loop */
        {                                   /* i = lex*nrstIp, so .. */
            nrstInStep = (long)realInStep;  /* imm. prec actual sample */
            fracInStep = realInStep-(FLOAT)nrstInStep;  /* Fractional part */
            negPhase = phasePerInStep * fracInStep;
            posPhase = -negPhase;
            /* cum. sinc arguments for +ve & -ve going spans into input */
            nrst = (int)negPhase;       frac = negPhase - (FLOAT)nrst;
            a = (sncTab[nrst]+frac*(sncTab[nrst+1]-sncTab[nrst]))*
                (FLOAT)inSnd[nrstInStep];
            for (j=1L; j<in2out; ++j) /* inner FIR convolution loop */
                {
                    posPhase += phasePerInStep;
                    negPhase += phasePerInStep;
                    if ( (x = nrstInStep-j)>=0L )
                        nrst = (int)negPhase;   frac = negPhase - (FLOAT)nrst;
                    a += (sncTab[nrst]+frac*(sncTab[nrst+1]-sncTab[nrst]))
                        * (FLOAT)inSnd[x];
                    if ( (x = nrstInStep+j)<inLen )
                        nrst = (int)posPhase;   frac = posPhase - (FLOAT)nrst;
                    a += (sncTab[nrst]+frac*(sncTab[nrst+1]-sncTab[nrst]))
                        * (FLOAT)inSnd[x];
                }
            outSnd[i] = (float)a;
            realInStep += stepInStep;
        }
}

void    FloatAndCopy(short *sce, FLOAT *dst, long size)
{
    while (size--)
        *dst++ = (FLOAT)*sce++;
}

/* Copy converted frame to the output data */
void    WriteOut(FLOAT *sce, FLOAT **pdst, long fsize)
                /* the frame size - but we may not copy them all! */
{
    int     j;

    for (j=0; j<(2L*(fsize/2L + 1L)); ++j ) /* i.e. mg/ph for just over 1/2 */
        *(*pdst)++ = sce[j];                /* pointer updated for next time */
}       

/*--------------------------------------------------------------------*/
/*---------------------------- sinc module ---------------------------*/
/*--------------------------------------------------------------------*/

/* (ugens7.h) #define SPTS (16) */ /* How many points in each lobe */

void MakeSinc(void)             /* initialise our static sinc table */
{
    int     i;
    int     stLen = SPDS*SPTS;  /* sinc table is SPDS/2 periods of sinc */
    FLOAT   theta   = 0.0f;     /* theta (sinc arg) reaches pi in SPTS */
    FLOAT   dtheta  = (FLOAT)(SBW*PI)/(FLOAT)SPTS;   /* SBW lowers cutoff to redc ali */
    FLOAT   phi     = 0.0f;     /* phi (hamm arg) reaches pi at max ext */
    FLOAT   dphi    = PI_F/(FLOAT)(SPDS*SPTS);


    if (sncTab == NULL)
        sncTab = (FLOAT *)malloc((long)(stLen+1) * sizeof(FLOAT));
    /* (stLen+1 to include final zero; better for interpolation etc) */
/*    printf("Make sinc : pts = %d, table = %lx \n",stLen,sncTab);   */
    sncTab[0] =  1.0f;
    for (i=1; i<=stLen; ++i) /* build table of sin x / x */
        {
            theta += dtheta;
            phi   += dphi;
            sncTab[i] = (FLOAT)sin(theta)/theta * (0.54f + 0.46f*(FLOAT)cos(phi));
            /* hamming window on top of sinc */
        }
}

void DestroySinc(void)  /* relase the lookup table */
{
    free(sncTab);
}

FLOAT SincIntp(FLOAT index)
/* Calculate the sinc of the 'index' value by interpolating the table */
/* <index> is scaled s.t. 1.0 is first zero crossing */
/* ! No checks ! */
{
    int     nrst;
    FLOAT   frac,scaledUp;

    scaledUp = index * SPTS;
    nrst = (int)scaledUp;
    frac = scaledUp - (FLOAT)nrst;
    return(sncTab[nrst] + frac*(sncTab[nrst+1]-sncTab[nrst]) );
}       

/****************************************/
/** prewarp.c module                    */
/****************************************/

/* spectral envelope detection: this is a very crude peak picking algorithm
        which is used to detect and pre-warp the spectral envelope so that
        pitch transposition can be performed without altering timbre.
        The basic idea is to disallow large negative slopes between
        successive values of magnitude vs. frequency. */

#ifndef NULL
#define NULL 0x0L
#endif


static  FLOAT   *env = (FLOAT *)NULL;   /* Scratch buffer to hold 'envelope' */

void PreWarpSpec(
    FLOAT   *spec,      /* spectrum as magnitude,phase */
    long     size,      /* full frame size, tho' we only use n/2+1 */
    FLOAT warpFactor) /* How much pitches are being multd by */
{
    FLOAT   eps,slope;
    FLOAT   mag, lastmag, nextmag, pkOld;
    long     pkcnt, i, j;

    if (env==(FLOAT *)NULL)
        env = (FLOAT *)malloc((long)size * sizeof(FLOAT));
    /*!! Better hope <size> in first call is as big as it gets !! */
    eps = -64.0f / size;              /* for spectral envelope estimation */
    lastmag = *spec;
    mag = spec[2*1];
    pkOld = lastmag;
    *env = pkOld;
    pkcnt = 1;

    for (i = 1; i < someof(size); i++)  /* step thru spectrum */
        {
            if (i < someof(size)-1)
                nextmag = spec[2*(i+1)];
            else nextmag = 0.0f;

            if (pkOld != 0.0f)
                slope = ((FLOAT) (mag - pkOld)/(pkOld * pkcnt));
            else
                slope = -10.0f;

            /* look for peaks */
            if ((mag>=lastmag)&&(mag>nextmag)&&(slope>eps))
                {
                    env[i] = mag;
                    pkcnt--;
                    for (j = 1; j <= pkcnt; j++)
                        {
                            env[i - pkcnt + j - 1]
                                = pkOld * (1.0f + slope * j);
                        }
                    pkOld = mag;
                    pkcnt = 1;
                }
            else
                pkcnt++;                    /* not a peak */
            
            lastmag = mag;
            mag = nextmag;
        }

    if (pkcnt > 1)                  /* get final peak */
        {
            mag = spec[2*(size/2)];
            slope = ((FLOAT) (mag - pkOld) / pkcnt);
            env[size/2] = mag;
            pkcnt--;
            for (j = 1; j <= pkcnt; j++)
                {
                    env[size/2 - pkcnt + j - 1] = pkOld + slope * j;
                }
        }

    for (i = 0; i < someof(size); i++)  /* warp spectral env.*/
        {
            j = (long)((FLOAT) i * warpFactor);
            mag = spec[2*i];
            if ((j < someof(size)) && (env[i] != 0.0f))
                spec[2*i] *= env[j]/env[i];
            else
                spec[2*i] = 0.0f;
/*      printf("I<%d>J<%d>S<%.0f>E<%.0f>F<%.0f>T<%0.f>",
            i, j, mag, env[i], env[j], spec[2*i]);  */
        }
}


