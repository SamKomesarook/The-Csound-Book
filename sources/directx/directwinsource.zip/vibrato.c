#include "cs.h"
#include <math.h>
#include "vibrato.h"
/*-------------- START Gab --------------------------------------------*/ /* gab d5*/
extern long holdrand;

#define oneUp31Bit		(double) (4.656612875245796924105750827168e-10)
#define randGab   (FLOAT)((double) (((holdrand = holdrand * 214013L + 2531011L) >> 1) & 0x7fffffff) * oneUp31Bit)
#define BiRandGab   (FLOAT)((double) (holdrand = holdrand * -214013L + 2531011L) * oneUp31Bit)

void ikRangeRand(RANGERAND *p) { /* gab d5*/
	*p->out = randGab * (*p->max - *p->min) + *p->min;
}

void aRangeRand(RANGERAND *p) { /* gab d5*/
	FLOAT min = *p->min, max = *p->max, *out = p->out;
	long n = ksmps;
	
	do {
		*out++ = randGab * (max - min) + min;
	} while (--n);
}

void ikDiscreteUserRand(DURAND *p) { /* gab d5*/
    if (p->pfn != (long)*p->tableNum) {
		if ( (p->ftp = ftfindp(p->tableNum) ) == NULL) {
			sprintf(errmsg, "invalid table no. %f", *p->tableNum);
			perferror(errmsg);
			return ;
		}
		p->pfn = (long)*p->tableNum;
    }
	*p->out = p->ftp->ftable[(long)(randGab * p->ftp->flen+.5)];
}

void aDiscreteUserRand(DURAND *p) { /* gab d5*/
	FLOAT *out = p->out, *table;
	long n = ksmps, flen;

	if (p->pfn != (long)*p->tableNum) {
		if ( (p->ftp = ftfindp(p->tableNum) ) == NULL) {
			sprintf(errmsg, "invalid table no. %f", *p->tableNum);
			perferror(errmsg);
			return ;
		}
		p->pfn = (long)*p->tableNum;
    }
	table = p->ftp->ftable;
	flen = p->ftp->flen;
	do {
		*out++ = table[(long)(randGab * flen +.5)]; 
	} while (--n);
}


void ikContinuousUserRand(CURAND *p) { /* gab d5*/
	long indx;
	FLOAT findx, fract,v1,v2;
    if (p->pfn != (long)*p->tableNum) {
		if ( (p->ftp = ftfindp(p->tableNum) ) == NULL) {
			sprintf(errmsg, "invalid table no. %f", *p->tableNum);
			perferror(errmsg);
			return ;
		}
		p->pfn = (long)*p->tableNum;
    }
	findx = (float) (randGab * p->ftp->flen+.5);
	indx = (long) findx;
	fract = findx - indx;
    v1 = *(p->ftp->ftable + indx);
    v2 = *(p->ftp->ftable + indx + 1);
    *p->out = (v1 + (v2 - v1) * fract) * (*p->max - *p->min) + *p->min;
}

void aContinuousUserRand(CURAND *p) { /* gab d5*/
	FLOAT min = *p->min, max = *p->max;
	FLOAT *out = p->out, *table;
	long n = ksmps, flen, indx;
	FLOAT findx, fract,v1,v2;

    if (p->pfn != (long)*p->tableNum) {
		if ( (p->ftp = ftfindp(p->tableNum) ) == NULL) {
			sprintf(errmsg, "invalid table no. %f", *p->tableNum);
			perferror(errmsg);
			return ;
		}
		p->pfn = (long)*p->tableNum;
    }

	table = p->ftp->ftable;
	flen = p->ftp->flen;

	do {
		findx = (float) (randGab * flen + .5);
		indx = (long) findx;
		fract = findx - indx;
		v1 = table[indx];
		v2 = table[indx+1];
		*out++ = (v1 + (v2 - v1) * fract) * (max - min) + min;
		//*out++ = table[(long)(randGab * flen +.5)]  * (*max - *min) + *min; 
	} while (--n);
}


void randomi_set(RANDOMI *p)  
{
    p->cpscod = (p->XINCODE & 01) ? 1 : 0;
	p->dfdmax=0;
}

void krandomi(RANDOMI *p)
{					
    *p->ar = (p->num1 + (FLOAT)p->phs * p->dfdmax) * (*p->max - *p->min) + *p->min ;
    p->phs += (long)(*p->xcps * kicvt);	
    if (p->phs >= MAXLEN) {		
		p->phs &= PHMASK;		
		p->num1 = p->num2;
		p->num2 = randGab ;	
		p->dfdmax = (p->num2 - p->num1) / fmaxlen;
    }
}

void randomi(RANDOMI *p)
{
    long	phs = p->phs, inc;
    int		n = ksmps;
    FLOAT	*ar, *cpsp;
	FLOAT amp, min;
	
    cpsp = p->xcps;
	min = *p->min;
    amp =  (*p->max - min);
    ar = p->ar;
    inc = (long)(*cpsp++ * sicvt);
    do {
		*ar++ = (p->num1 + (FLOAT)phs * p->dfdmax) * amp + min;
		phs += inc;	
		if (p->cpscod)
			inc = (long)(*cpsp++ * sicvt);	
		if (phs >= MAXLEN) {
			phs &= PHMASK;
			p->num1 = p->num2;
			p->num2 = randGab; 
			p->dfdmax = (p->num2 - p->num1) / fmaxlen;
		}
    } while (--n);
    p->phs = phs;
}

void randomh_set(RANDOMH *p)
{
    p->cpscod = (p->XINCODE & 01) ? 1 : 0;
}

void krandomh(RANDOMH *p)
{
    *p->ar = p->num1 * (*p->max - *p->min) + *p->min;  
    p->phs += (long)(*p->xcps * kicvt) ;
		if (p->phs >= MAXLEN) {
			p->phs &= PHMASK;	
			p->num1 = randGab; 
			
		}
}

void randomh(RANDOMH *p)
{
    long	phs = p->phs, inc;
    int	n = ksmps;
    FLOAT	*ar, *cpsp;
	FLOAT amp, min;

    cpsp = p->xcps;
	min = *p->min;
    amp =  (*p->max - min);
    ar = p->ar;
    inc = (long)(*cpsp++ * sicvt);
    do {
		*ar++ = p->num1 * amp + min;	
		phs += inc;				
		if (p->cpscod)
			inc = (long)(*cpsp++ * sicvt);
		if (phs >= MAXLEN) {			
			phs &= PHMASK;
			p->num1 = randGab; 
		}
    } while (--n);
    p->phs = phs;
}



static int one2kicvt;


void jitter2_set(JITTER2 *p)
{
	if (   *p->cps1==0 && *p->cps2==0 && *p->cps2==0 /* accept default values */
		&& *p->amp1==0 && *p->amp2==0 && *p->amp3==0) 
		p->flag = 1;
	else
		p->flag = 0;
	p->dfdmax1 = p->dfdmax2 = p->dfdmax3 = 0;
}


void jitter2(JITTER2 *p)
{
    FLOAT out1,out2,out3;
	out1 = (p->num1a + (FLOAT)p->phs1 * p->dfdmax1);
	out2 = (p->num1b + (FLOAT)p->phs2 * p->dfdmax2);
	out3 = (p->num1c + (FLOAT)p->phs3 * p->dfdmax3);

	if (p->flag) { /* accept default values */
	   *p->out = (out1* .5f + out2 * .3f + out3* .2f ) * *p->gamp ;
	   p->phs1 += (long) (0.82071231913 * kicvt); 
	   p->phs2 += (long) (7.009019029039107 * kicvt);
	   p->phs3 += (long) (10 * kicvt);
	}
	else {
		*p->out = (out1* *p->amp1 + out2* *p->amp2 +out3* *p->amp3) * *p->gamp ;
		p->phs1 += (long)( *p->cps1 * kicvt);
		p->phs2 += (long)( *p->cps2 * kicvt);
		p->phs3 += (long)( *p->cps3 * kicvt);
	}
    if (p->phs1 >= MAXLEN) {		
		p->phs1 &= PHMASK;		
		p->num1a = p->num2a;
		p->num2a = BiRandGab ;	
		p->dfdmax1 = (p->num2a - p->num1a) / fmaxlen;
    }
    if (p->phs2 >= MAXLEN) {		
		p->phs2 &= PHMASK;		
		p->num1b = p->num2b;
		p->num2b = BiRandGab ;	
		p->dfdmax2 = (p->num2b - p->num1b) / fmaxlen;
    }
    if (p->phs3 >= MAXLEN) {		
		p->phs3 &= PHMASK;		
		p->num1c = p->num2c;
		p->num2c = BiRandGab ;	
		p->dfdmax3 = (p->num2c - p->num1c) / fmaxlen;
    }

}

void jitter_set(JITTER *p)
{
	p->num2 = BiRandGab;
	p->initflag=1;
}


void jitter(JITTER *p)
{
    if (p->initflag) {
		p->initflag = 0;
		*p->ar = p->num2 * *p->amp ;
		goto next;
	}
	*p->ar = (p->num1 + (FLOAT)p->phs * p->dfdmax) * *p->amp ;
    p->phs += (long)(p->xcps * kicvt);	

	if (p->phs >= MAXLEN) {
next:
		p->xcps =  randGab  * (*p->cpsMax - *p->cpsMin) + *p->cpsMin;
		p->phs &= PHMASK;		
		p->num1 = p->num2;
		p->num2 = BiRandGab ;	
		p->dfdmax = (p->num2 - p->num1) / fmaxlen;
    }
}

void jitters_set(JITTERS *p)
{
	p->num1 = BiRandGab;
	p->num2 = BiRandGab;
	p->df1=0;
	p->initflag=1;
	p->cod = (p->XINCODE & 02) ? 1 : 0;

}


void jitters(JITTERS *p)
{
	float	x, c3= p->c3, c2= p->c2;
	float	f0 = p->num0, df0= p->df0;

    if (p->initflag == 1) {
		p->initflag =0;
		goto next;
	}
	p->phs += p->si;
	if (p->phs >= 1.) {
		float	slope, resd1, resd0, f2, f1;
next:
		p->si =  (randGab  * (*p->cpsMax - *p->cpsMin) + *p->cpsMin)/ekr ;
		while (p->phs > 1.)
			p->phs -=1.;
		f0 = p->num0 = p->num1;
		f1 = p->num1 = p->num2;
		f2 = p->num2 = BiRandGab ;
		df0 = p->df0 = p->df1;
		p->df1 = ( f2  - f0 ) / 2.f;
		slope = f1 - f0 ;	
		resd0 = df0 - slope;		
		resd1 = p->df1 - slope;		
		c3 = p->c3 = resd0 + resd1;
		c2 = p->c2 = - (resd1 + 2.0f* resd0);
    }
	x= (float) p->phs;
	*p->ar = (((c3 * x + c2) * x + df0) * x + f0) * *p->amp ;
}

void jittersa(JITTERS *p)
{

	float	x, c3=p->c3, c2=p->c2;
	float   f0= p->num0, df0 = p->df0;
	float *ar = p->ar, *amp = p->amp;
	float  cpsMax = *p->cpsMax, cpsMin = *p->cpsMin;
	int		n = ksmps, cod = p->cod;
	double phs = p->phs, si = p->si;

    if (p->initflag) {
		p->initflag = 0;
		goto next;

	}
	do {
		phs += si;	
		if (phs >= 1.) {
			float	slope, resd1, resd0, f2, f1;
next:
			si =  (randGab  * (cpsMax - cpsMin) + cpsMin)/esr ;
			while (phs > 1.) 
				phs -=1.;
			f0 = p->num0 = p->num1;
			f1 = p->num1 = p->num2;
			f2 = p->num2 = BiRandGab ;
			df0 = p->df0 = p->df1;
			p->df1 = ( f2 - f0 )/ 2.f;
			slope = f1 - f0;	
			resd0 = df0 - slope;		
			resd1 = p->df1 - slope;		
			c3 = p->c3 = resd0 + resd1;
			c2 = p->c2 = - (resd1 + 2.0f* resd0);
		}
		x = (float) phs;
		*ar++ = (((c3 * x + c2) * x + df0) * x + f0) * *amp;
		if (cod) amp++;
	}while(--n);
	p->phs = phs;
	p->si =si;
}



void random3_set(RANDOM3 *p)
{
	p->num1 = randGab;
	p->num2 = randGab;
	p->df1=0;
	p->initflag=1;
	p->cod = (p->XINCODE & 02) ? 1 : 0;
}


void random3(RANDOM3 *p)
{
	float	x, c3= p->c3, c2= p->c2;
	float	f0 = p->num0, df0= p->df0;

    if (p->initflag) {
		p->initflag =0;
		goto next;
	}
	p->phs += p->si;
	if (p->phs >= 1.) {
		float	slope, resd1, resd0, f2, f1;
next:
		p->si =  (randGab  * (*p->cpsMax - *p->cpsMin) + *p->cpsMin)/ekr ;
		while (p->phs > 1.)
			p->phs -=1.;
		f0 = p->num0 = p->num1;
		f1 = p->num1 = p->num2;
		f2 = p->num2 = randGab ;
		df0 = p->df0 = p->df1;
		p->df1 = ( f2  - f0 ) / 2.f;
		slope = f1 - f0 ;	
		resd0 = df0 - slope;		
		resd1 = p->df1 - slope;		
		c3 = p->c3 = resd0 + resd1;
		c2 = p->c2 = - (resd1 + 2.0f* resd0);
    }
	x= (float) p->phs;
	*p->ar = (((c3 * x + c2) * x + df0) * x + f0) *
			  (*p->rangeMax - *p->rangeMin) + *p->rangeMin ;
}

void random3a(RANDOM3 *p)
{

	float	x, c3=p->c3, c2=p->c2;
	float   f0= p->num0, df0 = p->df0;
	float *ar = p->ar, *rangeMin = p->rangeMin;
	float *rangeMax = p->rangeMax;
	float cpsMin = *p->cpsMin, cpsMax = *p->cpsMax;
	int		n = ksmps, cod = p->cod;
	double phs = p->phs, si = p->si;

    if (p->initflag) {
		p->initflag = 0;
		goto next;

	}
	do {
		phs += si;	
		if (phs >= 1.) {
			float	slope, resd1, resd0, f2, f1;
next:
			si =  (randGab  * (cpsMax - cpsMin) + cpsMin)/esr ;
			while (phs > 1.) 
				phs -=1.;
			f0 = p->num0 = p->num1;
			f1 = p->num1 = p->num2;
			f2 = p->num2 = BiRandGab ;
			df0 = p->df0 = p->df1;
			p->df1 = ( f2 - f0 )/ 2.f;
			slope = f1 - f0;	
			resd0 = df0 - slope;		
			resd1 = p->df1 - slope;		
			c3 = p->c3 = resd0 + resd1;
			c2 = p->c2 = - (resd1 + 2.0f* resd0);
		}
		x = (float) phs;
		*ar++ = (((c3 * x + c2) * x + df0) * x + f0) * 
				(*rangeMax - *rangeMin) + *rangeMin;
		if (cod) {
			rangeMin++;
			rangeMax++;
		}
	}while(--n);
	p->phs = phs;
	p->si =si;
}


void vibrato_set(VIBRATO *p)
{
    FUNC	*ftp;

    if ((ftp = ftfind(p->ifn)) != NULL) {
      p->ftp = ftp;
      if (*p->iphs >= 0)
        p->lphs = ((long)(*p->iphs * fmaxlen)) & PMASK;
    }
	p->xcpsAmpRate = randGab  * (*p->cpsMaxRate - *p->cpsMinRate) + *p->cpsMinRate;
	p->xcpsFreqRate = randGab  * (*p->ampMaxRate - *p->ampMinRate) + *p->ampMinRate;
    p->tablen = ftp->flen;
	p->tablenUPkr = p->tablen /ekr;

}


void vibrato(VIBRATO *p)
{
 
    FUNC	*ftp;
    double	phs, inc;
    float   *ftab, fract, v1;
	extern FLOAT powof2(FLOAT x);
	FLOAT RandAmountAmp,RandAmountFreq;
	
	RandAmountAmp = (p->num1amp + (FLOAT)p->phsAmpRate * p->dfdmaxAmp) * *p->randAmountAmp ;
	RandAmountFreq = (p->num1freq + (FLOAT)p->phsFreqRate * p->dfdmaxFreq) * *p->randAmountFreq ;
  
	phs = p->lphs;
	ftp = p->ftp;
	if (ftp==NULL) {
          initerror("vibrato(krate): not initialized");
          return;
	}
	fract = (float) (phs - (long)phs);  
	ftab = ftp->ftable + (long)phs;
	v1 = *ftab++;
	*p->out = (v1 + (*ftab - v1) * fract) * (*p->AverageAmp * powof2(RandAmountAmp));
	inc = ( *p->AverageFreq * powof2(RandAmountFreq)) *  p->tablenUPkr; //(long)(( *p->AverageFreq * powof2(RandAmountFreq) ) * kicvt);
	phs += inc;
    while (phs >= p->tablen)
      phs -= p->tablen;
    while (phs < 0 )
      phs += p->tablen;	

	p->lphs = phs;

	p->phsAmpRate += (long)(p->xcpsAmpRate * kicvt);	
    if (p->phsAmpRate >= MAXLEN) {
		p->xcpsAmpRate =  randGab  * (*p->ampMaxRate - *p->ampMinRate) + *p->ampMinRate;
		p->phsAmpRate &= PHMASK;		
		p->num1amp = p->num2amp;
		p->num2amp = BiRandGab ;	
		p->dfdmaxAmp = (p->num2amp - p->num1amp) / fmaxlen;
    }

	p->phsFreqRate += (long)(p->xcpsFreqRate * kicvt);	
    if (p->phsFreqRate >= MAXLEN) {
		p->xcpsFreqRate =  randGab  * (*p->cpsMaxRate - *p->cpsMinRate) + *p->cpsMinRate;
		p->phsFreqRate &= PHMASK;		
		p->num1freq = p->num2freq;
		p->num2freq = BiRandGab ;	
		p->dfdmaxFreq = (p->num2freq - p->num1freq) / fmaxlen;
    }
}




void vibr_set(VIBR *p)	  /* faster and easier to use than vibrato, but less flexible */
{
	
    FUNC	*ftp;

	#define randAmountAmp	1.59055f   /* these default values are far from being the best */
	#define	randAmountFreq	0.629921f  /* if you think you found better ones, please tell me*/
	#define	ampMinRate		1.f 		  /* them by posting a message to g.maldonado@agora.stm.it */
	#define	ampMaxRate		3.f 
	#define	cpsMinRate		1.19377f
	#define	cpsMaxRate		2.28100f  
	#define	iphs			0.f

    if ((ftp = ftfind(p->ifn)) != NULL) {
      p->ftp = ftp;
      p->lphs = ((long)(iphs * fmaxlen)) & PMASK;
    }
	p->xcpsAmpRate = randGab  * (cpsMaxRate - cpsMinRate) + cpsMinRate;
	p->xcpsFreqRate = randGab  * (ampMaxRate - ampMinRate) + ampMinRate;
	p->tablen = ftp->flen;
	p->tablenUPkr = p->tablen /ekr;
}

void vibr(VIBR *p)
{
    FUNC	*ftp;
    double	phs, inc;
    float   *ftab, fract, v1;
	extern FLOAT powof2(FLOAT x);
	FLOAT rAmountAmp,rAmountFreq;
	
	rAmountAmp = (p->num1amp + (FLOAT)p->phsAmpRate * p->dfdmaxAmp) * randAmountAmp ;
	rAmountFreq = (p->num1freq + (FLOAT)p->phsFreqRate * p->dfdmaxFreq) * randAmountFreq ;
  
	phs = p->lphs;
	ftp = p->ftp;
	if (ftp==NULL) {
          initerror("vibrato(krate): not initialized");
          return;
	}
	fract = (float) (phs - (long)phs); //PFRAC(phs);
	ftab = ftp->ftable + (long)phs; //(phs >> ftp->lobits);
	v1 = *ftab++;
	*p->out = (v1 + (*ftab - v1) * fract) * (*p->AverageAmp * powof2(rAmountAmp));
	inc = ( *p->AverageFreq * powof2(rAmountFreq) ) *  p->tablenUPkr; // * kicvt);
	phs += inc;
    while (phs >= p->tablen)
      phs -= p->tablen;
    while (phs < 0 )
      phs += p->tablen;	
	p->lphs = phs;

	p->phsAmpRate += (long)(p->xcpsAmpRate * kicvt);	
    if (p->phsAmpRate >= MAXLEN) {
		p->xcpsAmpRate =  randGab  * (ampMaxRate - ampMinRate) + ampMinRate;
		p->phsAmpRate &= PHMASK;		
		p->num1amp = p->num2amp;
		p->num2amp = BiRandGab ;	
		p->dfdmaxAmp = (p->num2amp - p->num1amp) / fmaxlen;
    }

	p->phsFreqRate += (long)(p->xcpsFreqRate * kicvt);	
    if (p->phsFreqRate >= MAXLEN) {
		p->xcpsFreqRate =  randGab  * (cpsMaxRate - cpsMinRate) + cpsMinRate;
		p->phsFreqRate &= PHMASK;		
		p->num1freq = p->num2freq;
		p->num2freq = BiRandGab ;	
		p->dfdmaxFreq = (p->num2freq - p->num1freq) / fmaxlen;
    }
	#undef  randAmountAmp 
	#undef	randAmountFreq	 
	#undef	ampMinRate		 
	#undef	ampMaxRate		 
	#undef	cpsMinRate		 
	#undef	cpsMaxRate		  
	#undef	iphs			

}


void krsnsetx(KRESONX *p) /* Gabriel Maldonado, modifies for arb order */
{
    int scale;
    p->scale = scale = (int) *p->iscl;
    if((p->loop = (int) (*p->ord + .5)) < 1) p->loop = 4; /*default value*/
    if (!*p->istor && (p->aux.auxp == NULL ||
                      (int)(p->loop*2*sizeof(float)) > p->aux.size))
      auxalloc((long)(p->loop*2*sizeof(float)), &p->aux);
    p->yt1 = (float*)p->aux.auxp; p->yt2 = (float*)p->aux.auxp + p->loop;
    if (scale && scale != 1 && scale != 2) {
      sprintf(errmsg,"illegal reson iscl value, %f",*p->iscl);
      initerror(errmsg);
    }
    p->prvcf = p->prvbw = -100.0f;

    if (!(*p->istor)) {
      int j;
      for (j=0; j< p->loop; j++) p->yt1[j] = p->yt2[j] = 0.0f;
    }
}

void kresonx(KRESONX *p) /* Gabriel Maldonado, modified  */
{
    int	flag = 0, j;
    float	*ar, *asig;
    float	c3p1, c3t4, omc3, c2sqr;
    float *yt1, *yt2, c1,c2,c3; 
	
    if (*p->kcf != p->prvcf) {
		p->prvcf = *p->kcf;
		p->cosf = (float) cos((double)(*p->kcf * tpidsr * ksmps));
		flag = 1;
    }
    if (*p->kbw != p->prvbw) {
		p->prvbw = *p->kbw;
		p->c3 = (float) exp((double)(*p->kbw * mtpdsr * ksmps));
		flag = 1;
    }
    if (flag) {
		c3p1 = p->c3 + 1.0f;
		c3t4 = p->c3 * 4.0f;
		omc3 = 1.0f - p->c3;
		p->c2 = c3t4 * p->cosf / c3p1;		/* -B, so + below */
		c2sqr = p->c2 * p->c2;
		if (p->scale == 1)
			p->c1 = omc3 * (float)sqrt(1.0 - (double)(c2sqr / c3t4));
		else if (p->scale == 2)
			p->c1 = (float)sqrt((double)((c3p1*c3p1-c2sqr) * omc3/c3p1));
		else p->c1 = 1.0f;
    }
    c1=p->c1; 
    c2=p->c2;
    c3=p->c3;
    yt1= p->yt1;
    yt2= p->yt2;
    asig = p->asig;
	ar = p->ar;
    for (j=0; j< p->loop; j++) {
		*ar = c1 * *asig + c2 * *yt1 - c3 * *yt2;
		*yt2 = *yt1;
		*yt1 = *ar;
		yt1++;
		yt2++;
		asig= p->ar;
    }
}

/*-------------- END Gab --------------------------------------------*/ /* gab d5*/
