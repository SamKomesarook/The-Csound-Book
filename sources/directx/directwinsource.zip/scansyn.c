/* Scanned Synthesis Opcodes:
   scansyn.c, scansyn.csd, scansyn.h and related files
   are Copyright, 1999 by Interval Research.
   Coded by Paris Smaragdis
   From an algorithm by Bill Verplank, Max Mathews and Rob Shaw

   Permission to use, copy, or modify these programs and their documentation
   for educational and research purposes only and without fee is hereby
   granted, provided that this copyright and permission notice appear on all
   copies and supporting documentation. For any other uses of this software,
   in original or modified form, including but not limited to distribution in
   whole or in part, specific prior permission from Interval Research must be
   obtained. Interval Research makes no representations about the suitability
   of this software for any purpose. It is provided "as is" without express or
   implied warranty.
*/

/* Code fixes by John ffitch, March 2000 */

#include "cs.h"
#include "scansyn.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "window.h"


/* Order of interpolation of scanning */
/* Either 1, 2 (linear), 3 (cubic) or 4 (quadratic) */
#define OSCIL_INTERP 4

/* Order of interpolation of updating */
/* Either 2 (linear) or 3 (cubic) */
#define PHASE_INTERP 3

/* Window to be applied at external force */
static FLOAT *ewin = NULL;


/****************************************************************************
 *	Helper functions and macros for updater
 ***************************************************************************/

/*
 *	Wavetable init
 */
static void scsnu_initw(PSCSNU *p)
{
    int i;
    FUNC *fi = ftfind( p->i_init);
    if (fi->flen != p->len)
      die(Str(X_1484,"scsnu: Init table has bad size"));
    for (i = 0 ; i != p->len ; i++)
      p->x1[i] = fi->ftable[i];
}

/*
 *	Hammer hit
 */
static void scsnu_hammer(PSCSNU *p, FLOAT pos, FLOAT sgn)
{
    int i, i1, i2;
    FUNC *fi;
    FLOAT *f;
    FLOAT tab = *p->i_init;

    /* Get table */
    if (tab<0.0f) tab = -tab;   /* JPff fix here */
    fi = ftfind(&tab);

    /* Add hit */
    f = fi->ftable;
    i1 = (int)(p->len*pos-fi->flen/2);
    i2 = (int)(p->len*pos+fi->flen/2);
    for (i = i1 ; i < 0 ; i++){
      p->x1[p->len-i-1] += sgn * *f++;
#ifdef XALL
      p->x2[p->len-i-1] += sgn * *f++;
      p->x3[p->len-i-1] += sgn * *f++;
#endif
    }
    for (; i < p->len && i < i2 ; i++){
      p->x1[i] += sgn * *f++;
#ifdef XALL
      p->x2[i] += sgn * *f++;
      p->x3[i] += sgn * *f++;
#endif
    }
    for (; i < i2 ; i++){
      p->x1[i-p->len] += sgn * *f++;
#ifdef XALL
      p->x2[i-p->len] += sgn * *f++;
      p->x3[i-p->len] += sgn * *f++;
#endif
    }
}



/******************************
 *	Linked list stuff
 ******************************/

struct scsn_elem {
    PSCSNU		*p;
    struct scsn_elem	*next;
};

struct scsn_elem scsn_list = {NULL,NULL};

/* add to list */
void listadd(PSCSNU *p)
{
    struct scsn_elem *i = &scsn_list;
    while(i->next != NULL)
      i = i->next;
    i->next = (struct scsn_elem *)calloc(1, sizeof(struct scsn_elem));
    i->p = p;
    i->next = NULL;
}

/* remove from list */
void listrm(PSCSNU *p)
{
    struct scsn_elem *q;
    struct scsn_elem *i = &scsn_list;
    while (i->next->p != p){
      i = i->next;
      if (i == NULL)
        die(Str(X_1485,"Eek ... scan synthesis id wasn't found"));
    }
    q = i->next->next;
    free(i->next);
    i->next = q;
}

/* Return from list according to id */
PSCSNU *listget(int id)
{
    struct scsn_elem *i = &scsn_list;
    while (i->p->id != id){
      i = i->next;
      if (i == NULL)
        die(Str(X_1485,"Eek ... scan synthesis id wasn't found"));
    }
    return i->p;
}



/****************************************************************************
 *	Functions for scsnu
 ***************************************************************************/

/*
 *	Setup the updater
 */
void scsnu_init(PSCSNU *p)
{
    /* Get parameter table pointers and check lengths */
    FUNC *f;
    int len;

    /* Mass */
    f = ftfind(p->i_m);
    len = p->len = f->flen;
    p->m = f->ftable;

    /* Centering */
    f = ftfind(p->i_c);
    if (f->flen != len)
      die(Str(X_1486,
              "scsnu: Parameter tables should all have the same length"));
    p->c = f->ftable;

    /* Damping */
    f = ftfind(p->i_d);
    if (f->flen != len)
      die(Str(X_1486,"scsnu: Parameter tables should all have the same length"));
    p->d = f->ftable;

    /* Spring stiffness */
    {
      int i, j;

      /* Get the table */
      f = ftfind(p->i_f);

     /* Check that the size is good */
      if (f->flen < len*len)
        die(Str(X_1488,"scsnu: Spring matrix is too small"));

      /* Setup an easier addressing scheme */
      auxalloc(len*len * sizeof(FLOAT), &p->aux_f);
      p->f = (FLOAT*)p->aux_f.auxp;
      for (i = 0 ; i != len ; i++) {
        for (j = 0 ; j != len ; j++)
          p->f[i*len+j] = f->ftable[i*len+j];
      }
    }

/* Make buffers to hold data */
#if PHASE_INTERP == 3
    auxalloc(6*len*sizeof(FLOAT), &p->aux_x);
#else
    auxalloc(5*len, &p->aux_x);
#endif
    p->x0 = (FLOAT*)p->aux_x.auxp;
    p->x1 = p->x0 + len;
    p->x2 = p->x1 + len;
    p->ext = p->x2 + len;
    p->v = p->ext + len;
#if PHASE_INTERP == 3
    p->x3 = p->v + len;
#endif

    /* Initialize them ... */
    {
      int i;
      for (i = 0 ; i != len ; i++) {
        p->x0[i] = p->x1[i] = p->x2[i]= p->ext[i] = 0.0f;
#if PHASE_INTERP == 3
        p->x3[i] = 0.0f;
#endif
      }
    }

    /* ... according to scheme */
    if ((int)*p->i_init < 0){
      scsnu_hammer(p, *p->i_l, 1);
      scsnu_hammer(p, *p->i_r, -1);
    }
    else {
      if (*p->i_id<0.0f) scsnu_hammer( p, .5, 1);
      else scsnu_initw(p);
    }
    /* Velocity gets presidential treatment */
    {
      int i;
      FUNC *f = ftfind(p->i_v);
      if (f->flen != len)
        die(Str(X_1486,
                "scsnu: Parameter tables should all have the same length"));
      for (i = 0 ; i != len ; i++)
        p->v[i] = f->ftable[i];
    }

    /* Cache update rate over to local structure */
    p->rate = *p->i_rate * esr;

      /* Initialize index */
    p->idx = 0;

    /* External force index */
    p->exti = 0;

    /* Setup display window */
    if (*p->i_disp){
      p->win = calloc(1, sizeof(WINDAT));
      dispset((WINDAT*)p->win, p->x1, len,
              Str(X_1487,"Mass displaycement"), 0,
              Str(X_1489,"Scansynth window"));
    }

    /* Make external force window if we haven't so far */
    if (ewin == NULL){
      int i;
      FLOAT arg =  PI_F/(len-1);
      ewin = (FLOAT *)calloc(len, sizeof(FLOAT));
      for (i = 0 ; i != len-1 ; i++)
        ewin[i] = (FLOAT)sqrt(sin((double)arg*i));
      ewin[i] = 0.0f; /* You get NaN otherwise */
    }

    /* Throw data into list or use table */
    if (*p->i_id < 0.0f) {
      FLOAT id = - *p->i_id;
      FUNC *f = ftfind(&id);
      p->out = f->ftable;
      p->id = (int)*p->i_id;

    }
    else {
      p->id = (int)*p->i_id;
      listadd(p);
    }
}



/*
 *	Performance function for updater
 */

static FLOAT dt = 1.0f;

void scsnu_play(PSCSNU *p)
{
    int n;
    int len = p->len;

    for (n = 0 ; n != ksmps ; n++){

      /* Put audio input in external force */
      p->ext[p->exti] = p->a_ext[n];
      p->exti++;
      if (p->exti >= len)
        p->exti = 0;

      /* If it is time to calculate next phase, do it */
      if (p->idx >= p->rate){
        int i, j;
        for (i = 0 ; i != len ; i++){
          FLOAT a = 0.0f;
				/* Throw in audio drive */
          p->v[i] += p->ext[p->exti++] * ewin[i];
          if (p->exti >= len)
            p->exti = 0;
				/* And push feedback */
          scsnu_hammer(p, *p->k_x, *p->k_y);
				/* Estimate acceleration */
          for (j = 0 ; j != len ; j++)
            if (p->f[i*len+j])
              a += (p->x1[j] - p->x1[i]) * p->f[i*len+j] * *p->k_f;
          a += - p->x1[i] * p->c[i] * *p->k_c -
               (p->x2[i] - p->x1[i]) * p->d[i] * *p->k_d;
          a /= p->m[i] * *p->k_m;
				/* From which we get velocity */
          p->v[i] += dt * a;
				/* ... and future position */
          p->x0[i] += p->v[i] * dt;
        }
        /* Swap to get time order */
        for (i = 0 ; i != len ; i++) {
#if PHASE_INTERP == 3
          p->x3[i] = p->x2[i];
#endif
          p->x2[i] = p->x1[i];
          p->x1[i] = p->x0[i];
        }
        /* Reset index and display the state */
        p->idx = 0;
        if (*p->i_disp)
          display(p->win);
      }
      if (p->id<0) { /* Write to ftable */
        int i;
        FLOAT t = (FLOAT)p->idx / p->rate;
        for (i = 0 ; i != p->len ; i++) {
#if PHASE_INTERP == 3
          p->out[i] = p->x1[i] + t*(-p->x3[i]*0.5f +
                                    t*(p->x3[i]*0.5f - p->x1[i] + p->x2[i]*0.5f)
                                    + p->x2[i]*0.5f);
#else
          p->out[i] = (p->x2[i] + (p->x1[i] - p->x2[i]) * t);
#endif
        }
      }
      /* Update counter */
      p->idx++;
    }
}



/****************************************************************************
 *	Functions for scsns
 ***************************************************************************/


/*
 *	Succesive phase interpolator
 */
#if PHASE_INTERP == 3
#define pinterp(ii, t) \
	(p->p->x1[p->t[(int)ii]] + (-p->p->x3[p->t[(int)ii]]*0.5f + (p->p->x3[p->t[(int)ii]]*0.5f - p->p->x1[p->t[(int)ii]] + p->p->x2[p->t[(int)ii]]*0.5f) + p->p->x2[p->t[(int)ii]]*0.5f))
#else
#define pinterp(ii, t) \
	(p->p->x2[p->t[(int)ii]] + (p->p->x1[p->t[(int)ii]] - p->p->x2[p->t[(int)ii]]) * t)
#endif



/*
 *	Init scaner
 */
void scsns_init(PSCSNS *p)
{
    /* Get corresponding update */
    p->p = listget((int)*p->i_id);

    /* Get trajectory matrix */
    {
      int i;
      FUNC *t = ftfind(p->i_trj);
      p->tlen = t->flen;
      /* Check that trajectory is within bounds */
      for (i = 0 ; i != p->tlen ; i++)
        if (t->ftable[i] < 0 || t->ftable[i] >= p->p->len)
          die(Str(X_1490,"vermp: Trajectory table includes values out of range"));
      /* Allocate memory and pad to accomodate interpolation */
      auxalloc((p->tlen+OSCIL_INTERP-1)*sizeof(long), &p->aux_t);
      p->t = (long*)p->aux_t.auxp + (int)(OSCIL_INTERP-1)/2;
      /* Fill 'er up */
      for (i = 0 ; i != p->tlen ; i++)
        p->t[i] = (long)t->ftable[i];
      /* Do wraparounds */
      for (i = 1 ; i <= (OSCIL_INTERP-1)/2 ; i++)
        p->t[-i] = p->t[i];
      for (i = 0 ; i <= OSCIL_INTERP/2 ; i++)
        p->t[p->tlen+1] = p->t[i];
    }
    /* Reset oscillator phase */
    p->phs = 0;
    /* Oscillator ratio */
    p->fix = (FLOAT)p->tlen/esr;
}



/*
 *	Performance function for scanner
 */
void scsns_play(PSCSNS *p)
{
    int i;
    FLOAT phs = p->phs, inc = *p->k_freq * p->fix;
    FLOAT t = (FLOAT)p->p->idx/p->p->rate;

    for (i = 0 ; i != ksmps ; i++) {
      /* Do various interpolations to get output sample ... */
      {
#if OSCIL_INTERP == 4
        FLOAT x = phs - (int)phs;
        FLOAT y1 = pinterp(phs-1, t);
        FLOAT y2 = pinterp(phs  , t);
        FLOAT y3 = pinterp(phs+1, t);
        FLOAT y4 = pinterp(phs+2, t);

        p->a_out[i] = *p->k_amp *
          (y2 + x*(-y1/3.0f - y2*0.5f + y3 +
                   x*(y1*0.5f - y2 + y3*0.5f +
                      x*(-y1/6.0f + y2*0.5f - y3*0.5f + y4/6.0f)) - y4/6.0f));
#elif OSCIL_INTERP == 3
        FLOAT x = phs - (int)phs;
        FLOAT y1 = pinterp(phs-1, t);
        FLOAT y2 = pinterp(phs  , t);
        FLOAT y3 = pinterp(phs+1, t);

        p->a_out[i] = *p->k_amp *
          (y2 + x*(-y1*0.5f + x*(y1*0.5f - y2 + y3*0.5f) + y3*0.5f));
#elif OSCIL_INTERP == 2
        FLOAT x = phs - (int)phs;
        FLOAT y1 = pinterp(phs  , t);
        FLOAT y2 = pinterp(phs+1, t);

        p->a_out[i] = *p->k_amp * (y1 + x*(-y1 + y2));
#else
        p->a_out[i] = *p->k_amp * (pinterp(phs, t));
#endif
      }

		/* Update oscillator phase and wrap around if needed */
      phs += inc;
      if (phs >= p->tlen)
        phs -= p->tlen;
    }

    /* Remember phase */
    p->phs = phs;
}
