/********************************************/
/* wrap and mirror UGs by Gabriel Maldonado */
/********************************************/

typedef struct {
  OPDS  h;
  float *xdest, *xsig, *xlow, *xhigh;
} WRAP;


typedef struct {
  OPDS  h;
  float *kout, *ksig, *kthreshold, *kmode;
  float old_sig;
} TRIG;
 
typedef struct {
  OPDS  h;
  float *r, *val1, *val2, *point, *imin, *imax;
  float point_factor;
} INTERPOL;

typedef struct {
	OPDS	h;
	float	*xndx, *xfn, *kinterp, *ixmode, *outargs[VARGMAX];
} MTABLEI;

typedef struct {
	OPDS	h;
	float	*xndx, *xfn, *kinterp, *ixmode, *outargs[VARGMAX];
	int nargs;
	float  	xbmul;
	long  pfn, len;
	float	*ftable;
} MTABLE;

typedef struct {
	OPDS	h;
	float	*xndx, *xfn, *ixmode, *inargs[VARGMAX];
} MTABLEIW;

typedef struct {
	OPDS	h;
	float	*xndx, *xfn, *ixmode, *inargs[VARGMAX];
	int nargs;
	float  	xbmul;
	long  pfn, len;
	float	*ftable;
} MTABLEW;

typedef struct {
	OPDS	h;
	float	*xndx, *xfn, *inargs[VARGMAX];
} MTABIW;

typedef struct {
	OPDS	h;
	float	*xndx, *xfn, *inargs[VARGMAX];
	int nargs;
	//float  	xbmul;
	long  pfn, len;
	float	*ftable;
} MTABW;

typedef struct {
	OPDS	h;
	float	*xndx, *xfn, *outargs[VARGMAX];
} MTABI;

typedef struct {
	OPDS	h;
	float	*xndx, *xfn, *outargs[VARGMAX];
	int nargs;
	//float  	xbmul;
	long  pfn, len;
	float	*ftable;
} MTAB;

