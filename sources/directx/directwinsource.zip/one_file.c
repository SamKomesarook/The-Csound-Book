#include "cs.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static char buffer[200];
static char orcname[L_tmpnam+4];
       char sconame[L_tmpnam+4];
static char midname[L_tmpnam+4];
static int midiSet;
#ifndef TRUE
#define TRUE (1)
#define FALSE (0)
#endif

#ifdef CWIN
typedef void ExitFunction(void);
extern int cwin_atexit(ExitFunction*);
#endif

#ifdef WIN32
char *mytmpnam(char *a)
{
    char *dir = getenv("SFDIR");
    if (dir==NULL) dir=getenv("HOME");
    dir = _tempnam(dir, "cs");
    strcpy(a, dir);
    free(dir);
    return a;
}
#endif

#ifdef macintosh
#define fgets macgetstring
char macBuffer[200];
int macBufNdx = 200;
char *macgetstring(char *str, int num, FILE *stream)
{
    int bufferNdx = 0;
    size_t ourReturn;
    while (true) {
      if (macBufNdx >= 200) { /*then we must read in new buffer */
	macBufNdx = 0;
	ourReturn = fread(macBuffer, 1, num, stream);
	if (ourReturn == 0)
	  return NULL;
      }
      else {
	char c = macBuffer[macBufNdx];
	if (c == '\0' || c == '\n' || c == '\r') {
	  buffer[bufferNdx] = '\r';
	  if (bufferNdx < 199)
	    buffer[bufferNdx+1] = '\0';
	  macBufNdx++;
	  return buffer;
	}
	else {
	  buffer[bufferNdx] = c;
	  bufferNdx++;
	  macBufNdx++;
	}
      }
    }
}
#endif

static char *my_fgets(char *s, int n, FILE *stream)
{
    char *a = s;
    if (n <= 1) return NULL;                  /* best of a bad deal */
    do {
      int ch = getc(stream);
      if (ch == EOF) {                       /* error or EOF       */
        if (s == a) return NULL;         /* no chars -> leave  */
        if (ferror(stream)) a = NULL;
        break; /* add NULL even if ferror(), spec says 'indeterminate' */
      }
      if ((*s++ = ch) == '\n') break;
      if (*(s-1) == '\r') break;
    }
    while (--n > 1);
    *s = 0;
    return a;
}


/*static*/ void deleteOrch(void) /* gab A8*/
{
    remove(orcname);
}

/*static*/ void deleteScore(void) /* gab A8*/
{
    remove(sconame);
}

static void deleteMIDI(void)
{
    remove(midname);
}

static     char files[1000];
extern int argdecode(int, char**, char**, char*);

int readOptions(FILE *unf)
{
    char *p;
    int argc = 0;
    char *argv[100];
    char *filnamp = files;
	
    while (fgets(buffer, 200, unf)!= NULL) {
		if (strstr(buffer,"</CsOptions>") == buffer) {
			return TRUE;
		}
		argc = 1;
		p = buffer;
		while (*p == ' ' || *p == '\t') p++;  /*gab a8*/  /* Ignore leading spaces and tab (gab A8)*/
      if (*p==';' || *p=='#') continue; /* Comment line? */
      if (*p=='\n' || *p=='\r' || *p==13 || *p==10) continue; /* Empty line? */
		argv[1] = p;
		while (*p != '\0') { 
			if (*p==' ') {
				*p++ = '\0';
#ifdef _DEBUG
			  printf("argc=%d argv[%d]=%s\n", argc, argc, argv[argc]);
#endif
				while (*p == ' ') p++;
				argv[++argc] = p;
			}
			else if (*p=='\n' || *p == '\r' || *p==13 || *p==10) { /*gab A8*/
				*p = '\0';
				break;
			}
			p++;
		}
#ifdef _DEBUG
      printf("argc=%d argv[%d]=%s\n", argc, argc, argv[argc]);
#endif
      argdecode(argc, argv, &filnamp, getenv("SFOUTYP")); /* Read an argv thing */
    }
    return FALSE;
}

static int createOrchestra(FILE *unf)
{
    char *p;
    FILE *orcf;
    printf("Creating...\n");
	
    tmpnam(orcname);		/* Generate orchestra name */
    if ((p=strchr(orcname, '.')) != NULL) *p='\0'; /* with extention */
    strcat(orcname, ".orc");
    orcf = fopen(orcname, "wt"); /* gab c3 */
    printf("Creating %s (%p)\n", orcname, orcf);
    if (orcf==NULL){
		perror("Failed to create\n");
		exit(1);
    }
    while (fgets(buffer, 200, unf)!= NULL) {
		if (strstr(buffer,"</CsInstruments>") == buffer) {
			fclose(orcf);
			atexit(deleteOrch);
			return TRUE;
      }
      else fputs(buffer, orcf);
    }
    return FALSE;
}


static int createScore(FILE *unf)
{
    char *p;
    FILE *scof;

    tmpnam(sconame);		/* Generate score name */
    if ((p=strchr(sconame, '.')) != NULL) *p='\0'; /* with extention */
    strcat(sconame, ".sco");
    scof = fopen(sconame, "wt"); /* gab c3 */
	/*RWD 3:2000*/
    if (scof==NULL)
      return FALSE;

    while (my_fgets(buffer, 200, unf)!= NULL) {
      if (strstr(buffer,"</CsScore>") == buffer) {
	fclose(scof);
	atexit(deleteScore);
	return TRUE;
      }
      else fputs(buffer, scof);
    }
    return FALSE;
}

static int createMIDI(FILE *unf)
{
    int size;
    char *p;
    FILE *midf;
    int c;

    if (tmpnam(midname)==NULL) { /* Generate MIDI file name */
      printf(Str(X_206,"Cannot create temporary file for MIDI subfile\n"));
      exit(1);
    }
    if ((p=strchr(midname, '.')) != NULL) *p='\0'; /* with extention */
    strcat(midname, ".mid");
    midf = fopen(midname, "wb");
    if (midf==NULL) {
      printf(Str(X_217,"Cannot open temporary file (%s) for MIDI subfile\n"), midname);
      exit(1);
    }
    my_fgets(buffer, 200, unf);
    if (sscanf(buffer, Str(X_464,"Size = %d"), &size)==0) {
      printf(Str(X_255,"Error in reading MIDI subfile -- no size read\n"));
      exit(1);
    }
    for (; size > 0; size--) {
      c = getc(unf);
      putc(c, midf);
    }
    fclose(midf);
    atexit(deleteMIDI);
    midiSet = TRUE;
    while (TRUE) {
      if (my_fgets(buffer, 200, unf)!= NULL) {
        if (strstr(buffer,"</CsMidifile>") == buffer) {
          return TRUE;
        }
      }
    }
    return FALSE;
}


check_empty(char *buf)  /*gab A8*/
{
	while (*buf) {
		if (*buf !=' ' && *buf !='\t' && *buf !=13 &&  *buf !=10) {
			if (*buf == ';') return 1;
			else	return 0;
		}
		buf++;
	}
	return 1;
}

static int eat_to_eol(char *buf)
{
    int i=0;

    while(buf[i] != '\n' && buf[i] != '\r')
        ++i;

    return i;	/* keep the \n for further processing */
}

int blank_buffer(void)
{
    int i=0;
    if (buffer[i] == ';')
      i += eat_to_eol(&buffer[i]);
    while (buffer[i]!='\n' && buffer[i]!='\0') {
      if (buffer[i]!=' ' && buffer[i]!='\t') return FALSE;
	  i++;	  /* gab e4*/
    }
    return TRUE;
}

int read_unified_file(char *name, char **score)
{
    extern void dies(char *s, char *t); /*gab A8*/
	//FILE *unf  = fopen(name, "rt"); /* gab c3 */
    FILE *unf  = fopen(name, "rb"); /* Need to open in binary to deal with
                                       MIDI and the like. */
	int flscore=0; /* gab d4*/
    int result = TRUE;
    int started = FALSE;
	/*RWD 3:2000  fopen can fail...*/
    if (unf==NULL)
		dies ("error opening unified file %s", name); /* gab A8 */
    orcname[0] = sconame[0] = midname[0] = '\0';
	midiSet = FALSE;
	
	printf("Calling unified file system with %s\n", name);
    while (my_fgets(buffer, 200, unf)) {
		if (strstr(buffer,"<CsoundSynthesizer>") == buffer ||
			strstr(buffer,"<CsoundSynthesiser>") == buffer) {
			printf(Str(X_453,"STARTING FILE\n"));
			started = TRUE;
		}
		else if (strstr(buffer,"</CsoundSynthesizer>") == buffer ||
			strstr(buffer,"</CsoundSynthesiser>") == buffer)	{
			strcpy(name, orcname);
			*score = sconame;
			if (midiSet) {
				O.FMidiname = midname;
				O.FMidiin = 1;
			}
			fclose(unf);
			if (!flscore) *score = NULL;  /* gab d4*/
			return result;
		}
		else if (strstr(buffer,"<CsOptions>") == buffer) {
			printf(Str(X_233,"Creating options\n"));
			result = (result && readOptions(unf));
		}
		/*        else if (strstr(buffer,"<CsFunctions>") == buffer) { */
		/*  	importFunctions(unf); */
		/*        } */
		else if (strstr(buffer,"<CsInstruments>") == buffer) {
			printf(Str(X_234,"Creating orchestra\n"));
			result = (result && createOrchestra(unf));
		}
		/*  	  else if (strstr(buffer,"<CsArrangement>") == buffer) { */
		/*  	    importArrangement(unf); */
		/*  	  } */
		else if (strstr(buffer,"<CsScore>") == buffer) {
			printf(Str(X_235,"Creating score\n"));
			result = (result && createScore(unf));
			flscore=1; /* gab d4*/
		}
/*  	  else if (strstr(buffer,"<CsTestScore>") == buffer) { */
/*  	    importTestScore(unf); */
/*  	  } */
		else if (strstr(buffer,"<CsMidifile>") == buffer) {
			result = (result && createMIDI(unf));
		}
		else if (blank_buffer()) continue;
		else if (check_empty(buffer)) ;/*gab A8*/
		else if (started && strchr(buffer, '<') == buffer) {
			printf(Str(X_510,"unknown command :%s\n"), buffer);
		}
		else {                    /* Quietly skip unknown text */
			/* printf(Str(X_510,"unknown command :%s\n"), buffer); */
		}
    }
    fclose(unf);
	if (!flscore) *score = NULL;  /* gab d4*/
    return result;
}

