/* Spectral Extraction and Amplitude Gating functions */
/* By Richard Karpen  June, 1998  */
/* Based on ideas from Tom Erbe's SoundHack  */

/* Predeclare Functions */

void SpectralExtract(FLOAT  *, FLOAT *, long, long, int, FLOAT);
FLOAT PvocMaxAmp( FLOAT *, long, long);
void PvAmpGate(FLOAT *, long, FUNC *, FLOAT);
