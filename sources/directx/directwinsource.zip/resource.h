//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Dialog.rc
//
#define MainDialog                      101
#define InputBoxGabFrame                102
#define iddNoArguments                  103
#define iddAbout                        104
#define IDI_ICON1                       105
#define IDB_BITMAP1                     109
#define IDB_BITMAP2                     112
#define IDC_CURSOR1                     113
#define QuitButton                      1001
#define IDC_Suppress                    1005
#define ID_display                      1006
#define EditInputBox                    1007
#define TestoInputBox                   1008
#define OkInputBox                      1009
#define idcBufferScrollBar              1011
#define idcBufferLabel                  1012
#define idcSleep                        1013
#define idcEnableFileOutput             1014
#define idcEditOutputFile               1015
#define IDC_BUTTON1                     1016
#define idcStart                        1016
#define IDC_BUTTON2                     1017
#define idcPause                        1017
#define idcBrowse                       1018
#define idcBrowseOut                    1018
#define idcStartStop                    1019
#define idcOrcFile                      1020
#define idcScoFile                      1021
#define idcOutFile                      1023
#define idcBrowseOrc                    1024
#define idcBrowseSco                    1025
#define idNoArgOkButton                 1026
#define idcGruppo1                      1027
#define idcBSizeLabel                   1028
#define idcAbout                        1029
#define idcAboutAuthor                  1030
#define idcAboutQuickRef                1031
#define idAboutOK                       1032
#define idcQrefLabel                    1033
#define idcCopyright                    1034
#define idcRestart                      1036
#define idcEditOrc                      1038
#define idcEditSco                      1039
#define idcFlags                        1041

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        114
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1042
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
