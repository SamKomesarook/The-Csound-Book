#include <stdio.h>
#include <string.h>
#include "cs.h"  
#include "fout.h"  

void wavWriteHdr2(FILE * fd, int sampsize, int nchls, double sr);
void wavReWriteHdr2(FILE * fd, long datasize);
extern long kcounter;
extern float onedkr;

struct	fileinTag {
	FILE* file;
	char name[256];
} file_opened[30];

int file_num=0;


void outfile_float (OUTFILE *p) 
{
	int nsmps= ksmps, j, nargs = p->nargs,k=0;
	float **args = p->argums;
	do {
		for (j = 0;j< nargs;j++) 	
			fwrite( &(args[j][k]), sizeof(float),1,p->fp);
		k++;
	} while (--nsmps);
}


void outfile_int (OUTFILE *p) 
{
	int nsmps= ksmps, j,nargs = p->nargs,k=0;
	float **args = p->argums;
	short temp;
	do {
		for (j = 0;j< nargs;j++) {
			temp = (short)	 args[j][k];
			fwrite( &temp, sizeof(short),1,p->fp);
		}
		k++;
	} while (--nsmps);
}


void outfile_int_head (OUTFILE *p) 
{
	int nsmps= ksmps, j,nargs = p->nargs,k=0;
	float **args = p->argums;
	short temp;
    do {
		for (j = 0;j< nargs;j++) {
			temp = (short)	 args[j][k];
			fwrite( &temp, sizeof(short),1,p->fp);
		}
		k++;
	} while (--nsmps);
	if (!(kcounter % 50))
		wavReWriteHdr2(p->fp, kcounter * ksmps * sizeof(short)*nargs); 
}




void outfile_set(OUTFILE *p) 
{
	if (*p->fname == sstrcod) { /* if char string name given */
		int j;	
		char fname[256];
		extern EVTBLK *currevent;
		extern char *unquote(char *name);
		if (p->STRARG == NULL) strcpy(fname,unquote(currevent->strarg)); 
		else strcpy(fname, unquote(p->STRARG));
		for (j=0; j<file_num || file_opened[j].name == NULL; j++) {
			if (!strcmp(file_opened[j].name,fname)) {
				p->fp = file_opened[j].file;
				goto done;
			}
		}
		if( (access( fname, 0 )) != -1 ) { /* if file exists */
			if (access(fname, 0x6)) /* check its access state */
				chmod(fname, S_IREAD | S_IWRITE); /* ... and make it read-write if necessary*/
		}
		if (( p->fp = fopen(fname,"wb")) == NULL)
			dies("fout: cannot open outfile %s",fname);
		else { /* put the file in the opened stack */
			strcpy(file_opened[file_num].name, fname); 
			file_opened[file_num].file=p->fp;
			file_num++;
		}
	}
	else { /* file handle as argument */
		if ( (p->fp = file_opened[(int) *p->fname].file) == NULL) 
			die("fout: invalid file handle"); 
	}
done:
	p->nargs = p->INOCOUNT-2 ; 
	switch((int) (*p->iflag+.5)) {
	case 0:
		p->outfilep =  (void(*)(void *)) outfile_float;
		break;
	case 1:
		p->outfilep = (void(*)(void *)) outfile_int;
		break;
	case 2:
		p->outfilep = (void(*)(void *)) outfile_int_head;
		wavWriteHdr2(               /* Write WAV header at start of file.  */
			p->fp,                  /* Called after open, before data writes*/
			2,						/* sample size in bytes */
			p->nargs,
			esr);          
		break;
	default:
		p->outfilep = (void(*)(void *)) outfile_int;
	}
	
}

void outfile (OUTFILE *p) 
{
	p->outfilep(p);
}

void koutfile_float (KOUTFILE *p) 
{
	int j, nargs = p->nargs;
	float **args = p->argums;
	for (j = 0;j< nargs;j++) 	
		fwrite( args[j], sizeof(float),1,p->fp);
}


void koutfile_int (KOUTFILE *p) 
{
	int j,nargs = p->nargs;
	float **args = p->argums;
	short temp;
		for (j = 0;j< nargs;j++) {
			temp = (short)	 *(args[j]);
			fwrite( &temp, sizeof(short),1,p->fp);
		}
}






void koutfile_set(KOUTFILE *p) 
{
	if (*p->fname == sstrcod) {/*gab B1*/ /* if char string name given */
		int j;	
		char fname[256];
		extern EVTBLK *currevent; /*gab B1*/
		extern char *unquote(char *name);
		if (p->STRARG == NULL) strcpy(fname,unquote(currevent->strarg)); /*gab B1*/
		else strcpy(fname, unquote(p->STRARG));
		//} 
		// else dies ("fout: problems opening outfile %s",fname);
		for (j=0; j<file_num || file_opened[j].name == NULL; j++) {
			if (!strcmp(file_opened[j].name,fname)) {
				p->fp = file_opened[j].file;
				goto done;
			}
		}
		if( !(access( fname, 0 )) ) { /* if file exists */
			if (access(fname, 0x6)) /* check its access state */
				chmod(fname, S_IREAD | S_IWRITE); /* ... and make it read-write if necessary*/
		}
		if (( p->fp = fopen(fname,"wb")) == NULL)
			dies("foutk: cannot open outfile %s",fname);
		else { /* put the file in the opened stack */
			strcpy(file_opened[file_num].name, fname);  
			file_opened[file_num].file=p->fp;
			file_num++;
		}
	}
	else { /* file handle argument */
		if ( (p->fp = file_opened[(int) *p->fname].file) == NULL) 
			die("fout: invalid file handle"); 
	}
done:
	
	
	switch((int) (*p->iflag+.5)) {
	case 0:
		p->koutfilep = (void(*)(void *)) koutfile_float;
		break;
	case 1:
		p->koutfilep = (void(*)(void *)) koutfile_int;
		break;
	default:
		p->koutfilep = (void(*)(void *)) koutfile_int;
	}
	p->nargs = p->INOCOUNT-2 ; 
}

void koutfile (KOUTFILE *p) 
{
	p->koutfilep(p);
}


/*--------------*/


/* syntax: 
	ihandle fiopen "filename" [, iascii]
*/
void fiopen(FIOPEN *p) /* open a file and return its handle */
{						/* the handle is simply a stack index */
	char fname[256];
	char omode[4];
	FILE *fp;
	strcpy(fname, unquote(p->STRARG));	

	if( (access( fname, 0 )) != -1 ) {/* if file exists */
		 if (access(fname, 0x6)) /* check its access state */
			  chmod(fname, S_IREAD | S_IWRITE); /* ... and make it read-write if necessary*/
	}
	switch ((int) *p->iascii) {
		case 0:
			strcpy(omode, "wt"); 
			break;
		case 1:
			strcpy(omode, "rt");
			break;
		case 2:
			strcpy(omode, "wb");
			break;
		case 3:
			strcpy(omode, "rb");
			break;
	}
	if (( fp = fopen(fname,omode)) == NULL)
		    dies("fout: cannot open outfile %s",fname);
	strcpy(file_opened[file_num].name, fname);
	file_opened[file_num].file=fp;
	*p->ihandle = (float) file_num;
	file_num++;
	
}

/* syntax: 
		fouti  ihandle, iascii, iflag, iarg1 [,iarg2,....,iargN]
*/

long kreset=0;
void ioutfile_set(IOUTFILE *p)
{
	int j;
	float **args=p->argums;
	FILE *fil = file_opened[(int) *p->ihandle].file;
	if (fil == NULL) die("fouti: invalid file handle");
	if (*p->iascii == 0) { /* ascii format */
		switch ((int) *p->iflag) {
		case 1: { /* whith prefix (i-statement, p1, p2 and p3) */
			int p1 = (int) p->h.insdshead->insno;
			double p2 =   (double) kcounter * onedkr ;
			double p3 = p->h.insdshead->p3;
			if (p3 > 0.) 
				fprintf(fil, "i %i %f %f ", p1, p2, p3);
			else
				fprintf(fil, "i %i %f . ", p1, p2);
				}
			break;
		case 2: /* whith prefix (start at 0 time) */
			if (kreset == 0) kreset = kcounter;
			{
				int p1 = (int) p->h.insdshead->insno;
				double p2= (double) (kcounter - kreset) * onedkr ;
				double p3 = p->h.insdshead->p3;
				if (p3 > 0.)
					fprintf(fil, "i %i %f %f ", p1, p2, p3);
				else
					fprintf(fil, "i %i %f . ", p1, p2);
			}
			break;
		case 3: /* reset */ 
			kreset=0;
			return;
			
		}
		for (j=0; j < p->INOCOUNT - 3;j++) {
			fprintf( fil, " %f",(double) *args[j]);
		}
		putc('\n',fil);
	}
	else { /* binary format */
		for (j=0; j < p->INOCOUNT - 3;j++) {   /*fwrite( const void *buffer, size_t size, size_t count, FILE *stream );*/
			fwrite(args[j], sizeof(float),1, fil );
		}
	}
}


void ioutfile_set_r(IOUTFILE_R *p)
{
    short *xtra;
	if (*(xtra = &(p->h.insdshead->xtratim)) < 1 )  /* gab-a5 revised */
		*xtra = 1;
	p->counter =  kcounter ;
	p->done=1;
	if (*p->iflag==2)
		if (kreset == 0) kreset = kcounter;
	

}


void ioutfile_r(IOUTFILE_R *p)
{
	if (p->h.insdshead->relesing) {
		if (p->done) {
			int j;
			float **args=p->argums;
			FILE *fil = file_opened[(int) *p->ihandle].file;
			if (fil == NULL) die("fouti: invalid file handle");
			if (*p->iascii == 0) { /* ascii format */
				switch ((int) *p->iflag) { 
				case 1:	{	/* whith prefix (i-statement, p1, p2 and p3) */
					int p1 = (int) p->h.insdshead->insno;
					double p2 = p->counter * onedkr;
					double p3 = (double) (kcounter-p->counter) * onedkr ;
					fprintf(fil, "i %i %f %f ", p1, p2, p3);	
						}
					break;
				case 2: /* whith prefix (start at 0 time) */
					{
						int p1 = (int) p->h.insdshead->insno;
						double p2 = (p->counter - kreset) *onedkr ;
						double p3 = (double) (kcounter-p->counter) * onedkr;
						fprintf(fil, "i %i %f %f ", p1, p2, p3);	
					}
					break;
				case 3: /* reset */
					kreset=0;
					return;
				}
				for (j=0; j < p->INOCOUNT - 3;j++) {
					fprintf( fil, " %f",(double) *args[j]);
				}
				putc('\n',fil);
			}
			else { /* binary format */
				for (j=0; j < p->INOCOUNT - 3;j++) {   /*fwrite( const void *buffer, size_t size, size_t count, FILE *stream );*/
					fwrite(args[j], sizeof(float),1, fil );
				}
			}
			p->done = 0;
		}
	}
}



/*----------------------------------*/

void infile_float (INFILE *p) 
{
	int nsmps= ksmps, j, nargs = p->nargs,k=0;
	float **args = p->argums;
	if (p->flag) {
		fseek(p->fp, p->currpos*sizeof(float)*nargs ,SEEK_SET);
		p->currpos+=nsmps;
		do {
			for (j = 0;j< nargs;j++) {
				if(fread( &(args[j][k]), sizeof(float),1,p->fp)) ;
				else {
					p->flag = 0;	
					args[j][k] = 0.;
				}
			}
			k++;
		} while (--nsmps);
	}
	else { /* after end of file */
		do {
			for (j = 0;j< nargs;j++) 
					args[j][k] = 0.;
			k++;
		} while (--nsmps);
	}
}


void infile_int (INFILE *p) 
{
	int nsmps= ksmps, j,nargs = p->nargs,k=0;
	float **args = p->argums;
	short temp;
	if (p->flag) {
		fseek(p->fp, p->currpos*sizeof(short)*nargs ,SEEK_SET);
		p->currpos+=nsmps;
		do {
			for (j = 0;j< nargs;j++) {
				if(fread( &temp, sizeof(short),1,p->fp))
					args[j][k] = (float) temp;
				else {
					p->flag = 0;	
					args[j][k] = 0.;
				}
			}
			k++;
		} while (--nsmps);
	}
	else {  /* after end of file */
		do {
			for (j = 0;j< nargs;j++) 
					args[j][k] = 0.;
			k++;
		} while (--nsmps);
	}
}




void infile_set(INFILE *p) 
{
    if (*p->fname == sstrcod) { /* if char string name given */
		int j;
		extern EVTBLK *currevent;
		extern char *unquote(char *name);
		char fname[256];
		if (p->STRARG == NULL) strcpy(fname,unquote(currevent->strarg));
		else strcpy(fname, unquote(p->STRARG));
		for (j=0; j<file_num || file_opened[j].name == NULL; j++) {
			if (!strcmp(file_opened[j].name,fname)) {
				p->fp = file_opened[j].file;
				goto done;
			}
		}
		if( (access( fname, 0 )) != -1 ) { /* if file exists */
			 if (access(fname, 0x6)) /* check its access state */
				  chmod(fname, S_IREAD | S_IWRITE); /* ... and make it read-write if necessary*/
		}
		if (( p->fp = fopen(fname,"rb")) == NULL)
			   dies("fin: cannot open infile %s",fname);
		else { /* put the file in the opened stack */
			strcpy(file_opened[file_num].name, fname);
			file_opened[file_num].file=p->fp;
			file_num++;
		}
	} 
	else { /* file handle argument */
		if ( (p->fp = file_opened[(int) *p->fname].file) == NULL) 
			die("fin: invalid file handle"); 
	}
done:
	switch((int) (*p->iflag+.5)) {
		case 0:
			p->infilep = (void(*)(void *)) infile_float;
			break;
		case 1:
			p->infilep = (void(*)(void *)) infile_int;
			break;
		default:
			p->infilep = (void(*)(void *)) infile_int;
	}
	p->nargs = p->INOCOUNT-3 ; 
	p->currpos = (long) *p->iskpfrms;
	p->flag=1;
}

void infile (INFILE *p) 
{
	p->infilep(p);
}


/*----------------------------*/


void kinfile_float (KINFILE *p) 
{
	int j, nargs = p->nargs;
	float **args = p->argums;
	if (p->flag) {
		fseek(p->fp, p->currpos*sizeof(float)*nargs ,SEEK_SET);
		p->currpos++;
		for (j = 0;j< nargs;j++) {
			if(fread(args[j], sizeof(float),1,p->fp)) ;
			else {
				p->flag = 0;
				*(args[j]) = 0.;
			}
		}
	}
	else { /* after end of file */
		for (j = 0; j < nargs; j++)
				*(args[j]) = 0.;
	}
}


void kinfile_int (KINFILE *p) 
{
	int j,nargs = p->nargs;
	float **args = p->argums;
	short temp;
	if (p->flag) {
		fseek(p->fp, p->currpos*sizeof(short)*nargs ,SEEK_SET);
		p->currpos++;
		for (j = 0;j< nargs;j++) {
			if(fread( &temp, sizeof(short),1,p->fp))
				*(args[j]) = (float) temp;
			else {
				p->flag = 0;	
				*(args[j]) = 0.;
			}
		}
	}
	else {  /* after end of file */
		for (j = 0;j< nargs;j++) 
				*(args[j]) = 0.;
	}
}


void kinfile_set(KINFILE *p) 
{
    if (*p->fname == sstrcod) { /* if char string name given */
		int j;
		extern EVTBLK *currevent;
		extern char *unquote(char *name);
		char fname[256];
		if (p->STRARG == NULL) strcpy(fname,unquote(currevent->strarg)); /*gab B1*/
		else strcpy(fname, unquote(p->STRARG));
		for (j=0; j<file_num || file_opened[j].name == NULL; j++) {
			if (!strcmp(file_opened[j].name,fname)) {
				p->fp = file_opened[j].file;
				goto done;
			}
		}
		if( (access( fname, 0 )) != -1 ) { /* if file exists */
			 if (access(fname, 0x6)) /* check its access state */
				  chmod(fname, S_IREAD | S_IWRITE); /* ... and make it read-write if necessary*/
		}
		if (( p->fp = fopen(fname,"rb")) == NULL)
			   dies("fin: cannot open infile %s",fname);
		else { /* put the file in the opened stack */
			strcpy(file_opened[file_num].name, fname);
			file_opened[file_num].file=p->fp;
			file_num++;
		}
	} 
	else {/* file handle argument */
		if ( (p->fp = file_opened[(int) *p->fname].file) == NULL) 
			die("fink: invalid file handle"); 
	}
done:
	switch((int) (*p->iflag+.5)) {
		case 0:
			p->kinfilep = (void(*)(void *)) kinfile_float;
			break;
		case 1:
			p->kinfilep = (void(*)(void *)) kinfile_int;
			break;
		default:
			p->kinfilep = (void(*)(void *)) kinfile_int;
	}
	p->nargs = p->INOCOUNT-3 ; 
	p->currpos = (long) *p->iskpfrms;
	p->flag=1;
}


void kinfile (KINFILE *p) 
{
	p->kinfilep(p);
}



void i_infile(I_INFILE *p) 
{
    int j, nargs;
	FILE *fp;
	float **args = p->argums;
	if (*p->fname == sstrcod) {/* if char string name given */
		char fname[256] , omode[4];
		extern EVTBLK *currevent; 
		extern char *unquote(char *name);
		
		if (p->STRARG == NULL) strcpy(fname,unquote(currevent->strarg)); 
		else strcpy(fname, unquote(p->STRARG));
		for (j=0; j<file_num || file_opened[j].name == NULL; j++) {
			if (!strcmp(file_opened[j].name,fname)) {
				fp = file_opened[j].file;
				goto done;
			}
		}
		if( (access( fname, 0 )) != -1 ) { /* if file exists */
			if (access(fname, 0x6)) /* check its access state */
				chmod(fname, S_IREAD | S_IWRITE); /* ... and make it read-write if necessary*/
		}
		switch ((int) (*p->iflag+.5)) {
		case 0:
		case 1:
			strcpy(omode, "rt"); 
			break;
		case 2:
			strcpy(omode, "rb"); 
			break;
		}
		if (( fp = fopen(fname,omode)) == NULL)
			dies("fin: cannot open infile %s",fname);
		else { /* put the file in the opened stack */
			strcpy(file_opened[file_num].name, fname);
			file_opened[file_num].file=fp;
			file_num++;
		}
	} 
	else {/* file handle argument */
		if ( (fp = file_opened[(int) *p->fname].file) == NULL) 
			die("fink: invalid file handle"); 
	}
done:
	nargs = p->INOCOUNT-3 ; 
	switch((int) (*p->iflag+.5)) {
		
	case 0: /* ascii file with loop */
		{
			char cf[20], *cfp;
newcycle:
			for (j = 0;j< nargs;j++) {
				cfp = cf;
				while ((*cfp=getc(fp)) == 'i' 
					|| *cfp == ' '
					|| *cfp == '/t'
					|| *cfp == '/n') ;
				if (*cfp == EOF) {
					fseek(fp, 0 ,SEEK_SET);
					goto newcycle;
				}
				while ((*cfp >= '0'	&& *cfp <= '9')	|| *cfp == '.')  
				{
					*(++cfp) = getc(fp);
				}
				*(args[j]) = (float) atof (cf);
				if (*cfp == EOF) {
					fseek(fp, 0 ,SEEK_SET);
					break;
				}
			}
		}
		break;
	case 1: /* ascii file without loop */
		{
			char cf[20], *cfp;
			for (j = 0;j< nargs;j++) {
				cfp = cf;
				while ((*cfp=getc(fp)) == 'i' 
					|| *cfp == ' '
					|| *cfp == '/t'
					|| *cfp == '/n') ;
				if (*cfp == EOF) {
					*(args[j]) = 0;	
					break;
				}
				while ((*cfp >= '0'	&& *cfp <= '9')	|| *cfp == '.')  
				{
					*(++cfp) = getc(fp);
				}
				*(args[j]) = (float) atof (cf);
				if (*cfp == EOF) {
					*(args[j]) = 0;	
					break;
				}
			}
		}
		break;
	case 2: /* binary floats without loop */
		fseek(fp, p->currpos*sizeof(float)*nargs ,SEEK_SET);
		p->currpos++;
		for (j = 0;j< nargs;j++) {
			if(fread(args[j], sizeof(float),1,fp)) ;
			else {
				p->flag = 0;
				*(args[j]) = 0.;
			}
		}
		break;
	}
}

/*---------------------------*/

void incr (INCR *p)
{
	float *avar = p->avar, *aincr = p->aincr;
	int nsmps= ksmps;
	do 	*(avar++) += *(aincr++);
	while (--nsmps);
}


void clear (CLEARS *p)
{
	int nsmps= ksmps,j;
	float *avar;
	for (j=0;j< p->INOCOUNT;j++) {
		avar = p->argums[j];
		nsmps= ksmps;
		do 	*(avar++) = 0.;
		while (--nsmps);
	}
}


void sum(SUM *p)
{
	int nsmps=ksmps, count=(int) p->INOCOUNT,j,k=0;
	float *ar = p->ar, **args = p->argums;
	do {
		*ar=0.;
		for (j=0; j<count; j++) {
			*ar += args[j][k];
		}
		k++;
		ar++;
	} while (--nsmps);
}

/* Actually by JPff but after Gabriel */
void product(SUM *p)
{
    int nsmps=ksmps, count=(int) p->INOCOUNT,j,k=0;
    FLOAT *ar = p->ar, **args = p->argums;
    do {
      *ar=1.0f;
      for (j=0; j<count; j++)
 	*ar *= args[j][k];
      k++;
      ar++;
    } while (--nsmps);
}


/***********************************************/
/* WAV HEADER ROUTINES DERIVED By THOSE OF RWD */
/***********************************************/

#include        "soundio.h"
#include        "wave.h"
#include        "sfheader.h"
#include        <math.h>
static struct wav_head formhdr;
static long   framesize;
/* RWD.2.98 to avoid recalculating  variable  headersizes */
static long	this_hdrsize	= 0;
static short	this_format	= 0;
static long	datasize_offset	= 0;
static long	factchunk_offset= 0;
static long	nchans		= 0;


static short lenshort(short sval) /* coerce a natural short into a littlendian short */
{
    char  benchar[2];
    char *p = benchar;

    *p++ = 0xFF & sval;
    *p   = 0xFF & (sval >> 8);
    return(*(short *)benchar);
}

static long lenlong(long lval)     /* coerce a natural long into a littlendian long */
{
    char  benchar[4];
    char *p = benchar;

    *p++ = (char)(0xFF & lval);
    *p++ = (char)(0xFF & (lval >> 8));
    *p++ = (char)(0xFF & (lval >> 16));
    *p   = (char)(0xFF & (lval >> 24));
    return(*(long *)benchar);
}

static short natlshort(short sval) /* coerce a littlendian short into a natural short */
{
    unsigned char benchar[2];
    short natshort;

    *(short *)benchar = sval;
    natshort = benchar[1];
    natshort <<= 8;
    natshort |= benchar[0];
    return(natshort);
}

static long natllong(long lval)     /* coerce a littlendian long into a natural long */
{
    unsigned char benchar[4];
    unsigned char *p = benchar + 3;
    long natlong;

    *(long *)benchar = lval;
    natlong = *p--;
    natlong <<= 8;
    natlong |= *p--;
    natlong <<= 8;
    natlong |= *p--;
    natlong <<= 8;
    natlong |= *p;
    return(natlong);
}

/* RWD.2.98 many changes to set correct variable-header length etc */
void wavWriteHdr2(               /* Write WAV header at start of file.  */
    FILE *fd,                     /* Called after open, before data writes*/
    int sampsize,               /* sample size in bytes */
    int nchls,
    double sr)                  /* sampling rate */
{
       
	long databytes;
#ifdef DEBUG
        printf("wavWriteHdr: fd %d sampsize %d nchls %d sr %lf\n",
                fd,sampsize,nchls,sr);
#endif
        framesize = sampsize * nchls;
        databytes = 0;          /* reset later by wavReWriteHdr */

        formhdr.magic = *((long *)RIFF_ID);
        formhdr.len0 = lenlong(databytes + 36/*WAVHDRSIZ*/); 
        formhdr.magic1 = *((long *)WAVE_ID);
        formhdr.magic2 = *((long *)FMT_ID);
        /*formhdr.len = lenlong((long)16);        /* length of format chunk */
/* RWD.2.98 */
        this_format = (short)(sampsize==4 ? 3 : 1);
        formhdr.format = lenshort(this_format); /* PCM */		
        formhdr.len = this_format == 3 ? lenlong(18L) : lenlong(16L);
        nchans	= nchnls;       /* RWD for wavReWriteHdr() for fact chunk */
        formhdr.nchns = lenshort((short)nchls);
        formhdr.rate = lenlong((long)sr);
        formhdr.aver = lenlong((long)(sr * framesize));
        formhdr.nBlockAlign = lenshort((short)framesize); /* bytes per frame */
        formhdr.size = lenshort((short)(8 * sampsize));	/* bits per sample */
	/* RWD.2.98 have to do these later */
#if 0
        formhdr.magic3 = *((long *)DATA_ID);
        formhdr.datasize = lenlong(databytes);
#endif
        if (!fwrite((char *)&formhdr, sizeof(formhdr),1,fd))
            die("error writing WAV header");
        /* RWD add cbSize if format = 3 */
        if (this_format==3){
          short cbSize = 0;
          long factid = *((long *)FACT_ID);
          long chunksize = lenlong( sizeof(long));
          long factdata = 0;    /* filled in later... */
          if ((!fwrite((char *) &cbSize,sizeof(short),1,fd))
              || (!fwrite((char *)&factid,sizeof(long),1,fd))
              || (!fwrite((char *)&chunksize,sizeof(long),1,fd))
              || (!(factchunk_offset = fseek(fd,0,SEEK_CUR)) )
              || (!fwrite((char *)&factdata,sizeof(long),1,fd)))
            die("error writing WAV header");
          /* add statutory fact chunk for non-PCM formats */
        }
	/* RWD.2.98 then write data chunk info */
        {
          long magic3 = *((long *)DATA_ID);
          long datasize = lenlong(databytes);
          if ((!fwrite((char *)&magic3,  sizeof(long),1,fd)
              || ((fseek(fd,0,SEEK_CUR)))
              || (!fwrite((char *)&datasize,sizeof(long),1,fd))))
            die("error writing WAV header");
        }
        datasize_offset=ftell(fd)-sizeof(long);
		this_hdrsize = datasize_offset+sizeof(long);
}


void wavReWriteHdr2(FILE *fd,     /* Write proper sizes into WAV header  */
                   long datasize) /*        called before closing file   */
{                                 /*        & optionally under -R        */
     
	long  endpos = ftell(fd);
    /* RWD.2.98: all changed to deal with variable headersize */
    long length = lenlong(endpos-8);
    long size = lenlong(datasize);
    long size_in_samps = lenlong((datasize / sizeof(float)) / nchans);/* for fact chunk */
    if (endpos != datasize + this_hdrsize)
      die("inconsistent WAV size"); /* RWD.2.98: should be able to fudge something! */
    if (fseek(fd, 4L, 0)<0
        || !fwrite((char *)&length, sizeof(long),1,fd) 
        || (fseek(fd,datasize_offset,0))
        || !fwrite((char *)&size,sizeof(long),1,fd) )
      die("error rewriting WAV header");
    /* update fact chunk if non-PCM format */
    if (this_format==(short)3)
      if ((fseek(fd,factchunk_offset,0))
          || (!fwrite((char *)&size_in_samps,sizeof(long),1,fd)))
        die("error rewriting WAV header");		
    fseek(fd, endpos, 0);
}
