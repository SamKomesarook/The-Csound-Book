# define VERSION (4)
# define SUBVER  (01)
# define VERSIONSTRING  " v4.05"
# define DIRECTCSOUND_VERSION "4.65"

