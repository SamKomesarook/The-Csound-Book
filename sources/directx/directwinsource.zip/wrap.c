/********************************************/
/* wrap and mirror UGs by Gabriel Maldonado */
/********************************************/

#include "cs.h"  
#include "wrap.h"
#include <math.h>


void wrap(WRAP *p)
{
    register float 	*adest= p->xdest;
    register float  *asig = p->xsig;
    register float	xlow, xhigh, xsig; 
    register int loopcount = ksmps;

    if ((xlow=*p->xlow) >= (xhigh=*p->xhigh))	{
        register float 	xaverage;
        xaverage = (xlow + xhigh) / 2;
        do *adest++ = xaverage;
        while (--loopcount);
    }
	else  do {
		if ((xsig=(float) *asig++) >= xlow )	
			*adest++ = (float)(xlow + fmod(xsig - xlow, fabs(xlow-xhigh)));
		else	
			*adest++ = (float)(xhigh- fmod(xhigh- xsig, fabs(xlow-xhigh)));
	} while (--loopcount);
}


void kwrap(WRAP *p)
{
    register float xsig, xlow, xhigh;

    if ((xlow=*p->xlow) >= (xhigh=*p->xhigh)) *p->xdest = (xlow + xhigh) / 2;  
    else {
		if ((xsig=*p->xsig) >= xlow )	
			*p->xdest = (float)(xlow + fmod(xsig - xlow, fabs(xlow-xhigh)));
		else							
			*p->xdest = (float)(xhigh- fmod(xhigh- xsig, fabs(xlow-xhigh)));
	}
}


/*---------------------------------------------------------------------*/


void kmirror(WRAP *p)
{
    register float  xsig, xlow, xhigh;
    xsig = *p->xsig;
    xhigh= *p->xhigh;
    xlow = *p->xlow;

    if (xlow >= xhigh) 	*p->xdest = (xlow + xhigh) / 2;  
    else {
      kw_label:
        if ((xsig <= xhigh) && (xsig >= xlow)) 	*p->xdest = xsig;
        else {
            if (xsig > xhigh){ 
                xsig = xhigh+xhigh - xsig;
                goto kw_label;
            }
            else {
                xsig = xlow + xlow - xsig  ;
                goto kw_label;
            }
        }
    }
}


void mirror(WRAP *p)
{
    register float 	*adest, *asig;
    register float	xlow, xhigh, xaverage, xsig; 
    register int loopcount = ksmps;

    adest = p->xdest;
    asig  = p->xsig;
    xlow = *p->xlow;
    xhigh = *p->xhigh;

    if (xlow >= xhigh)	{
        xaverage = (xlow + xhigh) / 2;
        do *adest++ = xaverage;
        while (--loopcount);
    }

    do	{
        xsig = *asig++;
      w_label:
        if ((xsig <= xhigh) && ( xsig >= xlow ))   *adest++ = xsig;
        else {
            if (xsig > xhigh){
                xsig = xhigh+xhigh - xsig;
                goto w_label;
            }
            else {
                xsig = xlow+xlow - xsig;
                goto w_label;
            }
        }
    } while (--loopcount);
}


void trig_set(TRIG *p)	 /* trig by G.Maldonado */
{
	p->old_sig = 0.0;

}

void trig(TRIG *p)
{
 	switch ((int) (*p->kmode + .5)) {
		case	0:	  /* down-up */
			if (p->old_sig <= *p->kthreshold && *p->ksig > *p->kthreshold ) 
				*p->kout = 1.;
			else
				*p->kout = 0.;
			break;
		case	1:	 /* up-down */
			if (p->old_sig >= *p->kthreshold && *p->ksig < *p->kthreshold ) 
				*p->kout = 1.;
			else
				*p->kout = 0.;
			break;
		case	2:	 /* both */
			if 	((p->old_sig <= *p->kthreshold && *p->ksig > *p->kthreshold) ||
				 (p->old_sig >= *p->kthreshold && *p->ksig < *p->kthreshold ) )
				*p->kout = 1.;
			else
				*p->kout = 0.;
			break;  
		default: 
			perferror(" bad imode value");
	}
 	p->old_sig = *p->ksig;
}

/*--------------------------------*/

void mtable_i(MTABLEI *p)
{
	
	FUNC *ftp;
	int j, nargs;
	float *table, xbmul, *out = *p->outargs;
	if ((ftp = ftfind(p->xfn)) == NULL) {
		  initerror("mtablei: incorrect table number");
          return;
	}
	table = ftp->ftable;
	nargs = p->INOCOUNT-4;
	if (*p->ixmode)
		xbmul = (float) (ftp->flen / nargs);

	if (*p->kinterp) {
		float 	v1, v2 ;
		float fndx = (*p->ixmode) ? *p->xndx * xbmul : *p->xndx;
		long indx = (long) fndx;
		float fract = fndx - indx;
		for (j=0; j < nargs; j++) {
		    v1 = table[indx * nargs + j];
			v2 = table[(indx + 1) * nargs + j];
			*out++ = v1 + (v2 - v1) * fract;
		}
	}
	else {
		long indx = (*p->ixmode) ? (long)(*p->xndx * xbmul) : (long) *p->xndx;
		for (j=0; j < nargs; j++)
			*out++ =  table[indx * nargs + j];
	}
}

void mtable_set(MTABLE *p)	 /* mtab by G.Maldonado */
{
	FUNC *ftp;
	if ((ftp = ftfind(p->xfn)) == NULL) {
		  initerror("mtable: incorrect table number");
          return;
	}
	p->ftable = ftp->ftable;
	p->nargs = p->INOCOUNT-4;
	p->len = ftp->flen / p->nargs;
	p->pfn = (long) *p->xfn;
	if (*p->ixmode)
		p->xbmul = (float) ftp->flen / p->nargs;
}

void mtable_k(MTABLE *p)
{
	int j, nargs = p->nargs;
	float *out = *p->outargs;
	float *table;
	long len;
    if (p->pfn != (long)*p->xfn) {
		FUNC *ftp;
		if ( (ftp = ftfindp(p->xfn) ) == NULL) {
			perferror("mtable: incorrect table number");
			return;
		}
		p->pfn = (long)*p->xfn;
		p->ftable = ftp->ftable;
		p->len = ftp->flen / nargs;
		if (*p->ixmode)
			p->xbmul = (float) ftp->flen / nargs;
    }
	table= p->ftable;
	len = p->len;
	if (*p->kinterp) {
		float fndx;
		long indx;
		float fract;
		long indxp1;
		float 	v1, v2 ;
		fndx = (*p->ixmode) ? *p->xndx * p->xbmul : *p->xndx;
		if (fndx >= len)
			fndx = (float) fmod(fndx, len);
		indx = (long) fndx;
		fract = fndx - indx;
		indxp1 = (indx < len-1) ? (indx+1) * nargs : 0;
		indx *=nargs;
		for (j=0; j < nargs; j++) {
		    v1 = table[indx + j];
			v2 = table[indxp1 + j];
			*out++ = v1 + (v2 - v1) * fract;
		}
	}
	else {
		long indx = (*p->ixmode) ? ((long)(*p->xndx * p->xbmul) % len) * nargs : ((long) *p->xndx % len ) * nargs ;
		for (j=0; j < nargs; j++)
			*out++ =  table[indx + j];
	}
}

void mtable_a(MTABLE *p)
{
	int j, nargs = p->nargs;
	int	nsmps = ksmps, ixmode = (int) *p->ixmode, k=0;
	float **out = p->outargs;
	float *table;
	float *xndx = p->xndx, xbmul;
	long len;

    if (p->pfn != (long)*p->xfn) {
		FUNC *ftp;
		if ( (ftp = ftfindp(p->xfn) ) == NULL) {
			perferror("mtable: incorrect table number");
			return;
		}
		p->pfn = (long)*p->xfn;
		p->ftable = ftp->ftable;
		p->len = ftp->flen / nargs;
		if (ixmode)
			p->xbmul = (float) ftp->flen / nargs;
    }
	table = p->ftable;
	len = p->len;
	xbmul = p->xbmul;
	if (*p->kinterp) {
		float fndx;
		long indx;
		float fract;
		long indxp1;
		do {
			float 	v1, v2 ;
			fndx = (ixmode) ? *xndx++ * xbmul : *xndx++;
			if (fndx >= len)
				fndx = (float) fmod(fndx, len);
			indx = (long) fndx;
			fract = fndx - indx;
			indxp1 = (indx < len-1) ? (indx+1) * nargs : 0;
			indx *=nargs;
			for (j=0; j < nargs; j++) {
				v1 = table[indx + j];
				v2 = table[indxp1 + j];
				out[j][k] = v1 + (v2 - v1) * fract;
				
			}
			k++;
		} while(--nsmps);

	}
	else {
		do {
			long indx = (ixmode) ? ((long)(*xndx++ * xbmul)%len) * nargs : ((long) *xndx++ %len) * nargs;
			for (j=0; j < nargs; j++) {
				out[j][k] =  table[indx + j];
			}
			k++;
		} while(--nsmps);
	}
}




//////////// mtab start /////////////


void mtab_i(MTABI *p)
{
	FUNC *ftp;
	int j, nargs;
	long indx;
	float *table, /* xbmul, */ *out = *p->outargs;
	if ((ftp = ftfind(p->xfn)) == NULL) {
		  initerror("mtabi: incorrect table number");
          return;
	}
	table = ftp->ftable;
	nargs = p->INOCOUNT-2;

	indx = (long) *p->xndx;
	for (j=0; j < nargs; j++)
			*out++ =  table[indx * nargs + j];
}

void mtab_set(MTAB *p)	 /* mtab by G.Maldonado */
{
	FUNC *ftp;
	if ((ftp = ftfind(p->xfn)) == NULL) {
		  initerror("mtable: incorrect table number");
          return;
	}
	p->ftable = ftp->ftable;
	p->nargs = p->INOCOUNT-2;
	p->len = ftp->flen / p->nargs;
	p->pfn = (long) *p->xfn;
}

void mtab_k(MTAB *p)
{
	int j, nargs = p->nargs;
	float *out = *p->outargs;
	float *table;
	long len, indx;
    /*
	if (p->pfn != (long)*p->xfn) {
		FUNC *ftp;
		if ( (ftp = ftfindp(p->xfn) ) == NULL) {
			perferror("mtable: incorrect table number");
			return;
		}
		p->pfn = (long)*p->xfn;
		p->ftable = ftp->ftable;
		p->len = ftp->flen / nargs;
		if (*p->ixmode)
			p->xbmul = (float) ftp->flen / nargs;
    } */
	table= p->ftable;
	len = p->len;
	indx = ((long) *p->xndx % len ) * nargs ;
	for (j=0; j < nargs; j++)
			*out++ =  table[indx + j];
}

void mtab_a(MTAB *p)
{
	int j, nargs = p->nargs;
	int	nsmps = ksmps,  /* ixmode = (int) *p->ixmode, */ k=0;
	float **out = p->outargs;
	float *table;
	float *xndx = p->xndx /*, xbmul */;
	long len;
	/*
    if (p->pfn != (long)*p->xfn) {
		FUNC *ftp;
		if ( (ftp = ftfindp(p->xfn) ) == NULL) {
			perferror("mtable: incorrect table number");
			return;
		}
		p->pfn = (long)*p->xfn;
		p->ftable = ftp->ftable;
		p->len = ftp->flen / nargs;
		if (ixmode)
			p->xbmul = (float) ftp->flen / nargs;
    } */
	table = p->ftable;
	len = p->len;
	//xbmul = p->xbmul;
	do {
			long indx = ((long) *xndx++ %len) * nargs;
			for (j=0; j < nargs; j++) {
				out[j][k] =  table[indx + j];
			}
			k++;
	} while(--nsmps);
	
}


//////////// mtab end ///////////////


void mtablew_i(MTABLEIW *p)
{
	
	FUNC *ftp;
	int j, nargs;
	long indx;
	float *table, xbmul, *in = *p->inargs;
	if ((ftp = ftfind(p->xfn)) == NULL) {
		  initerror("mtablewi: incorrect table number");
          return;
	}
	table = ftp->ftable;
	nargs = p->INOCOUNT-3;
	if (*p->ixmode)
		xbmul = (float) (ftp->flen / nargs);
	indx = (*p->ixmode) ? (long)(*p->xndx * xbmul) : (long) *p->xndx;
	for (j=0; j < nargs; j++)
		//*out++ =  table[indx * nargs + j];
		table[indx * nargs + j] = *in++;
}


void mtablew_set(MTABLEW *p)	 /* mtabw by G.Maldonado */
{
	FUNC *ftp;
	if ((ftp = ftfind(p->xfn)) == NULL) {
		  initerror("mtabw: incorrect table number");
          return;
	}
	p->ftable = ftp->ftable;
	p->nargs = p->INOCOUNT-3;
	p->len = ftp->flen / p->nargs;
	p->pfn = (long) *p->xfn;
	if (*p->ixmode)
		p->xbmul = (float) ftp->flen / p->nargs;
}

void mtablew_k(MTABLEW *p)
{
	int j, nargs = p->nargs;
	float *in = *p->inargs;
	float *table;
	long len, indx;
    if (p->pfn != (long)*p->xfn) {
		FUNC *ftp;
		if ( (ftp = ftfindp(p->xfn) ) == NULL) {
			perferror("mtabw: incorrect table number");
			return;
		}
		p->pfn = (long)*p->xfn;
		p->ftable = ftp->ftable;
		p->len = ftp->flen / nargs;
		if (*p->ixmode)
			p->xbmul = (float) ftp->flen / nargs;
    }
	table= p->ftable;
	len = p->len;
	indx = (*p->ixmode) ? ((long)(*p->xndx * p->xbmul) % len) * nargs : ((long) *p->xndx % len ) * nargs ;
	for (j=0; j < nargs; j++)
		table[indx + j] = *in++;
}

void mtablew_a(MTABLEW *p)
{
	int j, nargs = p->nargs;
	int	nsmps = ksmps, ixmode = (int) *p->ixmode, k=0;
	float **in = p->inargs;
	float *table;
	float *xndx = p->xndx, xbmul;
	long len;

    if (p->pfn != (long)*p->xfn) {
		FUNC *ftp;
		if ( (ftp = ftfindp(p->xfn) ) == NULL) {
			perferror("mtabw: incorrect table number");
			return;
		}
		p->pfn = (long)*p->xfn;
		p->ftable = ftp->ftable;
		p->len = ftp->flen / nargs;
		if (ixmode)
			p->xbmul = (float) ftp->flen / nargs;
    }
	table = p->ftable;
	len = p->len;
	xbmul = p->xbmul;
	do {
		long indx = (ixmode) ? ((long)(*xndx++ * xbmul)%len) * nargs : ((long) *xndx++ %len) * nargs;
		for (j=0; j < nargs; j++) {
			table[indx + j] = in[j][k];
		}
		k++;
	} while(--nsmps);
}

////////////////////////////////////////

void mtabw_i(MTABIW *p)
{
	FUNC *ftp;
	int j, nargs;
	long indx;
	float *table, *in = *p->inargs;
	if ((ftp = ftfind(p->xfn)) == NULL) {
		  initerror("mtabwi: incorrect table number");
          return;
	}
	table = ftp->ftable;
	nargs = p->INOCOUNT-2;
	indx = (long) *p->xndx;
	for (j=0; j < nargs; j++)
		table[indx * nargs + j] = *in++;
}

void mtabw_set(MTABW *p)	 /* mtabw by G.Maldonado */
{
	FUNC *ftp;
	if ((ftp = ftfind(p->xfn)) == NULL) {
		  initerror("mtabw: incorrect table number");
          return;
	}
	p->ftable = ftp->ftable;
	p->nargs = p->INOCOUNT-2;
	p->len = ftp->flen / p->nargs;
	p->pfn = (long) *p->xfn;
//	if (*p->ixmode)
//		p->xbmul = (float) ftp->flen / p->nargs;
}

void mtabw_k(MTABW *p)
{
	int j, nargs = p->nargs;
	float *in = *p->inargs;
	float *table;
	long len, indx;
    if (p->pfn != (long)*p->xfn) {
		FUNC *ftp;
		if ( (ftp = ftfindp(p->xfn) ) == NULL) {
			perferror("mtablew: incorrect table number");
			return;
		}
		p->pfn = (long)*p->xfn;
		p->ftable = ftp->ftable;
		p->len = ftp->flen / nargs;
//		if (*p->ixmode)
//			p->xbmul = (float) ftp->flen / nargs;
    }
	table= p->ftable;
	len = p->len;
	//indx = (*p->ixmode) ? ((long)(*p->xndx * p->xbmul) % len) * nargs : ((long) *p->xndx % len ) * nargs ;
	indx = ((long) *p->xndx % len ) * nargs ;
	for (j=0; j < nargs; j++)
		table[indx + j] = *in++;
}

void mtabw_a(MTABW *p)
{
	int j, nargs = p->nargs;
	int	nsmps = ksmps, /* ixmode = (int) *p->ixmode, */ k=0;
	float **in = p->inargs;
	float *table;
	float *xndx = p->xndx /*  , xbmul */;
	long len;

    if (p->pfn != (long)*p->xfn) {
		FUNC *ftp;
		if ( (ftp = ftfindp(p->xfn) ) == NULL) {
			perferror("mtabw: incorrect table number");
			return;
		}
		p->pfn = (long)*p->xfn;
		p->ftable = ftp->ftable;
		p->len = ftp->flen / nargs;
//		if (ixmode)
//			p->xbmul = (float) ftp->flen / nargs;
    }
	table = p->ftable;
	len = p->len;
//	xbmul = p->xbmul;
	do {
		//long indx = (ixmode) ? ((long)(*xndx++ * xbmul)%len) * nargs : ((long) *xndx++ %len) * nargs;
		long indx = ((long) *xndx++ %len) * nargs;
		for (j=0; j < nargs; j++) {
			table[indx + j] = in[j][k];
		}
		k++;
	} while(--nsmps);
}





/*-------------------------------*/

/* interpolation opcodes by G.Maldonado */
void interpol(INTERPOL *p)
{
	float point_value = (float)((*p->point - *p->imin ) * (1./(*p->imax - *p->imin)));
	*p->r = point_value * (*p->val2 - *p->val1) + *p->val1;
}

void nterpol_init(INTERPOL *p)
{
	p->point_factor = 1.0f/(*p->imax - *p->imin) ;
}

void knterpol(INTERPOL *p)
{
 	float point_value = (*p->point - *p->imin ) * p->point_factor;
 	*p->r = point_value * (*p->val2 - *p->val1) + *p->val1;
}

void anterpol(INTERPOL *p)
{
    
 	register float point_value = (*p->point - *p->imin ) * p->point_factor;
    register float *out = p->r, *val1 = p->val1, *val2 = p->val2;
	register int loopcount = ksmps;
    do	{
	 	*out++ = point_value * (*val2++ - *val1) + *val1++;
    } while (--loopcount);


}



