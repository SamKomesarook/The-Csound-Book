typedef	struct {
  OPDS	h;
  FLOAT	*r1, *ifilno;
} SNDINFO;

typedef	struct {
  OPDS	h;
  FLOAT	*r1, *ifilno, *channel;
} SNDINFOPEAK;
