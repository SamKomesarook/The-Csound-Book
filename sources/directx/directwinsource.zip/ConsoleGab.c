					
/* some routines for Windows by Gabriel Maldonado */
#include <windows.h>
#include "cs.h"
#include <stdio.h>

#include "version.h"

int rows=0 , columns=0;
int exit_soon_flag=0;
void exit_soon() { exit_soon_flag=1;}

#ifndef GAB_WIN	//1

void set_rows(int n) {
	rows = n;
}

void set_columns( int n) {
 	columns = n;
}



BOOL WINAPI ctrlC( DWORD dwCtrlType )
{ 	
	if (dwCtrlType == CTRL_C_EVENT ) fcloseall();
	return FALSE;
}

void console_init()
{
	BOOL ret;
	ret=SetConsoleCtrlHandler(ctrlC,TRUE);
}

void console_rows()
{
	HANDLE cons_handle;
	COORD coord, firstcell;
	DWORD scritti;
	int xret;

	if (!columns && rows) columns=81;
	if (!rows && columns) rows = 26;
	coord.X=columns;
	coord.Y=rows;
 	firstcell.X=0;
	firstcell.Y=0;
 	cons_handle=GetStdHandle(STD_OUTPUT_HANDLE	);
	//if (columns || rows)
	xret = SetConsoleScreenBufferSize(cons_handle, coord);
	/*
	xret = SetConsoleTextAttribute( cons_handle,
						 BACKGROUND_BLUE
    						| BACKGROUND_GREEN
    						| BACKGROUND_RED
    						| BACKGROUND_INTENSITY 
							
	);
	*/
   	if (!columns) { coord.X = 100; coord.Y = 100; }
   	
   	FillConsoleOutputAttribute(
    	cons_handle,	// handle of screen buffer 
    	
		FOREGROUND_BLUE
		| FOREGROUND_GREEN /*| FOREGROUND_RED */| FOREGROUND_INTENSITY, 
	
    	coord.X * coord.Y,	// number of character cells to write to 
    	firstcell,	// x- and y-coordinates of first cell 
    	&scritti	// address of number of cells written to 
    );
    if (columns || rows)  xret =  ShowWindow( cons_handle,  SW_SHOWMAXIMIZED	   );	

}

void console_title()
{
	char stringa[256];
	HANDLE cons_handle;
 	cons_handle=GetStdHandle(STD_OUTPUT_HANDLE	);
	sprintf(stringa, "DirectCsoundCon " DIRECTCSOUND_VERSION " (synchronized to standard %s)", VERSIONSTRING);
  	SetConsoleTitle(stringa);	
}

void getgab() {
	extern int flprintf;
	if (exit_soon_flag) return;
	flprintf = 0;
	printf("\npress <RETURN> to terminate program...");
	getchar();
}

#else //GAB_WIN //1

void getgab() {
	extern int flprintf;
	if (exit_soon_flag) return;
	printf("\n----------------\nsession terminated. Click start to restart a new session");
	flprintf = 0;
	//printf("\npress <RETURN> to terminate program...");
	//getchar();
}


#endif //GAB_WIN //1

/*
void set_current_process_priority_critical()
{
 	 BOOL nRet;
 	 HANDLE currProcess, currThread;
 	 currProcess=GetCurrentProcess();
	 nRet=SetPriorityClass(  currProcess, REALTIME_PRIORITY_CLASS);
	 currThread = GetCurrentThread();
	 nRet=SetThreadPriority( currThread,  THREAD_PRIORITY_HIGHEST );
}


void set_current_process_priority_normal()
{
 	 BOOL nRet;
 	 HANDLE currProcess, currThread;
 	 currProcess=GetCurrentProcess();
	 nRet=SetPriorityClass(  currProcess, NORMAL_PRIORITY_CLASS	);
	 currThread = GetCurrentThread();
	 nRet=SetThreadPriority( currThread,  THREAD_PRIORITY_NORMAL );
}
*/


#undef MessageBoxA
int MessageBoxGab( HWND hWnd, LPCTSTR lpText, LPCTSTR lpCaption, UINT uType )
{
	   if (!exit_soon_flag)
		   return MessageBox(  hWnd,  lpText,  lpCaption,  uType );

}

void dieu_gab(char *s, char *title)
{
 		MessageBox( NULL,	// handle of owner window
				s,	// address of text in message box
                title,	// address of title of message box  
                MB_SYSTEMMODAL | MB_ICONSTOP 	// style of message box
		);
}
