extern "C" {
#include "cscore.h" 
}

/*----------------------------*/
/* user-defined generative functions */

void cscore(EVLIST *a, long *parm_array)
{


}
