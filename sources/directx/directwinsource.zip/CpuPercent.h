
typedef struct {
	OPDS	h;
	float	*instrnum, *ipercent; /* iascii=0 open ascii (default), iflag=1 open binary */
} CPU_PERC;
