#include "cs.h"         /*                                      PIYCH.C       */
#include <math.h>
#include "window.h"
#include "spectra.h"
#include "pitch.h"
//#include "uggab.h" /*gab*/
#include "fout.h" /*gab*/
extern  long    kcounter;
extern void DOWNset(DOWNDAT *, long);
extern void SPECset(SPECDAT *, long);

#define STARTING 1
#define PLAYING  2
#define LOGTWO (0.693147)
#define LOG10D20 (0.11512925)

static FLOAT bicoefs[] =
    { -0.2674054f, 0.7491305f, 0.7160484f, 0.0496285f, 0.7160484f,
      0.0505247f, 0.3514850f, 0.5257536f, 0.3505025f, 0.5257536f,
      0.3661840f, 0.0837990f, 0.3867783f, 0.6764264f, 0.3867783f };

void pitchset(PITCH *p)    /* pitch - uses specta technology */
{
    FLOAT	b;              /* For RMS */
    int     n, nocts, nfreqs, ncoefs;
    FLOAT   Q, *fltp;
    OCTDAT  *octp;
    DOWNDAT *dwnp = &p->downsig;
    SPECDAT *specp = &p->wsig;
    long    npts, nptls, nn, lobin;
    int     *dstp, ptlmax;
    FLOAT   fnfreqs, rolloff, *oct0p, *flop, *fhip, *fundp, *fendp, *fp;
    FLOAT   weight, weightsum, dbthresh, ampthresh;

                                /* RMS of input signal */
    b = 2.0f - (FLOAT)cos((double)(10.0f * tpidsr));
    p->c2 = b - (FLOAT)sqrt((double)(b * b - 1.0));
    p->c1 = 1.0f - p->c2;
    if (!*p->istor) p->prvq = 0.0f;
                                /* End of rms */
                                /* Initialise spectrum */
      p->timcount = (int)(ekr * *p->iprd + .001f); /* for mac roundoff */
      nocts = (int)*p->iocts; if (nocts<=0) nocts = 6;
      nfreqs = (int)*p->ifrqs; if (nfreqs<=0) nfreqs = 12;
      ncoefs = nocts * nfreqs;
      Q = *p->iq; if (Q<=0.0f) Q = 15.0f;

      if (p->timcount <= 0)     initerror(Str(X_863,"illegal iprd"));
      if (nocts > MAXOCTS)      initerror(Str(X_861,"illegal iocts"));
      if (nfreqs > MAXFRQS)     initerror(Str(X_852,"illegal ifrqs"));
      if (inerrcnt)             return;

      if (nocts != dwnp->nocts
          || nfreqs != p->nfreqs  /* if anything has changed */
	  || Q != p->curq ) {                /*     make new tables */
        double      basfrq, curfrq, frqmlt, Qfactor;
        double      theta, a, windamp, onedws, pidws;
        FLOAT       *sinp, *cosp;
        int         k, sumk, windsiz, halfsiz, *wsizp, *woffp;
        long        auxsiz, bufsiz;
        long        majr, minr, totsamps;
        double      hicps,locps,oct;  /*   must alloc anew */
        extern double onept;

        p->nfreqs = nfreqs;
        p->curq = Q;
        p->ncoefs = ncoefs;
        dwnp->srate = esr;
        hicps = dwnp->srate * 0.375;            /* top freq is 3/4 pi/2 ...   */
        oct = log(hicps / onept) / LOGTWO;      /* octcps()  (see aops.c)     */
        dwnp->looct = (FLOAT)(oct - nocts);     /* true oct val of lowest frq */
        locps = hicps / (1L << nocts);
        basfrq = hicps/2.0;                          /* oct below retuned top */
        frqmlt = pow((double)2.0,(double)1./nfreqs);   /* nfreq interval mult */
        Qfactor = Q * dwnp->srate;
        curfrq = basfrq;
        for (sumk=0,wsizp=p->winlen,woffp=p->offset,n=nfreqs; n--; ) {
	  *wsizp++ = k = (int)(Qfactor/curfrq) | 01;  /* calc odd wind sizes */
	  *woffp++ = (*(p->winlen) - k) / 2;          /* & symmetric offsets */
	  sumk += k;                                  /*    and find total   */
  	  curfrq *= frqmlt;
        }
        windsiz = *(p->winlen);
        auxsiz = (windsiz + 2*sumk) * sizeof(FLOAT);   /* calc lcl space rqd */

        auxalloc((long)auxsiz, &p->auxch1);            /*  & alloc auxspace  */

        fltp = (FLOAT *) p->auxch1.auxp;
        p->linbufp = fltp;      fltp += windsiz; /* linbuf must take nsamps */
        p->sinp = sinp = fltp;  fltp += sumk;
        p->cosp = cosp = fltp;                         /* cos gets rem sumk  */
        wsizp = p->winlen;
        curfrq = basfrq * TWOPI / dwnp->srate;
        for (n = nfreqs; n--; ) {                      /* now fill tables */
	  windsiz = *wsizp++;                          /*  (odd win size) */
	  halfsiz = windsiz >> 1;
	  onedws = 1.0 / (windsiz-1);
	  pidws = PI / (windsiz-1);
	  for (k = -halfsiz; k<=halfsiz; k++) {        /*   with sines    */
	    a = cos(k * pidws);
            windamp = 0.08 + 0.92 * a * a;             /*   times hamming */
	    windamp *= onedws;                         /*   scaled        */
	    theta = k * curfrq;
	    *sinp++ = (FLOAT)(windamp * sin(theta));
	    *cosp++ = (FLOAT)(windamp * cos(theta));
	  }
	  curfrq *= frqmlt;                        /*   step by log freq  */
        }
        dwnp->hifrq = (FLOAT)hicps;
        dwnp->lofrq = (FLOAT)locps;
        dwnp->nsamps = windsiz = *(p->winlen);
        dwnp->nocts = nocts;
        minr = windsiz >> 1;                  /* sep odd windsiz into maj, min */
        majr = windsiz - minr;                /*      & calc totsamps reqd     */
        totsamps = (majr*nocts) + (minr<<nocts) - minr;
        DOWNset(dwnp, totsamps);              /* auxalloc in DOWNDAT struct */
        fltp = (FLOAT *) dwnp->auxch.auxp;    /*  & distrib to octdata */
        for (n=nocts,octp=dwnp->octdata+(nocts-1); n--; octp--) {
	  bufsiz = majr + minr;
          octp->begp = fltp;  fltp += bufsiz; /*        (lo oct first) */
	  octp->endp = fltp;  minr *= 2;
        }
        SPECset(specp, (long)ncoefs);         /* prep the spec dspace */
        specp->downsrcp = dwnp;               /*  & record its source */
      }
      for (octp=dwnp->octdata; nocts--; octp++) { /* reset all oct params, &  */
        octp->curp = octp->begp;
        for (fltp=octp->feedback,n=6; n--; )
	  *fltp++ = 0.0f;
        octp->scount = 0;
      }
      specp->nfreqs = p->nfreqs;               /* save the spec descriptors */
      specp->dbout = 0;
      specp->ktimstamp = 0;                    /* init specdata to not new  */
      specp->ktimprd = p->timcount;
      p->scountdown = p->timcount;             /* prime the spect countdown */
                                /* Start specptrk */
    if ((npts = specp->npts) != p->winpts) {        /* if size has changed */
      SPECset(&p->wfund, (long)npts);               /*   realloc for wfund */
      p->wfund.downsrcp = specp->downsrcp;
      p->fundp = (FLOAT *) p->wfund.auxch.auxp;
      p->winpts = npts;
    }
    if (*p->inptls<=0.0f) nptls = 4;
    else nptls = (long)*p->inptls;
    if (nptls > MAXPTL) {
      initerror(Str(X_874,"illegal no of partials"));
      return;
    }
    if (*p->irolloff<=0.0f) *p->irolloff = 0.6f;
    p->nptls = nptls;        /* number, whether all or odd */
      ptlmax = nptls;
    dstp = p->pdist;
    fnfreqs = (FLOAT)specp->nfreqs;
    for (nn = 1; nn <= ptlmax; nn++)
      *dstp++ = (int) ((log((double) nn) / LOGTWO) * fnfreqs + .5);
    if ((rolloff = *p->irolloff) == 0. || rolloff == 1. || nptls == 1) {
      p->rolloff = 0;
      weightsum = (FLOAT)nptls;
    } else {
      FLOAT *fltp = p->pmult;
      FLOAT octdrop = (1.0f - rolloff) / fnfreqs;
      weightsum = 0.0f;
      for (dstp = p->pdist, nn = nptls; nn--; ) {
	weight = 1.0f - octdrop * *dstp++;       /* rolloff * octdistance */
	weightsum += weight;
	*fltp++ = weight;
      }
      if (*--fltp < 0.0f)
	initerror(Str(X_1123,"per oct rolloff too steep"));
      p->rolloff = 1;
    }
    lobin = (long)(specp->downsrcp->looct * fnfreqs);
    oct0p = p->fundp - lobin;                   /* virtual loc of oct 0 */

    flop = oct0p + (int)(*p->ilo * fnfreqs);
    fhip = oct0p + (int)(*p->ihi * fnfreqs);
    fundp = p->fundp;
    fendp = fundp + specp->npts;
    if (flop < fundp) flop = fundp;
    if (fhip > fendp) fhip = fendp;
    if (flop >= fhip) {         /* chk hi-lo range valid */
      initerror(Str(X_866,"illegal lo-hi values"));
      return;
    }
    for (fp = fundp; fp < flop; )
      *fp++ = 0.0f;   /* clear unused lo and hi range */
    for (fp = fhip; fp < fendp; )
      *fp++ = 0.0f;

    dbthresh = *p->idbthresh;                     /* thresholds: */
    ampthresh = (FLOAT)exp((double)dbthresh * LOG10D20);
    p->threshon = ampthresh;              /* mag */
    p->threshoff = ampthresh * 0.5f;
    p->threshon *= weightsum;
    p->threshoff *= weightsum;
    p->oct0p = oct0p;                 /* virtual loc of oct 0 */
    p->confact = *p->iconf;
    p->flop = flop;
    p->fhip = fhip;
    p->playing = 0;
    p->kvalsav = (*p->istrt>=0.0f ? *p->istrt : (*p->ilo+*p->ihi)*0.5f);
    p->kval = p->kinc = 0.0f;
    p->kavl = p->kanc = 0.0f;
    p->jmpcount =  0;
}

void pitch(PITCH *p)
{
    FLOAT	*asig;
    FLOAT	q;
    FLOAT	c1 = p->c1, c2 = p->c2;

    FLOAT   a, b, *dftp, *sigp = p->asig, SIG, yt1, yt2;
    int     nocts, nsmps = ksmps, winlen;
    DOWNDAT *downp = &p->downsig;
    OCTDAT  *octp;
    SPECDAT *specp;
    double  c;
    FLOAT kvar;
                                /* RMS */
    q = p->prvq;
    asig = p->asig;
    do {
      FLOAT as = *asig++;
      q = c1 * as * as + c2 * q;
      SIG = *sigp++;                        /* for each source sample:     */
      octp = downp->octdata;                /*   align onto top octave     */
      nocts = downp->nocts;
      do {                                  /*   then for each oct:        */
	FLOAT *coefp,*ytp,*curp;
	int   nfilt;
	curp = octp->curp;
	*curp++ = SIG;                      /*  write samp to cur buf  */
	if (curp >= octp->endp)
	  curp = octp->begp;                /*    & modulo the pointer */
	octp->curp = curp;
	if (!(--nocts))  break;             /*  if lastoct, break      */
	coefp = bicoefs;  ytp = octp->feedback;
	for (nfilt = 3; nfilt--; ) {        /*  apply triple biquad:   */
	  yt2 = *ytp++; yt1 = *ytp--;             /* get prev feedback */
	  SIG -= (*coefp++ * yt1);                /* apply recurs filt */
	  SIG -= (*coefp++ * yt2);
	  *ytp++ = yt1; *ytp++ = SIG;             /* stor nxt feedback */
	  SIG *= *coefp++;
	  SIG += (*coefp++ * yt1);                /* apply forwrd filt */
	  SIG += (*coefp++ * yt2);
	}
      } while (!(++octp->scount & 01) && octp++); /* send alt samps to nxtoct */
    } while (--nsmps);
    p->prvq = q;
    kvar = (FLOAT) sqrt((double)q); /* End of spectrun part */

    specp = &p->wsig;
    if ((--p->scountdown)) goto nxt;  /* if not yet time for new spec */
    p->scountdown = p->timcount;     /* else reset counter & proceed:        */
    downp = &p->downsig;
    nocts = downp->nocts;
    octp = downp->octdata + nocts;
    dftp = (FLOAT *) specp->auxch.auxp;
    winlen = *(p->winlen);
    while (nocts--) {
      FLOAT  *bufp, *sinp, *cosp;
      int    len, *lenp, *offp, nfreqs;
      FLOAT    *begp, *curp, *endp, *linbufp;
      int      len2;
      octp--;                              /* for each oct (low to high)   */
      begp = octp->begp;
      curp = octp->curp;
      endp = octp->endp;
      if ((len = endp - curp) >= winlen)     /*   if no wrap               */
	linbufp = curp;                    /*     use samples in circbuf */
      else {
	len2 = winlen - len;
	linbufp = bufp = p->linbufp;       /*   else cp crcbuf to linbuf */
	while (len--)
	  *bufp++ = *curp++;
	curp = begp;
	while (len2--)
	  *bufp++ = *curp++;
      }
      cosp = p->cosp;                        /*   get start windowed sines */
      sinp = p->sinp;
      lenp = p->winlen;
      offp = p->offset;
      for (nfreqs=p->nfreqs; nfreqs--; ) {   /*   now for ea. frq this oct */
	a = 0.0f;
	b = 0.0f;
	bufp = linbufp + *offp++;
	for (len = *lenp++; len--; bufp++) {  /* apply windowed sine seg */
	  a += *bufp * *cosp++;
	  b += *bufp * *sinp++;
	}
	c = a*a + b*b;                        /* get magnitude    */
        c = sqrt(c);
	*dftp++ = (FLOAT)c;                       /* store in out spectrum   */
      }
    }
    specp->ktimstamp = kcounter;                  /* time-stamp the output   */

 nxt:
                                /* specptrk */
    {
      FLOAT *inp = (FLOAT *) specp->auxch.auxp;
      FLOAT *endp = inp + specp->npts;
      FLOAT *inp2, sum, *fp;
      int   nn, *pdist, confirms;
      FLOAT kval, fmax, *fmaxp, absdiff, realbin;
      FLOAT *flop, *fhip, *ilop, *ihip, a, b, c, denom, delta;
      long  lobin, hibin;

      if (inp==NULL) {             /* RWD fix */
 	initerror(Str(X_1126,"pitch: not initialised"));
	return;
      }
      kval = p->playing == PLAYING ? p->kval : p->kvalsav;
      lobin = (long)((kval - kvar) * specp->nfreqs);  /* set lims of frq interest */
      hibin = (long)((kval + kvar) * specp->nfreqs);
      if ((flop = p->oct0p + lobin) < p->flop)  /*       as fundp bin pntrs */
	flop = p->flop;
      if ((fhip = p->oct0p + hibin) > p->fhip)  /*       within hard limits */
	fhip = p->fhip;
      ilop = inp + (flop - p->fundp);           /* similar for input bins   */
      ihip = inp + (fhip - p->fundp);
      inp = ilop;
      fp = flop;
      if (p->rolloff) {
	FLOAT *pmult;
	do {
	  sum = *inp;
	  pdist = p->pdist + 1;
	  pmult = p->pmult + 1;
	  for (nn = p->nptls; --nn; ) {
	    if ((inp2 = inp + *pdist++) >= endp)
	      break;
	    sum += *inp2 * *pmult++;
	  }
	  *fp++ = sum;
	} while (++inp < ihip);
      }
      else {
	do {
	  sum = *inp;
	  pdist = p->pdist + 1;
	  for (nn = p->nptls; --nn; ) {
	    if ((inp2 = inp + *pdist++) >= endp)
	      break;
	    sum += *inp2;
	  }
	  *fp++ = sum;
	} while (++inp < ihip);
      }
      fp = flop;                               /* now srch fbins for peak */
      for (fmaxp = fp, fmax = *fp; ++fp<fhip; )
	if (*fp > fmax) {
	  fmax = *fp;
	  fmaxp = fp;
	}
      if (!p->playing) {
	if (fmax > p->threshon)         /* not playing & threshon? */
	  p->playing = STARTING;      /*   prepare to turn on    */
	else goto output;
      }
      else {
	if (fmax < p->threshoff) {      /* playing & threshoff ? */
	  if (p->playing == PLAYING)
	    p->kvalsav = p->kval;   /*   save val & turn off */
	  p->kval = 0.0f;
	  p->kavl = 0.0f;
	  p->kinc = 0.0f;
	  p->kanc = 0.0f;
	  p->playing = 0;
	  goto output;
	}
      }
      a = fmaxp>flop ? *(fmaxp-1) : 0.0f;     /* calc a refined bin no */
      b = fmax;
      c = fmaxp<fhip-1 ? *(fmaxp+1) : 0.0f;
      if (b < 2.0f * (a + c))
	denom = b + b - a - c;
      else denom = a + b + c;
      if (denom != 0.0f)
	delta = 0.5f * (c - a) / denom;
      else delta = 0.0f;
      realbin = (fmaxp - p->oct0p) + delta;    /* get modified bin number  */
      kval = realbin / specp->nfreqs;        /*     & cvt to true decoct */

      if (p->playing == STARTING) {            /* STARTING mode:           */
	if ((absdiff = kval - p->kvalsav) < 0.0f)
	  absdiff = -absdiff;
	confirms = (int)(absdiff * p->confact); /* get interval dependency  */
	if (p->jmpcount < confirms) {
	  p->jmpcount += 1;                /* if not enough confirms,  */
	  goto output;                     /*    must wait some more   */
	} else {
	  p->playing = PLAYING;            /* else switch on playing   */
	  p->jmpcount = 0;
	  p->kval = kval;                  /*    but suppress interp   */
	  p->kinc = 0.0f;
	}
      } else {                                 /* PLAYING mode:            */
	if ((absdiff = kval - p->kval) < 0.0f)
	  absdiff = -absdiff;
	confirms = (int)(absdiff * p->confact); /* get interval dependency  */
	if (p->jmpcount < confirms) {
	  p->jmpcount += 1;                /* if not enough confirms,  */
	  p->kinc = 0.0f;                 /*    must wait some more   */
	} else {
	  p->jmpcount = 0;                 /* else OK to jump interval */
          p->kval = kval;
	}
      }
      fmax += delta * (c - a) / 4.0f;           /* get modified amp */
      p->kavl = fmax;
    }
output:
    *p->koct = p->kval;                   /* output true decoct & amp */
    *p->kamp = p->kavl;
}




/* Multiply and accumulate opcodes */

void macset(SUM *p)
{
    if ((((int)p->INOCOUNT)&1)==1) {
      perferror(Str(X_1453, "Must have even number of arguments in mac\n"));
    }
}

void maca(SUM *p)
{
    int nsmps=ksmps, count=(int) p->INOCOUNT, j, k=0;
    FLOAT *ar = p->ar, **args = p->argums;
    do {
      *ar = 0.0f;
      for (j=0; j<count; j +=2)
 	*ar += args[j][k] * args[j+1][k];
      k++;
      ar++;
    } while (--nsmps);
}

void mac(SUM *p)
{
    int nsmps=ksmps, count=(int) p->INOCOUNT, j, k=0;
    FLOAT *ar = p->ar, **args = p->argums;
    do {
      *ar = 0.0f;
      for (j=0; j<count; j +=2)
 	*ar += *args[j]* args[j+1][k];
      k++;
      ar++;
    } while (--nsmps);
}

#ifdef __unix
#include <sys/time.h>
#include <sys/resource.h>
#else
#include <time.h>
#endif

int counters[33] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                    0};
void clockset(CLOCK *p)
{
    p->c = (int)*p->cnt;
    if (p->c < 0 || p->c > 31)
      p->c = 32;
}

void clockon(CLOCK *p)
{
#if defined(__unix)
    struct rusage r;
    getrusage(0, &r);
    counters[p->c] -= 1000*r.ru_utime.tv_sec + r.ru_utime.tv_usec/1000 +
                      1000*r.ru_stime.tv_sec + r.ru_stime.tv_usec/1000;
#else
    counters[p->c] -= clock();
#endif
}

void clockoff(CLOCK *p)
{
#if defined(__unix)
    struct rusage r;
    getrusage(0, &r);
    counters[p->c] += 1000*r.ru_utime.tv_sec + r.ru_utime.tv_usec/1000 +
                      1000*r.ru_stime.tv_sec + r.ru_stime.tv_usec/1000;
#else
    counters[p->c] += clock();
#endif
}

void clockread(CLKRD *p)
{
    int cnt = (int) *p->a;
    if (cnt < 0 || cnt > 32) cnt = 32;
    *p->r = (FLOAT)counters[cnt];
}

void instcount(INSTCNT *p)
{
    extern int maxinsno;
    extern INSTRTXT **instrtxtp;
    int n = (int)*p->ins;
    if (n<0 || n>maxinsno || instrtxtp[n]==NULL)
      *p->cnt = 0.0f;
    else
      *p->cnt = (FLOAT)instrtxtp[n]->active;
}

/* After gabriel maldonado */
FLOAT cpu_power_busy=0.0f;  /* accumulates the supposed percent of cpu usage */
extern  INSTRTXT **instrtxtp;
extern int	maxinsno;

void cpuperc(CPU_PERC *p)
{
    int n = (int) *p->instrnum;
    if (n>=0 && n<=maxinsno && instrtxtp[n]!=NULL)     /* If instrument exists */
      instrtxtp[n]->cpuload = *p->ipercent;
}

void maxalloc(CPU_PERC *p)
{
    int n = (int) *p->instrnum;
    if (n>=0 && n<=maxinsno && instrtxtp[n]!=NULL)     /* If instrument exists */
      instrtxtp[n]->maxalloc = (int)*p->ipercent;
}

void prealloc(CPU_PERC *p)
{
    int n = (int) *p->instrnum;
    if (n>=0 && n<=maxinsno && instrtxtp[n]!=NULL) { /* If instrument exists */
      int a = (int)*p->ipercent - instrtxtp[n]->active;
      for ( ; a>0; a--) instance(n);
    }
}

/* ************************************************************ */
/* Opcodes from Peter Neub�cker                              */
/* ************************************************************ */

void adsyntset(ADSYNT *p)
{
    FUNC    *ftp;
    int     count;
    long    *lphs;

    p->inerr = 0;

    if ((ftp = ftfind(p->ifn)) != NULL) {
      p->ftp = ftp;
    }
    else {
      p->inerr = 1;
      initerror(Str(X_173,"adsynt: wavetable not found!"));
      return;
    }

    count = (int)*p->icnt;
    if (count < 1)
      count = 1;
    p->count = count;

    if ((ftp = ftfind(p->ifreqtbl)) != NULL) {
      p->freqtp = ftp;
    }
    else {
      p->inerr = 1;
      initerror(Str(X_309,"adsynt: freqtable not found!"));
      return;
    }
    if (ftp->flen < count) {
      p->inerr = 1;
      initerror(Str(X_1424,"adsynt: partial count is greater than freqtable size!"));
      return;
    }

    if ((ftp = ftfind(p->iamptbl)) != NULL) {
      p->amptp = ftp;
    }
    else {
      p->inerr = 1;
      initerror(Str(X_1473, "adsynt: amptable not found!"));
      return;
    }
    if (ftp->flen < count) {
      p->inerr = 1;
      initerror(Str(X_1474,"adsynt: partial count is greater than amptable size!"));
      return;
    }

    if (p->lphs.auxp==NULL || p->lphs.size < (long)sizeof(long)*count)
      auxalloc(sizeof(long)*count, &p->lphs);

    lphs = (long*)p->lphs.auxp;
    if (*p->iphs > 1) {
      do
        *lphs++ = ((long)((FLOAT)((double)rand()/(double)RAND_MAX)
                          * fmaxlen)) & PHMASK;
      while (--count);
    }
    else if (*p->iphs >= 0){
      do
        *lphs++ = ((long)(*p->iphs * fmaxlen)) & PHMASK;
      while (--count);
    }
}

void adsynt(ADSYNT *p)
{
    FUNC    *ftp, *freqtp, *amptp;
    FLOAT   *ar, *ar0, *ftbl, *freqtbl, *amptbl;
    FLOAT   amp0, amp, cps0, cps;
    long    phs, inc, lobits;
    long    *lphs;
    int     nsmps, count;

    if (p->inerr) {
      initerror(Str(X_1475,"adsynt: not initialized"));
      return;
    }
    ftp = p->ftp;
    ftbl = ftp->ftable;
    lobits = ftp->lobits;
    freqtp = p->freqtp;
    freqtbl = freqtp->ftable;
    amptp = p->amptp;
    amptbl = amptp->ftable;
    lphs = (long*)p->lphs.auxp;

    cps0 = *p->kcps;
    amp0 = *p->kamp;
    count = p->count;

    ar0 = p->sr;
    ar = ar0;
    nsmps = ksmps;
    do
      *ar++ = 0;
    while (--nsmps);

    do {
      ar = ar0;
      nsmps = ksmps;
      amp = *amptbl++ * amp0;
      cps = *freqtbl++ * cps0;
      inc = (long) (cps * sicvt);
      phs = *lphs;
      do {
        *ar++ += *(ftbl + (phs >> lobits)) * amp;
        phs += inc;
        phs &= PHMASK;
      }
      while (--nsmps);
      *lphs++ = phs;
    }
    while (--count);
}

void hsboscset(HSBOSC *p)
{
    FUNC	*ftp;
    int		octcnt, i;

    if ((ftp = ftfind(p->ifn)) != NULL) {
      p->ftp = ftp;
      if (*p->ioctcnt < 2)
        octcnt = 3;
      else
        octcnt = (int)*p->ioctcnt;
      if (octcnt > 10)
        octcnt = 10;
      p->octcnt = octcnt;
      if (*p->iphs >= 0)
        {  for (i=0; i<octcnt; i++)
          p->lphs[i] = ((long)(*p->iphs * fmaxlen)) & PHMASK;
        }
    }
    if ((ftp = ftfind(p->imixtbl)) != NULL) {
      p->mixtp = ftp;
    }
}

void hsboscil(HSBOSC  *p)
{
    FUNC	*ftp, *mixtp;
    FLOAT	fract, v1, amp0, amp, *ar0, *ar, *ftab, *mtab;
    long	phs, inc, lobits;
    long    phases[10];
    int		nsmps;
    FLOAT	tonal, bright, freq, ampscl;
    int     octcnt = p->octcnt;
    FLOAT   octstart, octoffs, octbase;
    int     octshift, i, mtablen;
    FLOAT 	hesr = esr / 2.0f;

    ftp = p->ftp;
    mixtp = p->mixtp;
    if (ftp==NULL) {
      initerror(Str(X_1476,"hsboscil: not initialized"));
      return;
    }
    if (mixtp==NULL) {
      initerror(Str(X_1476,"hsboscil: not initialized"));
      return;
    }

    tonal = *p->ktona;
    tonal -= (FLOAT)floor(tonal);
    bright = *p->kbrite - tonal;
    octstart = bright - (FLOAT)octcnt / 2.0f;
    octbase = (FLOAT)floor(floor(octstart) + 1.5);
    octoffs = octbase - octstart;

    mtab = mixtp->ftable;
    mtablen = mixtp->flen;
    freq = *p->ibasef * (FLOAT)pow(2.0, tonal) * (FLOAT)pow(2.0, octbase);

    ampscl = mtab[(int)((1.0 / (FLOAT)octcnt) * mtablen)];
    amp = mtab[(int)((octoffs / (FLOAT)octcnt) * mtablen)];
    if ((amp - p->prevamp) > (ampscl * 0.5))
      octshift = 1;
    else if ((amp - p->prevamp) < (-(ampscl * 0.5)))
      octshift = -1;
    else
      octshift = 0;
    p->prevamp = amp;

    ampscl = 0;
    for (i=0; i<octcnt; i++) {
      phases[i] = p->lphs[(i+octshift+100*octcnt) % octcnt];
      ampscl += mtab[(int)(((FLOAT)i / (FLOAT)octcnt) * mtablen)];
    }

    amp0 = *p->kamp / ampscl;
    lobits = ftp->lobits;
    ar0 = p->sr;
    ar = ar0;
    nsmps = ksmps;
    do {
      *ar++ = 0.0;
    } while (--nsmps);

    for (i=0; i<octcnt; i++) {
      ar = ar0;
      nsmps = ksmps;
      phs = phases[i];
      amp = mtab[(int)((octoffs / (FLOAT)octcnt) * mtablen)] * amp0;
      if (freq > hesr)
        amp = 0;
      inc = (long)(freq * sicvt);
      do {
        fract = PFRAC(phs);
        ftab = ftp->ftable + (phs >> lobits);
        v1 = *ftab++;
        *ar++ += (v1 + (*ftab - v1) * fract) * amp;
        phs += inc;
        phs &= PHMASK;
      }
      while (--nsmps);
      p->lphs[i] = phs;

      octoffs += 1.0;
      freq *= 2.0;
    }
}

void pitchamdfset(PITCHAMDF *p)
{
    FLOAT srate, downs;
    long  size, minperi, maxperi, downsamp, upsamp, msize, bufsize, interval;
    FLOAT *medi, *buf;

    p->inerr = 0;
    
    downs = *p->idowns;
    if (downs < (-1.9)) {
      upsamp = (int)((downs * (-1.0)) + 0.5);
      downsamp = 0;
      srate = esr * (float)upsamp;
    }
    else {
      downsamp = (int)(downs+0.5);
      if (downsamp < 1)
        downsamp = 1;
      srate = esr / (float)downsamp;
      upsamp = 0;
    }

    minperi = (long)(srate / *p->imaxcps);
    maxperi = (long)(srate / *p->imincps);
    if (maxperi <= minperi) {
      p->inerr = 1;
      initerror(Str(X_1477,"pitchamdf: maxcps must be > mincps !"));
      return;
    }
    
    if (*p->iexcps < 1)
        interval = maxperi;
    else
        interval = (long)(srate / *p->iexcps);
    if (interval < ksmps) {
      if (downsamp)
        interval = ksmps / downsamp;
      else
        interval = ksmps * upsamp;
    }

    size = maxperi + interval;
    bufsize = size + maxperi + 2;

    p->srate = srate;
    p->downsamp = downsamp;
    p->upsamp = upsamp;
    p->minperi = minperi;
    p->maxperi = maxperi;
    p->size = size;
    p->readp = 0;
    p->index = 0;
    p->lastval = 0;
    if (*p->icps < 1)
        p->peri = (minperi + maxperi) / 2;
    else 
        p->peri = (int)(srate / *p->icps);

    if (*p->irmsmedi < 1)
        p->rmsmedisize = 0;
    else 
        p->rmsmedisize = (int)(*p->irmsmedi+0.5)*2+1;
    p->rmsmediptr = 0;

    if (p->medisize) {
      msize = p->medisize * 3;
      if (p->median.auxp==NULL || p->median.size < (long)sizeof(FLOAT)*msize)
        auxalloc(sizeof(FLOAT)*(msize), &p->median);
      medi = (FLOAT*)p->median.auxp;
      do 
        *medi++ = 0;
      while (--msize);
    }

    if (*p->imedi < 1)
      p->medisize = 0;
    else 
      p->medisize = (int)(*p->imedi+0.5)*2+1;
    p->mediptr = 0;

    if (p->medisize) {
      msize = p->medisize * 3;
      if (p->median.auxp==NULL || p->median.size < (long)sizeof(FLOAT)*msize)
        auxalloc(sizeof(FLOAT)*(msize), &p->median);
      medi = (FLOAT*)p->median.auxp;
      do 
        *medi++ = (FLOAT)p->peri;
      while (--msize);
    }

    if (p->buffer.auxp==NULL || p->buffer.size < (long)sizeof(FLOAT)*(bufsize)) {
      auxalloc(sizeof(FLOAT)*(bufsize), &p->buffer);
      buf = (FLOAT*)p->buffer.auxp;
      do 
        *buf++ = 0;
      while (--bufsize);
    }
}

#define SWAP(a,b) temp=(a);(a)=(b);(b)=temp;

FLOAT medianvalue(unsigned long n, FLOAT *vals)
{   /* vals must point to 1 below relevant data! */
    unsigned long i, ir, j, l, mid;
    unsigned long k = (n + 1) / 2;
    FLOAT a, temp;

    l = 1;
    ir = n;
    while (1) {
      if (ir <= l+1) {
        if (ir == l+1 && vals[ir] < vals[l]) {
          SWAP(vals[l], vals[ir])
          }
          return vals[k];
        }
        else {
          mid = (l+ir) >> 1;
          SWAP(vals[mid], vals[l+1])
          if (vals[l+1] > vals[ir]) {
            SWAP(vals[l+1], vals[ir])
          }
          if (vals[l] > vals[ir]) {
            SWAP(vals[l], vals[ir]) }
          if (vals[l+1] > vals[l]) {
            SWAP(vals[l+1], vals[l]) }
          i = l + 1;
          j = ir;
          a = vals[l];
          while (1) {
            do i++; while (vals[i] < a);
            do j--; while (vals[j] > a);
            if (j < i) break;
            SWAP(vals[i], vals[j])
          }
          vals[l] = vals[j];
          vals[j] = a;
          if (j >= k) ir = j-1;
          if (j <= k) l = i;
        }
    }
}
#undef SWAP

    
void pitchamdf(PITCHAMDF *p)
{
    FLOAT *buffer = (FLOAT*)p->buffer.auxp;
    FLOAT *rmsmedian = (FLOAT*)p->rmsmedian.auxp;
    long  rmsmedisize = p->rmsmedisize;
    long  rmsmediptr = p->rmsmediptr;
    FLOAT *median = (FLOAT*)p->median.auxp;
    long  medisize = p->medisize;
    long  mediptr = p->mediptr;
    long  size = p->size;
    long  index = p->index;
    long  minperi = p->minperi;
    long  maxperi = p->maxperi;
    FLOAT *asig = p->asig;
    FLOAT srate = p->srate;
    long  peri = p->peri;
    long  downsamp = p->downsamp;
    long  upsamp = p->upsamp;
    FLOAT upsmp = (FLOAT)upsamp;
    FLOAT lastval = p->lastval;
    FLOAT newval, delta;
    long  readp = p->readp;
    long  interval = size - maxperi;
    int   nsmps = ksmps;
    int   i;
    long  i1, i2;
    FLOAT val, rms;
    double sum;
    FLOAT acc, accmin, diff;

    if (p->inerr) {
      initerror(Str(X_1478,"pitchamdf: not initialized"));
      return;
    }

    if (upsamp) {
      while (1) {
        newval = asig[readp++];
        delta = (newval-lastval) / upsmp;
        lastval = newval;
            
        for (i=0; i<upsamp; i++) {
          newval += delta;
          buffer[index++] = newval;
        
          if (index == size) {
            peri = minperi;
            accmin = 0;
            for (i2 = 0; i2 < size; ++i2) {
              diff = buffer[i2+minperi] - buffer[i2];
              if (diff > 0)  accmin += diff;
              else           accmin -= diff;
            }
            for (i1 = minperi + 1; i1 <= maxperi; ++i1) {
              acc = 0;
              for (i2 = 0; i2 < size; ++i2) {
                diff = buffer[i1+i2] - buffer[i2];
                if (diff > 0)   acc += diff;
                else            acc -= diff;
              }
              if (acc < accmin) {
                accmin = acc;
                peri = i1;
              }
            }
        
            for (i1 = 0; i1 < interval; i1++)
              buffer[i1] = buffer[i1+interval];
            index = maxperi;
        
            if (medisize) {
              median[mediptr] = (FLOAT)peri;
              for (i1 = 0; i1 < medisize; i1++)
                median[medisize+i1] = median[i1];
              
              median[medisize*2+mediptr] =
                medianvalue(medisize, &median[medisize-1]);
              peri = (long)median[medisize*2 + ((mediptr+medisize/2+1) % medisize)];
              
              mediptr = (mediptr + 1) % medisize;
              p->mediptr = mediptr;
            }
          }
        }
        if (readp >= nsmps) break;
      }
      readp = readp % nsmps;
      p->lastval = lastval;
    }
    else {
      while (1) {
        buffer[index++] = asig[readp];
        readp += downsamp;

        if (index == size) {
          peri = minperi;
          accmin = 0;
          for (i2 = 0; i2 < size; ++i2) {
            diff = buffer[i2+minperi] - buffer[i2];
            if (diff > 0)  accmin += diff;
            else           accmin -= diff;
          }
          for (i1 = minperi + 1; i1 <= maxperi; ++i1) {
            acc = 0;
            for (i2 = 0; i2 < size; ++i2) {
              diff = buffer[i1+i2] - buffer[i2];
              if (diff > 0)   acc += diff;
              else            acc -= diff;
            }
            if (acc < accmin) {
              accmin = acc;
              peri = i1;
            }
          }

          for (i1 = 0; i1 < interval; i1++)
            buffer[i1] = buffer[i1+interval];
          index = maxperi;

          if (medisize) {
            median[mediptr] = (FLOAT)peri;
            for (i1 = 0; i1 < medisize; i1++)
              median[medisize+i1] = median[i1];

            median[medisize*2+mediptr] =
              medianvalue(medisize, &median[medisize-1]);
            peri = (long)median[medisize*2 +
                               ((mediptr+medisize/2+1) % medisize)];
          
            mediptr = (mediptr + 1) % medisize;
            p->mediptr = mediptr;
          }
        }
      
        if (readp >= nsmps) break;
      }
      readp = readp % nsmps;
    }
    buffer = &buffer[(index + size - peri) % size];
    sum = 0.0;
    for (i1=0; i1<peri; i1++) {
      val = *buffer++;
      sum += (double)(val * val);
    }
    rms = (FLOAT)sqrt(sum / (double)peri);
    if (rmsmedisize) {
      rmsmedian[rmsmediptr] = rms;
      for (i1 = 0; i1 < rmsmedisize; i1++)
        rmsmedian[rmsmedisize+i1] = rmsmedian[i1];

      rmsmedian[rmsmedisize*2+rmsmediptr] =
        medianvalue(rmsmedisize, &rmsmedian[rmsmedisize-1]);
      rms = rmsmedian[rmsmedisize*2 +
                     ((rmsmediptr+rmsmedisize/2+1) % rmsmedisize)];

      rmsmediptr = (rmsmediptr + 1) % rmsmedisize;
      p->rmsmediptr = rmsmediptr;
    }

    *p->kcps = srate / (FLOAT)peri;
    *p->krms = rms;
    p->index = index;
    p->peri = peri;
    p->readp = readp;

}

/*==================================================================*/
/* phasorbnk                                                        */
/*==================================================================*/

#define FZERO	(0.0f)
#define FONE	(1.0f)

void phsbnkset(PHSORBNK *p)
{
    double  phs;
    int    count;
    double  *curphs;

    count = (int)(*p->icnt + 0.5);
    if (count < 2)
      count = 2;

    if (p->curphs.auxp==NULL || p->curphs.size < (long)sizeof(double)*count)
      auxalloc(sizeof(double)*count, &p->curphs);

    curphs = (double*)p->curphs.auxp;
    if (*p->iphs > 1) {
      do 
        *curphs++ = (double)rand()/(double)RAND_MAX;
      while (--count);
    }
    else if ((phs = *p->iphs) >= 0) {
      do 
        *curphs++ = phs;
      while (--count);
    }
}

void kphsorbnk(PHSORBNK *p)
{
    double  phs;
    double  *curphs = (double*)p->curphs.auxp;
    int     size = p->curphs.size / sizeof(double);
    int     index = (int)(*p->kindx);

    if (curphs == NULL) {
      initerror(Str(X_1479,"phasorbnk: not initialized"));
      return;
    }

    if (index<0 || index>=size) {
      *p->sr = 0.0;
      return;
    }

    *p->sr = (FLOAT)(phs = curphs[index]);
    if ((phs += *p->xcps * onedkr) >= 1.0)
      phs -= 1.0;
    else if (phs < 1.0)
      phs += 1.0;
    curphs[index] = phs;
}

void phsorbnk(PHSORBNK *p)
{
    int	    nsmps = ksmps;
    FLOAT   *rs;
    double  phase, incr;
    double  *curphs = (double*)p->curphs.auxp;
    int     size = p->curphs.size / sizeof(double);
    int     index = (int)(*p->kindx);

    if (curphs == NULL) {
      initerror(Str(X_1479,"phasorbnk: not initialized"));
      return;
    }

    if (index<0 || index>=size) {
      *p->sr = 0.0f;
      return;
    }
    
    rs = p->sr;
    phase = curphs[index];
    if (p->XINCODE) {
      FLOAT *cps = p->xcps;
      do {
        incr = (double)(*cps++ / esr);
        *rs++ = (FLOAT)phase;
        phase += incr;
        if (phase >= 1.0)
          phase -= 1.0;
        else if (phase < 0.0)
          phase += 1.0;
      } while (--nsmps);
    }
    else {
      incr = (double)(*p->xcps / esr);
      do {
        *rs++ = (FLOAT)phase;
        phase += incr;
        if (phase >= 1.0)
          phase -= 1.0;
        else if (phase < 0.0)
          phase += 1.0;
      } while (--nsmps);
    }
    curphs[index] = phase;
}

void printi(PRINTI *p)
{
    char    *sarg;

    if ((*p->ifilcod != sstrcod) || (*p->STRARG == 0)) 
    {   sprintf(errmsg, "printi parameter was not a \"quoted string\"\n");
        initerror(errmsg);
        return;
    }
    else 
    {   sarg = p->STRARG;
        do 
        { putchar(*sarg);
        } while (*++sarg != 0);
        putchar(10);
        putchar(13);
    }
}


/*====================
opcodes from Jens Groh
======================*/

void nlalp_set(NLALP *p) {
   if (!(*p->istor)) {
      p->m0 = 0.;
      p->m1 = 0.;
   }
}



void nlalp(NLALP *p) {
   int nsmps;
   float *rp;
   float *ip;
   double m0;
   double m1;
   double tm0;
   double tm1;
   double klfact;
   double knfact;

   nsmps = ksmps;
   rp = p->aresult;
   ip = p->ainsig;
   klfact = (double)*p->klfact;
   knfact = (double)*p->knfact;
   tm0 = p->m0;
   tm1 = p->m1;
   if (knfact == 0.) { /* linear case */
      if (klfact == 0.) { /* degenerated linear case */
         m0 = (double)*ip++ - tm1;
         *rp++ = (float)(tm0);
         while (--nsmps) {
            *rp++ = (float)(m0);
            m0 = (double)*ip++;
         }
         tm0 = m0;
         tm1 = 0.;
      } else { /* normal linear case */
         do {
            m0 = (double)*ip++ - tm1;
            m1 = m0 * klfact;
            *rp++ = (float)(tm0 + m1);
            tm0 = m0;
            tm1 = m1;
         } while (--nsmps);
      }
   } else { /* non-linear case */
      if (klfact == 0.) { /* simplified non-linear case */
         do {
            m0 = (double)*ip++ - tm1;
            m1 = fabs(m0) * knfact;
            *rp++ = (float)(tm0 + m1);
            tm0 = m0;
            tm1 = m1;
         } while (--nsmps);
      } else { /* normal non-linear case */
         do {
            m0 = (double)*ip++ - tm1;
            m1 = m0 * klfact + fabs(m0) * knfact;
            *rp++ = (float)(tm0 + m1);
            tm0 = m0;
            tm1 = m1;
         } while (--nsmps);
      }
   }
   p->m0 = tm0;
   p->m1 = tm1;
}


