
typedef	struct {
	OPDS	h;
	float	*ar, *asig, *kfco, *kres, *istor;
	float	ynm1, ynm2;  
} LOWPR;


typedef	struct {
	OPDS	h;
	float	*ar, *asig, *kfco, *kres, *ord, *istor;
	float	ynm1[10], ynm2[10] ;   
	int		loop;
} LOWPRX;

typedef	struct {
	OPDS	h;
	float	*ar, *asig, *kfco, *kres, *ord, *sep;
	float	ynm1[10], ynm2[10], cut[10];  
	int		loop;
} LOWPR_SEP;

typedef	struct {
	OPDS	h;
	float	*ar, *asig, *kcf, *kbw, *ord, *sep, *iflag, *iscl, *istor;
	int     scale, loop;
	float	yt1[50], yt2[50];
} RESONY;
/*
typedef	struct {
    OPDS	h;
    FLOAT	*ar, *asig, *kcf, *kbw, *ord, *sep, *iflag, *iscl, *istor;
    int     	scale, loop;
    AUXCH	aux;
    FLOAT	*yt1, *yt2;
} RESONY;
*/