        		/*					PITCH.H	*/

typedef struct {
	OPDS	h;
	FLOAT	*koct, *kamp;
	FLOAT   *asig;
        FLOAT	*iprd, *ilo, *ihi, *idbthresh;
                                /* Optional */
        FLOAT	*ifrqs, *iconf, *istrt, *iocts, *iq, *inptls, *irolloff, *istor;
	FLOAT	c1, c2, prvq;
#define MAXFRQS 120
	SPECDAT wsig;
	int	nfreqs, ncoefs, dbout, scountdown, timcount;
	FLOAT	curq, *sinp, *cosp, *linbufp;
	int     winlen[MAXFRQS], offset[MAXFRQS];
	DOWNDAT downsig;
	WINDAT  sinwindow, octwindow;
	AUXCH	auxch1, auxch2;
	int	pdist[MAXPTL], nptls, rolloff;
	FLOAT	pmult[MAXPTL], confact, kvalsav, kval, kavl, kinc, kanc;
	FLOAT   *flop, *fhip, *fundp, *oct0p, threshon, threshoff;
	int	winpts, jmpcount, playing;
	SPECDAT	wfund;
} PITCH;


typedef struct {
	OPDS	h;
        FLOAT	*cnt;
        int	c;
} CLOCK;

typedef struct {
	OPDS	h;
        FLOAT	*r;
        FLOAT	*a;
} CLKRD;

typedef struct {
	OPDS	h;
        FLOAT	*cnt;
        FLOAT	*ins;
} INSTCNT;

typedef struct {
    OPDS	h;
    FLOAT	*instrnum, *ipercent;
} CPU_PERC;

typedef struct {
    OPDS    h;
    FLOAT   *sr, *kamp, *kcps, *ifn, *ifreqtbl, *iamptbl, *icnt, *iphs;
    FUNC    *ftp;
    FUNC    *freqtp;
    FUNC    *amptp;
    int     count;
    int     inerr;
    AUXCH   lphs;
} ADSYNT;

typedef struct {
    OPDS	h;
    FLOAT	*sr, *kamp, *ktona, *kbrite, *ibasef, *ifn;
    FLOAT	*imixtbl, *ioctcnt, *iphs;
    long	lphs[10];
    int		octcnt;
    FLOAT 	prevamp;
    FUNC	*ftp;
    FUNC	*mixtp;
} HSBOSC;

typedef struct {
    OPDS    h;
    FLOAT   *kcps, *krms, *asig, *imincps, *imaxcps, *icps, 
            *imedi, *idowns, *iexcps, *irmsmedi;
    FLOAT   srate;
    FLOAT   lastval;
    long    downsamp;
    long    upsamp;
    long    minperi;
    long    maxperi;
    long    index;
    long    readp;
    long    size;
    long    peri;
    long    medisize;
    long    mediptr;
    long    rmsmedisize;
    long    rmsmediptr;
    int     inerr;
    AUXCH   median;
    AUXCH   rmsmedian;
    AUXCH   buffer;
} PITCHAMDF;

typedef struct {
	OPDS	h;
	FLOAT	*sr, *xcps, *kindx, *icnt, *iphs;
	AUXCH   curphs;
} PHSORBNK;

typedef struct {
    OPDS    h;
    float   *ifilcod;
} PRINTI;


typedef struct { /* for nlalp opcode */
   OPDS h; /* header */
   float *aresult; /* resulting signal */
   float *ainsig; /* input signal */
   float *klfact; /* linear factor */
   float *knfact; /* nonlinear factor */
   float *istor; /* initial storage disposition */
   double m0; /* energy storage */
   double m1; /* energy storage */
} NLALP;