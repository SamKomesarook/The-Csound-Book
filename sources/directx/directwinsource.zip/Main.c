#include "cs.h"                 /*                               MAIN.C */
#include "soundio.h"
#include <ctype.h>              /* For isdigit */

#ifdef SYMANTEC
#define main mw_main
#endif

#ifdef __ZPC__
unsigned int _stack = 0xFFF0U;
#endif

int     ScotScore = 0;
/*static*/  char        *scorename = NULL;
        char    *xfilename = NULL;
static  char    *sortedscore = "score.srt";
static  char    *xtractedscore = "score.xtr";
static  char    *playscore = "score.srt";     /* unless we extract */
static  FILE    *scorin, *scorout, *xfile;
        FILE    *dribble;
extern  void    dieu(char *);
extern  OPARMS  O;
char    *orchname = NULL;  /* used by rdorch */
int     keep_tmp = 0;
int     dither_output = 0;      /* A boolean really */
extern int argdecode(int, char**, char**, char*);
#ifdef LINUX
int midi_out;
extern void openMIDIout(void);
#endif


#ifdef GAB_RT	/* gab-A1 */
extern int flprintf, flprintfbis; 
extern void setcolor(unsigned short );
int ug_flag=-1;  /* gab A8*/
#include <time.h> 
#endif 	/* gab-A1 */



#ifdef CWIN
void dialog_arguments(void);
#include <stdarg.h>
extern int cwin_atexit(void (*)(void));

int cwin_main(int argc, char **argv)
#else

#ifdef GAB_WIN //1
int csound_main(int argc, char **argv)	 /* gab d2 */
#else  //GAB_WIN //1
int main(int argc, char **argv)	 /* gab d2 */
#endif	 //GAB_WIN //1

#endif
{
        char  *s;
        char  *filnamp, *envoutyp = NULL;
        int   n;
extern  int   getsizformat(int), musmon(void);
extern  char  *getstrformat(int);

#ifdef	WIN32  /* gab-A1 */
		int aaa=POLL_EVENTS();
	
	/*	Michael Gogins 1997-02-24 added: */
	extern OENTRY *opcodlst;
	extern void csOpcodeLoadAll();
	/*	End Gogins. */
#ifdef GAB_RT /*gab-A1*/
	int unified_flag=0;
	unsigned int timer_init(void); 
	clock_t t1, t0;	  
	double elapsed;
#ifndef GAB_WIN 
	extern void console_rows();
extern void console_title();
extern void console_init();
	console_init();
	console_title();
#endif	 //GAB_WIN 
	O.inbufsamps=O.outbufsamps=400; /* gab B0 */
	O.SusPThresh = 64; /* gab A8*/
	O.sfheader =1; 	/* gab A8*/
	t0 = clock();

	/* Michael Gogins 1997-02-24 added:  */
	csOpcodeLoadAll();
	//init_cpu_control();
	/*	End Gogins. */
#endif	/* GAB_RT (gab-A1) */
#endif /*WIN32*/

#ifdef __ZPC__
#ifdef WITHx87
        extern int _8087;
        if (_8087 == 0)
            die("This Csound needs an 80x87");
#endif
#endif
#ifndef SYMANTEC
        {
            char *getenv(const char*);
            if ((envoutyp = getenv("SFOUTYP")) != NULL) {
                if (strcmp(envoutyp,"AIFF") == 0)
                    O.filetyp = TYP_AIFF;
                else if (strcmp(envoutyp,"WAV") == 0)
                    O.filetyp = TYP_WAV;
                else {
                    sprintf(errmsg,"%s not a recognized SFOUTYP env setting",
                            envoutyp);
                    dieu(errmsg);
                }
            }
        }
#endif
        if (!POLL_EVENTS()) exit(1);
#ifdef CWIN
        cwin_atexit(all_free);
#endif
        O.filnamspace = filnamp = mmalloc((long)1024);
        dribble = NULL;
        if (--argc == 0) {
#ifdef CWIN
            dialog_arguments();
#else
            dieu("insufficient arguments");
#endif
        }
#ifdef CWIN
        else
#endif
        argdecode(argc, argv, &filnamp, envoutyp);

#ifdef GAB_WIN
		{
			 extern void SetConWinParms();
			 SetConWinParms();
		}
#endif

#ifdef GAB_RT /* gab-A1 */

#ifndef GAB_WIN
        console_rows(); 
#endif /* GAB_WIN */
	printf( "Csound Version %s (%s)\n", VERSIONSTRING, __DATE__);
	if 	(ug_flag >=0) {
		list_opcodes(ug_flag);
		printf("\n-----------------------------\n\n");
		exit(0);
		dieu("\n-----------------------------\n");
	}
#endif		/* GAB_RT */
        if (!POLL_EVENTS()) exit(1);
        if (orchname == NULL)
            dieu("no orchestra name");
		else if ((strcmp(orchname+strlen(orchname)-4, ".csd")==0 ||
			strcmp(orchname+strlen(orchname)-4, ".CSD")==0)
			&& (scorename==NULL || strlen(scorename)==0)) {
			int read_unified_file(char *, char **);
			err_printf("UnifiedCSD:  %s\n", orchname);
			if (!read_unified_file(orchname, &scorename)) {
				err_printf(Str(X_240,"Decode failed....stopping\n"));
				exit(1);
			}
			unified_flag = 1; /* gab A8*/
		}
		if (O.Linein || O.Midiin || O.FMidiin)
            O.RTevents = 1;
        if (O.RTevents || O.sfread)
            O.ksensing = 1;
        if (!O.outformat)                       /* if no audioformat yet  */
            O.outformat = AE_SHORT;             /*  default to short_ints */
        O.outsampsiz = getsizformat(O.outformat);
        O.informat = O.outformat; /* informat defaults; resettable by readinheader */
        O.insampsiz = O.outsampsiz;
        if (O.filetyp == TYP_AIFF || O.filetyp == TYP_WAV) {
            if (!O.sfheader)
                dieu("can't write AIFF/WAV soundfile with no header");
            /* WAVE format supports only unsigned bytes for 1- to 8-bit
               samples and signed short integers for 9 to 16-bit samples.
                                   -- Jonathan Mohr  1995 Oct 17  */
            /* Also seems that type 3 is floats */
            if (O.filetyp == TYP_WAV &&
                O.outformat != AE_UNCH && O.outformat != AE_SHORT &&
                O.outformat != AE_FLOAT ) {
              sprintf(errmsg,"WAV does not support %s encoding %s",
                      getstrformat(O.outformat), "-- try '-8' or '-s' options");
              dieu(errmsg);
            }
            else if (O.filetyp == TYP_AIFF &&
                     O.outformat != AE_CHAR && O.outformat != AE_SHORT) {
              sprintf(errmsg,"AIFF does not support %s encoding %s",
                      getstrformat(O.outformat), "-- try '-c' or '-s' options");
              dieu(errmsg);
            }
        }
        if (!POLL_EVENTS()) exit(1);
        if (O.rewrt_hdr && !O.sfheader)
            dieu("can't rewrite header if no header requested");
        if (O.sr_override || O.kr_override) {
            long ksmpsover;
            if (!O.sr_override || !O.kr_override)
                dieu("srate and krate overrides must occur jointly");
            ksmpsover = O.sr_override / O.kr_override;
            if (ksmpsover * O.kr_override != O.sr_override)
                dieu("command-line srate / krate not integral");
        }

 
/*else (gab A8)*/ err_printf("orchname:  %s\n", orchname);
        if (scorename != NULL)
            err_printf("scorename: %s\n", scorename);
        if (xfilename != NULL)
            err_printf("xfilename: %s\n", xfilename);
#if defined(SYS5) || defined(WIN32)
        {
          static  char  buf[80];
          VMSG(setvbuf(stdout,buf,_IOLBF,80);)
        }
#else
#if !defined(SYMANTEC) && !defined(LATTICE)
        VMSG(setlinebuf(stdout);)
#endif
#endif
        if (scorename == NULL) {
          if (O.RTevents) {
			void write_dummy_score(char *s);
            err_printf("realtime performance using dummy numeric scorefile\n");
			O.playscore="score.srt";
            write_dummy_score(O.playscore);
            goto perf;
          }
          else scorename = "score.srt";
        }
        if (!POLL_EVENTS()) exit(1);
        if ((n = strlen(scorename)) > 4            /* if score ?.srt or ?.xtr */
          && (!strcmp(scorename+n-4,".srt")
              || !strcmp(scorename+n-4,".xtr"))) {
            err_printf("using previous %s\n",scorename);
            playscore = sortedscore = scorename;            /*   use that one */
        }
        else {
            if (!(scorin = fopen(scorename, "r")))          /* else sort it   */
                dies("cannot open scorefile %s", scorename);
            if (!(scorout = fopen(sortedscore, "w")))
                dies("cannot open %s for writing", sortedscore);
            printf("sorting score ...\n");
            scsort(scorin, scorout); //  <<1>>
            fclose(scorin);
            fclose(scorout);
        }
        if (!POLL_EVENTS()) exit(1);
        if (xfilename != NULL) {                        /* optionally extract */
            if (!strcmp(scorename,"score.xtr"))
                dies("cannot extract %s, name conflict",scorename);
            if (!(xfile = fopen(xfilename, "r")))
                dies("cannot open extract file %s", xfilename);
            if (!(scorin = fopen(sortedscore, "r")))
                dies("cannot reopen %s", sortedscore);
            if (!(scorout = fopen(xtractedscore, "w")))
                dies("cannot open %s for writing", xtractedscore);
            err_printf("  ... extracting ...\n");
            scxtract(scorin, scorout, xfile);
            fclose(scorin);
            fclose(scorout);
            playscore = xtractedscore;
        }           
        printf("\t... done\n");
        if (!POLL_EVENTS()) exit(1);

        s = playscore;
        O.playscore = filnamp;
        while ((*filnamp++ = *s++));    /* copy sorted score name */

perf:   O.filnamsize = filnamp - O.filnamspace;
        if (!POLL_EVENTS()) exit(1);
        otran();   // <<2>>             /* read orcfile, setup desblks & spaces     */
        if (!POLL_EVENTS()) exit(1);
#ifdef GAB_RT
        if (flprintfbis) { /* gab-A1 */
    		printf("--->Warning!!! all console text messages are disabled!!!\n");
			#ifdef GAB_WIN
			{
				extern void DisableDisplay(); /*gab d3*/
				DisableDisplay();
			}
			#endif	//GAB_WIN
	    	flprintf=1;
	    }
		if (unified_flag){ /* gab A8 */
			extern void deleteOrch();
			extern void deleteScore();
			deleteOrch(); 
			deleteScore();
		}
		n = musmon(); // <<3
    	t1 = clock();
    	elapsed = (double) (t1-t0)/ (double) CLOCKS_PER_SEC;
    	printf("Total processing time: %.3lf seconds", elapsed);
    	//getgab(); /* gab d4*/
       	return n; 
#else /* GAB_RT */

	/* fine aggiunta Gabriele */   /* gab-A1 */
        return musmon();        /* load current orch and play current score */
#endif /* GAB_RT */
}




#ifdef CWIN
int args_OK = 0;
extern void  cwin_poll_window_manager(void);
extern void cwin_args(char **, char **, char **);

void dialog_arguments(void)
{
    cwin_args(&orchname, &scorename, &xfilename);
}
#endif

#ifndef GAB_WIN //CWIN
#include <stdarg.h>

void dribble_printf(char *fmt, ...)
{
    if (!flprintf) {  /* gab-A1 */
        va_list a;
        va_start(a, fmt);
        vprintf(fmt, a);
        va_end(a);
        if (dribble != NULL) {
            va_start(a, fmt);
            vfprintf(dribble, fmt, a);
            va_end(a);
        }
    }  
}

void err_printf(char *fmt, ...)
{
		extern int flprintf; /* gab c3 */
		int temp;
		temp = flprintf;
		flprintf = 0;
    if (!flprintf) {  /* gab-A1 */
        va_list a;
        va_start(a, fmt);
        vfprintf(stderr, fmt, a);
        va_end(a);
        if (dribble != NULL) {
            va_start(a, fmt); /* gab */
            vfprintf(dribble, fmt, a);
            va_end(a);
        }
    }
	flprintf=temp;
}
#endif

void write_dummy_score(char *s)
{
	FILE *dummy;
	if ((dummy=fopen(s,"wt"))==NULL) {
		printf("error opening dummy file score.srt\n");
		exit(0);
	}
	fprintf(dummy,"w 0 60\nf 0  900000  900000\n");
	fclose(dummy);
}

