#include "sftype.h"
#include "sf.h"

typedef struct {
	OPDS	h;
	float	*ihandle, *fname;
} SFLOAD;

typedef struct {
	OPDS	h;
	float	*ihandle;
} SFPLIST;

typedef struct {
	OPDS	h;
	float	*startNum,*ihandle;
} SFPASSIGN;

typedef struct {
	OPDS	h;
	float	*ipresethandle, *iprog, *ibank, *isfhandle, *iPresetHandle;
} SFPRESET;

#define MAXSPLT 10

typedef struct {
	OPDS	h;
	float	*out1, *out2,  *ivel, *inotnum,*xamp, *xfreq, *ipresethandle, *iflag;
	int spltNum;
	SHORT *base[MAXSPLT], mode[MAXSPLT];
	DWORD end[MAXSPLT], startloop[MAXSPLT], endloop[MAXSPLT];
	double si[MAXSPLT],phs[MAXSPLT];
	float  leftlevel[MAXSPLT], rightlevel[MAXSPLT];
} SFPLAY;
										  

typedef struct {
	OPDS	h;
	float	*out1,  *ivel, *inotnum,*xamp, *xfreq, *ipresethandle, *iflag;
	int spltNum;
	SHORT *base[MAXSPLT], mode[MAXSPLT];
	DWORD end[MAXSPLT], startloop[MAXSPLT], endloop[MAXSPLT];
	double si[MAXSPLT],phs[MAXSPLT];
	float  attenuation[MAXSPLT] ;
} SFPLAYMONO;

typedef struct {
	OPDS	h;
	float	*out1,  *ivel, *inotnum, *xamp, *xfreq, *instrNum, *sfBank, *iflag;
	int spltNum;
	SHORT *base[MAXSPLT], mode[MAXSPLT];
	DWORD end[MAXSPLT], startloop[MAXSPLT], endloop[MAXSPLT];
	double si[MAXSPLT],phs[MAXSPLT];
	float  attenuation[MAXSPLT] ;
} SFIPLAYMONO;


typedef struct {
	OPDS	h;
	float	*out1, *out2, *ivel, *inotnum, *xamp, *xfreq, *instrNum, *sfBank, *iflag;
	int spltNum;
	SHORT *base[MAXSPLT], mode[MAXSPLT];
	DWORD end[MAXSPLT], startloop[MAXSPLT], endloop[MAXSPLT];
	double si[MAXSPLT],phs[MAXSPLT];
	float  leftlevel[MAXSPLT], rightlevel[MAXSPLT];
} SFIPLAY;
