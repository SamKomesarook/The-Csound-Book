/*      vdelay, multitap, reverb2 coded by Paris Smaragdis 1994 */
/*      Berklee College of Music Csound development team        */
/*      Copyright (c) May 1994.  All rights reserved            */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "cs.h"
#include "vdelay.h"
#include "revsets.h"

#define ESR     (esr/1000.0f)

void vdelset(VDEL *p)           /*  vdelay set-up   */
{
    unsigned long n = (long)(*p->imaxd * ESR);
    FLOAT *buf;

    if (n == 0) n = 1;		/* fix due to Troxler */

    if (!*p->istod) {
      if (p->aux.auxp == NULL ||
	  (int)(n*sizeof(FLOAT)) > p->aux.size) /* allocate space for delay buffer */
	auxalloc(n * sizeof(FLOAT), &p->aux);
      else {
	buf = (FLOAT *)p->aux.auxp;  /*    make sure buffer is empty       */
	do {
	  *buf++ = 0.0f;
	} while (--n);
      }
      p->left = 0;
    }
}

void vdelay(VDEL *p)              /*      vdelay  routine */
{
    unsigned long  nn, maxd, indx;
    FLOAT *out = p->sr;  /* assign object data to local variables   */
    FLOAT *in = p->ain;
    FLOAT *del = p->adel;
    FLOAT *buf = (FLOAT *)p->aux.auxp;

    if (buf==NULL) {            /* RWD fix */
      initerror(Str(X_1372,"vdelay: not initialized"));
      return;
    }
    maxd = (unsigned long) (*p->imaxd * ESR);
    if (maxd == 0) maxd = 1;	/* Degenerate case */
    nn = ksmps;
    indx = p->left;

    if (p->XINCODE == 3)    {    /*      if delay is a-rate      */
        do {
	    FLOAT  fv1, fv2;
	    long   v1, v2;
        
            buf[indx] = *in++;
            fv1 = indx - (*del++) * ESR;
        /* Make sure Inside the buffer      */
	    /*
	     * The following has been fixed by adding a cast and making a
	     * ">=" instead of a ">" comparison. The order of the comparisons
	     * has been swapped as well (a bit of a nit, but comparing a
	     * possibly negative number to an unsigned isn't a good idea--and
	     * broke on Alpha).
	     * heh 981101
	     */
            while (fv1 < 0.0f)
                fv1 += (FLOAT)maxd;
            while (fv1 >= (FLOAT)maxd)
                fv1 -= (FLOAT)maxd;
        
            if (fv1 < maxd - 1) /* Find next sample for interpolation      */
                fv2 = fv1 + 1;
            else
                fv2 = 0.0f;
        
            v1 = (long)fv1;
            v2 = (long)fv2;
            *out++ = buf[v1] + (fv1 - ( long)fv1) * ( buf[v2] - buf[v1]);
        
            if (++indx == maxd) indx = 0;             /* Advance current pointer */

        } while (--nn);
    }
    else {                      /* and, if delay is k-rate */
        do {
            FLOAT  fv1, fv2;
            long   v1, v2;
        
            buf[indx] = *in++;
            fv1 = indx - *del * ESR;
				/* Make sure inside the buffer      */
	    /*
	     * See comment above--same fix applied here.  heh 981101
	     */
            while (fv1 < 0.0f)
                fv1 += (FLOAT)maxd;
            while (fv1 >= (FLOAT)maxd)
                fv1 -= (FLOAT)maxd;
        
            if (fv1 < maxd - 1) /* Find next sample for interpolation      */
                fv2 = fv1 + 1;
            else
                fv2 = 0.0f;
        
            v1 = (long)fv1;
            v2 = (long)fv2;
            *out++ = buf[v1] + (fv1 - ( long)fv1) * ( buf[v2] - buf[v1]);
        
            if (++indx == maxd) indx = 0;             /*      Advance current pointer */
                        
        } while (--nn);
    }
    p->left = indx;             /*      and keep track of where you are */
}

void vdelay3(VDEL *p)              /*      vdelay routine with cubic interp */
{
    unsigned long  nn, maxd, indx;
    FLOAT *out = p->sr;  /* assign object data to local variables   */
    FLOAT *in = p->ain;
    FLOAT *del = p->adel;
    FLOAT *buf = (FLOAT *)p->aux.auxp;

    if (buf==NULL) {            /* RWD fix */
      initerror(Str(X_1371,"vdelay3: not initialized"));
      return;
    }
    maxd = (unsigned long) (*p->imaxd * ESR);
    if (maxd == 0) maxd = 1;	/* Degenerate case */
    nn = ksmps;
    indx = p->left;

    if (p->XINCODE == 3)    {    /*      if delay is a-rate      */
        do {
	    FLOAT  fv1, fv2;
	    long   v0, v1, v2, v3;
        
            buf[indx] = *in++;
            fv1 = indx - (*del++) * ESR;
        /* Make sure Inside the buffer      */
	    /*
	     * The following has been fixed by adding a cast and making a
	     * ">=" instead of a ">" comparison. The order of the comparisons
	     * has been swapped as well (a bit of a nit, but comparing a
	     * possibly negative number to an unsigned isn't a good idea--and
	     * broke on Alpha).
	     * heh 981101
	     */
            while (fv1 < 0.0f)
                fv1 += (FLOAT)maxd;
            while (fv1 >= (FLOAT)maxd)
                fv1 -= (FLOAT)maxd;
        
            if (fv1 < maxd - 1) /* Find next sample for interpolation      */
                fv2 = fv1 + 1;
            else
                fv2 = 0.0f;

            v1 = (long)fv1;
            v2 = (long)fv2;
            if (maxd<4) {
            *out++ = buf[v1] + (fv1 - ( long)fv1) * ( buf[v2] - buf[v1]);
            }
            else {
              FLOAT delfrac = fv1 - ( long)fv1;
              v0 = (v1==0 ? maxd-1 : v1-1);
              v3 = (v2==(long)maxd-1 ? 0 : v2+1);
              {
                FLOAT frsq = delfrac*delfrac;
                FLOAT frcu = frsq*buf[v0];
                FLOAT t1 = buf[v3] + 3*buf[v1];
                *out++ = buf[v1] + 0.5f*frcu +
                  delfrac*(buf[v2] - frcu/6 - t1/6 - buf[v0]/3) +
                  frsq*delfrac*(t1/6 - 0.5f*buf[v2]) +
                  frsq*(0.5f* buf[v2] - buf[v1]);
              }
            }
            if (++indx == maxd) indx = 0;             /* Advance current pointer */

        } while (--nn);
    }
    else {                      /* and, if delay is k-rate */
        do {
            FLOAT  fv1, fv2;
	    long   v0, v1, v2, v3;
        
            buf[indx] = *in++;
            fv1 = indx - *del * ESR;
				/* Make sure inside the buffer      */
	    /*
	     * See comment above--same fix applied here.  heh 981101
	     */
            while (fv1 < 0.0f)
                fv1 += (FLOAT)maxd;
            while (fv1 >= (FLOAT)maxd)
                fv1 -= (FLOAT)maxd;
        
            if (fv1 < maxd - 1) /* Find next sample for interpolation      */
                fv2 = fv1 + 1;
            else
                fv2 = 0.0f;
        
            v1 = (long)fv1;
            v2 = (long)fv2;
            if (maxd<4) {
            *out++ = buf[v1] + (fv1 - ( long)fv1) * ( buf[v2] - buf[v1]);
            }
            else {
              FLOAT delfrac = fv1 - ( long)fv1;
              v0 = (v1==0 ? maxd : v1-1);
              v3 = (v2==(long)maxd-1 ? 0 : v2+1);
              {
                FLOAT frsq = delfrac*delfrac;
                FLOAT frcu = frsq*buf[v0];
                FLOAT t1 = buf[v3] + 3*buf[v1];
                *out++ = buf[v1] + 0.5f*frcu +
                  delfrac*(buf[v2] - frcu/6 - t1/6 - buf[v0]/3) +
                  frsq*delfrac*(t1/6 - 0.5f*buf[v2]) +
                  frsq*(0.5f* buf[v2] - buf[v1]);
              }
            }
            if (++indx == maxd) indx = 0;             /*      Advance current pointer */
                        
        } while (--nn);
    }
    p->left = indx;             /*      and keep track of where you are */
}

void multitap_set(MDEL *p)
{
    long n;
    FLOAT *buf, max = 0.0f;

    if (p->INOCOUNT/2 == (FLOAT)p->INOCOUNT/2.)
        die(Str(X_539,"Wrong input count in multitap\n"));

    for (n = 0 ; n < p->INOCOUNT - 1 ; n += 2) {
        if (max < *p->ndel[n]) max = *p->ndel[n];
    }

    n = (long)(esr * max * sizeof(FLOAT));
    if (p->aux.auxp == NULL ||    /* allocate space for delay buffer */
	n > p->aux.size)
      auxalloc(n, &p->aux);
    else {
      buf = (FLOAT *)p->aux.auxp; /* make sure buffer is empty       */
      n = p->max;
      do {
	*buf++ = 0.0f;
      } while (--n);
    }

    p->left = 0;
    p->max = (long)(esr * max);
}

void multitap_play(MDEL *p)
{                               /* assign object data to local variables   */
    long  n, nn = ksmps, indx = p->left, delay;
    FLOAT *out = p->sr, *in = p->ain;
    FLOAT *buf = (FLOAT *)p->aux.auxp;
    FLOAT max = (FLOAT)p->max;

    if (buf==NULL) {            /* RWD fix */
      initerror(Str(X_1008,"multitap: not initialized"));
      return;
    }
    do {
        buf[indx] = *in++;      /*      Write input     */
        *out = 0.0f;            /*      Clear output buffer     */

        if (++indx == max) indx = 0;         /*      Advance input pointer   */
        for (n = 0 ; n < p->INOCOUNT - 1 ; n += 2) {
            delay = indx - (long)(esr * *p->ndel[n]);
            if (delay < 0)
                delay += (long)max;
            *out += buf[delay] * *p->ndel[n+1]; /*      Write output    */
        }
        out++;                  /*      Advance output pointer  */
    } while (--nn);
    p->left = indx;
}

#ifdef OLD_CODE
#define LOG001  (-6.9078)       /* log(.001) */

void reverb2_set(STVB *p)            /* 6-comb/lowpass, 5-allpass reverberator */
{
     long i, n;
     FLOAT *temp;

    if (*p->hdif > 1.0 || *p->hdif < 0)
        die(Str(X_294,"High frequency diffusion not in (0, 1)\n"));

    if (*p->istor == 0.0 || p->temp.auxp == NULL) {
      auxalloc(ksmps * sizeof(FLOAT), &p->temp);
      temp = (FLOAT *)p->temp.auxp;
      for (n = 0 ; n < ksmps ; n++)
        *temp++ = 0.0;
      for (i = 0 ; i < Combs ; i++) {
        p->c_time[i] = gc_time[i];
        p->c_gain[i] = exp((double)(LOG001 * (p->c_time[i]/esr) /
                                    (gc_gain[i] * *p->time)));
        p->g[i] = *p->hdif;
        p->c_gain[i] = p->c_gain[i] * (1 - p->g[i]);
        p->z[i] = 0.0;

        auxalloc((long)(p->c_time[i] * sizeof(FLOAT)), &p->caux[i]);
        p->cbuf_cur[i] = (FLOAT *)p->caux[i].auxp;
        for (n = 0 ; n < p->c_time[i] ; n++)
            *(p->cbuf_cur[i] + n) = 0.0;
      }

      for (i = 0 ; i < Alpas ; i++) {
        p->a_time[i] = ga_time[i];
        p->a_gain[i] = exp((double)(LOG001 * (p->c_time[i]/esr) /
                                    (ga_gain[i] * *p->time)));
        auxalloc((long) p->a_time[i] * sizeof(FLOAT), &p->aaux[i]);
        p->abuf_cur[i] = (FLOAT *)p->aaux[i].auxp;
      }
    }

    p->prev_time = *p->time;
    p->prev_hdif = *p->hdif;
}

void reverb2_play(STVB *p)
{
    long       i, n = ksmps;
     FLOAT      *in, *out = p->out, *buf, *end;
     FLOAT      gain, z;
     FLOAT	hdif = *p->hdif;
     FLOAT	time = *p->time;

     if (p->temp.auxp==NULL) {
       initerror(Str(X_1165,"reverb2: not initialized"));
       return;
     }
     do  *out++ = 0.0f;
     while (--n);
     if (time != p->prev_time || hdif != p->prev_hdif) {
       if (hdif > 1.0f) {
         printf(Str(X_532,"Warning: High frequency diffusion>1\n"));
         hdif = 1.0f;
       }
       if (hdif < 0.0f)       {
         printf(Str(X_531,"Warning: High frequency diffusion<0\n"));
         hdif = 0.0f;
       }
       if (time < 0.0f)       {
         printf(Str(X_356,"Negative time?\n"));
         time = 0.0;
       }
       for (i = 0 ; i < Combs ; i++)   {
         p->c_gain[i] = exp((double)(LOG001 * (p->c_time[i]/esr) /
                                     (gc_gain[i] * time)));
         p->g[i] = hdif;
         p->c_gain[i] = p->c_gain[i] * (1 - p->g[i]);
         p->z[i] = 0.0f;
       }

       for (i = 0 ; i < Alpas ; i++)
         p->a_gain[i] = exp((double)(LOG001 * (p->a_time[i]/esr) /
                                     (ga_gain[i] * time)));

       p->prev_time = time;
       p->prev_hdif = hdif;
     }

     for (i = 0 ; i < Combs ; i++)       {
       buf = p->cbuf_cur[i];
       end = (FLOAT *)p->caux[i].endp;
       gain = p->c_gain[i];
       in = p->in;
       out = p->out;
       n = ksmps;
       do {
         *out++ += *buf;
         *buf += p->z[i] * p->g[i];
         p->z[i] = *buf;
         *buf *= gain;       
         *buf += *in++;                      
         if (++buf >= end)
           buf = (FLOAT *)p->caux[i].auxp;
       } while (--n);
       p->cbuf_cur[i] = buf;
     }

     for (i = 0 ; i < Alpas ; i++)       {
       in = (FLOAT *)p->temp.auxp;
       out = p->out;
       n = ksmps;
       do      *in++ = *out++;
       while (--n);
       buf = p->abuf_cur[i];
       end = (FLOAT *)p->aaux[i].endp;
       gain = p->a_gain[i];
       in = (FLOAT *)p->temp.auxp;
       out = p->out;
       n = ksmps;
       do {
         z = *buf;
         *buf = gain * z + *in++;
         *out++ = z - gain * *buf;
         if (++buf >= end)
           buf = (FLOAT *)p->aaux[i].auxp;
       } while (--n);
       p->abuf_cur[i] = buf;
     }
}
#endif

/*      nreverb coded by Paris Smaragdis 1994 and Richard Karpen 1998 */

#define LOG001  (-6.9078)       /* log(.001) */
#define true 1
#define false 0

FLOAT ngc_time[Combs] = {1433.0f, 1601.0f, 1867.0f, 2053.0f, 2251.0f, 2399.0f};
FLOAT ngc_gain[Combs] = {.822f, .802f, .773f, .753f, .753f, .753f};
FLOAT nga_time[Alpas] = {347.0f, 113.0f, 37.0f, 59.0f, 43.0f};
FLOAT nga_gain = 0.7f;

int prime( int val )
{
    int i, last;
	
    last = (int)sqrt( (double)val );
    for ( i = 3; i <= last; i+=2 ) {
      if ( (val % i) == 0 ) return false;
    }
    return true;
}

void nreverb_set(NREV *p)   /* 6-comb/lowpass, 5-allpass reverberator */
{
     long i, n;
     FLOAT *temp;
     FLOAT srscale=esr/25641.0f; /* denominator is probably CCRMA "samson box" sampling-rate! */
     int c_time, a_time;

     if (*p->hdif > 1.0f || *p->hdif < 0.0f)
        die(Str(X_294,"High frequency diffusion not in (0, 1)\n"));
     
     if (*p->istor == 0.0f || p->temp.auxp == NULL) {
       auxalloc(ksmps * sizeof(FLOAT), &p->temp);
       temp = (FLOAT *)p->temp.auxp;
       for (n = 0 ; n < ksmps ; n++)
         *temp++ = 0.0f;
 
       for (i = 0 ; i < Combs ; i++) {
       /* derive new primes to make delay times work with orch. sampling-rate */ 
         c_time = (int)(ngc_time[i] * srscale);
         if (c_time % 2 == 0)  c_time += 1;
         while(!prime( c_time))  c_time += 2;
         p->c_time[i] = (FLOAT)c_time;

         p->c_gain[i] = (FLOAT)exp((double)(LOG001 * (p->c_time[i]/esr) /
					    (ngc_gain[i] * *p->time)));
         p->g[i] = *p->hdif;
         p->c_gain[i] = p->c_gain[i] * (1 - p->g[i]);
         p->z[i] = 0.0f;

         auxalloc((long)(p->c_time[i] * sizeof(FLOAT)), &p->caux[i]);
         p->cbuf_cur[i] = (FLOAT *)p->caux[i].auxp;
         for (n = 0 ; n < p->c_time[i] ; n++)
           *(p->cbuf_cur[i] + n) = 0.0f;
       }
       for (i = 0 ; i < 5 ; i++) {
         a_time = (int)(nga_time[i] * srscale);
         if (a_time % 2 == 0)  a_time += 1;
         while(!prime( a_time))  a_time += 2;
         p->a_time[i] = (FLOAT)a_time;
         p->a_gain[i] = (FLOAT)exp((double)(LOG001 * (p->a_time[i]/esr) /
					    (nga_gain * *p->time))); 
         auxalloc((long) p->a_time[i] * sizeof(FLOAT), &p->aaux[i]);
         p->abuf_cur[i] = (FLOAT *)p->aaux[i].auxp;
       }
        
     }

     p->prev_time = *p->time;
     p->prev_hdif = *p->hdif;
}

void nreverb(NREV *p)
{
    long       i, n = ksmps;
    FLOAT      *in, *out = p->out, *buf, *end;
    FLOAT      gain, z;
    FLOAT      hdif = *p->hdif;
    FLOAT      time = *p->time;

    if (p->temp.auxp==NULL) {
      initerror(Str(X_1165,"reverb2: not initialized"));
      return;
    }
    do  *out++ = 0.0f;
    while (--n);
    if (*p->time != p->prev_time || *p->hdif != p->prev_hdif) {
      if (hdif > 1.0f) {
        printf(Str(X_532,"Warning: High frequency diffusion>1\n"));
        hdif = 1.0f;
      }
      if (hdif < 0.0f)       {
        printf(Str(X_531,"Warning: High frequency diffusion<0\n"));
        hdif = 0.0f;
      }
      if (time < 0.0f)       {
        printf(Str(X_356,"Negative time?\n"));
        time = 0.0f;
      }
      for (i = 0 ; i < Combs ; i++)   {
        p->c_gain[i] = (FLOAT)exp((double)(LOG001 * (p->c_time[i]/esr) /
					   (ngc_gain[i] * time)));
        p->g[i] = hdif;
        p->c_gain[i] = p->c_gain[i] * (1 - p->g[i]);
        p->z[i] = 0.0f;
      }

      for (i = 0 ; i < Alpas ; i++)
        p->a_gain[i] = (FLOAT)exp((double)(LOG001 * (p->a_time[i]/esr) /
					   (nga_gain * time)));

      p->prev_time = time;
      p->prev_hdif = hdif;
    }

    for (i = 0 ; i < Combs ; i++)       {
      buf = p->cbuf_cur[i];
      end = (FLOAT *)p->caux[i].endp;
      gain = p->c_gain[i];
      in = p->in;
      out = p->out;
      n = ksmps;
      do {
        *out++ += *buf;
        *buf += p->z[i] * p->g[i];
        p->z[i] = *buf;
        *buf *= gain;       
        *buf += *in++;                      
        if (++buf >= end)
          buf = (FLOAT *)p->caux[i].auxp;
      } while (--n);
      p->cbuf_cur[i] = buf;
    }

    for (i = 0 ; i < 5 ; i++)       {
      in = (FLOAT *)p->temp.auxp;
      out = p->out;
      n = ksmps;
      do      *in++ = *out++;
      while (--n);
      buf = p->abuf_cur[i];
      end = (FLOAT *)p->aaux[i].endp;
      gain = p->a_gain[i];
      in = (FLOAT *)p->temp.auxp;
      out = p->out;
      n = ksmps;
      do {
        z = *buf;
        *buf = gain * z + *in++;
        *out++ = z - gain * *buf;
        if (++buf >= end)
          buf = (FLOAT *)p->aaux[i].auxp;
      } while (--n);
      p->abuf_cur[i] = buf;
    }
}

