							/* biquad.h */


				/* Structure for biquadratic filter */
typedef struct {
    OPDS    h;
    FLOAT   *out, *in, *b0, *b1, *b2, *a0, *a1, *a2, *reinit;
    FLOAT   xnm1, xnm2, ynm1, ynm2;
} BIQUAD;

				/* Structure for moogvcf filter */
typedef struct {
    OPDS    h;
    FLOAT   *out, *in, *fco, *res, *max;
    FLOAT   xnm1, y1nm1, y2nm1, y3nm1, y1n, y2n, y3n, y4n;
    short   fcocod, rezcod;
} MOOGVCF;

				/* Structure for rezzy filter */
typedef struct {
    OPDS    h;
    FLOAT *out, *in, *fco, *rez, *mode;
    FLOAT   xnm1, xnm2, ynm1, ynm2;
    short   fcocod, rezcod;
} REZZY;

                                /* Structure for distortion */
typedef struct {
    OPDS    h;
    FLOAT   *out, *in, *pregain, *postgain, *shape1, *shape2;
} DISTORT;

                                /* Structure for vco, analog modeling opcode */
typedef struct {
    OPDS    h;
    FLOAT   *ar, *xamp, *xcps, *wave, *pw, *sine, *maxd;
    FLOAT   ynm1, ynm2, leaky;
    short   ampcod, cpscod;
    int     iphs;
    long    lphs;
    FUNC    *ftp;
 /* Insert VDelay here */
    AUXCH   aux;
 /* AUXCH   auxd; */
    long    left;
 /* End VDelay insert  */
} VCO;

typedef struct {
    OPDS    h;
    FLOAT   *outx, *outy, *outz, *mass1, *mass2, *sep, *xval, *yval, *zval;
    FLOAT   *vxval, *vyval, *vzval, *delta, *fric;
    FLOAT   s1z, s2z, friction;
    FLOAT   x, y, z, vx, vy, vz, ax, ay, az, hstep;
} PLANET;

typedef struct {
    OPDS h;
    FLOAT *out, *in, *fc, *v, *q, *mode;
    FLOAT xnm1, xnm2, ynm1, ynm2, imode;
} PAREQ;

typedef struct {
    OPDS    h;
    FLOAT   *out, *in, *mode, *maxdel, *del1, *gain1, *del2, *gain2;
    FLOAT   *del3, *gain3, *istor;
    FLOAT   *curp, out1, out2, out3;
    FLOAT   *beg1p, *beg2p, *beg3p, *end1p, *end2p, *end3p;
    FLOAT   *del1p, *del2p, *del3p;
    long    npts;
    AUXCH   auxch;
} NESTEDAP;

typedef struct {
    OPDS    h;
    FLOAT   *outx, *outy, *outz, *s, *r, *b, *hstep, *inx, *iny, *inz, *skip;
    FLOAT   valx, valy, valz;
} LORENZ;

