#include "cs.h"
#include "foldover.h"

void fold_set(FOLD *p)
{
	p->sample_index = 0;
	p->index = 0;
}

void fold(FOLD *p)
{
    int	nsmps = ksmps;
	float *ar = p->ar;
	float *asig = p->asig;
	float kincr = *p->kincr;
	double *index = &p->index;
	long *sample_index = &p->sample_index;
	float *value = &p->value;
	do {
		if (*index < *sample_index) {
			*index += kincr;
			*ar = *value = *asig;
		}
		else *ar = *value;
		
		(*sample_index)++;
		ar++;
		asig++;
	} while (--nsmps);
}
