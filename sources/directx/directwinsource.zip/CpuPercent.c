#include "cs.h"  
#include "CpuPercent.h"

float cpu_power_percent[MAXINSNO+1]; /*gab b3*/ /* contains supposed cpu usage percent of the corresponding instr num*/
float cpu_power_busy;  /*gab b3*/ /* accumulates the supposed percent of cpu usage */


void cpuperc(CPU_PERC *p)
{						
	cpu_power_percent[(int) *p->instrnum] = *p->ipercent;
}
