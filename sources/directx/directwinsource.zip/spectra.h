       		/*					SPECTRA.H	*/

#define MAXFRQS 120

typedef struct {
	OPDS	h;
	SPECDAT *wsig;
	FLOAT	*signal,*iprd,*iocts,*ifrqs,*iq,*ihann;
        FLOAT   *idbout,*idisprd,*idsines;
	int	nfreqs, hanning, ncoefs, dbout, nsmps, scountdown, timcount;
	FLOAT	curq, *sinp, *cosp, *linbufp;
	int     disprd, dcountdown, winlen[MAXFRQS], offset[MAXFRQS];
	DOWNDAT downsig;
	WINDAT  sinwindow, octwindow;
	AUXCH	auxch1, auxch2;
} SPECTRUM;

#ifdef never
typedef struct {
	OPDS	h;
	SPECDAT *wsig;
	DOWNDAT *dsig;
	FLOAT	*iprd, *ifrqs, *iq, *ihann, *idbout, *idsines;
	int	nfreqs, hanning, ncoefs, dbout;
	FLOAT	curq, *sinp, *cosp, *linbufp;
	int     countdown, timcount, winlen[MAXFRQS];
	WINDAT  dwindow;
	AUXCH	auxch;
} NOCTDFT;
#endif

typedef struct {
	OPDS	h;
	SPECDAT *wsig;
	FLOAT	*iprd, *iwtflg;
	int     countdown, timcount;
	WINDAT  dwindow;
} SPECDISP;

#define MAXPTL 10

typedef struct {
	OPDS	h;
	FLOAT	*koct, *kamp;
	SPECDAT *wsig;
	FLOAT	*kvar, *ilo, *ihi, *istrt, *idbthresh, *inptls, *irolloff;
	FLOAT	*iodd, *iconf, *interp, *ifprd, *iwtflg;
	int	pdist[MAXPTL], nptls, rolloff, kinterp, ftimcnt;
	FLOAT	pmult[MAXPTL], confact, kvalsav, kval, kavl, kinc, kanc;
	FLOAT   *flop, *fhip, *fundp, *oct0p, threshon, threshoff;
	int	winpts, jmpcount, playing;
	SPECDAT	wfund;
	SPECDISP fdisplay;
} SPECPTRK;

typedef struct {
	OPDS	h;
	FLOAT	*ksum;
	SPECDAT *wsig;
	FLOAT   *interp;
	int     kinterp;
	FLOAT	kval, kinc;
} SPECSUM;

typedef struct {
	OPDS	h;
	SPECDAT	*waddm;
	SPECDAT *wsig1, *wsig2;
	FLOAT   *imul2;
	FLOAT	mul2;
} SPECADDM;

typedef struct {
	OPDS	h;
	SPECDAT *wdiff;
	SPECDAT *wsig;
	SPECDAT specsave;
} SPECDIFF;

typedef struct {
	OPDS	h;
	SPECDAT *wscaled;
	SPECDAT *wsig;
	FLOAT	*ifscale, *ifthresh;
	int	thresh;
	FLOAT	*fscale, *fthresh;
	AUXCH	auxch;
} SPECSCAL;

typedef struct {
	OPDS	h;
	SPECDAT *wacout;
	SPECDAT *wsig;
	SPECDAT accumer;
} SPECHIST;

typedef struct {
	OPDS	h;
	SPECDAT *wfil;
	SPECDAT *wsig;
	FLOAT	*ifhtim;
	FLOAT   *coefs, *states;
	AUXCH	auxch;
} SPECFILT;
