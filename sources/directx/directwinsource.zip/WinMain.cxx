#define noMessageBoxGab
#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <conio.h>  
#include <mbstring.h>
#include <malloc.h>
#include <process.h>
#include "resource.h" 
#include "cs.h"

#ifdef GAB_WIN	 /* GAB d1 */
#define printf cwin_printf
extern "C" void (*cwin_printf)(char *s,...);
extern "C" int (*cwin_putchar)(int c);
extern "C" char * InputBoxGab(char *text, char *title);
extern "C" int MessageBoxGab( HWND hWnd, LPCTSTR lpText, LPCTSTR lpCaption, UINT uType );

#undef putchar
#define putchar cwin_putchar
#endif	  /* end gab d1 */

#define CONSOLE_BUFF 37000

extern "C" int  __argc;
extern "C" char **__argv;
extern "C" int exit_soon_flag;
extern "C" int flStartStop;

// prototipi di funzioni

LRESULT CALLBACK MainWndProc(	HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK NoArgumentsProc(HWND hDlg,UINT message, UINT wParam,LONG lParam);
extern "C" LPSTR quote(LPSTR );
void WINAPI GabConsole(LPVOID);
int CsoundProcess(LPSTR lpCmdLine);
//void null_printf(char *s,...);
extern "C" void gab_printf(char *s,...);
extern "C" void (*err_printf)(char *s,...);
//int null_putchar(int c);
extern "C" int gab_putch(int c); 
extern "C" void reset_all();
extern "C" void RegistrySet();
extern "C" void RegistryGet();
extern "C" void setBufScroll(int value);
extern "C" LRESULT CALLBACK AboutProc(HWND hDlg,UINT msg, UINT wParam,LONG lParam);


extern "C" LPSTR ExtractDir(LPSTR source);

extern "C" LPSTR FileDialogBox(HWND hOwner, LPSTR szFilter, LPSTR WindCaption, LPSTR defaultExt, LPSTR InitialDir );


extern "C" unsigned int inbufsiz,  outbufsiz;
extern "C" OPARMS O;
extern "C" int nchnls;
extern "C" BOOL flag3d;
extern "C" unsigned int outbuf3Dsiz;
extern "C" int sleep_flag;

extern "C" char terminato[];
static char *buff;
extern "C" char *orchname;
extern "C" char *scorename;
extern "C" int	synterrcnt;

HANDLE thConsole;
HANDLE thCsound;
HANDLE thWinMain;
DWORD IDThreadConsole;
DWORD IDThreadCsound;
BOOL MainWaitFlag=1;
BOOL IsStarted;
BOOL IsPaused;
BOOL IsOpened;
LPSTR  lpGlobalCmdLine;


//LRESULT CALLBACK  MainDialogProc(HWND hDlg,UINT message, UINT wParam,LONG lParam);
LRESULT CALLBACK MainConsoleProc(HWND hDlg,UINT message, UINT wParam,LONG lParam);
void EnableDisplay();

void Welcome(void);

extern "C" HINSTANCE hProcessInstance;	
//HWND MainProcessWinHandle;
extern "C" HWND MainDialogHandle;
extern "C" char TextBuf[16000];


int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int  nCmdShow)
{
	void WINAPI MainConsole(VOID);
	MSG msg ;
	//DWORD nRet;
	hProcessInstance = hInstance;
	lpGlobalCmdLine =  lpCmdLine;
	DialogBox(hProcessInstance, MAKEINTRESOURCE(MainDialog), NULL, (DLGPROC) MainConsoleProc);

	while(GetMessage(&msg,NULL,0,0))
	{
			TranslateMessage( &msg) ;
			DispatchMessage( &msg) ;
	}
	return msg.wParam;
}

LRESULT CALLBACK 
MainWndProc( HWND hwnd,	UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg)
	{
		case WM_DESTROY:
			PostQuitMessage(0);
			break ;
		default:
			break;
	}
	return DefWindowProc( hwnd, msg, wParam, lParam) ;
}


extern "C" int csound_main(int argc, char **argv);
extern "C" char *unquote(char *name);

static int xMinScroll;       // minimum horizontal scroll value 
extern "C" int xCurrentScroll;   // current horizontal scroll value 
static int xMaxScroll;       // maximum horizontal scroll value 


extern "C" int   segamps, sormsg;
extern "C" short rngflg;

void EnableDisplay(){
	cwin_printf = gab_printf;
	cwin_putchar = gab_putch;
	err_printf = gab_printf;
	O.msglevel = 0x7f;
	segamps = 1;
	sormsg =1;
	rngflg=1;
}


extern "C" char *OrcFile;
extern "C"char *ScoFile;
extern "C" char *WavFile;
extern "C"  char *LastFlags;
static BOOL FirstStart = TRUE;
static BOOL NewArguments = FALSE;
static char LineaComando[MAXCMDLINE][MAXNAME];
static char *LineaCom[MAXCMDLINE];
static int   LineaCnumArg;

int CsoundProcess(LPSTR lpCmdLine)
{
	int j, nRet;
	static char *s;
	if (FirstStart) {
		buff = (char *) malloc(CONSOLE_BUFF * sizeof(char)); buff[0]='\0';
		s =	(char *) malloc(MAXNAME * sizeof(char)); s[0]='\0';
		OrcFile = (char *) malloc(MAXNAME * sizeof(char)); OrcFile[0]='\0';
		ScoFile = (char *) malloc(MAXNAME * sizeof(char)); ScoFile[0]='\0';
		WavFile = (char *) malloc(MAXNAME * sizeof(char)); WavFile[0]='\0';
		LastFlags = (char *) malloc(MAXNAME * sizeof(char)); LastFlags[0]='\0';
		RegistryGet();
	}
	if (lpCmdLine[0] == '\0') {
		int j=1;
		char *token;
		static char buf[MAXNAME];
		if (FirstStart)	 
			NewArguments = TRUE;
		DialogBox(hProcessInstance, 
			MAKEINTRESOURCE(iddNoArguments), NULL , (DLGPROC) NoArgumentsProc);
		strcpy (LineaComando[0],__argv[0]);
		strcpy(buf,	LastFlags);
		token = strtok( buf, " \t" );

		while( token != NULL )
		{
			strcpy( LineaComando[j], token); 
			token = strtok( NULL, " " );
			j++;
		}
		strcpy(LineaComando[j++],OrcFile); //saves OrcFile;
		strcpy(buf,ScoFile);
		if (strtok(buf," ")){
			strcpy (LineaComando[j++] , ScoFile);// bufarray[2];
		}
		strcpy(buf,WavFile);
		if (strtok(buf," ") ) {
			strcpy(LineaComando[j], "-o");
			strcat(LineaComando[j++], WavFile);
		}
		LineaCnumArg=j;
	}
	else if (FirstStart) {
		LineaCnumArg = 	__argc;
		for(j =0; j< __argc ; j++){
			strcpy(LineaComando[j], __argv[j]);
		}
	}

	for (j = 0; j < LineaCnumArg; j++) {
		 LineaCom[j] = LineaComando[j];
	}

	FirstStart = FALSE;
	flStartStop = TRUE;
	NewArguments = TRUE;
	
	//////////////////////////////////////
	nRet = csound_main(LineaCnumArg, LineaCom);
	//////////////////////////////////////
	
	flStartStop=FALSE;
	SetDlgItemText(MainDialogHandle,idcStartStop,"Start");
	reset_all();
#undef exit
	
	if (exit_soon_flag) exit(0);
	return nRet;
}

extern "C" void DisableDisplay();
extern "C" void SetConWinParms();
extern "C" int directSound_flag;
extern "C" void (*audtran)(char *, int);
extern "C" void PlayDsoundNowait(char *, int);
extern "C" void PlayDsoundSleep(char *, int);
extern "C" void PlayDsoundAndFileNowait(char *, int);
extern "C" void PlayDsoundAndFileSleep(char *, int);
extern "C" void set_current_process_priority_critical(void);
extern "C" void set_current_process_priority_normal(void);
extern "C" void GabWriteAudioFile();
extern "C" void GabCloseAudioFile(); 

static BOOL fopened = FALSE;

LRESULT CALLBACK
MainConsoleProc(HWND hDlg,UINT msg, UINT wParam,LONG lParam)
{
	int nRet;
	static int fl = 1;
	switch (msg) { 		
		case WM_INITDIALOG:
			MainDialogHandle = hDlg;
			//MainProcessWinHandle = hDlg;
			EnableDisplay();
			// CSOUND THREAD
			thCsound = CreateThread(
				NULL,	// address of thread security attributes  
				8192,	// initial thread stack size, in bytes 
				(LPTHREAD_START_ROUTINE) CsoundProcess, // address of thread function 
				lpGlobalCmdLine,	// argument for new thread 
				0,	// creation flags 
				&IDThreadCsound// address of returned thread ID 
				);
			if (!thCsound) nRet = GetLastError();
			nRet = SetThreadPriority(thCsound, THREAD_PRIORITY_NORMAL);	
			{	
				LPSTR  s;
				char stringa[MAXNAME];
				HFONT fnt;
				LOGFONT logfnt;
				sprintf(stringa, "DirectCsound " DIRECTCSOUND_VERSION " (synchronized to standard %s)", VERSIONSTRING);
				nRet=SetWindowText(hDlg,stringa);
				
				DragAcceptFiles(hDlg,TRUE); 
				MainWaitFlag=0;
				
				logfnt.lfHeight	= 8;
				logfnt.lfWidth = 0;
				logfnt.lfEscapement	= 0;
				logfnt.lfOrientation= 0;
				logfnt.lfWeight	= 0;
				logfnt.lfItalic	= FALSE;
				logfnt.lfUnderline	= FALSE;
				logfnt.lfStrikeOut	= FALSE;
				logfnt.lfCharSet	= DEFAULT_CHARSET;
				logfnt.lfOutPrecision = OUT_DEFAULT_PRECIS;
				logfnt.lfClipPrecision= CLIP_DEFAULT_PRECIS;
				logfnt.lfQuality	= DEFAULT_QUALITY;
				logfnt.lfPitchAndFamily	= DEFAULT_PITCH | FF_DONTCARE;
				strcpy (logfnt.lfFaceName, "Courier\0");
				fnt = CreateFontIndirect( &logfnt);
				SendMessage(hDlg,
					WM_SETICON, 
					(WPARAM) ICON_BIG, (LPARAM) LoadIcon(hProcessInstance,MAKEINTRESOURCE(IDI_ICON1)));
				SendDlgItemMessage(hDlg, ID_display, 
					WM_SETFONT, 
					(WPARAM) fnt, MAKELPARAM(TRUE, 0));
				
				s=GetCommandLine();
				if(strstr(s,"+O")) {
					DisableDisplay();
					SetDlgItemText(hDlg,IDC_Suppress,"Enable Display");
					fl=0;
				}
				if (strstr(s,"+*") )
					CheckDlgButton( hDlg,idcSleep, BST_CHECKED);

				EnableWindow( GetDlgItem( hDlg, idcStart), FALSE);
				EnableWindow( GetDlgItem( hDlg, idcPause), FALSE);
			}
			break;
		case WM_SYSCOMMAND:
			switch(wParam) {
				case SC_CLOSE:
					RegistrySet();
					EndDialog(hDlg,1);
					exit(0);
			}
			break;
		case WM_SIZE:
			{
				HWND/*HANDLE */ hnd;
				RECT rett;
				int width, height;
				GetWindowRect( hDlg, &rett); 
				width = rett.right- rett.left-16;
				height = rett.bottom-rett.top-150;
				hnd = GetDlgItem(  hDlg, ID_display); 
				SetWindowPos( hnd, // handle of window 
					HWND_TOP, // placement-order handle 
					0, // horizontal position 
					0, 	// vertical position 
					width, // width 
					height, // height 
					SWP_NOREPOSITION | SWP_NOMOVE // window-positioning flags 
				);
				
				hnd = GetDlgItem(  hDlg, idcBufferScrollBar); 
				SetWindowPos( hnd, // handle of window 
					HWND_TOP, // placement-order handle 
					0, // horizontal position 
					0, 	// vertical position 
					width, // width 
					14, // height 
					SWP_NOREPOSITION | SWP_NOMOVE // window-positioning flags 
				);
			}	
			break;
		case WM_COMMAND :
			switch(wParam) {
				case idcEditOrc: 
					{
						char str[512], *editor;
						char *filename;
						int nRet;
						str[0] = '\0';
						if (OrcFile[0] == '\0') {
							filename = FileDialogBox(hDlg,  
								"Orc Files (*.ORC)\0*.ORC\0CSD Files (*.CSD)\0*.*\0All Files (*.*)\0*.*\0", 
								"Create Orchestra File", "orc", ExtractDir(OrcFile));
							if (filename[0] != '\0') 
								strcpy(OrcFile, unquote(filename));
						}
						if ((editor = getenv("CSEDITOR")) == NULL)
							strcpy(str,"notepad.exe");	 
						else
							strcpy(str,editor);
						nRet=_spawnlp(_P_NOWAIT, str," ",quote(OrcFile), NULL);
						nRet = errno ; 
					}
					break;
				case idcEditSco:
					{
						char str[512], *editor;
						char *filename;
						int nRet;
						str[0] = '\0';
						if (OrcFile[0] == '\0') {
							filename = FileDialogBox(hDlg,  
								"Score Files (*.SCO)\0*.SCO\0All Files (*.*)\0*.*\0", 
								"Create Score File", "sco", ExtractDir(ScoFile));
							if (filename[0] != '\0') 
								strcpy(ScoFile,unquote(filename));
						}
						if ((editor = getenv("CSEDITOR")) == NULL)
							strcpy(str,"notepad.exe");	 
						else
							strcpy(str,editor);
						nRet=_spawnlp(_P_NOWAIT, str," ",quote(ScoFile), NULL);
						nRet = errno ; 
					}
					break;

				case QuitButton:
					RegistrySet();
					EndDialog(hDlg,1);
					exit(0);
					break;
				case idcStartStop:
					synterrcnt = 0;
					if (flStartStop) {
						fcloseall();
						gab_printf(terminato);
						TerminateThread(thCsound,0);
						reset_all();
						SetDlgItemText(hDlg,idcStartStop,"Start");
						flStartStop=FALSE;
						NewArguments=TRUE;
					}
					else {
						int nRet;
						gab_printf("\nNew Csound session started...\nCould need some seconds to be activated\n");
						SetDlgItemText(hDlg,idcStartStop,"Stop");
						flStartStop = TRUE;
						NewArguments=FALSE;
						thCsound = CreateThread(
							NULL,	// address of thread security attributes  
							8192,	// initial thread stack size, in bytes 
							(LPTHREAD_START_ROUTINE) CsoundProcess, // address of thread function 
							LineaComando,	// argument for new thread 
							0,	// creation flags 
							&IDThreadCsound// address of returned thread ID 
							);
						if (!thCsound) nRet = GetLastError();
						SetThreadPriority(thCsound, THREAD_PRIORITY_NORMAL);
						
					}
					
					break;
				case idcRestart: 
					{
						int nRet;
						synterrcnt = 0;
						if (flStartStop) {
							fcloseall();
							gab_printf(terminato);
							TerminateThread(thCsound,0);
							reset_all();
							NewArguments=TRUE;
						}
						SetDlgItemText(hDlg,idcStartStop,"Stop");
						gab_printf("\nNew Csound session started...\nCould need some seconds to be activated\n");
						flStartStop=TRUE;
						lpGlobalCmdLine = "\0";					
						thCsound = CreateThread(
							NULL,	// address of thread security attributes  
							8192,	// initial thread stack size, in bytes 
							(LPTHREAD_START_ROUTINE) CsoundProcess, // address of thread function 
							"\0",	// argument for new thread 
							0,	// creation flags 
							&IDThreadCsound// address of returned thread ID 
							);
						if (!thCsound) nRet = GetLastError();
						SetThreadPriority(thCsound, THREAD_PRIORITY_NORMAL);
						//NewArguments=TRUE;
						
					}
					break;
				case IDC_Suppress:
					if (fl) {
						DisableDisplay();
						SetDlgItemText(hDlg,IDC_Suppress,"Enable Display");

					}
					else {
						EnableDisplay();
						SetDlgItemText(hDlg,IDC_Suppress,"Suppress Display");
					}
					fl = !fl;
					break;
			    case idcSleep:
					if ( directSound_flag ) {
						if (BST_CHECKED==IsDlgButtonChecked( hDlg, idcSleep)){ 
							sleep_flag=TRUE;
							audtran =  PlayDsoundSleep;
							set_current_process_priority_critical();
						}
						else {
							sleep_flag=FALSE;
							audtran =  PlayDsoundNowait;
							set_current_process_priority_normal();
						}
					}		
					break;
				case idcBrowse:	
					{ 
					LPSTR filename;
					filename = FileDialogBox(hDlg,  
							"Wave Files (*.WAV)\0*.WAV\0All Files (*.*)\0*.*\0", 
							"Browse Output Audio File", "wav",ExtractDir(WavFile));
					if (filename[0] != '\0')
						SetDlgItemText(hDlg,idcEditOutputFile,filename);
					}
					break;
				case idcAbout:
					{
						LRESULT CALLBACK AboutProc(HWND hDlg,UINT msg, UINT wParam,LONG lParam);
						DialogBox(hProcessInstance, MAKEINTRESOURCE(iddAbout), NULL, (DLGPROC) AboutProc);
					}
					break;
				case idcEnableFileOutput:
					{
						static char buf[MAXNAME];
						if  (BST_CHECKED==IsDlgButtonChecked( hDlg, idcEnableFileOutput)){ 
							GetDlgItemText( hDlg,idcEditOutputFile, buf, sizeof(buf));
							if(*buf != '\0') {
								EnableWindow( GetDlgItem( hDlg, idcStart), TRUE);
								EnableWindow( GetDlgItem( hDlg, idcPause), TRUE);
								IsOpened = TRUE;
								O.outfilename =  buf;
								GabWriteAudioFile();
							}
							else { 
								IsOpened=FALSE;
								EnableWindow( GetDlgItem( hDlg, idcStart), FALSE);
								EnableWindow( GetDlgItem( hDlg, idcPause), FALSE);
								CheckDlgButton( hDlg,idcEnableFileOutput, BST_UNCHECKED); 
							}
						}
						else {
							IsOpened=FALSE;
							EnableWindow( GetDlgItem( hDlg, idcStart), FALSE);
							EnableWindow( GetDlgItem( hDlg, idcPause), FALSE);
							GabCloseAudioFile();
						}
					}
					break;
				case idcStart:
					{
						if (sleep_flag)
							audtran = PlayDsoundAndFileSleep;
						else
							audtran = PlayDsoundAndFileNowait;
					}
					break;
				case idcPause:
					{
						if (sleep_flag)
							audtran = PlayDsoundSleep;
						else
							audtran = PlayDsoundNowait;
					}
					break;
			}		
			break;
		case WM_DROPFILES:
			{	
				HDROP /*HANDLE*/	hDrop = (HDROP /*HANDLE*/) wParam;
				static char buf[256];
				int nRet;
				DragQueryFile(  hDrop,  // handle to structure for dropped files 
					0,  // index of file to query 
					buf,  // buffer for returned filename 
					400  // size of buffer for filename 
					);
				if (strstr(buf,".csd") || strstr(buf,".rto")) {
					
					if (flStartStop) {
						fcloseall();
						gab_printf(terminato);
						TerminateThread(thCsound,0);
						reset_all();
					}
					SetDlgItemText(hDlg,idcStartStop,"Stop");
					//strcpy(BakArguments[1],buf);
					//strcpy (buf,"\"");
					//strcat (buf, BakArguments[1]);
					//strcat (buf, "\""); 
					//maxCurrArgs=2;
					//strcpy( GabCommandLine, buf);
					flStartStop = TRUE;
					NewArguments=FALSE;
					thCsound = CreateThread(
						NULL,	// address of thread security attributes  
						8192,	// initial thread stack size, in bytes 
						(LPTHREAD_START_ROUTINE) CsoundProcess, // address of thread function 
						buf,	// argument for new thread 
						0,	// creation flags 
						&IDThreadCsound// address of returned thread ID 
						);
					if (!thCsound) nRet = GetLastError();
					SetThreadPriority(thCsound, THREAD_PRIORITY_NORMAL);	
				}
				else {
					MessageBox(hDlg, 
						"Only .csd and .rto files allowed in this drag/drop context\r\nOperation aborted!",
						"DirectCsound warning", MB_OK);
				}
			}
			break;
		case WM_HSCROLL:
			{
			HWND hnd;
			char st[10];
			int value;
			SCROLLINFO scroll;
			switch((int) LOWORD(wParam)) {
				case SB_PAGEUP: 
					value = xCurrentScroll - 10; 
					break; 
				case SB_PAGEDOWN: 
					value = xCurrentScroll + 10; 
					break; 
	            case SB_LINEUP: 
		            value = xCurrentScroll - 1; 
			        break; 
	            case SB_LINEDOWN: 
		            value = xCurrentScroll + 1; 
			        break; 
				case SB_THUMBPOSITION: 
					value = HIWORD(wParam); 
					break;
		       default: 
		            value = xCurrentScroll; 
			}
			value = max(2, value); 
			value = min(1500, value); 
			xCurrentScroll = value;
			scroll.cbSize = sizeof(scroll); 
			scroll.fMask  = SIF_POS; 
			scroll.nPos   = value; 
			hnd = GetDlgItem(  hDlg, idcBufferScrollBar);
			SetScrollInfo(hnd, SB_CTL,&scroll,TRUE);
			SetDlgItemText(hDlg,idcBufferLabel,itoa(value,st,10));
			outbuf3Dsiz = outbufsiz = inbufsiz = value * O.outsampsiz * nchnls;
			O.inbufsamps = O.outbufsamps= value*nchnls;
			}
			break;
	}
	return FALSE;
}

static int  pointer =0;
static  LPSTR p;


extern "C" void gab_printf(char *s,...)
{
	
	static char temp[4096], temp2[4096], *cp;
	static int counter=0;
	long  *args, a1, a2, a3, a4, a5, a6, a7, a8;
	static LRESULT i=0;
	int j=0;
		
	args= (long *)&s;
	args++;
	a1= *args++;
	a2= *args++;
	a3= *args++;
	a4= *args++;
	a5= *args++;
	a6= *args++;
	a7= *args++;
	a8= *args++;

	cp = s;	j=0;
	if (pointer > CONSOLE_BUFF-256) {
		pointer = 0;
		buff[0]='\0';
	}

	
	while (*cp != 0) {
		if (*cp != '\n') temp[j++] = *cp++;
		else {			   	
			temp[j++]= '\r';
			temp[j++]= '\n';
			cp++;
		}
	}
	temp[j]='\0';
	sprintf(temp2, temp, a1, a2, a3, a4, a5, a6, a7, a8);
	strcat(buff,temp2);

	SetDlgItemText(MainDialogHandle,ID_display,buff);
	SendDlgItemMessage(MainDialogHandle, ID_display, 
                        EM_LINESCROLL, 
                        (WPARAM) 0, (LPARAM) 2000); 
	pointer+=(strlen(temp2)+1);
}



extern "C" int gab_putch(int c) 
{
	char ch[3];
	int num;
	if (pointer > 15000) {
		pointer = 0	;
		buff[0]='\0';
	}
	if (c != '\n') {
		ch[0]=c;
		ch[1]=0;
		num=1;
	}
	else {
		ch[0]='\r';
		ch[1]='\n';
		ch[2]='\0';
		num=2;
	}
	strcat(buff,ch);
	pointer+=num;
	return c;
}

static int outflg=0;

LRESULT CALLBACK 
NoArgumentsProc(HWND hDlg,UINT msg, UINT wParam,LONG lParam)
{
   	switch (msg) {
		
		HWND hnd;
		case WM_INITDIALOG:
			hnd= GetDlgItem(  hDlg, idcFlags);
			SendDlgItemMessage (hDlg,idcFlags, CB_ADDSTRING, (WPARAM) 0, (LPARAM) LastFlags);
			SendDlgItemMessage (hDlg,idcFlags, CB_ADDSTRING, (WPARAM) 0, (LPARAM) "-+K -+S -b800");
			SendDlgItemMessage (hDlg,idcFlags, CB_ADDSTRING, (WPARAM) 0, (LPARAM) "-+K -+S -+C -b800");
			SendDlgItemMessage (hDlg,idcFlags, CB_ADDSTRING, (WPARAM) 0, (LPARAM) "-+K -+X -b800");
			SendDlgItemMessage (hDlg,idcFlags, CB_ADDSTRING, (WPARAM) 0, (LPARAM) "-+K -+X -+C -b800");
			SendDlgItemMessage (hDlg,idcFlags, CB_ADDSTRING, (WPARAM) 0, (LPARAM) "-d -+K -+S -b800 -+O -m0");
			SendDlgItemMessage (hDlg,idcFlags, CB_ADDSTRING, (WPARAM) 0, (LPARAM) "-d -+K -+S -+C -b800 -+O -m0");
			SendDlgItemMessage (hDlg,idcFlags, CB_ADDSTRING, (WPARAM) 0, (LPARAM) "-d -+K -+X -b800 -+O -m0");
			SendDlgItemMessage (hDlg,idcFlags, CB_ADDSTRING, (WPARAM) 0, (LPARAM) "-W");
			SendDlgItemMessage (hDlg,idcFlags, CB_ADDSTRING, (WPARAM) 0, (LPARAM) "-+K -+q -b2000 -+e");  
			SendDlgItemMessage (hDlg,idcFlags, CB_ADDSTRING, (WPARAM) 0, (LPARAM) "-Msbmidi -odevaudio -b2000");  
			SendDlgItemMessage (hDlg,idcFlags, CB_ADDSTRING, (WPARAM) 0, (LPARAM) "-idevaudio -odevaudio -b2000");
			SendDlgItemMessage (hDlg,idcFlags, CB_ADDSTRING, (WPARAM) 0, (LPARAM) "-Msbmidi -idevaudio -odevaudio -b2000");  
			if (NewArguments) {
				SetDlgItemText(hDlg,idcOrcFile,OrcFile);
				SetDlgItemText(hDlg,idcScoFile,ScoFile);
				SetDlgItemText(hDlg,idcOutFile,WavFile);
				SetDlgItemText(hDlg,idcFlags,LastFlags);
			} 
			break;
		case WM_COMMAND :
			switch(LOWORD(wParam)) {
				ULONG pp;
				pp=HIWORD(wParam);
				case idcFlags:
					switch HIWORD(wParam) {
						case CBN_DROPDOWN: {
							static BOOL fShow=TRUE;
							fShow=FALSE;
						}
						break;
					}
					break;
				case idNoArgOkButton:
					{
						char buf[MAXNAME];
						*buf = '\0';
						SendDlgItemMessage(hDlg, idcFlags, 
							WM_GETTEXT, 
							(WPARAM) 128, (LPARAM) buf);
						strcpy(LastFlags,buf);
						SendDlgItemMessage(hDlg, idcOrcFile, 
							WM_GETTEXT, 
							(WPARAM) 128, (LPARAM) buf);
						strcpy(OrcFile,unquote(buf));
						SendDlgItemMessage(hDlg, idcScoFile, 
							WM_GETTEXT, 
							(WPARAM) 128, (LPARAM) buf);
						strcpy(ScoFile,unquote(buf));
						SendDlgItemMessage(hDlg, idcOutFile, 
							WM_GETTEXT, 
							(WPARAM) 128, (LPARAM) buf);
						strcpy(WavFile,unquote(buf));
						EndDialog(hDlg,1);
					}
					break;
				case idcBrowseOrc:
					{ 
						LPSTR filename;
						filename = FileDialogBox(hDlg,  
							"Orchestra Files (*.orc)\0*.orc\0CSD files (*.csd)\0*.csd\0All Files (*.*)\0*.*\0", 
							"Browse Orchestra File", "orc", ExtractDir(OrcFile));
						if (filename[0] != '\0') {
							SetDlgItemText(hDlg,idcOrcFile,filename);
							strcpy(OrcFile,unquote(filename));
						}
					}
					break;
				case idcBrowseSco:
					{ 
						LPSTR filename;
						
						filename = FileDialogBox(hDlg,  
							"Score Files (*.sco)\0*.sco\0All Files (*.*)\0*.*\0", 
							"Browse Score File", "sco", ExtractDir(ScoFile));
						if (filename[0] != '\0') {
							SetDlgItemText(hDlg,idcScoFile,filename);
							strcpy(ScoFile,unquote(filename));
						}
				}
					break;
				case idcBrowseOut:
					{ 
						LPSTR filename;
						filename = FileDialogBox(hDlg,  
							"Wave Files (*.WAV)\0*.WAV\0All Files (*.*)\0*.*\0", 
							"Browse Output Audio File", "wav",ExtractDir(WavFile));
						if (filename[0] != '\0')  {
							SetDlgItemText(hDlg,idcOutFile,filename);
							strcpy(WavFile,unquote(filename));
						}
					}
					break;
			}
			break;
		case WM_DROPFILES:
			{	
				HDROP	hDrop = (HDROP) wParam;
				static char buf[MAXNAME],buf1[MAXNAME];
				char *ext;
				
				DragQueryFile(  hDrop,  // handle to structure for dropped files 
					0,  // index of file to query 
					buf,  // buffer for returned filename 
					400  // size of buffer for filename 
					);
				strcpy(buf1,buf);
				if (strstr(strlwr(buf1),".orc")) {
					long ndx;
					SetDlgItemText(hDlg,idcOrcFile,buf);
					strcpy(OrcFile,buf);
					strcpy(ScoFile,buf);
					ext = strstr(strlwr(buf1),".orc");
					ndx = ext-buf1;
					strcpy((ScoFile+ndx), ".sco");
					SetDlgItemText(hDlg,idcScoFile,	ScoFile);



				}
				else if (strstr(strlwr(buf1),".rto") ) {
					SetDlgItemText(hDlg,idcOrcFile,buf);
					strcpy(OrcFile,buf);
					SetDlgItemText(hDlg,idcScoFile,	"\0");
					strcpy(ScoFile, "\0");
					SetDlgItemText(hDlg,idcOutFile,	"\0");
					strcpy(WavFile,	"\0");
				}
 				else if (strstr(strlwr(buf1),".csd") ) {
					SetDlgItemText(hDlg,idcOrcFile,buf);
					strcpy(OrcFile,buf);
					SetDlgItemText(hDlg,idcScoFile,"\0");
					strcpy(ScoFile, "\0");
					SetDlgItemText(hDlg,idcOutFile,"\0");
					strcpy(WavFile,	"\0");
					SetDlgItemText(hDlg,idcFlags,"\0");
					strcpy(LastFlags,"\0");
					
				}
				else if (strstr(strlwr(buf1),".sco")) {
					 SetDlgItemText(hDlg,idcScoFile,buf);
					 strcpy(ScoFile,buf);
				}
				else if (strstr(strlwr(buf1),".wav") || strstr(buf,".raw") || strstr(buf,".aif") ) {
					 SetDlgItemText(hDlg,idcOutFile,buf);
					 strcpy(WavFile,buf);
				}
				else {
					MessageBox(hDlg, 
						"Only .orc .sco .csd and .rto files allowed in this drag/drop context\r\nOperation aborted!",
						"DirectCsound warning", MB_OK);
				}
			}
			break;
		case WM_SYSCOMMAND:
			//*GabCommandLine = '\0';
			if (wParam == SC_CLOSE)	
				EndDialog(hDlg,1);
			break;
		default:
			break;
	}
	return FALSE;
}

  


LPSTR FileDialogBox(HWND hOwner, LPSTR szFilter, LPSTR WinCaption, LPSTR defExt, LPSTR InitialDir )
{
	static char szRetFile[512];
	static char szFileTitle[512];
	char	initdir[512];
	
	OPENFILENAME OpenFileName;

	BOOL gg;
	strcpy(initdir,InitialDir); 
	
	szRetFile[0]='\0';
	OpenFileName.lStructSize       = sizeof(OPENFILENAME);
	OpenFileName.hwndOwner         = hOwner;
	OpenFileName.hInstance         = (HINSTANCE /*HANDLE*/) hProcessInstance;
	OpenFileName.lpstrFilter       = szFilter;
	OpenFileName.lpstrCustomFilter = (LPSTR) NULL;
	OpenFileName.nMaxCustFilter    = 0L;
	OpenFileName.nFilterIndex      = 1L;
	OpenFileName.lpstrFile         = szRetFile;
	OpenFileName.nMaxFile          = sizeof(szRetFile)-2;
	OpenFileName.lpstrFileTitle    = szFileTitle;
	OpenFileName.nMaxFileTitle     = sizeof(szFileTitle)-2;
	OpenFileName.lpstrInitialDir   = initdir;
	OpenFileName.lpstrTitle        = WinCaption; 
	OpenFileName.Flags             = OFN_HIDEREADONLY | OFN_EXPLORER ;
	OpenFileName.nFileOffset       = 0;
	OpenFileName.nFileExtension    = 0;
	OpenFileName.lpstrDefExt       = defExt; //"wav";
	OpenFileName.lCustData         = 0;
	OpenFileName.Flags             = 0;
	gg=GetOpenFileName( &OpenFileName);					
	return szRetFile;
}


extern "C" LPSTR ExtractDir(LPSTR source)
{
	static char dest[MAXNAME];
	char *p, *lastslash=NULL;
	strcpy(dest,source);
	p=dest;
	while(*p != '\0') {
		if(*p== '\\')
			lastslash=p;
		p++;
	}
	if (lastslash !=NULL)
		*lastslash='\0';
	return dest;
}

extern "C" LPSTR quote(LPSTR source)
{
    static char newname[MAXNAME];
 	strcpy (newname, "\"");
	strcat (newname,source);
	strcat (newname, "\"");
	return newname;
}



void setBufScroll(int value)
{
	SCROLLINFO scroll;
	HWND hnd;
	char st[10];
	scroll.cbSize = sizeof(scroll); 
	scroll.fMask  = SIF_POS; 
	scroll.nPos   = value; 

	hnd = GetDlgItem( MainDialogHandle, idcBufferScrollBar);
			SetScrollInfo(hnd, SB_CTL,&scroll,TRUE);
			SetDlgItemText(MainDialogHandle,idcBufferLabel,itoa(value,st,10));
}

