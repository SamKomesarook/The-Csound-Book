double besseli(double);
FLOAT unifrand(FLOAT);
FLOAT linrand(FLOAT);
FLOAT trirand(FLOAT);
FLOAT exprand(FLOAT);
FLOAT biexprand(FLOAT);
FLOAT gaussrand(FLOAT);
FLOAT cauchrand(FLOAT);
FLOAT pcauchrand(FLOAT);
FLOAT weibrand(FLOAT, FLOAT);
FLOAT betarand(FLOAT, FLOAT, FLOAT);
FLOAT poissrand(FLOAT);

typedef struct	{
	OPDS	h;
	FLOAT	*sr, *in, *powerOf, *norm;
} POW;

typedef	struct	{
	OPDS	h;
	FLOAT	*out, *arg1, *arg2, *arg3;
} PRAND; 

