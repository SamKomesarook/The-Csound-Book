typedef struct	{	/* gab d5*/
	OPDS	h;
	FLOAT	*out, *min, *max;
} RANGERAND;

typedef struct	{	/* gab d5*/
	OPDS	h;
	FLOAT	*out, *tableNum;
	int		pfn;
	FUNC	*ftp;
} DURAND;

typedef struct	{	/* gab d5*/
	OPDS	h;
	FLOAT	*out, *min,*max,*tableNum;
	int		pfn;
	FUNC	*ftp;
} CURAND;

typedef struct {  /* gab d5 */
	OPDS	h;
	FLOAT	*ar, *min, *max, *xcps;
	short	cpscod;
    long	phs;
	FLOAT	num1, num2, dfdmax;
} RANDOMI; 

typedef struct {  /* gab d5 */
	OPDS	h;
	FLOAT	*ar, *min, *max, *xcps;
	short	cpscod;
	long	phs;
	FLOAT	num1;
} RANDOMH;

typedef struct {  /* gab d5 */
	OPDS	h;
	FLOAT	*out, *gamp, *amp1, *cps1, *amp2, *cps2, *amp3, *cps3;
	int	    flag;
    long	phs1,phs2,phs3;
	FLOAT	num1a,num2a, dfdmax1,num1b,num2b, dfdmax2,num1c,num2c, dfdmax3;
} JITTER2; 


typedef struct {  /* gab d5 */
	OPDS	h;
	FLOAT	*ar, *amp, *cpsMin, *cpsMax;
	FLOAT	xcps;
    long	phs;
	int initflag;
	FLOAT	num1, num2, dfdmax;
} JITTER; 

typedef struct {  /* gab d5 */
	OPDS	h;
	FLOAT	*ar, *amp, *cpsMin, *cpsMax;
	double	si;
    double	phs;
	int initflag, cod;
	FLOAT	num0, num1, num2, df0, df1,c3, c2;
} JITTERS; 


typedef struct {  /* gab d5 */
	OPDS	h;
	FLOAT	*ar, *rangeMin, *rangeMax, *cpsMin, *cpsMax;
	double	si;
    double	phs;
	int initflag, cod;
	FLOAT	num0, num1, num2, df0, df1,c3, c2;
} RANDOM3; 

typedef struct {  /* gab d5 */
	OPDS	h;
	FLOAT	*out, *AverageAmp,*AverageFreq, *randAmountAmp, *randAmountFreq; 
	FLOAT	*ampMinRate, *ampMaxRate, *cpsMinRate, *cpsMaxRate, *ifn, *iphs;
	FLOAT	xcpsAmpRate, xcpsFreqRate;
	double	lphs, tablenUPkr;
    long	tablen, phsAmpRate, phsFreqRate;
	FLOAT	num1amp, num2amp, num1freq, num2freq, dfdmaxAmp, dfdmaxFreq;
	FUNC	*ftp;
} VIBRATO; 


typedef struct {  /* gab d5 */
	OPDS	h;
	FLOAT	*out, *AverageAmp,*AverageFreq,*ifn; 
	FLOAT	xcpsAmpRate, xcpsFreqRate;
	double	lphs, tablenUPkr;
    long	tablen, phsAmpRate, phsFreqRate;
	FLOAT	num1amp, num2amp, num1freq, num2freq, dfdmaxAmp, dfdmaxFreq;
	FUNC	*ftp;
} VIBR; 

typedef	struct {
	OPDS	h;
	float	*ar, *asig, *kcf, *kbw, *ord, *iscl, *istor;
	int     scale, loop;
	float	c1, c2, c3, *yt1, *yt2, cosf, prvcf, prvbw;
	AUXCH	aux;
} KRESONX;

