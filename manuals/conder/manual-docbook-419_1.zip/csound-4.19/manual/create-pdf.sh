#!/bin/sh
# ********************************************************
# Module: create-pdf.sh
# Purpose: Because it is so buggy, pdfjadetex has to be 
#          executed three times in order to get proper 
#          page numbers in our PDF file.
# ********************************************************
pdfjadetex $1 
pdfjadetex $1
pdfjadetex $1

exit 0
