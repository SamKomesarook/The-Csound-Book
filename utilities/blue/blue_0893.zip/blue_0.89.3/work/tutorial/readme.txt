blue tutorial files - 2001.8.16

alright, these are pretty bad tutorial files, but this is taking me way too long tonight to do.  anyways, feel free to look through.  each file demonstrates a different sound object.  probably the best thing to do is generate to a .csd file and see what got generated and compare to what got put in.

i'll try to make better tutorial files later.  until then, feel free to email me any questions and i'll be happy to explain anything.

thanks,
steven yi
kunstmusik@hotmail.com
www.kunstmusik.com