/* fGetPanFac.C    by David Hainsworth   */

float fGetPanFac(float fRan)
{
	return fRan;
}
