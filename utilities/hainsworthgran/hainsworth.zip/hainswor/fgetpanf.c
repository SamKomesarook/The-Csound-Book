/* fGetPanFac2.C    by David Hainsworth   */

float fGetPanFac2(float fArray[], float fTime, float fTotalTime)
{

	float fIndex, frac, fRange ;		/* initialize index table block */
	int index, next ;
	int idur = fTotalTime ;

	fIndex = fTime/idur * 64. ;	/* calculate index */
	index  = fIndex ;
	next   = index + 1;
	frac   = fIndex - (int)fIndex;

	fRange = fArray[index] + (fArray[next] - fArray[index]) * frac; 

	if (fRange <= .1)
	{
		do
		{
			fRan = (float)drand48();
		} while(fRan > .2);

		return (fRan + .4);
	}

	if (fRange > .1 && fRange <= .2)
	{
		 do
		{
			fRan = (float)drand48();
		}  while(fRan > .4);

		return (fRan + .3);
	}

	if (fRange > .2 && fRange <= .3)
	{
	   	do
	   	{
	         		fRan = (float)drand48();
	   	}  while(fRan > .6);

	  	 return (fRan + .2);
	}

	if (fRange > .3 && fRange <= .4)
	{
	  	 do
	   	{
	         		fRan = (float)drand48();
	   	}  while(fRan > .8);

	   	return (fRan + .1);
		}

/* ****************************************************** */

	if (fRange > .4 && fRange <= .5)
	{
		fRan = (float)drand48();
	  	 return fRan;
	}

	if (fRange > .5 && fRange <= .62)
	{
	   	do
		{
		   	fRan = (float)drand48();
		}  while(fRan > .4 && fRan < .6);
		
		return fRan;
	}

	if (fRange > .62 && fRange <= .75)
	{
	   	do
		{
		   	fRan = (float)drand48();
		}  while(fRan > .3 && fRan < .7);

		return fRan;
	}

	if (fRange > .75 && fRange <= .87)
	{
	   	do
		{
		  	 fRan = (float)drand48();
		}  while(fRan > .2 && fRan < .8);

		return fRan;
	}

	if (fRange > .87)
	{
	   	do
		{
		   	fRan = (float)drand48();
		}  while(fRan > .1 && fRan < .9);

		return fRan;
	}
}
