/* fGetPanFac3.C    by David Hainsworth   */

float fGetPanFac3(float fRan, float fArrayAxis[], float fArrayWidth[], float fTime, float 	fTotalTime)
{

	float fIndex, frac, fAxis, fPanWidth ;      	/* initialize variables */
	float fHalf, fAltAxis, fResult ;
        	int index, next ;
        	int idur = fTotalTime ;

        	fIndex = fTime/idur * 64. ;                		/* Calculate indexes for   */ 
       	index  = fIndex ;			    	/* Pan Axis and Pan Width. */
  	next   = index + 1;
	frac   = fIndex - (int)fIndex;
							/* calculate Pan Axis  */
	fAxis     = fArrayAxis[index] + (fArrayAxis[next] - fArrayAxis[index]) * frac;
	fPanWidth = fArrayWidth[index] + (fArrayWidth[next] - fArrayWidth[index]) * 			frac;  /* calculate Pan Width */

	fRan = fRan * fPanWidth;	/* Constrain Random Number to between 							fPanWidth */
	fAltAxis = fAxis - (fPanWidth*.5);	/* Calculate Altered Axis */
	fResult = fAltAxis + fRan; 	/* Result = Altered Axis + Constrained Random 						Number */      
	return fResult;		/* return result */
}
