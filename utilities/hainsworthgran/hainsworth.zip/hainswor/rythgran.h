struct ICARD {
      char cI;          		/* holds i for iCard */
      char cInsNo;      		/* instr # */
      float fStart;    		/* start time for grain */
      float fDur;      		/* duration of grain */
      float fPitchFac; 	 	/* pitch factor */
      int iFileNum;     		/* soundin file # */
      float fSkipTime;  		/* skiptime */      
      float fGainFac;  	 	/* gain factor  */
      float fInitGain;  		/* Initail Gain Factor */
      int EnvFn;       	 	/* Envelope Func # */
      float fPan;       		/* Pan */
} ;


struct INPUTDATA {    				
        	float fGapTime[11];
        	float p[11]; 
        	float GrainLen[11];
        	float fPitchRandom[11];
	float fRanPchDev[11];
	float PchFact[11];
	float fEnvel[11];
        	float fSndFile[11];
        	float Panner[11];
        	float fPanWidth[11];
        	float fSkipPointer[11];
} ;

struct SCOREDATA {

	float fTotalTime, fQuarterNote;
        	float fInitGain, fGain, fDurFac;
        	float fLoopStart, fLoopEnd;
        	int iFileNumFlag, iSkipFlag, iPanFlag; 
        	int iSoundins[8];
        	long lSeed;
        	char szPchTablFileName[80];
	float *fArrayRanPchDev;
	float *fArrayPitchRand;
	float *fArrayGapTime;
	float *fArraySkipPointer;
	float *fArrayPanWidth;
	float *fArray, *fArrayPchFact, *fArrayGrainLen, *fArrayEnvel;
	float *fArraySndFile, *fArrayPan;
} ;


