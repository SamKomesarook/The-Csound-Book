/* 	fGetGainFac2.C	by David Hainsworth		*/

float fGetGainFac2(float fRan, float fGain)
{
	float fResult;
	fResult = fRan*fGain;	 
	return fResult;	
}
