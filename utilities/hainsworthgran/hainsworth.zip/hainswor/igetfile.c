        /* iGetFileNum901.C    by David Hainsworth    5/24/96  */


   int iGetFileNum901( float fRan, float *pSndFileTable )
   {

	float fResult;         
	int iRan;

	fRan = fRan*99;
	iRan = (int)fRan;

	fResult = pSndFileTable[iRan];

        	return (int)fResult;

   }	
	

