        /* iGetFileNum9.C    by David Hainsworth    5/18/96  */

iGetFileNum9(float fRan, int isoundins[], float fArrayPitchSet[], float 	fArrayPitchRandom[], float fTime, float fTotalTime)
{
	float fIndex, frac, fPitchSet, fPitchRandom ;    /* Declare Variables */
	int index, next ;
	int idur = fTotalTime ;
	static int iLastSndFile, iNextSndFile;

	fIndex = fTime/idur * 63. ;		/* calculate index */
	index  = fIndex ;
	next   = index + 1;
	frac   = fIndex - (int)fIndex;

	fPitchSet    = fArrayPitchSet[index] + (fArrayPitchSet[next] -					fArrayPitchSet[index]) * frac; 
	fPitchRandom = fArrayPitchRandom[index] + (fArrayPitchRandom[next] - 			fArrayPitchRandom[index]) * frac; 

	if ( fRan >= fPitchSet )   /* If True choose from PitchSet 1 --ELSE-- 
						Choose from PitchSet 2  */
	{
	if ( fRan >= fPitchRandom ) /* if True pitches cycle thorough PitchSet 1 --ELSE-- 
					pitches are randomly selected from PitchSet 1 */
	{
	if ( iLastSndFile >= 4 )
	iLastSndFile = iLastSndFile - 4;

	      iNextSndFile = iLastSndFile + 1;
	         if (iNextSndFile >= 4)
		    iNextSndFile = iNextSndFile % 4;
	      iLastSndFile = iNextSndFile;   	/* Set Last SndFile = to Current SndFile */ 
	      return isoundins[iNextSndFile];
	   }

	else
	{
	 	if ( fRan <= .25 )
		{
			iLastSndFile = 0;
 	 		return isoundins[0];
		}

	      	if ( fRan > .25 && fRan <= .5 )
	      	{
	          		iLastSndFile = 1;
	          		return isoundins[1];
	      	}

              	if ( fRan > .5 && fRan <= .75 )
	      	{
	          		iLastSndFile = 2;
                  		return isoundins[2];
	      	}

              	else
	      	{
	          		iLastSndFile = 3;
                  		return isoundins[3];
	      	}
	}
	}

	else
	{
	   	if ( fRan >= fPitchRandom )  /* if True pitches cycle thorough PitchSet 2 --				ELSE-- pitches are randomly selected from PitchSet 2 */
	   	{
	      		if ( iLastSndFile < 4 )
	         			iLastSndFile = iLastSndFile + 4;

	      		iNextSndFile = iLastSndFile + 1;
	         		if (iNextSndFile >= 8)
		    		iNextSndFile = ((iNextSndFile % 4) + 4); 
	      		iLastSndFile = iNextSndFile;   	/* Set Last SndFile = to 									Current SndFile */ 
	      		return isoundins[iNextSndFile];
	   	}

	   	else
	   	{
	      		if ( fRan <= .25 )
	      		{
	        			 iLastSndFile = 4;
 	         			return isoundins[4];
	      		}

	      		if ( fRan > .25 && fRan <= .5 )
	      		{
		 		iLastSndFile = 5;
	         			return isoundins[5];
	      		}

              		if ( fRan > .5 && fRan <= .75 )
	      		{
		  		iLastSndFile = 6;
                  			return isoundins[6];
	      		}

              		else
	      		{
		  		iLastSndFile = 7;
                  			return isoundins[7];
	      		}
	   	}
	}	
    }	
	

