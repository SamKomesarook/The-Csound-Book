/* fGetGapTime2.C	by David W. Hainsworth         5/18/96  */

float fGetGapTime2(float fRan, float fQuarterNote, float fArrayGapTime[], float fTime, 	float fTotalTime)
{

	float fIndex, frac, fGapTime, fGapTimeIndex; 	/* initialize variables */
	int index, next ;
	 int idur = fTotalTime ;

	fRan = fRan*.2 - .1;       /* Rand # between -.1 and .1 */

	fIndex = fTime/idur * 63. ;		/* Calculate index for */ 
	 index  = fIndex ;			/* SkipTime Pointer */
	next   = index + 1;
	frac   = fIndex - (int)fIndex;
						/* calculate GapTime Index */
	fGapTimeIndex = fArrayGapTime[index] + (fArrayGapTime[next] - 				fArrayGapTime[index]) * frac; 
	fGapTimeIndex = fGapTimeIndex + fRan; 

	if(fGapTimeIndex < .1)
	{
	   	fGapTime = fQuarterNote;  /* Quarter Notes */
	   	return fGapTime;
	}

	if(fGapTimeIndex >= .1 && fGapTimeIndex < .2)  
	{
	   	fGapTime = fQuarterNote*.5;  /* Eighth Notes */
	   	return fGapTime;
	}

	if(fGapTimeIndex >= .2 && fGapTimeIndex < .3)  
	{
	   	fGapTime = fQuarterNote*.25;  /* 16th Notes */
	   	return fGapTime;
	}

	if(fGapTimeIndex >= .3 && fGapTimeIndex < .4)  
	{
	   	fGapTime = fQuarterNote*.125;  /* 32nd Notes */
	   	return fGapTime;
	}

	if(fGapTimeIndex >= .4 && fGapTimeIndex < .5)  
	{
	   	fGapTime = fQuarterNote*.0625;  /* 64th Notes */
	  	 return fGapTime;
	}

	if(fGapTimeIndex >= .5 && fGapTimeIndex < .6)  
	{
	   	fGapTime = fQuarterNote*.03125;  /* 128th Notes */
	   	return fGapTime;
	}

	if(fGapTimeIndex >= .6 && fGapTimeIndex < .7)  
	{
	   	fGapTime = fQuarterNote*.015625;  /* 256th Notes */
	  	 return fGapTime;
	}

	if(fGapTimeIndex >= .7 && fGapTimeIndex < .8)  
	{
	   	fGapTime = fQuarterNote*.0078125;  /* 512th Notes */
	   	return fGapTime;
	}

	if(fGapTimeIndex >= .8 && fGapTimeIndex < .9)  
	{
	   	fGapTime = fQuarterNote*.004;  /* 1024th Notes */
	   	return fGapTime;
	}

	if(fGapTimeIndex >= .9 && fGapTimeIndex < 1)  
	{
	   	fGapTime = fQuarterNote*.002;  /* 2048th Notes */
	   	return fGapTime;
	}
}
