/*   iGetEnv5.c    by David Hainsworth   */
/*   Chooses envelope Fn#'s --- moves smoothly from one Fn# to another.  */

int iGetEnv5(float fRan, int iEnvelopes[], float fArray[], float fTime, float fTotalTime)
{
	float fIndex, frac, fRange, fFac ;    /* initialize index table block */
        	int index, next ;
       	 int idur = fTotalTime;

        	fIndex = fTime/idur * 63. ;              /* calculate index */
       	index  = fIndex ;
  	next   = index + 1;
	frac   = fIndex - (int)fIndex;

	fRange = fArray[index] + (fArray[next] - fArray [index]) * frac; 

	if( fRan <= fRange )
	
		return iEnvelopes[0];
	else
		return iEnvelopes[1];
}	
	
