  /* RythGranTest.C      used with eventide5.orc  */

  #include <sys/types.h>
  #include <malloc.h>
  #include <stdio.h>
  #include <string.h>
  #include "RythGranTest.h"

  extern void DataIn( struct INPUTDATA *, struct SCOREDATA *, char * );
  extern void ProcessData( struct INPUTDATA *, struct SCOREDATA * );
  extern void Score( struct SCOREDATA *, char * );


  main(int argc, char *argv[])
  {

    	struct INPUTDATA InData;
    	struct SCOREDATA ScoreDat;   
    
   	char DataFileBuf[25];
    	char ScoreFileBuf[25];
    

		/* ********** Call DataIn.c ********* */
   	strcpy( DataFileBuf, argv[2] );
   	DataIn( &InData, &ScoreDat, DataFileBuf );  

      		/* ******* Call ProcessData.c ******* */
   	ProcessData( &InData, &ScoreDat ); 

		/* ********* Call Score.c   ********* */ 
   	strcpy( ScoreFileBuf, argv[1] );
   	score( &ScoreDat, ScoreFileBuf );

		/* ********* Free all memory allocated by malloc ********* */
/*	free(ScoreDat.pSndFileTable);
	free(ScoreDat.fArrayRanPchDev);    
	free(ScoreDat.fArrayPitchRandom);  
	free(ScoreDat.fArrayGapTime);      
	free(ScoreDat.fArraySkipPointer);  
	free(ScoreDat.fArrayPanWidth);     
	free(ScoreDat.fArray);             
	free(ScoreDat.fArrayPchFact);      
	free(ScoreDat.fArrayGrainLen);    
	free(ScoreDat.fArrayEnvel);          
	free(ScoreDat.fArraySndFile);      
	free(ScoreDat.fArrayPan);       */             
  }


