#include <sys/types.h>
#include <malloc.h>
#include "RythGranTest.h"

extern void vGen7_2(float[], float[]);		/* In file "gen7_2.c" */

void ProcessData( struct INPUTDATA *InData, struct SCOREDATA *ScoreDat  )
{
	/* malloc memory for Tables */

	ScoreDat->fArrayRanPchDev   	= malloc(64 * sizeof(float));
	ScoreDat->fArrayPitchRand   	  	= malloc(64 * sizeof(float));  
	ScoreDat->fArrayGapTime       	= malloc(64 * sizeof(float));
	ScoreDat->fArraySkipPointer   	= malloc(64 * sizeof(float)) ;
	ScoreDat->fArrayPanWidth    	= malloc(64 * sizeof(float));   
	ScoreDat->fArray           		= malloc(64 * sizeof(float)); 
	ScoreDat->fArrayPchFact     		= malloc(64 * sizeof(float));   
	ScoreDat->fArrayGrainLen    		= malloc(64 * sizeof(float)); 
	ScoreDat->fArrayEnvel       		= malloc(64 * sizeof(float));
	ScoreDat->fArraySndFile     		= malloc(64 * sizeof(float));   
	ScoreDat->fArrayPan         		= malloc(64 * sizeof(float));    
	  
	/* Use Gen 7 to create Tables */

    	vGen7_2(ScoreDat->fArray, InData->p);    
    	vGen7_2(ScoreDat->fArrayGrainLen, InData->GrainLen);   
	vGen7_2(ScoreDat->fArrayPchFact, InData->PchFact);   
        	vGen7_2(ScoreDat->fArrayEnvel, InData->fEnvel);           
        	vGen7_2(ScoreDat->fArrayRanPchDev, InData->fRanPchDev); 
        	vGen7_2(ScoreDat->fArraySndFile, InData->fSndFile);    
        	vGen7_2(ScoreDat->fArrayPan, InData->Panner);            
        	vGen7_2(ScoreDat->fArrayPanWidth, InData->fPanWidth);    
        	vGen7_2(ScoreDat->fArraySkipPointer, InData->fSkipPointer); 
        	vGen7_2(ScoreDat->fArrayGapTime, InData->fGapTime);        
        	vGen7_2(ScoreDat->fArrayPitchRand, InData->fPitchRandom); 
}
