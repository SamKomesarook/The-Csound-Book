/* float *ProbabilityTable(float *fList, int nValues)
 *
 * Allocates and fills a table with values provided by user and distributed
 * according to probability of occurrence.  Place values and probabilities
 * in an array of floats, as follows:  val1, prob1, val2, prob2, etc.
 * The probabilities are entered as percentages (0 - 100), and they must add
 * up to 100.  Call passing a pointer to the list and the number of values.
 * E.g., for a table of 4 values (8.00, 8.05, 8.07, 9.00) with probabilities
 * of 25, 30, 40, and 5 percent, respectively, do the following:
 *
 * float fList[8] = { 8.00, 25., 8.05, 30., 8.07, 40., 9.00, 5. } ;
 * float *pTable ;
 * pTable = ProbabilityTable(fList, 4) ;
 *
 * Notes:
 *
 * ProbabilityTable returns a pointer to the table generated, which can
 * then be accessed as a standard array, e.g., value = pTable[index], where
 * the index is a random integer value between 0 and 99.
 *
 * The user is responsible for freeing the memory used by the table once it
 * is no longer needed, i.e., free (pTable) ;
 */

 #define TABLESIZE 100 
 #include <sys/types.h>
 #include <malloc.h> 

float *ProbabilityTable(float *pList, int nValues)
{
	int i, k, j;
	float *pBuffer;

	pBuffer = malloc( TABLESIZE * sizeof(float) );

	for( i = 0, k = 0; i < nValues && k < TABLESIZE; i++ )
		for( j = 0; j < pList[i*2+1]; j++ ) 
		{
			pBuffer[k++] = pList[i*2];    
		}
	return pBuffer ;
}

