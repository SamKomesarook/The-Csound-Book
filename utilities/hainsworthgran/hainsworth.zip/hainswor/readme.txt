Hainsworth Granular Synth Program


	This program takes an input data file (*.dat) and outputs a Csound score file that 
can be compiled with Russell Pinkston�s eventide instrument.  I use Dr. Pinkston�s 
eventide instrument because I like the quality of pitch shift obtained by using delay lines 
more than the quality of standard resampling.  Delay lines do not distort the temporal aspect 
of the input sound file (i.e. no Mickey mouse effect).  Pitch shifting with delay lines is less 
efficient than straight resamping, but I think it sounds better (especially at extreme 
transpositions).  Also inefficient is my use of the soundin opcode rather than gen1 tables 
for my input sound files.  My reason for this is that I often use long files and sometimes as 
many a 50 input sound files.  I was constantly running out of memory when using tables.  
In fact, the entire idea  of a score generating program is much less efficient than a program 
that manipulates audio directly.  My reasons for using score generation rather than direct 
manipulation of the audio is that score generation allows the program to be altered fairly 
easily.  I�ve made more than 20 versions of this program to implement various musical 
ideas and address other Csound instruments.  With a very basic knowledge of C, anyone 
could easily adapt my program for other uses.
	The program is initiated at a command line with the following syntax:  COMMAND   
OUTPUTSCOREFILE   INPUTDATAFILE.  This version is compiled for Silicon 
Graphics computers.  
	The input data file allows the user to specify the parameters both static and time 
varying for the output score.  For instance the duration field in the input data file is a static 
duration in seconds.  The time varying parameters are input using the gen7 table syntax of:  
value, number of table locations, value, number of table locations, etc.  In fact I adapted the 
gen7 code from the Csound source code for my implementation.  It is best to work from a 
template (refer to example.dat) for the input data file because all the parameters must be 
present and in the correct order for the program to execute successfully.  Also the strings 
beginning with * that describe the input parameters must also be present.  The input 
parameters are:

1. Seed			An integer seed for the random number generator.

2. Duration   			The duration in seconds of the output sound file.

3. QuarterNoteDuration	This basic GapTme (time between proposed grain start 	
				times).  Lower numbers allow greater density whereas 	
				higher numbers mean a decrease in density.

4. Gaptime			11 input values in gen7 syntax (64 location table) specifying 	
				the changing gaptime (actually a factor of Quarter note 	
				duration) between possible grain events.  Values must be 	
				between 0 and 1 with values between .9 and 1 specifying 	
				QuaterNoteDuration * .002 and values between 0 and .1 	
				specifying QurterNoteDuration.

5. Density			11 input values in gen7 syntax (64 location table) Specifying 
				the relative grain density over time. Values must be between 	
				0 and 1.

6. GrainSize			11 input values in gen7 syntax (64 location table) specifying 	
				the size in seconds of grains over time. Values must be 	
				between 0 and 1.  However, grain sizes greater than 1 may 	
				be achieved using the Duration Factor parameter.

7. Duration factor		the GrainSize value is multiplied by the duration factor.

8. File Number Flag		Not fully implemented yet.  Do not attempt to use.  Just put a 
				1 in the data file to prevent crashing.

8. pitch probability table	String input specifying a file containing a pitch probability 	
				table (still experimental).  Do not use.  Just put some string 	
				in the data file to prevent crashing.

9. Sound file numbers		up to 8 soundfile numbers can be inputted.  Must be an 	
				integer referring to the star in the soundin syntax soundin.*.

10. pitch ordered or random	Actually refers to SoundFileNumbers and not the pitch 	
				shifting parameters.

11. Pitch deviation		deviation in semitones from �pitch in semitones�

12. Pitch in semitones		deviation in semitones (floating point values can be used for 	
				pitches between semitones).  Values can be positive or 	
				negative.

13. Gain			Gain factor to achieve a proper amplitude in the output sound 
				file.  

14. Initial Gain		essentially the same as above.

15. Envelopes			11 input values in gen7 syntax (64 location table) specifying 	
				changing envelopes over time.  Currently the envelopes are 	
				hardwired into the code.  However after creating the score 	
				they can be edited before compiling with eventide.orc.  The 	
				grain envelopes are fTables 4 and 5.  FTable 4 is an 		
				exponential decay and fTable 5 is an exponential rise and 	
				decay.  I use exponential envelopes because I prefer to 	
				emphasize the individual grains, linear envelopes would 	
				make a more blended less aggressive texture.

16. Sound files		experimental ignore for now.

17. PanFlag			Flag indicating the panning mode.  0 = pan mode 1 (random 	
				pan position).  1 = pan mode 2 (see description below). 2 = 	
				pan mode 3 (see description below).

18. Panner			Used with pan modes 2 and 3.

19. PanWidth			Used with pan mode 3.

20. SkipTime flag		Flag indicating skiptime mode.  0 = skiptime mode 1 (all 	
				skiptimes are zero.  1 = skiptime mode 2 (skiptime move 	
				through soundfile from zero and then loops). 2 = skiptime 	
				mode 3 (skiptime chosen randomly from between loopStart 	
				and loopEnd).  3 = skiptime mode 4 (SkipTImePointer 	
				moves through soundfile using gen7 table)

21. loop start and loop end	indicates skiptime looping start and end points.  Used with 	
				skiptime modes 2 and 3.

22. SkipTime pointer		11 input values in gen7 syntax (64 location table) specifying 	
				the time in seconds of the skiptime parameter.  Used with 	
				skiptime mode 4.
