#include <math.h>
#include <stdio.h>
#include "RythGranTest.h"

extern int iGetFileNum9(float, int[], float[], float[], float, float);
extern int iGetFileNum901( float, float * );
extern int iGetEnv5(float, int[], float[], float, float); 
extern float *ProbabilityTable( float *, int );
extern float *TableSet3( char *, int * );
extern float *InitSndFileTable( char * );
extern float fGetNextDur2(float[], float, float, float);
extern float fGetPchFac4(float, float[], float, float, float *);
extern float fGetSkipTime(float, int, int[], float[]);  
extern float fGetSkipTime2(float, float, float);
extern float fGetSkipTime3(float[], float, float);
extern float fGetGainFac2(float, float);
extern float fGetPanFac();
extern float fGetPanFac2(float[], float, float);
extern float fGetPanFac3(float, float[], float[], float, float);
extern float fGetGapTime2(float, float, float[], float, float); 
extern float fillTable(float[], float, int);   

void score(  struct SCOREDATA *ScoreDat, char ScoreFileName[] )
{
	struct ICARD Card;
	FILE *scorefile;
	float fDensity, fRan, fGap;
	float fSTime = 0;
	float fTime = 0;
	int iEnvelopes[2] = {4, 5};
	srand48(ScoreDat->lSeed);   /* Seed Random Number Generator */

	if ((scorefile = fopen(ScoreFileName, "w")) == NULL)
	{
		printf("Enter the name of a data file to hold your\n");
		printf("score file on the command line\n.");
		exit(-1);
	}

	/* Print Gen Header to Score. */
	fprintf(scorefile, "f01		0	512	
					10	1	;sine wave\n\n");
	fprintf(scorefile, "f02		0	513	
					7	1	
					513	0	;linear decay\n\n");
	fprintf(scorefile, ";Amp gating function:  f(x) = 1 - x^6, x -> -1, 1\n");
	fprintf(scorefile, "f03		0	513	
					3	1	
					1	1	
					0	0	
					0	0	
					0	-1\n");
	fprintf(scorefile, "f04		0	513	
					-5	1	
					256	.01
					255	.0001	;Exponential decay\n");
	fprintf(scorefile, "f05		0	513	
					5	.0001	
					156	1
					156	1	
					200	.0001	;Exponential rise and decay\n");

	/* Initialize some Card variables */
	Card.cI = 'i';
	Card.cInsNo = '1';
	Card.fDur = .0001;
	Card.fInitGain = ScoreDat->fInitGain;


	while ( fTime < ScoreDat->fTotalTime - Card.fDur )
	{
		fDensity = fillTable( ScoreDat->fArray, fTime, 
				(int)ScoreDat->fTotalTime );
		fRan = (float)drand48();

		if (fRan <= fDensity)  /* if true create grain */
		{
			fGap = fGetGapTime2(fRan, ScoreDat->fQuarterNote, 
				ScoreDat->fArrayGapTime, fTime, ScoreDat->fTotalTime);
			if( fRan > .2 )
				fTime += fGap;
			fSTime += fGap;
			if (fSTime >= ScoreDat->fLoopEnd )
				fSTime = ScoreDat->fLoopStart;

			Card.fStart = fTime;  
			Card.EnvFn  = iGetEnv5(fRan, iEnvelopes, 
				ScoreDat->fArrayEnvel, 
				fTime, ScoreDat->fTotalTime); 
			Card.fDur = fGetNextDur2(ScoreDat->fArrayGrainLen, fTime, 
				ScoreDat->fTotalTime, ScoreDat->fDurFac);
			Card.fGainFac  = fGetGainFac2(fRan, ScoreDat->fGain);
			Card.fPitchFac = fGetPchFac4(fRan, ScoreDat->fArrayPchFact, 
						fTime, ScoreDat->fTotalTime, 
						ScoreDat->fArrayRanPchDev);

			/* Need to add Probtab Stuff */
			Card.iFileNum = iGetFileNum9(fRan, ScoreDat->iSoundins, 
				ScoreDat->fArraySndFile, ScoreDat->fArrayPitchRand, 
				fTime, ScoreDat->fTotalTime);

			/* **************** PANNING  ************** */
			if( ScoreDat->iPanFlag == 0 )		
				Card.fPan  = fGetPanFac();

			if( ScoreDat->iPanFlag == 1 )   /* .1 middle - .5 Rand - .9 ends */
				Card.fPan = fGetPanFac2(ScoreDat->fArrayPan, fTime, 
				ScoreDat->fTotalTime);
			else
				Card.fPan = fGetPanFac3(fRan, ScoreDat->fArrayPan, 
					ScoreDat->fArrayPanWidth, fTime, 
					ScoreDat->fTotalTime);

			/* ************** SKIP TIME  ************* */
			if (ScoreDat->iSkipFlag == 0)
				Card.fSkipTime = 0;	/* All Skip Times are Zero */

			if (ScoreDat->iSkipFlag == 1)
				Card.fSkipTime = fSTime;	/* Skip Times move through 
							SndFile at real time and loops */
			if (ScoreDat->iSkipFlag == 2)
			/* Chosen randomly from between fLoopStart and fLoopEnd */
		 		Card.fSkipTime = fGetSkipTime2(fRan, 
					ScoreDat->fLoopStart, ScoreDat->fLoopEnd);  
			if (ScoreDat->iSkipFlag == 3) 	/* Moving pointer */ 
				Card.fSkipTime = fGetSkipTime3(
					ScoreDat->fArraySkipPointer, 
					fTime, ScoreDat->fTotalTime);  

			/* ******** Print Score line ********** */
			fprintf(scorefile,"\n%c%c %.4f %.4f .1 %.3f %d %.3f 0 %.3f 0 0 
				%.2f %d %.2f",

				Card.cI,
				Card.cInsNo,
				Card.fStart,
				Card.fDur, 
				Card.fPitchFac,
				Card.iFileNum,
				Card.fSkipTime,
				Card.fGainFac,
				Card.fInitGain,
				Card.EnvFn,
				Card.fPan);
		}

	 	else		/*  if not true do not create grain */
		{
			fGap = fGetGapTime2(fRan, ScoreDat->fQuarterNote, 
				ScoreDat->fArrayGapTime, fTime, ScoreDat->fTotalTime); 
			fTime += fGap;
			fSTime += fGap;
			if (fSTime >= ScoreDat->fLoopEnd )
				fSTime = ScoreDat->fLoopStart;
		}
	}
	fprintf(scorefile, "\n\n%c\n", 'e');
	fclose(scorefile);
}
