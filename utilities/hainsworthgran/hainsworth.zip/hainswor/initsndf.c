/* InitSndFileTable.c  by David W. Hainsworth */

extern float *TableSet3( char *, int * );
extern float *ProbabilityTable( float *, int );

float *InitSndFileTable( char *szFileName )
{
	float *buf;
	float *pTable;
	int iNumItems = 0;
	int iHalfNumItems;

	/* Initialize Probability Table with TableSet (in file tablset3).  */
	buf = TableSet3( szFileName, &iNumItems );

	iHalfNumItems = iNumItems/2;

	pTable = ProbabilityTable( buf, iHalfNumItems );

	return pTable;
}

