/* Adapted from Csound source code by David W. Hainsworth */


void vGen7_2(float fArray[], float p[])
{
int seglen;
int nsegs = 5;
float *valp, *fp, *finp;
float amp1, incr;
valp = p;
fp = fArray;
finp = fp + 63;  	/* 63 is (1 - table length)  */

	do {   	amp1 = *valp++;
		if (!(seglen = *valp++)) 
			continue;
		incr = (*valp - amp1) / seglen;
		while (seglen--)
		{
			*fp++ = amp1;
			amp1 += incr;
		}
	}while (--nsegs);
  }

