float fGetPchFac4(float fRan, float fArray[], float fTime, float fTotalTime, float 	fRandFactor[])
{
    	float fIndex, frac, fx, fRanX ;
    	int index, next ;
    	int iDur = fTotalTime; 

    	fRan = (fRan*2)-1;    /* Random number now between -1 and 1 */
    	fIndex = fTime/iDur * 63. ;
    	index = fIndex ;
    	next = index + 1;
    	frac = fIndex - (int)fIndex;

    	fRanX = fRandFactor[index] + (fRandFactor[next] - fRandFactor[index]) * frac;
    	fRanX = fRan*fRanX;          /* moving range of random deviation */

    	fx = fArray[index] + (fArray[next] - fArray[index]) * frac; 
    	fx = fx+fRanX;       /* adds moving random deviation factor fRanX 
				to fx (pch)  */

    	return fx;
}

