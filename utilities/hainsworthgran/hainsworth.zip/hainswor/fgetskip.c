/* fGetSkipTime3.C	by David Hainsworth		May 11 1996  */

float fGetSkipTime3(float fArraySkipTime[], float fTime, float fTotalTime)
{
	float fIndex, frac, fSkipTime ;      /* initialize variables */
	int index, next ;
	int idur = fTotalTime ;

	fIndex = fTime/idur * 64. ;	/* Calculate index for   */ 
	 index  = fIndex ;		/* SkipTime Pointer.     */
	next   = index + 1;
	frac   = fIndex - (int)fIndex;
	/* Calculate SkipTime Pointer */
	fSkipTime = fArraySkipTime[index] + (fArraySkipTime[next] - 					fArraySkipTime[index]) * frac;

	return fSkipTime;
}
