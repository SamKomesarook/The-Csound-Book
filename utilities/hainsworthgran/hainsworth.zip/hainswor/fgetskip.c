/*	fGetSkipTime.C	by David Hainsworth		*/

float fGetSkipTime(float fRan, int iSoundNum, int isoundins[], float fsoundinDur[])
{
	float fTotalTime;
	float fSkipTime;

	if( iSoundNum == isoundins[0] )
		fTotalTime = fsoundinDur[0];

	if( iSoundNum == isoundins[1] )
		fTotalTime = fsoundinDur[1];

	if( iSoundNum == isoundins[2] )
		fTotalTime = fsoundinDur[2];

	fSkipTime = (fTotalTime - 1) * fRan;

	return fSkipTime;		
 }	
