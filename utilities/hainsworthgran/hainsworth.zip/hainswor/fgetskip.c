/* fGetSkipTime2.C    by David Hainsworth    May 11 1996  */

float fGetSkipTime2(float fRan, float fLoopStart, float fLoopEnd)
{

	float fLoopDur, fSkipTime;

	fLoopDur = fLoopEnd - fLoopStart;

	fSkipTime = (fLoopDur*fRan) + fLoopStart;

	return fSkipTime;
}
