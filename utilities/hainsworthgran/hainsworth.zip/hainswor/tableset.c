/*   TableSet3.c by David Hainsworth with help from Russell Pinkston   */

#include <sys/types.h>
#include <stdio.h>
#include <malloc.h>

float *TableSet3( char *szFN, int *iNumItems )
{
	int count;
	FILE *f;
	float *buffer;

	if ((f = fopen(szFN, "r")) == NULL)  /* Open file (szFN) */
	{
		printf("Can't open ProbTable file.\n");
		exit(-1);
	}

	fscanf( f, "%d", iNumItems );		/* scan first item which contains
						the number of items remaining
						in the data file (szFN)  */

	buffer = malloc( *iNumItems * sizeof(float) );	/* malloc space for
								iNumItems floats */

	for( count = 0; count < *iNumItems; count++ )
		fscanf( f, "%f", &buffer[count] );	/* Read rest of szFN 
							into buffer. */
	fclose( f );

	return buffer;
}
