#include <stdio.h>
#include "RythGranTest.h"

void DataIn( struct INPUTDATA *InData, struct SCOREDATA *ScoreDat, char DataFileName[] ) 
{

	FILE *datafile;

	if ((datafile = fopen(DataFileName, "r")) == NULL)
	{
		printf("Enter the name of an existing data file as the third\n");
		printf("argument on the command line.\n");
		exit(-1);
	}

	/* Scan in Data from Datafile */
	fscanf(datafile, "%ld%*s %f%*s %f%*s 
		%f%f%f%f%f%f%f%f%f%f%f%*s 	
		%f%f%f%f%f%f%f%f%f%f%f%*s 
		%f%f%f%f%f%f%f%f%f%f%f%*s 
		%f%*s %d%*s%s%*s %d%d%d%d%d%d%d%d%*s",  

		&ScoreDat->lSeed, &ScoreDat->fTotalTime, &ScoreDat->fQuarterNote,

		&InData->fGapTime[0], &InData->fGapTime[1], &InData->fGapTime[2], 
		&InData->fGapTime[3], &InData->fGapTime[4], &InData->fGapTime[5], 
		&InData->fGapTime[6], &InData->fGapTime[7], &InData->fGapTime[8], 
		&InData->fGapTime[9], &InData->fGapTime[10],

		&InData->p[0], &InData->p[1], &InData->p[2], &InData->p[3], 
		&InData->p[4], &InData->p[5], &InData->p[6], &InData->p[7], 
		&InData->p[8], &InData->p[9], &InData->p[10], 

		&InData->GrainLen[0], &InData->GrainLen[1], &InData->GrainLen[2], 
		&InData->GrainLen[3], &InData->GrainLen[4], &InData->GrainLen[5], 
		&InData->GrainLen[6], &InData->GrainLen[7], &InData->GrainLen[8], 
		&InData->GrainLen[9], &InData->GrainLen[10],

		&ScoreDat->fDurFac, &ScoreDat->iFileNumFlag, 
		&ScoreDat->szPchTablFileName,

		&ScoreDat->iSoundins[0], &ScoreDat->iSoundins[1], 
		&ScoreDat->iSoundins[2], &ScoreDat->iSoundins[3], 
		&ScoreDat->iSoundins[4], &ScoreDat->iSoundins[5], 
		&ScoreDat->iSoundins[6], &ScoreDat->iSoundins[7]); 

	fscanf(datafile, "%f %f %f %f %f %f %f %f %f %f %f %*s", 
		&InData->fPitchRandom[0], &InData->fPitchRandom[1], 
		&InData->fPitchRandom[2], &InData->fPitchRandom[3], 
		&InData->fPitchRandom[4], &InData->fPitchRandom[5], 
		&InData->fPitchRandom[6], &InData->fPitchRandom[7], 
		&InData->fPitchRandom[8], &InData->fPitchRandom[9], 
		&InData->fPitchRandom[10]);

	fscanf(datafile, "%f %f %f %f %f %f %f %f %f %f %f %*s   
		%f %f %f %f %f %f %f %f %f %f %f %*s  %f %*s 
		%f %*s  %f %f %f %f %f %f %f %f %f %f %f %*s   
		%f %f %f %f %f %f %f %f %f %f %f %*s",

		&InData->fRanPchDev[0], &InData->fRanPchDev[1], 
		&InData->fRanPchDev[2], &InData->fRanPchDev[3], 
		&InData->fRanPchDev[4], &InData->fRanPchDev[5], 
		&InData->fRanPchDev[6], &InData->fRanPchDev[7], 
		&InData->fRanPchDev[8], &InData->fRanPchDev[9], 
		&InData->fRanPchDev[10],

		&InData->PchFact[0], &InData->PchFact[1], &InData->PchFact[2], 
		&InData->PchFact[3], &InData->PchFact[4], &InData->PchFact[5], 
		&InData->PchFact[6], &InData->PchFact[7], &InData->PchFact[8],
		&InData->PchFact[9], &InData->PchFact[10], 

		&ScoreDat->fGain, &ScoreDat->fInitGain,

		&InData->fEnvel[0], &InData->fEnvel[1], &InData->fEnvel[2], 
		&InData->fEnvel[3], &InData->fEnvel[4], &InData->fEnvel[5], 
		&InData->fEnvel[6], &InData->fEnvel[7], &InData->fEnvel[8], 
		&InData->fEnvel[9], &InData->fEnvel[10],

		&InData->fSndFile[0], &InData->fSndFile[1], &InData->fSndFile[2], 
		&InData->fSndFile[3], &InData->fSndFile[4], &InData->fSndFile[5], 
		&InData->fSndFile[6], &InData->fSndFile[7], &InData->fSndFile[8], 
		&InData->fSndFile[9], &InData->fSndFile[10]);

	fscanf(datafile, "%d %*s", &ScoreDat->iPanFlag);

	fscanf(datafile, "%f %f %f %f %f %f %f %f %f %f %f %*s", 
		&InData->Panner[0], &InData->Panner[1], &InData->Panner[2], 
		&InData->Panner[3], &InData->Panner[4], &InData->Panner[5], 
		&InData->Panner[6], &InData->Panner[7], &InData->Panner[8], 
		&InData->Panner[9], &InData->Panner[10]);

	fscanf(datafile, "%f %f %f %f %f %f %f %f %f %f %f %*s", 
		&InData->fPanWidth[0], &InData->fPanWidth[1], 
		&InData->fPanWidth[2], &InData->fPanWidth[3], 
		&InData->fPanWidth[4], &InData->fPanWidth[5], 
		&InData->fPanWidth[6], &InData->fPanWidth[7], 
		&InData->fPanWidth[8], &InData->fPanWidth[9], 
		&InData->fPanWidth[10]);

	fscanf(datafile, "%d %*s", &ScoreDat->iSkipFlag);
	fscanf(datafile, "%f %f %*s", &ScoreDat->fLoopStart, &ScoreDat->fLoopEnd);
	fscanf(datafile, "%f %f %f %f %f %f %f %f %f %f %f %*s",
		&InData->fSkipPointer[0], &InData->fSkipPointer[1],
		&InData->fSkipPointer[2], &InData->fSkipPointer[3],
		&InData->fSkipPointer[4], &InData->fSkipPointer[5],
		&InData->fSkipPointer[6], &InData->fSkipPointer[7],
		&InData->fSkipPointer[8], &InData->fSkipPointer[9],
		&InData->fSkipPointer[10]);

	fclose(datafile);

 }
