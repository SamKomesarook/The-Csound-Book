
float fillTable (float fArray[], float fTime, int idur)
{
	float fIndex, frac, fx ;
	int index, next ;

	 fIndex = fTime/idur * 63. ;
	index = fIndex ;
	next = index + 1;
	frac = fIndex - (int)fIndex;
	fx = fArray[index] + (fArray[next] - fArray [index]) * frac;

	return fx;
}

