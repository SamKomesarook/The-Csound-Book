float fGetNextDur2(float fArray[], float fTime, float fTotalTime, float fDurFac)
{
	float fIndex, frac, fx ;
	int index, next ;
	int idur = fTotalTime;

	fIndex = fTime/idur * 63. ;
	index = fIndex ;
	next = index + 1;
	frac = fIndex - (int)fIndex;

	fx = fArray[index] + (fArray[next] - fArray [index]) * frac;

	return fx*fDurFac;
}

